﻿<#
.SYNOPSIS
  Extract and validate a PFX for Polarion Linux/Apache HTTPS.
.NOTES
  Compatible with Windows PowerShell 5.1 and PowerShell 7+.
  The generated polarion-server.key is unencrypted for unattended Apache startup.
#>
[CmdletBinding()]
param(
    [string]$PfxPath = 'D:\cert\Polarioncert.pfx',
    [string]$OutputDirectory = 'D:\cert\Extracted',
    [string]$OpenSslPath = 'D:\Polarion\bundled\apache\bin\openssl.exe',
    [string[]]$RequiredDnsName = @(),
    [switch]$Force,
    [switch]$KeepTemporaryFiles
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:Failed = $false
$script:UseLegacy = $false
$script:LogLines = New-Object System.Collections.Generic.List[string]

function Write-Log {
    param([string]$Message, [ValidateSet('INFO','OK','WARN','ERROR')][string]$Level = 'INFO')
    $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    $script:LogLines.Add($line)
    $color = switch ($Level) { 'OK' {'Green'} 'WARN' {'Yellow'} 'ERROR' {'Red'} default {'Cyan'} }
    Write-Host $line -ForegroundColor $color
}

function Convert-SecureToPlain {
    param([Security.SecureString]$Secure)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Invoke-OpenSSL {
    param(
        [string[]]$Arguments,
        [string]$Password,
        [switch]$AllowFailure,
        [switch]$Quiet
    )
    if (-not $Quiet) { Write-Log ('OpenSSL: ' + ($Arguments -join ' ')) }
    $oldPassword = $env:POLARION_PFX_PASSWORD
    $oldErrorActionPreference = $ErrorActionPreference
    try {
        if ($PSBoundParameters.ContainsKey('Password')) {
            $env:POLARION_PFX_PASSWORD = $Password
        }

        # OpenSSL writes normal informational output (for example, MAC details)
        # to STDERR. With global ErrorActionPreference=Stop, Windows PowerShell 5.1
        # can incorrectly turn that successful STDERR output into a terminating error.
        # Temporarily use Continue and determine success only from the native exit code.
        $ErrorActionPreference = 'Continue'
        $output = & $script:OpenSSL @Arguments 2>&1 | ForEach-Object { $_.ToString() }
        $code = $LASTEXITCODE
        $text = $output -join [Environment]::NewLine

        if (($code -ne 0) -and (-not $AllowFailure)) {
            throw "OpenSSL exited with code $code. $text"
        }

        return [PSCustomObject]@{
            ExitCode = $code
            Output   = $text
        }
    }
    finally {
        $ErrorActionPreference = $oldErrorActionPreference
        if ($null -eq $oldPassword) {
            Remove-Item Env:\POLARION_PFX_PASSWORD -ErrorAction SilentlyContinue
        }
        else {
            $env:POLARION_PFX_PASSWORD = $oldPassword
        }
    }
}

function Write-Ascii {
    param([string]$Path, [string]$Content)
    [IO.File]::WriteAllText($Path, $Content, [Text.Encoding]::ASCII)
}

function Get-PemBlocks {
    param([string]$Path)
    $content = Get-Content -LiteralPath $Path -Raw
    $pattern = '(?s)-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----'
    $found = Select-String -InputObject $content -Pattern $pattern -AllMatches
    $blocks = @()
    if ($null -ne $found) {
        foreach ($m in $found.Matches) { $blocks += ($m.Value.Trim() + [Environment]::NewLine) }
    }
    return $blocks
}

function Get-CertInfo {
    param([string]$Path)
    $basic = Invoke-OpenSSL -Arguments @('x509','-in',$Path,'-noout','-subject','-issuer') -Quiet
    $text = (Invoke-OpenSSL -Arguments @('x509','-in',$Path,'-noout','-text') -Quiet).Output
    $subject = (($basic.Output -split '\r?\n' | Where-Object { $_ -match '^subject=' } | Select-Object -First 1) -replace '^subject=\s*','').Trim()
    $issuer = (($basic.Output -split '\r?\n' | Where-Object { $_ -match '^issuer=' } | Select-Object -First 1) -replace '^issuer=\s*','').Trim()
    [PSCustomObject]@{
        Path = $Path
        Subject = $subject
        Issuer = $issuer
        IsCA = ($text -match 'CA:TRUE')
        IsSelfIssued = ($subject -eq $issuer)
    }
}

function Test-DnsMatch {
    param([string]$Pattern, [string]$Name)
    $p = $Pattern.Trim().ToLowerInvariant()
    $n = $Name.Trim().ToLowerInvariant()
    if ($p -eq $n) { return $true }
    if ($p.StartsWith('*.')) {
        $suffix = $p.Substring(1)
        if (-not $n.EndsWith($suffix)) { return $false }
        $prefix = $n.Substring(0, $n.Length - $suffix.Length)
        return (($prefix.Length -gt 0) -and (-not $prefix.Contains('.')))
    }
    return $false
}

try {
    Write-Log 'Starting Polarion PFX extraction.'
    if (-not (Test-Path -LiteralPath $PfxPath -PathType Leaf)) { throw "PFX not found: $PfxPath" }
    if (-not (Test-Path -LiteralPath $OpenSslPath -PathType Leaf)) { throw "OpenSSL not found: $OpenSslPath" }

    $script:OpenSSL = (Resolve-Path -LiteralPath $OpenSslPath).Path
    $PfxPath = (Resolve-Path -LiteralPath $PfxPath).Path
    $OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
    $version = (& $script:OpenSSL version 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0) { throw "OpenSSL could not run: $OpenSslPath" }
    Write-Log "Using $version" 'OK'

    if (Test-Path -LiteralPath $OutputDirectory) {
        $items = @(Get-ChildItem -LiteralPath $OutputDirectory -Force -ErrorAction SilentlyContinue)
        if (($items.Count -gt 0) -and (-not $Force)) { throw "Output folder is not empty. Re-run with -Force: $OutputDirectory" }
        if ($Force) { Remove-Item -LiteralPath $OutputDirectory -Recurse -Force }
    }
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $temp = Join-Path $OutputDirectory '_temporary'
    New-Item -ItemType Directory -Path $temp -Force | Out-Null

    $securePassword = Read-Host 'Enter the PFX password' -AsSecureString
    $plainPassword = Convert-SecureToPlain $securePassword
    $passArgs = @('-passin','env:POLARION_PFX_PASSWORD')

    $inspect = Invoke-OpenSSL -Arguments (@('pkcs12','-in',$PfxPath,'-info','-noout') + $passArgs) -Password $plainPassword -AllowFailure
    if (($inspect.ExitCode -ne 0) -and ($inspect.Output -match 'unsupported|RC2|legacy provider|inner_evp_generic_fetch')) {
        Write-Log 'Legacy PKCS#12 algorithm detected; retrying with -legacy.' 'WARN'
        $script:UseLegacy = $true
        $inspect = Invoke-OpenSSL -Arguments (@('pkcs12','-legacy','-in',$PfxPath,'-info','-noout') + $passArgs) -Password $plainPassword -AllowFailure
    }
    if ($inspect.ExitCode -ne 0) { throw "PFX validation failed. Check password/integrity. $($inspect.Output)" }
    Write-Log "PFX validation succeeded. Legacy mode: $($script:UseLegacy)" 'OK'

    $legacy = if ($script:UseLegacy) { @('-legacy') } else { @() }
    $leafRaw = Join-Path $temp 'leaf.pem'
    $keyRaw = Join-Path $temp 'key.pem'
    $caRaw = Join-Path $temp 'ca.pem'
    $serverCert = Join-Path $OutputDirectory 'polarion-server.crt'
    $serverKey = Join-Path $OutputDirectory 'polarion-server.key'

    Invoke-OpenSSL -Arguments (@('pkcs12') + $legacy + @('-in',$PfxPath,'-clcerts','-nokeys','-out',$leafRaw) + $passArgs) -Password $plainPassword | Out-Null
    $leafBlocks = @(Get-PemBlocks $leafRaw)
    if ($leafBlocks.Count -lt 1) { throw 'No server certificate found in PFX.' }
    Write-Ascii $serverCert $leafBlocks[0]

    $keyResult = Invoke-OpenSSL -Arguments (@('pkcs12') + $legacy + @('-in',$PfxPath,'-nocerts','-noenc','-out',$keyRaw) + $passArgs) -Password $plainPassword -AllowFailure
    if (($keyResult.ExitCode -ne 0) -and ($keyResult.Output -match 'Unknown option|unrecognized option')) {
        Write-Log 'Retrying private-key extraction with -nodes.' 'WARN'
        Invoke-OpenSSL -Arguments (@('pkcs12') + $legacy + @('-in',$PfxPath,'-nocerts','-nodes','-out',$keyRaw) + $passArgs) -Password $plainPassword | Out-Null
    } elseif ($keyResult.ExitCode -ne 0) { throw "Private-key extraction failed. $($keyResult.Output)" }
    Invoke-OpenSSL -Arguments @('pkey','-in',$keyRaw,'-out',$serverKey) | Out-Null
    Invoke-OpenSSL -Arguments @('pkey','-in',$serverKey,'-check','-noout') | Out-Null

    Invoke-OpenSSL -Arguments (@('pkcs12') + $legacy + @('-in',$PfxPath,'-cacerts','-nokeys','-out',$caRaw) + $passArgs) -Password $plainPassword | Out-Null
    $caBlocks = @(Get-PemBlocks $caRaw)
    if ($caBlocks.Count -lt 1) { throw 'No CA certificates found in PFX.' }

    $allCa = @()
    for ($i=0; $i -lt $caBlocks.Count; $i++) {
        $p = Join-Path $temp ('ca-{0}.crt' -f ($i+1))
        Write-Ascii $p $caBlocks[$i]
        $allCa += Get-CertInfo $p
    }
    $roots = @($allCa | Where-Object { $_.IsCA -and $_.IsSelfIssued })
    $intermediates = @($allCa | Where-Object { $_.IsCA -and (-not $_.IsSelfIssued) })
    if ($roots.Count -eq 0) { Write-Log 'No self-issued root was included in the PFX.' 'WARN' }

    $serverInfo = Get-CertInfo $serverCert
    $ordered = New-Object System.Collections.ArrayList
    $remaining = New-Object System.Collections.ArrayList
    foreach ($c in $intermediates) { [void]$remaining.Add($c) }
    $issuer = $serverInfo.Issuer
    while ($remaining.Count -gt 0) {
        $next = $remaining | Where-Object { $_.Subject -eq $issuer } | Select-Object -First 1
        if ($null -eq $next) { break }
        [void]$ordered.Add($next); [void]$remaining.Remove($next); $issuer = $next.Issuer
    }
    foreach ($c in $remaining) { [void]$ordered.Add($c); Write-Log "Appending unlinked intermediate: $($c.Subject)" 'WARN' }

    $intDir = Join-Path $OutputDirectory 'Intermediates'
    $rootDir = Join-Path $OutputDirectory 'Roots'
    New-Item -ItemType Directory -Path $intDir,$rootDir -Force | Out-Null
    $intPaths = @(); $rootPaths = @()
    for ($i=0; $i -lt $ordered.Count; $i++) {
        $dest = Join-Path $intDir ('intermediate-{0}.crt' -f ($i+1)); Copy-Item $ordered[$i].Path $dest -Force; $intPaths += $dest
        Write-Log "Intermediate: $($ordered[$i].Subject)"
    }
    for ($i=0; $i -lt $roots.Count; $i++) {
        $dest = Join-Path $rootDir ('root-{0}.crt' -f ($i+1)); Copy-Item $roots[$i].Path $dest -Force; $rootPaths += $dest
        Write-Log "Root: $($roots[$i].Subject)"
    }
    if ($intPaths.Count -eq 1) { Copy-Item $intPaths[0] (Join-Path $OutputDirectory 'bw-intermediate-1.crt') -Force }
    if ($rootPaths.Count -eq 1) { Copy-Item $rootPaths[0] (Join-Path $OutputDirectory 'bw-enterprise-root.crt') -Force }

    $fullchain = Join-Path $OutputDirectory 'polarion-fullchain.pem'
    $fullParts = @((Get-Content $serverCert -Raw).Trim())
    foreach ($p in $intPaths) { $fullParts += (Get-Content $p -Raw).Trim() }
    Write-Ascii $fullchain (($fullParts -join [Environment]::NewLine) + [Environment]::NewLine)

    $caBundle = Join-Path $OutputDirectory 'bw-ca-bundle.crt'
    $bundleParts = @()
    foreach ($p in $intPaths) { $bundleParts += (Get-Content $p -Raw).Trim() }
    foreach ($p in $rootPaths) { $bundleParts += (Get-Content $p -Raw).Trim() }
    if ($bundleParts.Count -gt 0) { Write-Ascii $caBundle (($bundleParts -join [Environment]::NewLine) + [Environment]::NewLine) }

    Invoke-OpenSSL -Arguments @('x509','-in',$serverCert,'-noout','-checkend','0') | Out-Null
    $eku = Invoke-OpenSSL -Arguments @('x509','-in',$serverCert,'-noout','-ext','extendedKeyUsage') -AllowFailure -Quiet
    if ($eku.Output -match 'TLS Web Server Authentication|serverAuth') { Write-Log 'Server Authentication EKU detected.' 'OK' } else { Write-Log 'Server Authentication EKU not detected.' 'WARN' }

    $san = Invoke-OpenSSL -Arguments @('x509','-in',$serverCert,'-noout','-ext','subjectAltName') -AllowFailure -Quiet
    $dnsNames = @()
    if ($san.ExitCode -eq 0) {
        $matches = Select-String -InputObject $san.Output -Pattern 'DNS:([^,\s]+)' -AllMatches
        foreach ($m in $matches.Matches) { $dnsNames += $m.Groups[1].Value }
    }
    Write-Log ('DNS SAN entries: ' + ($dnsNames -join ', '))
    foreach ($name in $RequiredDnsName) {
        $covered = $false
        foreach ($pattern in $dnsNames) { if (Test-DnsMatch $pattern $name) { $covered = $true; break } }
        if ($covered) { Write-Log "DNS covered: $name" 'OK' } else { Write-Log "DNS NOT covered: $name" 'ERROR' }
    }

    $certPub = Join-Path $temp 'cert-pub.pem'; $certDer = Join-Path $temp 'cert-pub.der'; $keyDer = Join-Path $temp 'key-pub.der'
    Invoke-OpenSSL -Arguments @('x509','-in',$serverCert,'-pubkey','-noout','-out',$certPub) | Out-Null
    Invoke-OpenSSL -Arguments @('pkey','-pubin','-in',$certPub,'-outform','DER','-out',$certDer) | Out-Null
    Invoke-OpenSSL -Arguments @('pkey','-in',$serverKey,'-pubout','-outform','DER','-out',$keyDer) | Out-Null
    if ((Get-FileHash $certDer -Algorithm SHA256).Hash -ne (Get-FileHash $keyDer -Algorithm SHA256).Hash) { throw 'Certificate/private-key mismatch.' }
    Write-Log 'Certificate and private key match.' 'OK'

    if ($rootPaths.Count -gt 0) {
        $rootBundle = Join-Path $temp 'roots.crt'
        Write-Ascii $rootBundle (((@($rootPaths | ForEach-Object { (Get-Content $_ -Raw).Trim() })) -join [Environment]::NewLine) + [Environment]::NewLine)
        $verify = @('verify','-CAfile',$rootBundle)
        if ($intPaths.Count -gt 0) {
            $intBundle = Join-Path $temp 'intermediates.crt'
            Write-Ascii $intBundle (((@($intPaths | ForEach-Object { (Get-Content $_ -Raw).Trim() })) -join [Environment]::NewLine) + [Environment]::NewLine)
            $verify += @('-untrusted',$intBundle)
        }
        $verify += $serverCert
        Invoke-OpenSSL -Arguments $verify | Out-Null
        Write-Log 'Certificate chain verified.' 'OK'
    }

    $apache = @'
# Modern Apache 2.4.8+
SSLCertificateFile "/etc/polarion/ssl/polarion-fullchain.pem"
SSLCertificateKeyFile "/etc/polarion/ssl/polarion-server.key"

# Legacy alternative (do not enable together with the modern model)
#SSLCertificateFile "/etc/polarion/ssl/polarion-server.crt"
#SSLCertificateKeyFile "/etc/polarion/ssl/polarion-server.key"
#SSLCertificateChainFile "/etc/polarion/ssl/Intermediates/intermediate-1.crt"

# Only for client-certificate validation/mTLS
#SSLCACertificateFile "/etc/polarion/ssl/bw-ca-bundle.crt"
'@
    Write-Ascii (Join-Path $OutputDirectory 'apache-ssl-reference.conf') $apache

    $manifest = @()
    Get-ChildItem $OutputDirectory -File -Recurse | Where-Object { $_.Name -notin @('SHA256SUMS.txt','extraction-report.txt') } | ForEach-Object {
        $relative = $_.FullName.Substring($OutputDirectory.Length).TrimStart('\')
        $manifest += ('{0}  {1}' -f ((Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()), $relative)
    }
    Write-Ascii (Join-Path $OutputDirectory 'SHA256SUMS.txt') (($manifest -join [Environment]::NewLine) + [Environment]::NewLine)
    Write-Log 'Extraction and validation completed successfully.' 'OK'
    Write-Log 'polarion-server.key is unencrypted; secure it and use chmod 600 on Linux.' 'WARN'
}
catch {
    $script:Failed = $true
    Write-Log $_.Exception.Message 'ERROR'
    Write-Log 'Do not deploy partially generated files.' 'ERROR'
}
finally {
    Remove-Item Env:\POLARION_PFX_PASSWORD -ErrorAction SilentlyContinue
    if ($null -ne (Get-Variable securePassword -ErrorAction SilentlyContinue) -and $null -ne $securePassword) { $securePassword.Dispose() }
    $plainPassword = $null
    if (($null -ne (Get-Variable temp -ErrorAction SilentlyContinue)) -and (Test-Path $temp) -and (-not $KeepTemporaryFiles)) { Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
    if (($null -ne (Get-Variable OutputDirectory -ErrorAction SilentlyContinue)) -and (Test-Path $OutputDirectory)) {
        [IO.File]::WriteAllLines((Join-Path $OutputDirectory 'extraction-report.txt'), $script:LogLines, [Text.Encoding]::UTF8)
    }
}
if ($script:Failed) { exit 1 } else { exit 0 }
