﻿[CmdletBinding()]
param(
    [string[]]$RequiredDnsName = @(),
    [switch]$Force,
    [switch]$KeepTemporaryFiles
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$PfxFile = 'D:\cert\Polarioncert.pfx'
$OutputDirectory = 'D:\cert\Extracted'
$OpenSslPath = 'D:\Polarion\bundled\apache\bin\openssl.exe'
$MainScript = Join-Path $PSScriptRoot 'Extract-PolarionPfx.ps1'

foreach ($item in @($PfxFile,$OpenSslPath,$MainScript)) {
    if (-not (Test-Path -LiteralPath $item -PathType Leaf)) { throw "Required file not found: $item" }
}

Write-Host "PFX:     $PfxFile" -ForegroundColor Cyan
Write-Host "Output:  $OutputDirectory" -ForegroundColor Cyan
Write-Host "OpenSSL: $OpenSslPath" -ForegroundColor Cyan

$params = @{
    PfxPath = $PfxFile
    OutputDirectory = $OutputDirectory
    OpenSslPath = $OpenSslPath
    RequiredDnsName = $RequiredDnsName
    Force = $Force
    KeepTemporaryFiles = $KeepTemporaryFiles
}
& $MainScript @params
exit $LASTEXITCODE
