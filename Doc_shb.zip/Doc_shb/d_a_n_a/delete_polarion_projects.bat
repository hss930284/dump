

@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ====== CONFIG ======
set "POLARION_URL=https://hnjhyvdi05.tatatechnologies.com/"
set "BEARER_TOKEN=eyJraWQiOiI4YmRjOWNkNS1hYzFjMDI1My00OWY1NDg2Ni1hZjhjZGVmMyIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhZG1pbiIsImlkIjoiODRjM2MwZDktYWMxYzAyNTMtMjc2ZmQxNzMtMWI1MzJlYzMiLCJleHAiOjE3NTkzNDM0MDAsImlhdCI6MTc1ODg2OTA0NX0.pJM25nqusBYR-9BnFC_O9UIlon1sURconuNj9FzRh4LZLpNPe1pikg3GczpfwNg3NJzH4HszWPLYP-qDIrGhczTP8cAnQT7CbmjHb8xFTGjQfMJFTJOaSvHk_9zRaYJucPL-_ADpnV26gLmG8Z8vTq3osJPbtVp0Djeyz6Bb2D4BKwiqpoY38wCkCsEGi8WwURIpojUAdFYdTr_HCLTwtjLlTZX2RwPyPoLPtcFfvbHeQHMySFKHCaycG76BwBsW5mMjeLCSlvDVFyGXvz47KCJWEE7a5_nGMm37ie3AT-vnY5248z46Crjpjsa2t941PLlqmXv4zlAtWGRGezIsdg"
set "INPUT_FILE=projects_to_delete.txt"
set "LOG=delete_projects.log"
set "DRY_RUN=0"   rem set to 1 for dry-run (no deletions)
rem ===============

if not exist "%INPUT_FILE%" (
    echo [ERROR] Input file "%INPUT_FILE%" not found.
    exit /b 1
)

echo ==== %DATE% %TIME% : Delete Projects started ==== >> "%LOG%"

for /f "usebackq delims= tokens=*" %%a in ("%INPUT_FILE%") do (
    set "LINE=%%a"
    rem Skip empty lines and lines starting with # or ;
    if not "!LINE!"=="" if /i not "!LINE:~0,1!"=="#" if /i not "!LINE:~0,1!"==";" (
        set "PROJECT=!LINE!"
        echo Deleting project: !PROJECT!

        if "!DRY_RUN!"=="1" (
            echo [DRY-RUN] Would delete: !PROJECT!
            echo %DATE% %TIME% [DRY-RUN] Would delete: !PROJECT! >> "%LOG%"
        ) else (
            rem Call curl and capture only the HTTP status code
            for /f %%h in ('
                curl -sS -o NUL -w "%%{http_code}" ^
                    -X DELETE "!POLARION_URL!/polarion/rest/v1/projects/!PROJECT!" ^
                    -H "Authorization: Bearer !BEARER_TOKEN!" ^
                    -H "Accept: application/json"
            ') do set "STATUS=%%h"

            if "!STATUS!"=="204" (
                echo [OK 204] Deleted !PROJECT!
                echo %DATE% %TIME% [OK 204] !PROJECT! >> "%LOG%"
            ) else if "!STATUS!"=="200" (
                echo [OK 200] Deleted !PROJECT!
                echo %DATE% %TIME% [OK 200] !PROJECT! >> "%LOG%"
            ) else (
                rem Rerun capturing response body for diagnostics
                set "TMPRESP=%TEMP%\polarion_delete_!PROJECT!.json"
                curl -sS -X DELETE "!POLARION_URL!/polarion/rest/v1/projects/!PROJECT!" ^
                    -H "Authorization: Bearer !BEARER_TOKEN!" ^
                    -H "Accept: application/json" -o "!TMPRESP!" -w " HTTP=%%{http_code}" > "%TEMP%\status.tmp"
                set /p RESLINE=<"%TEMP%\status.tmp"
                del "%TEMP%\status.tmp" 2>nul

                echo [FAIL !STATUS!] !PROJECT!  %RESLINE%
                echo %DATE% %TIME% [FAIL !STATUS!] !PROJECT! %RESLINE% >> "%LOG%"
                echo Response saved to "!TMPRESP!" >> "%LOG%"
            )
        )
        echo.
    )
)

echo ==== %DATE% %TIME% : Script finished ==== >> "%LOG%"
echo Script finished. See "%LOG%" for details.
pause