@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ==========================================================
rem delete-polarion-projects.bat
rem Deletes Polarion projects listed in a text file.
rem Token is hardcoded below.
rem ==========================================================

set "INPUT=projects_to_delete.txt"
set "BASE_URL=https://hnjhyvdi05.tatatechnologies.com/polarion"
set "TOKEN=eyJraWQiOiI4YmRjOWNkNS1hYzFjMDI1My00OWY1NDg2Ni1hZjhjZGVmMyIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhZG1pbiIsImlkIjoiODRjM2MwZDktYWMxYzAyNTMtMjc2ZmQxNzMtMWI1MzJlYzMiLCJleHAiOjE3NTkzNDM0MDAsImlhdCI6MTc1ODg2OTA0NX0.pJM25nqusBYR-9BnFC_O9UIlon1sURconuNj9FzRh4LZLpNPe1pikg3GczpfwNg3NJzH4HszWPLYP-qDIrGhczTP8cAnQT7CbmjHb8xFTGjQfMJFTJOaSvHk_9zRaYJucPL-_ADpnV26gLmG8Z8vTq3osJPbtVp0Djeyz6Bb2D4BKwiqpoY38wCkCsEGi8WwURIpojUAdFYdTr_HCLTwtjLlTZX2RwPyPoLPtcFfvbHeQHMySFKHCaycG76BwBsW5mMjeLCSlvDVFyGXvz47KCJWEE7a5_nGMm37ie3AT-vnY5248z46Crjpjsa2t941PLlqmXv4zlAtWGRGezIsdg"

if not exist "%INPUT%" (
  echo [ERROR] Input file "%INPUT%" not found.
  exit /b 3
)

echo === Deleting Polarion projects listed in "%INPUT%" against %BASE_URL% ===

for /f "usebackq delims=" %%P in ("%INPUT%") do (
  set "ID=%%P"
  if not "!ID!"=="" if not "!ID:~0,1!"=="#" (
    call :trim ID
    if "!ID!"=="" goto :continue
    call :delete_one "!ID!"
  )
  :continue
)

echo Done.
exit /b 0

:delete_one
set "PID=%~1"
set "URL=%BASE_URL%/rest/v1/projects/%PID%"
echo [INFO] Deleting "!PID!" ...
for /f "delims=" %%S in ('
  curl -sS -o NUL -w "%%{http_code}" ^
    -X DELETE "%URL%" ^
    -H "accept: application/json" ^
    -H "Authorization: Bearer %TOKEN%"
') do set "CODE=%%S"

if "%CODE%"=="200" (
  echo [OK] 200 Deleted "!PID!"
) else if "%CODE%"=="204" (
  echo [OK] 204 No Content for "!PID!"
) else if "%CODE%"=="202" (
  echo [OK] 202 Accepted for "!PID!"
) else if "%CODE%"=="404" (
  echo [WARN] 404 Not Found for "!PID!"
) else if "%CODE%"=="401" (
  echo [ERROR] 401 Unauthorized (check token) for "!PID!"
) else if "%CODE%"=="403" (
  echo [ERROR] 403 Forbidden for "!PID!"
) else (
  echo [ERROR] %CODE% for "!PID!"
)
exit /b

:trim
setlocal EnableDelayedExpansion
set "s=!%~1!"
for /f "tokens=* delims= " %%a in ("!s!") do set "s=%%a"
:trimloop
if "!s:~-1!"==" " (set "s=!s:~0,-1!" & goto :trimloop)
endlocal & set "%~1=%s%"
exit /b