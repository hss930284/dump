@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ==========================================================
rem delete-polarion-projects.bat
rem Deletes Polarion projects listed in a text file.
rem Token is hardcoded below. Supports --dry-run.
rem ==========================================================

rem --------- Config (edit these) ---------
set "INPUT=projects_to_delete.txt"
set "BASE_URL=https://hnjhyvdi05.tatatechnologies.com/polarion"
set "TOKEN=eyJraWQiOiI4YmRjOWNkNS1hYzFjMDI1My00OWY1NDg2Ni1hZjhjZGVmMyIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhZG1pbiIsImlkIjoiODRjM2MwZDktYWMxYzAyNTMtMjc2ZmQxNzMtMWI1MzJlYzMiLCJleHAiOjE3NTkzNDM0MDAsImlhdCI6MTc1ODg2OTA0NX0.pJM25nqusBYR-9BnFC_O9UIlon1sURconuNj9FzRh4LZLpNPe1pikg3GczpfwNg3NJzH4HszWPLYP-qDIrGhczTP8cAnQT7CbmjHb8xFTGjQfMJFTJOaSvHk_9zRaYJucPL-_ADpnV26gLmG8Z8vTq3osJPbtVp0Djeyz6Bb2D4BKwiqpoY38wCkCsEGi8WwURIpojUAdFYdTr_HCLTwtjLlTZX2RwPyPoLPtcFfvbHeQHMySFKHCaycG76BwBsW5mMjeLCSlvDVFyGXvz47KCJWEE7a5_nGMm37ie3AT-vnY5248z46Crjpjsa2t941PLlqmXv4zlAtWGRGezIsdg"
rem If you use self-signed TLS in test only, set the next flag to 1 to add -k to curl
set "ALLOW_INSECURE=0"
rem --------------------------------------

rem --------- Parse optional args ---------
set "ARG1=%~1"
set "ARG2=%~2"
set "DRY_RUN=0"

if /I "%ARG1%"=="--dry-run" (
  set "DRY_RUN=1"
) else (
  if not "%ARG1%"=="" set "INPUT=%ARG1%"
  if /I "%ARG2%"=="--dry-run" set "DRY_RUN=1"
)

if not exist "%INPUT%" (
  echo [ERROR] Input file "%INPUT%" not found.
  echo Usage: %~nx0 [projects.txt] [--dry-run]
  exit /b 3
)

if "%TOKEN%"=="" (
  echo [ERROR] TOKEN is empty. Edit the script and set the TOKEN value.
  exit /b 2
)

if "%ALLOW_INSECURE%"=="1" (set "CURL_INSECURE=-k") else (set "CURL_INSECURE=")

echo === Deleting Polarion projects from "%INPUT%" against %BASE_URL% ===
if "%DRY_RUN%"=="1" (echo [MODE] DRY-RUN ^(no deletions will be performed^))

rem --------- Iterate lines ---------
for /f "usebackq delims=" %%P in ("%INPUT%") do (
  set "ID=%%P"
  rem Skip blanks and comment lines
  if not "!ID!"=="" if not "!ID:~0,1!"=="#" (
    call :trim ID
    if not "!ID!"=="" call :delete_one "!ID!"
  )
)

echo Done.
exit /b 0

rem --------- Subroutines ---------

:delete_one
set "PID=%~1"
set "URL=%BASE_URL%/rest/v1/projects/%PID%"

if "%DRY_RUN%"=="1" (
  echo [DRY-RUN] Would DELETE: %URL%
  exit /b
)

echo [INFO] Deleting "!PID!" ...
for /f "delims=" %%S in ('
  curl %CURL_INSECURE% -sS -o NUL -w "%%{http_code}" ^
    -X DELETE "%URL%" ^
    -H "accept: application/json" ^
    -H "Authorization: Bearer %TOKEN%"
') do set "CODE=%%S"

if "%CODE%"=="200" (
  echo [OK] 200 Deleted "!PID!"
) else if "%CODE%"=="204" (
  echo [OK] 204 No Content "!PID!"
) else if "%CODE%"=="202" (
  echo [OK] 202 Accepted "!PID!"
) else if "%CODE%"=="404" (
  echo [WARN] 404 Not Found "!PID!"
) else if "%CODE%"=="401" (
  echo [ERROR] 401 Unauthorized "!PID!" (check token/expiry)
) else if "%CODE%"=="403" (
  echo [ERROR] 403 Forbidden "!PID!" (insufficient rights)
) else (
  echo [ERROR] %CODE% for "!PID!"
)
exit /b

:trim
setlocal EnableDelayedExpansion
set "s=!%~1!"
for /f "tokens=* delims= " %%a in ("!s!") do set "s=%%a"
