@echo off
setlocal enabledelayedexpansion

:: Paths
set HTPASSWD_PATH=E:\Polarion\bundled\apache\bin\htpasswd.exe
set PASSWD_FILE=E:\Polarion\data\svn\passwd_credentials
set USER_LIST=users.txt

:: Check if htpasswd exists
if not exist "%HTPASSWD_PATH%" (
    echo htpasswd.exe not found at %HTPASSWD_PATH%
    exit /b 1
)

:: Check if user list exists
if not exist "%USER_LIST%" (
    echo User list file not found: %USER_LIST%
    exit /b 1
)

:: Loop through each line in users.txt
for /f "tokens=1,2 delims=:" %%A in (%USER_LIST%) do (
    set USER=%%A
    set PASS=%%B

    :: Add or update user
    "%HTPASSWD_PATH%" -b "%PASSWD_FILE%" !USER! !PASS!
    echo Updated user: !USER!
)

echo All users processed.
endlocal
pause