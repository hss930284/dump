Readme

1. Go to Document \& Pages
2. Go to any space Eg: Default Space
3. Create New LiveReport Page/Info Page
4. Open Widgets \& Add Script Block
5. Add the following Script Polarion\_ validation\_all\_details to fetch \& view all project details in Polarion under Script Block.
6. Click Apply
7. Check All the Project Details
