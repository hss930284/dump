**README**



1. Create a projects\_to\_delete.txt file with the list of project ids of Polarion that needs to be deleted(refer projects\_to\_delete.txt for reference)
2. Open Polarion Click on Setting> MyAccount >Personal Access Token
3. Create a Personal Access Token 
4. Copy the API Token and add it in the script polarion\_project\_delete.bat under *set "TOKEN=<API Token>"*
5. Add the polarion base url in the script polarion\_project\_delete.bat under *set "BASE\_URL=<polarion url>* (Eg: https://polarion.test/polarion)
6. Open cmd \& run/execute polarion\_project\_delete.bat
7. Check in the Polarion if the project mentioned in the list exists in the Polarion after script execution or not.
