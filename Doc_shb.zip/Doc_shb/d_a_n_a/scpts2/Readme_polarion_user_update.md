README



1. Copy the polarion\_user\_update.bat script at Polarion Server location.
2. Create a user.txt file with the username:password for the list of users whose credentials needs to be updated (local users) (check the example users.txt for reference)
3. Open the cmd \& Execute/run the script polarion\_user\_update.bat
