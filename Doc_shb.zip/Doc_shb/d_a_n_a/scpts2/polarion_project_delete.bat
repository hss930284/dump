@echo off
setlocal EnableExtensions EnableDelayedExpansion


set "INPUT=projects_to_delete.txt"
set "BASE_URL=<polarion url>"
set "TOKEN=<API Token>"

set "ALLOW_INSECURE=0"

set "THROTTLE=0"

set "ARG1=%~1"
set "ARG2=%~2"
set "DRY_RUN=1"

if /I "%ARG1%"=="--dry-run" (
  set "DRY_RUN=1"
) else (
  if not "%ARG1%"=="" set "INPUT=%ARG1%"
  if /I "%ARG2%"=="--dry-run" set "DRY_RUN=1"
)

if not exist "%INPUT%" (
  echo [ERROR] Input file "%INPUT%" not found.
  echo Usage: %~nx0 [projects.txt] [--dry-run]
  exit /b 3
)

if "%TOKEN%"=="" (
  echo [ERROR] TOKEN is empty. Edit the script and set the TOKEN value.
  exit /b 2
)

if "%ALLOW_INSECURE%"=="1" (set "CURL_INSECURE=-k") else (set "CURL_INSECURE=")

echo === Deleting Polarion projects from "%INPUT%" against %BASE_URL% ===
if "%DRY_RUN%"=="1" (echo [MODE] DRY-RUN ^(no deletions will be performed^))

for /f "usebackq delims=" %%P in ("%INPUT%") do (
  set "ID=%%P"

  if not "!ID!"=="" if not "!ID:~0,1!"=="#" (
    call :trim ID
    if not "!ID!"=="" call :delete_one "!ID!"
  )
)

echo Done.
exit /b 0



:delete_one
setlocal EnableDelayedExpansion
set "PID=%~1"
set "URL=%BASE_URL%/rest/v1/projects/%PID%"

if "%DRY_RUN%"=="1" (
  echo [DRY-RUN] Would DELETE: %URL%
  goto :after
)

echo [INFO] Deleting "!PID!" ...


set "CODE="
for /f "usebackq delims=" %%S in (`curl %CURL_INSECURE% --no-progress-meter -s -o NUL -w "%%{http_code}" ^
  -X DELETE "%URL%" ^
  -H "accept: application/json" ^
  -H "Authorization: Bearer %TOKEN%" 2^>NUL`) do (
  set "CODE=%%S"
)

set "CODE=!CODE: =!"
set "CODE=!CODE:~0,3!"

if "!CODE!"=="200" (
  echo [OK] 200 Deleted "!PID!"
) else if "!CODE!"=="204" (
  echo [OK] 204 No Content "!PID!"
) else if "!CODE!"=="202" (
  echo [OK] 202 Accepted "!PID!" ^(deletion queued asynchronously^)
) else if "!CODE!"=="404" (
  echo [WARN] 404 Not Found "!PID!"
) else if "!CODE!"=="401" (
  echo [ERROR] 401 Unauthorized "!PID!" ^(check token/expiry^)
) else if "!CODE!"=="403" (
  echo [ERROR] 403 Forbidden "!PID!" ^(insufficient rights^)
) else if "!CODE!"=="" (
  echo [ERROR] No HTTP code received for "!PID!" ^(network/TLS issue^)
) else (
  echo [ERROR] !CODE! for "!PID!"
)

:after
if %THROTTLE% GTR 0 timeout /t %THROTTLE% >NUL
endlocal & goto :eof

:trim
setlocal EnableDelayedExpansion
set "s=!%~1!"
for /f "tokens=* delims= " %%a in ("!s!") do set "s=%%a"
:trimloop
if "!s:~-1!"==" " (set "s=!s:~0,-1!" & goto :trimloop)
endlocal & set "%~1=%s%"
