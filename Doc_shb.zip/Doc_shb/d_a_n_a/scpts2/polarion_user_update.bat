@echo off
setlocal enabledelayedexpansion


set HTPASSWD_PATH=C:\Polarion\bundled\apache\bin\htpasswd.exe
set PASSWD_FILE=C:\Polarion\data\svn\passwd_credentials
set USER_LIST=users.txt


if not exist "%HTPASSWD_PATH%" (
    echo htpasswd.exe not found at %HTPASSWD_PATH%
    exit /b 1
)


if not exist "%USER_LIST%" (
    echo User list file not found: %USER_LIST%
    exit /b 1
)


for /f "tokens=1,2 delims=:" %%A in (%USER_LIST%) do (
    set USER=%%A
    set PASS=%%B

    
    "%HTPASSWD_PATH%" -b "%PASSWD_FILE%" !USER! !PASS!
    echo Updated user: !USER!
)

echo All users processed.
endlocal
pause