#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import csv
import json
import time
import logging
import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# =========================================================
# CONFIGURATION
# =========================================================

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 60
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_IDS = [48]

ATTACHMENT_ROOT_DIR = r"D:\SBM_ATTACHMENTS"

ONLY_DIRECT_FILES = True
SKIP_IF_FILENAME_ALREADY_ATTACHED = True

ATTACHMENT_DESCRIPTION = "Attachment migrated from SBM source folder."

PAGE_SIZE = 500

LOG_FILE = "cb_attachment_import.log"
RUN_LOCK_FILE = "cb_attachment_import.lock"

SUCCESS_CSV = "attachment_import_success.csv"
FAILED_CSV = "attachment_import_failed.csv"
NOT_FOUND_CSV = "attachment_folder_ids_not_found.csv"
SKIPPED_CSV = "attachment_import_skipped.csv"
DUPLICATE_MATCH_CSV = "attachment_duplicate_item_matches.csv"


# =========================================================
# TRACKER CONFIGURATION
# =========================================================

TRACKER_SEARCH_CONFIG = [
    {
        "logical_name": "Issue",
        "tracker_id": 294498,
        "tracker_name": "Issue",
        "sbm_field_name": "SBM Item Id",
    },
    {
        "logical_name": "Retex",
        "tracker_id": 294309,
        "tracker_name": "Retex",
        "sbm_field_name": "SBM Retex Id",
    },
    {
        "logical_name": "SDT",
        "tracker_id": 295425,
        "tracker_name": "A-EMS Specification",
        "sbm_field_name": "SBM SDT Id",
    },
    {
        "logical_name": "MDT",
        "tracker_id": 295368,
        "tracker_name": "A-EMS Module",
        "sbm_field_name": "SBM MDT Id",
    },
    {
        "logical_name": "Change Request",
        "tracker_id": 293926,
        "tracker_name": "Change Request",
        "sbm_field_name": "SBM CR Id",
    },
    {
        "logical_name": "Tag Management",
        "tracker_id": 293706,
        "tracker_name": "Tag Management",
        "sbm_field_name": "SBM Tag Id",
    },
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging() -> logging.Logger:
    logger_obj = logging.getLogger("cb_attachment_import")
    logger_obj.setLevel(logging.INFO)
    logger_obj.handlers.clear()

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    file_handler.setFormatter(formatter)

    logger_obj.addHandler(console_handler)
    logger_obj.addHandler(file_handler)

    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def normalize_sbm_id(value: Any) -> Optional[str]:
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    return re.sub(r"\s+", "", text).upper()


def safe_sleep() -> None:
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def get_project_ids_csv() -> str:
    valid_project_ids = []

    for project_id in PROJECT_IDS:
        if project_id is None:
            continue

        project_id_text = str(project_id).strip()

        if project_id_text:
            valid_project_ids.append(project_id_text)

    if not valid_project_ids:
        raise ValueError("PROJECT_IDS is empty. Please configure at least one project ID.")

    return ",".join(valid_project_ids)


def iter_attachment_folders(root_dir: str) -> List[Path]:
    root = Path(root_dir)

    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(
            f"ATTACHMENT_ROOT_DIR does not exist or is not a directory: {root_dir}"
        )

    folders = [path for path in root.iterdir() if path.is_dir()]
    folders.sort(key=lambda path: path.name.upper())

    return folders


def iter_files_inside_folder(folder: Path) -> List[Path]:
    if ONLY_DIRECT_FILES:
        files = [path for path in folder.iterdir() if path.is_file()]
    else:
        files = [path for path in folder.rglob("*") if path.is_file()]

    files.sort(key=lambda path: str(path).upper())

    return files


def is_pid_running(pid: int) -> bool:
    if not pid:
        return False

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_run_lock() -> None:
    if os.path.exists(RUN_LOCK_FILE):
        try:
            existing_pid_text = Path(RUN_LOCK_FILE).read_text(encoding="utf-8").strip()
            existing_pid = int(existing_pid_text)

            if is_pid_running(existing_pid):
                raise RuntimeError(
                    f"Another run appears active. Lock file={RUN_LOCK_FILE}, PID={existing_pid}"
                )

        except ValueError:
            pass

        logger.warning("Removing stale lock file: %s", RUN_LOCK_FILE)
        os.remove(RUN_LOCK_FILE)

    Path(RUN_LOCK_FILE).write_text(str(os.getpid()), encoding="utf-8")
    logger.info("Run lock acquired: %s", RUN_LOCK_FILE)


def release_run_lock() -> None:
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)
            logger.info("Run lock released: %s", RUN_LOCK_FILE)
    except Exception as ex:
        logger.warning("Unable to release lock file %s: %s", RUN_LOCK_FILE, ex)


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        verify_ssl: bool = True,
        timeout: int = 60,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Accept": "application/json"})

        retry = Retry(
            total=5,
            connect=5,
            read=5,
            status=5,
            backoff_factor=1,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            raise_on_status=False,
        )

        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def request(self, method: str, path: str, **kwargs) -> Any:
        url = self._url(path)
        kwargs.setdefault("timeout", self.timeout)

        response = self.session.request(method, url, **kwargs)
        safe_sleep()

        if response.status_code >= 400:
            response_text = response.text[:3000] if response.text else ""
            raise RuntimeError(
                f"Codebeamer API error {response.status_code} for {method} {url}: {response_text}"
            )

        if response.status_code == 204 or not response.text:
            return None

        try:
            return response.json()
        except Exception:
            return response.text

    def get(self, path: str, **kwargs) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> Any:
        return self.request("POST", path, **kwargs)

    def post_raw(self, path: str, **kwargs) -> requests.Response:
        """
        Raw POST used for multipart attachments.
        This avoids generic JSON handling and allows verification manually.
        """
        url = self._url(path)
        kwargs.setdefault("timeout", self.timeout)

        response = self.session.post(url, **kwargs)
        safe_sleep()

        return response


# =========================================================
# QUERY RESPONSE HELPERS
# =========================================================

def extract_items_from_query_response(data: Any) -> List[Dict[str, Any]]:
    if data is None:
        return []

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("items", "itemRefs", "results", "data"):
            value = data.get(key)

            if isinstance(value, list):
                return value

    return []


def extract_item_id(item_ref: Dict[str, Any]) -> Optional[int]:
    if not isinstance(item_ref, dict):
        return None

    for key in ("id", "itemId"):
        value = item_ref.get(key)

        if value:
            try:
                return int(value)
            except Exception:
                pass

    item = item_ref.get("item")

    if isinstance(item, dict) and item.get("id"):
        return int(item["id"])

    return None


def extract_item_name(item_ref: Dict[str, Any]) -> str:
    if not isinstance(item_ref, dict):
        return ""

    for key in ("name", "summary"):
        value = item_ref.get(key)

        if value:
            return str(value)

    item = item_ref.get("item")

    if isinstance(item, dict) and item.get("name"):
        return str(item["name"])

    return ""


# =========================================================
# ITEM DETAIL FIELD HELPERS
# =========================================================

def get_item_detail(cb: CodebeamerClient, item_id: int) -> Dict[str, Any]:
    return cb.get(f"/v3/items/{item_id}")


def extract_field_values_from_item_detail(
    item_detail: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if not isinstance(item_detail, dict):
        return []

    for key in ("customFields", "fields", "fieldValues"):
        value = item_detail.get(key)

        if isinstance(value, list):
            return value

    return []


def field_value_to_text(field_value: Dict[str, Any]) -> Optional[str]:
    if not isinstance(field_value, dict):
        return None

    for key in ("value", "text", "name"):
        value = field_value.get(key)

        if value is not None and not isinstance(value, (dict, list)):
            return str(value).strip()

    values = field_value.get("values")

    if isinstance(values, list) and values:
        parts = []

        for value in values:
            if isinstance(value, dict):
                parts.append(
                    str(
                        value.get("name")
                        or value.get("value")
                        or value.get("id")
                        or ""
                    ).strip()
                )
            else:
                parts.append(str(value).strip())

        return ";".join([part for part in parts if part])

    return None


def extract_field_value_by_name(
    item_detail: Dict[str, Any],
    field_name: str,
) -> Optional[str]:
    target_field_name = normalize_name(field_name)

    for field_value in extract_field_values_from_item_detail(item_detail):
        current_field_name = normalize_name(field_value.get("name"))

        if current_field_name == target_field_name:
            return field_value_to_text(field_value)

    return None


# =========================================================
# CODEBEAMER ITEM SEARCH
# =========================================================

def query_tracker_items(
    cb: CodebeamerClient,
    tracker_id: int,
    page_size: int = PAGE_SIZE,
) -> List[Dict[str, Any]]:
    all_items = []
    page = 1
    project_ids_csv = get_project_ids_csv()

    while True:
        query_string = (
            f"tracker.id IN ({tracker_id}) "
            f"AND project.id IN ({project_ids_csv})"
        )

        payload = {"queryString": query_string}

        logger.info(
            "Querying tracker_id=%s page=%s project_ids=%s",
            tracker_id,
            page,
            project_ids_csv,
        )

        data = cb.post(
            f"/v3/items/query?page={page}&pageSize={page_size}",
            json=payload,
        )

        items = extract_items_from_query_response(data)

        if not items:
            break

        all_items.extend(items)

        logger.info(
            "Tracker %s: loaded page %s with %s items",
            tracker_id,
            page,
            len(items),
        )

        if len(items) < page_size:
            break

        page += 1

    return all_items


def build_sbm_id_index_for_tracker(
    cb: CodebeamerClient,
    tracker_id: int,
    tracker_name: str,
    logical_name: str,
    sbm_field_name: str,
) -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:

    logger.info(
        "Scanning tracker '%s' tracker_id=%s by field '%s'",
        tracker_name,
        tracker_id,
        sbm_field_name,
    )

    index: Dict[str, List[Dict[str, Any]]] = {}
    duplicate_rows: List[Dict[str, Any]] = []

    item_refs = query_tracker_items(cb, tracker_id)

    logger.info(
        "Tracker '%s' returned %s item references",
        tracker_name,
        len(item_refs),
    )

    for item_ref in item_refs:
        item_id = extract_item_id(item_ref)

        if not item_id:
            continue

        try:
            detail = get_item_detail(cb, item_id)

            item_name = (
                detail.get("name")
                or extract_item_name(item_ref)
                or str(item_id)
            )

            raw_sbm_id = extract_field_value_by_name(detail, sbm_field_name)
            sbm_id = normalize_sbm_id(raw_sbm_id)

            if not sbm_id:
                continue

            row = {
                "logical_name": logical_name,
                "tracker_id": tracker_id,
                "tracker_name": tracker_name,
                "sbm_field_name": sbm_field_name,
                "sbm_id": sbm_id,
                "item_id": item_id,
                "item_name": item_name,
            }

            index.setdefault(sbm_id, []).append(row)

        except Exception as ex:
            logger.warning(
                "Failed reading item detail. tracker=%s item=%s error=%s",
                tracker_name,
                item_id,
                ex,
            )

    for sbm_id, matches in index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_rows.append({
                    "sbm_id": sbm_id,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": match["item_id"],
                    "item_name": match["item_name"],
                    "duplicate_count": len(matches),
                })

    logger.info(
        "Tracker '%s' indexed %s unique SBM IDs",
        tracker_name,
        len(index),
    )

    return index, duplicate_rows


def build_global_sbm_index(
    cb: CodebeamerClient,
) -> Tuple[
    Dict[str, List[Dict[str, Any]]],
    List[Dict[str, Any]],
    List[Dict[str, Any]],
]:

    global_index: Dict[str, List[Dict[str, Any]]] = {}
    duplicate_rows: List[Dict[str, Any]] = []
    skipped_tracker_rows: List[Dict[str, Any]] = []

    for cfg in TRACKER_SEARCH_CONFIG:
        tracker_id = cfg.get("tracker_id")

        if not tracker_id:
            reason = "Tracker ID not configured; tracker skipped"

            logger.warning(
                "%s: logical_name=%s tracker_name=%s field=%s",
                reason,
                cfg.get("logical_name"),
                cfg.get("tracker_name"),
                cfg.get("sbm_field_name"),
            )

            skipped_tracker_rows.append({
                "reason": reason,
                "logical_name": cfg.get("logical_name"),
                "tracker_name": cfg.get("tracker_name"),
                "sbm_field_name": cfg.get("sbm_field_name"),
            })

            continue

        tracker_index, tracker_duplicates = build_sbm_id_index_for_tracker(
            cb=cb,
            tracker_id=int(tracker_id),
            tracker_name=cfg["tracker_name"],
            logical_name=cfg["logical_name"],
            sbm_field_name=cfg["sbm_field_name"],
        )

        for sbm_id, matches in tracker_index.items():
            global_index.setdefault(sbm_id, []).extend(matches)

        duplicate_rows.extend(tracker_duplicates)

    for sbm_id, matches in global_index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_rows.append({
                    "sbm_id": sbm_id,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": match["item_id"],
                    "item_name": match["item_name"],
                    "duplicate_count": len(matches),
                })

    return global_index, duplicate_rows, skipped_tracker_rows


# =========================================================
# ATTACHMENT HELPERS - UPDATED WORKING APPROACH
# =========================================================

def extract_attachment_file_name(
    attachment_obj: Dict[str, Any],
) -> Optional[str]:
    if not isinstance(attachment_obj, dict):
        return None

    for key in ("name", "fileName", "filename"):
        value = attachment_obj.get(key)

        if value:
            return str(value).strip()

    return None


def extract_attachments_from_response(data: Any) -> List[Dict[str, Any]]:
    if data is None:
        return []

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("attachments", "items", "data", "results"):
            value = data.get(key)

            if isinstance(value, list):
                return value

    return []


def get_existing_attachment_file_names(
    cb: CodebeamerClient,
    item_id: int,
) -> set:
    try:
        data = cb.get(f"/v3/items/{item_id}/attachments")
        attachments = extract_attachments_from_response(data)

        names = set()

        for attachment in attachments:
            file_name = extract_attachment_file_name(attachment)

            if file_name:
                names.add(file_name.lower())

        return names

    except Exception as ex:
        logger.warning(
            "Could not read existing attachments for item %s. "
            "Duplicate check skipped. Error=%s",
            item_id,
            ex,
        )

        return set()


def is_attachment_visible_after_upload(
    cb: CodebeamerClient,
    item_id: int,
    file_name: str,
    wait_seconds: float = 1.0,
) -> bool:
    """
    Verifies whether uploaded file is actually visible on Codebeamer item.
    This is important because API may return success but file may not be attached
    if multipart field name is not accepted by that Codebeamer version.
    """
    time.sleep(wait_seconds)

    existing_names = get_existing_attachment_file_names(cb, item_id)
    return file_name.lower() in existing_names


def upload_attachment_once(
    cb: CodebeamerClient,
    item_id: int,
    file_path: Path,
    multipart_field_name: str,
) -> Tuple[bool, str]:
    """
    Upload one file with one multipart field name.
    Returns:
      success_by_http_status, response_text
    """
    mime_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"

    with open(file_path, "rb") as file_obj:
        files = {
            multipart_field_name: (
                file_path.name,
                file_obj,
                mime_type,
            )
        }

        data = {
            "description": ATTACHMENT_DESCRIPTION,
        }

        response = cb.post_raw(
            f"/v3/items/{item_id}/attachments",
            files=files,
            data=data,
        )

    response_text = response.text[:3000] if response.text else ""

    if response.status_code >= 400:
        return False, f"HTTP {response.status_code}: {response_text}"

    return True, f"HTTP {response.status_code}: {response_text}"


def upload_attachment_verified(
    cb: CodebeamerClient,
    item_id: int,
    file_path: Path,
) -> Tuple[bool, str]:
    """
    Upload attachment and verify it appears on the item.

    Tries multiple multipart field names because Codebeamer environments
    may accept different names depending on version/configuration.
    """
    multipart_field_candidates = [
        "attachments",
        "file",
        "upload",
    ]

    attempt_messages = []

    for field_name in multipart_field_candidates:
        logger.info(
            "Trying attachment upload. item=%s file=%s multipart_field=%s",
            item_id,
            file_path.name,
            field_name,
        )

        try:
            http_success, response_message = upload_attachment_once(
                cb=cb,
                item_id=item_id,
                file_path=file_path,
                multipart_field_name=field_name,
            )

            attempt_messages.append(
                f"field={field_name}, http_success={http_success}, response={response_message}"
            )

            if not http_success:
                continue

            if is_attachment_visible_after_upload(cb, item_id, file_path.name):
                return True, f"Attachment visible after upload using multipart field '{field_name}'"

            logger.warning(
                "Upload API returned success, but attachment not visible. "
                "item=%s file=%s field=%s",
                item_id,
                file_path.name,
                field_name,
            )

        except Exception as ex:
            attempt_messages.append(
                f"field={field_name}, exception={str(ex)}"
            )
            logger.warning(
                "Attachment upload attempt failed. item=%s file=%s field=%s error=%s",
                item_id,
                file_path.name,
                field_name,
                ex,
            )

    return False, " | ".join(attempt_messages)


# =========================================================
# REPORT HELPERS
# =========================================================

def write_csv(path: str, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        logger.info("No rows for report: %s", path)
        return

    fieldnames = sorted({key for row in rows for key in row.keys()})

    with open(path, "w", newline="", encoding="utf-8-sig") as file_obj:
        writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    logger.info("Report written: %s rows=%s", path, len(rows))


# =========================================================
# MAIN ATTACHMENT PROCESS
# =========================================================

def process_attachment_folders(
    cb: CodebeamerClient,
    global_index: Dict[str, List[Dict[str, Any]]],
) -> Tuple[
    List[Dict[str, Any]],
    List[Dict[str, Any]],
    List[Dict[str, Any]],
    List[Dict[str, Any]],
]:

    success_rows: List[Dict[str, Any]] = []
    failed_rows: List[Dict[str, Any]] = []
    not_found_rows: List[Dict[str, Any]] = []
    skipped_rows: List[Dict[str, Any]] = []

    folders = iter_attachment_folders(ATTACHMENT_ROOT_DIR)

    logger.info(
        "Found %s folders under attachment root: %s",
        len(folders),
        ATTACHMENT_ROOT_DIR,
    )

    for folder in folders:
        folder_sbm_id = normalize_sbm_id(folder.name)

        if not folder_sbm_id:
            skipped_rows.append({
                "folder": str(folder),
                "reason": "Folder name is blank or invalid",
            })
            continue

        files = iter_files_inside_folder(folder)

        if not files:
            skipped_rows.append({
                "folder_sbm_id": folder_sbm_id,
                "folder": str(folder),
                "reason": "No files found inside folder",
            })
            logger.info("Folder %s skipped: no files", folder_sbm_id)
            continue

        matches = global_index.get(folder_sbm_id, [])

        if not matches:
            not_found_rows.append({
                "folder_sbm_id": folder_sbm_id,
                "folder": str(folder),
                "file_count": len(files),
                "reason": "No matching Codebeamer item found in configured trackers/projects/fields",
            })
            logger.warning(
                "No Codebeamer item found for folder/SBM ID: %s",
                folder_sbm_id,
            )
            continue

        logger.info(
            "Folder %s matched %s Codebeamer item(s); file count=%s",
            folder_sbm_id,
            len(matches),
            len(files),
        )

        for match in matches:
            item_id = int(match["item_id"])

            existing_names = (
                get_existing_attachment_file_names(cb, item_id)
                if SKIP_IF_FILENAME_ALREADY_ATTACHED
                else set()
            )

            for file_path in files:
                if not file_path.is_file():
                    continue

                if (
                    SKIP_IF_FILENAME_ALREADY_ATTACHED
                    and file_path.name.lower() in existing_names
                ):
                    skipped_rows.append({
                        "folder_sbm_id": folder_sbm_id,
                        "folder": str(folder),
                        "file_path": str(file_path),
                        "file_name": file_path.name,
                        "logical_name": match["logical_name"],
                        "tracker_id": match["tracker_id"],
                        "tracker_name": match["tracker_name"],
                        "sbm_field_name": match["sbm_field_name"],
                        "item_id": item_id,
                        "item_name": match.get("item_name"),
                        "reason": "Same file name already attached; skipped duplicate",
                    })

                    logger.info(
                        "Skipped duplicate attachment. item=%s file=%s",
                        item_id,
                        file_path.name,
                    )
                    continue

                success, message = upload_attachment_verified(
                    cb=cb,
                    item_id=item_id,
                    file_path=file_path,
                )

                if success:
                    success_rows.append({
                        "folder_sbm_id": folder_sbm_id,
                        "folder": str(folder),
                        "file_path": str(file_path),
                        "file_name": file_path.name,
                        "file_size_bytes": file_path.stat().st_size,
                        "logical_name": match["logical_name"],
                        "tracker_id": match["tracker_id"],
                        "tracker_name": match["tracker_name"],
                        "sbm_field_name": match["sbm_field_name"],
                        "item_id": item_id,
                        "item_name": match.get("item_name"),
                        "status": "ATTACHED_AND_VERIFIED",
                        "message": message,
                    })

                    logger.info(
                        "Attached and verified file. item=%s file=%s",
                        item_id,
                        file_path,
                    )

                else:
                    failed_rows.append({
                        "folder_sbm_id": folder_sbm_id,
                        "folder": str(folder),
                        "file_path": str(file_path),
                        "file_name": file_path.name,
                        "logical_name": match["logical_name"],
                        "tracker_id": match["tracker_id"],
                        "tracker_name": match["tracker_name"],
                        "sbm_field_name": match["sbm_field_name"],
                        "item_id": item_id,
                        "item_name": match.get("item_name"),
                        "error": message,
                    })

                    logger.error(
                        "Attachment failed or not visible after upload. item=%s file=%s error=%s",
                        item_id,
                        file_path,
                        message,
                    )

    return success_rows, failed_rows, not_found_rows, skipped_rows


# =========================================================
# MAIN
# =========================================================

def main() -> None:
    acquire_run_lock()

    try:
        logger.info("Starting Codebeamer attachment folder import")
        logger.info("Attachment root directory: %s", ATTACHMENT_ROOT_DIR)
        logger.info("Project IDs configured: %s", PROJECT_IDS)

        cb = CodebeamerClient(
            base_url=CB_BASE_URL,
            username=CB_USER,
            password=CB_PASS,
            verify_ssl=VERIFY_SSL,
            timeout=TIMEOUT,
        )

        global_index, duplicate_rows, skipped_tracker_rows = build_global_sbm_index(cb)

        logger.info(
            "Global SBM index contains %s unique SBM IDs",
            len(global_index),
        )

        success_rows, failed_rows, not_found_rows, skipped_rows = process_attachment_folders(
            cb=cb,
            global_index=global_index,
        )

        skipped_rows.extend(skipped_tracker_rows)

        write_csv(SUCCESS_CSV, success_rows)
        write_csv(FAILED_CSV, failed_rows)
        write_csv(NOT_FOUND_CSV, not_found_rows)
        write_csv(SKIPPED_CSV, skipped_rows)
        write_csv(DUPLICATE_MATCH_CSV, duplicate_rows)

        logger.info(
            "Attachment import completed. Success=%s Failed=%s NotFound=%s Skipped=%s DuplicateMatches=%s",
            len(success_rows),
            len(failed_rows),
            len(not_found_rows),
            len(skipped_rows),
            len(duplicate_rows),
        )

    finally:
        release_run_lock()


if __name__ == "__main__":
    main()