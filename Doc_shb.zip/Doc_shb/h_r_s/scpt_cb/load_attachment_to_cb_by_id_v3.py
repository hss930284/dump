
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import csv
import time
import logging
import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Set
from datetime import datetime

import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# =========================================================
# CONFIGURATION
# =========================================================

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 60
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_IDS = [48, 47]

ATTACHMENT_ROOT_DIR = r"D:\SBM_ATTACHMENTS"

ONLY_DIRECT_FILES = True
SKIP_IF_FILENAME_ALREADY_ATTACHED = True

ATTACHMENT_DESCRIPTION = "Attachment migrated from SBM source folder."
PAGE_SIZE = 50

LOG_FILE = "cb_attachment_import.log"
RUN_LOCK_FILE = "cb_attachment_import.lock"

SUCCESS_CSV = "attachment_import_success.csv"
FAILED_CSV = "attachment_import_failed.csv"
NOT_FOUND_CSV = "attachment_folder_ids_not_found.csv"
SKIPPED_CSV = "attachment_import_skipped.csv"
DUPLICATE_MATCH_CSV = "attachment_duplicate_item_matches.csv"

EXCEL_REPORT_PREFIX = "attachment_import_run_report"


# =========================================================
# TRACKER CONFIGURATION
# =========================================================

TRACKER_SEARCH_CONFIG = [
    {"logical_name": "Issue", "tracker_id": 294498, "tracker_name": "Issue", "sbm_field_name": "SBM Item Id"},
    {"logical_name": "Retex", "tracker_id": 294309, "tracker_name": "Retex", "sbm_field_name": "SBM Retex Id"},
    {"logical_name": "SDT", "tracker_id": 295425, "tracker_name": "A-EMS Specification", "sbm_field_name": "SBM SDT Id"},
    {"logical_name": "MDT", "tracker_id": 295368, "tracker_name": "A-EMS Module", "sbm_field_name": "SBM MDT Id"},
    {"logical_name": "Change Request", "tracker_id": 293926, "tracker_name": "Change Request", "sbm_field_name": "SBM CR Id"},
    {"logical_name": "Tag Management", "tracker_id": 293706, "tracker_name": "Tag Management", "sbm_field_name": "SBM Tag Id"},
    {"logical_name": "New Function", "tracker_id": 301069, "tracker_name": "New Function", "sbm_field_name": "SBM NF Id"},
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging() -> logging.Logger:
    logger_obj = logging.getLogger("cb_attachment_import")
    logger_obj.setLevel(logging.INFO)
    logger_obj.handlers.clear()

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    file_handler.setFormatter(formatter)

    logger_obj.addHandler(console_handler)
    logger_obj.addHandler(file_handler)
    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def normalize_sbm_id(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return re.sub(r"\s+", "", text).upper()


def safe_sleep() -> None:
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def get_project_ids_csv() -> str:
    valid_project_ids = []
    for project_id in PROJECT_IDS:
        if project_id is None:
            continue
        project_id_text = str(project_id).strip()
        if project_id_text:
            valid_project_ids.append(project_id_text)
    if not valid_project_ids:
        raise ValueError("PROJECT_IDS is empty. Please configure at least one project ID.")
    return ",".join(valid_project_ids)


def iter_attachment_folders(root_dir: str) -> List[Path]:
    root = Path(root_dir)
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"ATTACHMENT_ROOT_DIR does not exist or is not a directory: {root_dir}")
    folders = [path for path in root.iterdir() if path.is_dir()]
    folders.sort(key=lambda path: path.name.upper())
    return folders


def iter_files_inside_folder(folder: Path) -> List[Path]:
    if ONLY_DIRECT_FILES:
        files = [path for path in folder.iterdir() if path.is_file()]
    else:
        files = [path for path in folder.rglob("*") if path.is_file()]
    files.sort(key=lambda path: str(path).upper())
    return files


def is_pid_running(pid: int) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_run_lock() -> None:
    if os.path.exists(RUN_LOCK_FILE):
        try:
            existing_pid_text = Path(RUN_LOCK_FILE).read_text(encoding="utf-8").strip()
            existing_pid = int(existing_pid_text)
            if is_pid_running(existing_pid):
                raise RuntimeError(f"Another run appears active. Lock file={RUN_LOCK_FILE}, PID={existing_pid}")
        except ValueError:
            pass
        logger.warning("Removing stale lock file: %s", RUN_LOCK_FILE)
        os.remove(RUN_LOCK_FILE)
    Path(RUN_LOCK_FILE).write_text(str(os.getpid()), encoding="utf-8")
    logger.info("Run lock acquired: %s", RUN_LOCK_FILE)


def release_run_lock() -> None:
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)
            logger.info("Run lock released: %s", RUN_LOCK_FILE)
    except Exception as ex:
        logger.warning("Unable to release lock file %s: %s", RUN_LOCK_FILE, ex)


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url: str, username: str, password: str, verify_ssl: bool = True, timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Accept": "application/json"})

        retry = Retry(
            total=5,
            connect=5,
            read=5,
            status=5,
            backoff_factor=1,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        kwargs.setdefault("timeout", self.timeout)
        response = self.session.request(method, url, **kwargs)
        safe_sleep()
        if response.status_code >= 400:
            response_text = response.text[:3000] if response.text else ""
            raise RuntimeError(f"Codebeamer API error {response.status_code} for {method} {url}: {response_text}")
        if response.status_code == 204 or not response.text:
            return None
        try:
            return response.json()
        except Exception:
            return response.text

    def get(self, path: str, **kwargs: Any) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> Any:
        return self.request("POST", path, **kwargs)

    def post_raw(self, path: str, **kwargs: Any) -> requests.Response:
        url = self._url(path)
        kwargs.setdefault("timeout", self.timeout)
        response = self.session.post(url, **kwargs)
        safe_sleep()
        return response


# =========================================================
# QUERY RESPONSE HELPERS
# =========================================================

def extract_items_from_query_response(data: Any) -> List[Dict[str, Any]]:
    if data is None:
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("items", "itemRefs", "results", "data"):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def extract_item_id(item_ref: Dict[str, Any]) -> Optional[int]:
    if not isinstance(item_ref, dict):
        return None
    for key in ("id", "itemId"):
        value = item_ref.get(key)
        if value:
            try:
                return int(value)
            except Exception:
                pass
    item = item_ref.get("item")
    if isinstance(item, dict) and item.get("id"):
        return int(item["id"])
    return None


def extract_item_name(item_ref: Dict[str, Any]) -> str:
    if not isinstance(item_ref, dict):
        return ""
    for key in ("name", "summary"):
        value = item_ref.get(key)
        if value:
            return str(value)
    item = item_ref.get("item")
    if isinstance(item, dict) and item.get("name"):
        return str(item["name"])
    return ""


# =========================================================
# TRACKER AND ITEM HELPERS
# =========================================================

def get_tracker_detail(cb: CodebeamerClient, tracker_id: int) -> Dict[str, Any]:
    try:
        data = cb.get(f"/v3/trackers/{tracker_id}")
        return data if isinstance(data, dict) else {}
    except Exception as ex:
        logger.warning("Unable to fetch tracker detail for tracker_id=%s. Error=%s", tracker_id, ex)
        return {}


def log_tracker_debug(cb: CodebeamerClient, tracker_id: int, tracker_name: str) -> None:
    detail = get_tracker_detail(cb, tracker_id)
    if not detail:
        logger.warning("Tracker debug: no detail returned for tracker_name=%s tracker_id=%s", tracker_name, tracker_id)
        return
    project_info = detail.get("project") or {}
    logger.info(
        "Tracker debug: configured_tracker_name='%s', tracker_id=%s, api_tracker_name='%s', api_project_id='%s', api_project_name='%s'",
        tracker_name,
        tracker_id,
        detail.get("name"),
        project_info.get("id"),
        project_info.get("name"),
    )


def get_item_detail(cb: CodebeamerClient, item_id: int) -> Dict[str, Any]:
    data = cb.get(f"/v3/items/{item_id}")
    return data if isinstance(data, dict) else {}


def extract_field_values_from_item_detail(item_detail: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(item_detail, dict):
        return []
    for key in ("customFields", "fields", "fieldValues"):
        value = item_detail.get(key)
        if isinstance(value, list):
            return value
    return []


def field_value_to_text(field_value: Dict[str, Any]) -> Optional[str]:
    if not isinstance(field_value, dict):
        return None
    for key in ("value", "text", "name"):
        value = field_value.get(key)
        if value is not None and not isinstance(value, (dict, list)):
            return str(value).strip()
    values = field_value.get("values")
    if isinstance(values, list) and values:
        parts = []
        for value in values:
            if isinstance(value, dict):
                parts.append(str(value.get("name") or value.get("value") or value.get("id") or "").strip())
            else:
                parts.append(str(value).strip())
        return ";".join([part for part in parts if part])
    return None


def extract_field_value_by_name(item_detail: Dict[str, Any], field_name: str) -> Optional[str]:
    target_field_name = normalize_name(field_name)
    for field_value in extract_field_values_from_item_detail(item_detail):
        current_field_name = normalize_name(field_value.get("name"))
        if current_field_name == target_field_name:
            return field_value_to_text(field_value)
    return None


def log_sample_field_names_for_items(cb: CodebeamerClient, tracker_name: str, item_refs: List[Dict[str, Any]], sample_size: int = 3) -> None:
    logger.warning("Debugging field names for tracker '%s'. Showing sample of %s item(s).", tracker_name, sample_size)
    count = 0
    for item_ref in item_refs:
        if count >= sample_size:
            break
        item_id = extract_item_id(item_ref)
        if not item_id:
            continue
        try:
            detail = get_item_detail(cb, item_id)
            fields = extract_field_values_from_item_detail(detail)
            field_names = [str(f.get("name")) for f in fields if f.get("name")]
            logger.warning("Sample item_id=%s item_name='%s' field_names=%s", item_id, detail.get("name"), field_names)
            count += 1
        except Exception as ex:
            logger.warning("Unable to log sample field names for item_id=%s. Error=%s", item_id, ex)


# =========================================================
# CODEBEAMER ITEM SEARCH
# =========================================================

def run_item_query(cb: CodebeamerClient, tracker_id: int, query_string: str, page_size: int = PAGE_SIZE) -> List[Dict[str, Any]]:
    all_items: List[Dict[str, Any]] = []
    page = 1
    seen_ids: Set[int] = set()
    while True:
        payload = {"queryString": query_string}
        logger.info("Querying tracker_id=%s page=%s query=%s", tracker_id, page, query_string)
        data = cb.post(f"/v3/items/query?page={page}&pageSize={page_size}", json=payload)
        items = extract_items_from_query_response(data)
        if not items:
            break
        new_items = []
        for item in items:
            item_id = extract_item_id(item)
            if item_id and item_id in seen_ids:
                continue
            if item_id:
                seen_ids.add(item_id)
            new_items.append(item)
        if not new_items:
            logger.warning("No new items found on page=%s for tracker_id=%s. Stopping pagination.", page, tracker_id)
            break
        all_items.extend(new_items)
        logger.info("Tracker %s: loaded page %s with %s item(s), new item(s)=%s", tracker_id, page, len(items), len(new_items))
        if len(items) < page_size:
            break
        page += 1
    return all_items


def query_tracker_items(cb: CodebeamerClient, tracker_id: int, tracker_name: str, page_size: int = PAGE_SIZE) -> List[Dict[str, Any]]:
    project_ids_csv = get_project_ids_csv()
    log_tracker_debug(cb, tracker_id, tracker_name)
    query_with_project = f"tracker.id IN ({tracker_id}) AND project.id IN ({project_ids_csv})"
    items = run_item_query(cb=cb, tracker_id=tracker_id, query_string=query_with_project, page_size=page_size)
    if items:
        return items
    logger.warning(
        "No items returned for tracker_id=%s tracker_name='%s' with project filter project_ids=%s. Trying fallback query with tracker.id only.",
        tracker_id,
        tracker_name,
        project_ids_csv,
    )
    query_tracker_only = f"tracker.id IN ({tracker_id})"
    fallback_items = run_item_query(cb=cb, tracker_id=tracker_id, query_string=query_tracker_only, page_size=page_size)
    if fallback_items:
        logger.warning("Fallback tracker-only query returned %s item(s) for tracker_id=%s tracker_name='%s'.", len(fallback_items), tracker_id, tracker_name)
    else:
        logger.warning("Fallback tracker-only query also returned 0 item(s) for tracker_id=%s tracker_name='%s'.", tracker_id, tracker_name)
    return fallback_items


def build_sbm_id_index_for_tracker(cb: CodebeamerClient, tracker_id: int, tracker_name: str, logical_name: str, sbm_field_name: str) -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:
    logger.info("Scanning tracker '%s' tracker_id=%s by field '%s'", tracker_name, tracker_id, sbm_field_name)
    index: Dict[str, List[Dict[str, Any]]] = {}
    duplicate_rows: List[Dict[str, Any]] = []
    item_refs = query_tracker_items(cb=cb, tracker_id=tracker_id, tracker_name=tracker_name)
    logger.info("Tracker '%s' returned %s item references", tracker_name, len(item_refs))

    for item_ref in item_refs:
        item_id = extract_item_id(item_ref)
        if not item_id:
            continue
        try:
            detail = get_item_detail(cb, item_id)
            item_name = detail.get("name") or extract_item_name(item_ref) or str(item_id)
            raw_sbm_id = extract_field_value_by_name(detail, sbm_field_name)
            sbm_id = normalize_sbm_id(raw_sbm_id)
            if not sbm_id:
                continue
            row = {
                "logical_name": logical_name,
                "tracker_id": tracker_id,
                "tracker_name": tracker_name,
                "sbm_field_name": sbm_field_name,
                "sbm_id": sbm_id,
                "item_id": item_id,
                "item_name": item_name,
            }
            index.setdefault(sbm_id, []).append(row)
        except Exception as ex:
            logger.warning("Failed reading item detail. tracker=%s item=%s error=%s", tracker_name, item_id, ex)

    if item_refs and not index:
        logger.warning(
            "Tracker '%s' returned item references but indexed 0 SBM IDs using field '%s'. This usually means field name is different in Codebeamer.",
            tracker_name,
            sbm_field_name,
        )
        log_sample_field_names_for_items(cb=cb, tracker_name=tracker_name, item_refs=item_refs, sample_size=3)

    for sbm_id, matches in index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_rows.append({
                    "sbm_id": sbm_id,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": match["item_id"],
                    "item_name": match["item_name"],
                    "duplicate_count": len(matches),
                })
    logger.info("Tracker '%s' indexed %s unique SBM IDs", tracker_name, len(index))
    return index, duplicate_rows


def build_global_sbm_index(cb: CodebeamerClient) -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    global_index: Dict[str, List[Dict[str, Any]]] = {}
    duplicate_rows: List[Dict[str, Any]] = []
    skipped_tracker_rows: List[Dict[str, Any]] = []

    for cfg in TRACKER_SEARCH_CONFIG:
        tracker_id = cfg.get("tracker_id")
        if not tracker_id:
            reason = "Tracker ID not configured; tracker skipped"
            logger.warning("%s: logical_name=%s tracker_name=%s field=%s", reason, cfg.get("logical_name"), cfg.get("tracker_name"), cfg.get("sbm_field_name"))
            skipped_tracker_rows.append({"reason": reason, "logical_name": cfg.get("logical_name"), "tracker_name": cfg.get("tracker_name"), "sbm_field_name": cfg.get("sbm_field_name")})
            continue
        tracker_index, tracker_duplicates = build_sbm_id_index_for_tracker(
            cb=cb,
            tracker_id=int(tracker_id),
            tracker_name=cfg["tracker_name"],
            logical_name=cfg["logical_name"],
            sbm_field_name=cfg["sbm_field_name"],
        )
        for sbm_id, matches in tracker_index.items():
            global_index.setdefault(sbm_id, []).extend(matches)
        duplicate_rows.extend(tracker_duplicates)

    for sbm_id, matches in global_index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_rows.append({
                    "sbm_id": sbm_id,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": match["item_id"],
                    "item_name": match["item_name"],
                    "duplicate_count": len(matches),
                })
    return global_index, duplicate_rows, skipped_tracker_rows


# =========================================================
# ATTACHMENT HELPERS
# =========================================================

def extract_attachment_file_name(attachment_obj: Dict[str, Any]) -> Optional[str]:
    if not isinstance(attachment_obj, dict):
        return None
    for key in ("name", "fileName", "filename"):
        value = attachment_obj.get(key)
        if value:
            return str(value).strip()
    return None


def extract_attachments_from_response(data: Any) -> List[Dict[str, Any]]:
    if data is None:
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("attachments", "items", "data", "results"):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def get_existing_attachment_file_names(cb: CodebeamerClient, item_id: int) -> Set[str]:
    try:
        data = cb.get(f"/v3/items/{item_id}/attachments")
        attachments = extract_attachments_from_response(data)
        names: Set[str] = set()
        for attachment in attachments:
            file_name = extract_attachment_file_name(attachment)
            if file_name:
                names.add(file_name.lower())
        return names
    except Exception as ex:
        logger.warning("Could not read existing attachments for item %s. Duplicate check skipped. Error=%s", item_id, ex)
        return set()


def is_attachment_visible_after_upload(cb: CodebeamerClient, item_id: int, file_name: str, wait_seconds: float = 1.0) -> bool:
    time.sleep(wait_seconds)
    existing_names = get_existing_attachment_file_names(cb, item_id)
    return file_name.lower() in existing_names


def upload_attachment_once(cb: CodebeamerClient, item_id: int, file_path: Path, multipart_field_name: str) -> Tuple[bool, str]:
    mime_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
    with open(file_path, "rb") as file_obj:
        files = {multipart_field_name: (file_path.name, file_obj, mime_type)}
        data = {"description": ATTACHMENT_DESCRIPTION}
        response = cb.post_raw(f"/v3/items/{item_id}/attachments", files=files, data=data)
    response_text = response.text[:3000] if response.text else ""
    if response.status_code >= 400:
        return False, f"HTTP {response.status_code}: {response_text}"
    return True, f"HTTP {response.status_code}: {response_text}"


def upload_attachment_verified(cb: CodebeamerClient, item_id: int, file_path: Path) -> Tuple[bool, str]:
    multipart_field_candidates = ["attachments", "file", "upload"]
    attempt_messages = []
    for field_name in multipart_field_candidates:
        logger.info("Trying attachment upload. item=%s file=%s multipart_field=%s", item_id, file_path.name, field_name)
        try:
            http_success, response_message = upload_attachment_once(cb=cb, item_id=item_id, file_path=file_path, multipart_field_name=field_name)
            attempt_messages.append(f"field={field_name}, http_success={http_success}, response={response_message}")
            if not http_success:
                continue
            if is_attachment_visible_after_upload(cb, item_id, file_path.name):
                return True, f"Attachment visible after upload using multipart field '{field_name}'"
            logger.warning("Upload API returned success, but attachment not visible. item=%s file=%s field=%s", item_id, file_path.name, field_name)
        except Exception as ex:
            attempt_messages.append(f"field={field_name}, exception={str(ex)}")
            logger.warning("Attachment upload attempt failed. item=%s file=%s field=%s error=%s", item_id, file_path.name, field_name, ex)
    return False, " | ".join(attempt_messages)


# =========================================================
# CSV REPORT HELPERS
# =========================================================

def write_csv(path: str, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        logger.info("No rows for report: %s", path)
        return
    fieldnames = sorted({key for row in rows for key in row.keys()})
    with open(path, "w", newline="", encoding="utf-8-sig") as file_obj:
        writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    logger.info("CSV report written: %s rows=%s", path, len(rows))


# =========================================================
# EXCEL RUN REPORT HELPERS
# =========================================================

def get_run_timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_report_datetime_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def get_cb_web_base_url(api_base_url: str) -> str:
    base = api_base_url.rstrip("/")
    if base.endswith("/api"):
        return base[:-4]
    return base


def build_cb_item_url(item_id: Any) -> str:
    if not item_id:
        return ""
    return f"{get_cb_web_base_url(CB_BASE_URL)}/issue/{item_id}"


def enrich_report_row(row: Dict[str, Any], run_status: str, report_generated_at: str) -> Dict[str, Any]:
    enriched = dict(row)
    folder_sbm_id = enriched.get("folder_sbm_id") or enriched.get("sbm_id") or enriched.get("source_sbm_id") or enriched.get("id") or ""
    item_id = enriched.get("item_id") or enriched.get("codebeamer_item_id") or enriched.get("codebeamer_id") or ""

    enriched["run_status"] = run_status
    enriched["report_generated_at"] = report_generated_at
    enriched["source_sbm_id"] = folder_sbm_id

    if item_id:
        enriched["codebeamer_item_id"] = item_id
        enriched["codebeamer_item_url"] = build_cb_item_url(item_id)
        enriched["attachment_linkage"] = f"{folder_sbm_id} -> Codebeamer Item ID {item_id}" if folder_sbm_id else f"Codebeamer Item ID {item_id}"
    else:
        enriched["codebeamer_item_id"] = ""
        enriched["codebeamer_item_url"] = ""
        enriched["attachment_linkage"] = f"{folder_sbm_id} -> NOT FOUND" if folder_sbm_id else "NOT FOUND"
    return enriched


def sanitize_sheet_name(sheet_name: str) -> str:
    for char in ["\\", "/", "*", "[", "]", ":", "?"]:
        sheet_name = sheet_name.replace(char, " ")
    return sheet_name[:31]


def preferred_field_order(all_fields: List[str]) -> List[str]:
    preferred = [
        "run_status", "report_generated_at", "source_sbm_id", "folder_sbm_id", "sbm_id",
        "attachment_linkage", "codebeamer_item_id", "item_id", "codebeamer_item_url",
        "logical_name", "tracker_id", "tracker_name", "sbm_field_name", "item_name",
        "file_name", "file_path", "file_size_bytes", "folder", "status", "reason", "error", "message", "duplicate_count",
    ]
    ordered = [field for field in preferred if field in all_fields]
    remaining = sorted([field for field in all_fields if field not in ordered])
    return ordered + remaining


def write_rows_to_sheet(ws: Any, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        ws.append(["No records available"])
        ws["A1"].font = Font(bold=True)
        ws.column_dimensions["A"].width = 30
        return

    all_fields = list({key for row in rows for key in row.keys()})
    fieldnames = preferred_field_order(all_fields)
    ws.append(fieldnames)

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    header_font = Font(bold=True)
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for row in rows:
        ws.append([row.get(field, "") for field in fieldnames])

    if "codebeamer_item_url" in fieldnames:
        url_col_idx = fieldnames.index("codebeamer_item_url") + 1
        for row_idx in range(2, ws.max_row + 1):
            cell = ws.cell(row=row_idx, column=url_col_idx)
            if cell.value:
                cell.hyperlink = cell.value
                cell.style = "Hyperlink"

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    for column_cells in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column_cells[0].column)
        for cell in column_cells:
            value = str(cell.value) if cell.value is not None else ""
            max_length = max(max_length, len(value))
        ws.column_dimensions[column_letter].width = min(max_length + 2, 80)


def write_summary_sheet(
    wb: Workbook,
    report_generated_at: str,
    success_rows: List[Dict[str, Any]],
    failed_rows: List[Dict[str, Any]],
    not_found_rows: List[Dict[str, Any]],
    skipped_rows: List[Dict[str, Any]],
    duplicate_rows: List[Dict[str, Any]],
) -> None:
    ws = wb.active
    ws.title = "Summary"
    total_rows = len(success_rows) + len(failed_rows) + len(not_found_rows) + len(skipped_rows) + len(duplicate_rows)
    summary_rows = [
        ["Report Generated At", report_generated_at],
        ["Attachment Root Directory", ATTACHMENT_ROOT_DIR],
        ["Project IDs", ", ".join([str(project_id) for project_id in PROJECT_IDS])],
        ["Total Records In Excel", total_rows],
        ["Total Success", len(success_rows)],
        ["Total Failed", len(failed_rows)],
        ["Total Not Found", len(not_found_rows)],
        ["Total Skipped", len(skipped_rows)],
        ["Total Duplicate Matches", len(duplicate_rows)],
    ]
    for row in summary_rows:
        ws.append(row)
    title_fill = PatternFill("solid", fgColor="D9EAF7")
    for cell in ws["A"]:
        cell.font = Font(bold=True)
        cell.fill = title_fill
    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 100


def write_excel_run_report(
    success_rows: List[Dict[str, Any]],
    failed_rows: List[Dict[str, Any]],
    not_found_rows: List[Dict[str, Any]],
    skipped_rows: List[Dict[str, Any]],
    duplicate_rows: List[Dict[str, Any]],
) -> str:
    report_generated_at = get_report_datetime_text()
    timestamp = get_run_timestamp()
    excel_file_name = f"{EXCEL_REPORT_PREFIX}_{timestamp}.xlsx"

    success_enriched = [enrich_report_row(row, "SUCCESS", report_generated_at) for row in success_rows]
    failed_enriched = [enrich_report_row(row, "FAILED", report_generated_at) for row in failed_rows]
    not_found_enriched = [enrich_report_row(row, "NOT_FOUND", report_generated_at) for row in not_found_rows]
    skipped_enriched = [enrich_report_row(row, "SKIPPED", report_generated_at) for row in skipped_rows]
    duplicate_enriched = [enrich_report_row(row, "DUPLICATE_MATCH", report_generated_at) for row in duplicate_rows]

    all_rows = success_enriched + failed_enriched + not_found_enriched + skipped_enriched + duplicate_enriched

    wb = Workbook()
    write_summary_sheet(wb, report_generated_at, success_enriched, failed_enriched, not_found_enriched, skipped_enriched, duplicate_enriched)

    for sheet_name, rows in [
        ("All Details", all_rows),
        ("Success", success_enriched),
        ("Failed", failed_enriched),
        ("Not Found", not_found_enriched),
        ("Skipped", skipped_enriched),
        ("Duplicate Matches", duplicate_enriched),
    ]:
        ws = wb.create_sheet(title=sanitize_sheet_name(sheet_name))
        write_rows_to_sheet(ws, rows)

    wb.save(excel_file_name)
    logger.info("Excel run report written: %s", excel_file_name)
    return excel_file_name


# =========================================================
# MAIN ATTACHMENT PROCESS
# =========================================================

def process_attachment_folders(cb: CodebeamerClient, global_index: Dict[str, List[Dict[str, Any]]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    success_rows: List[Dict[str, Any]] = []
    failed_rows: List[Dict[str, Any]] = []
    not_found_rows: List[Dict[str, Any]] = []
    skipped_rows: List[Dict[str, Any]] = []

    folders = iter_attachment_folders(ATTACHMENT_ROOT_DIR)
    logger.info("Found %s folders under attachment root: %s", len(folders), ATTACHMENT_ROOT_DIR)

    for folder in folders:
        folder_sbm_id = normalize_sbm_id(folder.name)
        if not folder_sbm_id:
            skipped_rows.append({"folder": str(folder), "reason": "Folder name is blank or invalid"})
            continue

        files = iter_files_inside_folder(folder)
        if not files:
            skipped_rows.append({"folder_sbm_id": folder_sbm_id, "folder": str(folder), "reason": "No files found inside folder"})
            logger.info("Folder %s skipped: no files", folder_sbm_id)
            continue

        matches = global_index.get(folder_sbm_id, [])
        if not matches:
            for file_path in files:
                not_found_rows.append({
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "file_size_bytes": file_path.stat().st_size if file_path.exists() else "",
                    "file_count": len(files),
                    "reason": "No matching Codebeamer item found in configured trackers/projects/fields",
                })
            logger.warning("No Codebeamer item found for folder/SBM ID: %s", folder_sbm_id)
            continue

        logger.info("Folder %s matched %s Codebeamer item(s); file count=%s", folder_sbm_id, len(matches), len(files))

        for match in matches:
            item_id = int(match["item_id"])
            existing_names = get_existing_attachment_file_names(cb, item_id) if SKIP_IF_FILENAME_ALREADY_ATTACHED else set()

            for file_path in files:
                if not file_path.is_file():
                    continue

                if SKIP_IF_FILENAME_ALREADY_ATTACHED and file_path.name.lower() in existing_names:
                    skipped_rows.append({
                        "folder_sbm_id": folder_sbm_id,
                        "folder": str(folder),
                        "file_path": str(file_path),
                        "file_name": file_path.name,
                        "file_size_bytes": file_path.stat().st_size,
                        "logical_name": match["logical_name"],
                        "tracker_id": match["tracker_id"],
                        "tracker_name": match["tracker_name"],
                        "sbm_field_name": match["sbm_field_name"],
                        "item_id": item_id,
                        "item_name": match.get("item_name"),
                        "reason": "Same file name already attached; skipped duplicate",
                    })
                    logger.info("Skipped duplicate attachment. item=%s file=%s", item_id, file_path.name)
                    continue

                success, message = upload_attachment_verified(cb=cb, item_id=item_id, file_path=file_path)
                common_row = {
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "file_size_bytes": file_path.stat().st_size,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": item_id,
                    "item_name": match.get("item_name"),
                }
                if success:
                    row = dict(common_row)
                    row.update({"status": "ATTACHED_AND_VERIFIED", "message": message})
                    success_rows.append(row)
                    logger.info("Attached and verified file. item=%s file=%s", item_id, file_path)
                    existing_names.add(file_path.name.lower())
                else:
                    row = dict(common_row)
                    row.update({"error": message})
                    failed_rows.append(row)
                    logger.error("Attachment failed or not visible after upload. item=%s file=%s error=%s", item_id, file_path, message)

    return success_rows, failed_rows, not_found_rows, skipped_rows


# =========================================================
# MAIN
# =========================================================

def main() -> None:
    acquire_run_lock()
    try:
        logger.info("Starting Codebeamer attachment folder import")
        logger.info("Attachment root directory: %s", ATTACHMENT_ROOT_DIR)
        logger.info("Project IDs configured: %s", PROJECT_IDS)

        cb = CodebeamerClient(base_url=CB_BASE_URL, username=CB_USER, password=CB_PASS, verify_ssl=VERIFY_SSL, timeout=TIMEOUT)
        global_index, duplicate_rows, skipped_tracker_rows = build_global_sbm_index(cb)
        logger.info("Global SBM index contains %s unique SBM IDs", len(global_index))

        success_rows, failed_rows, not_found_rows, skipped_rows = process_attachment_folders(cb=cb, global_index=global_index)
        skipped_rows.extend(skipped_tracker_rows)

        write_csv(SUCCESS_CSV, success_rows)
        write_csv(FAILED_CSV, failed_rows)
        write_csv(NOT_FOUND_CSV, not_found_rows)
        write_csv(SKIPPED_CSV, skipped_rows)
        write_csv(DUPLICATE_MATCH_CSV, duplicate_rows)

        excel_report_file = write_excel_run_report(
            success_rows=success_rows,
            failed_rows=failed_rows,
            not_found_rows=not_found_rows,
            skipped_rows=skipped_rows,
            duplicate_rows=duplicate_rows,
        )

        logger.info("Run-wise Excel report created: %s", excel_report_file)
        logger.info(
            "Attachment import completed. Success=%s Failed=%s NotFound=%s Skipped=%s DuplicateMatches=%s ExcelReport=%s",
            len(success_rows),
            len(failed_rows),
            len(not_found_rows),
            len(skipped_rows),
            len(duplicate_rows),
            excel_report_file,
        )
    finally:
        release_run_lock()


if __name__ == "__main__":
    main()
