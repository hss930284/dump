#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import csv
import time
import logging
import mimetypes
from pathlib import Path
from datetime import datetime
from urllib.parse import unquote

import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# =========================================================
# CONFIGURATION
# =========================================================

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 60
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_IDS = [48, 47]

ATTACHMENT_ROOT_DIR = r"D:\SBM_ATTACHMENTS"

ONLY_DIRECT_FILES = True
SKIP_IF_FILENAME_ALREADY_ATTACHED = True

ATTACHMENT_DESCRIPTION = "Attachment migrated from SBM source folder."

PAGE_SIZE = 500

ATTACHMENT_VISIBILITY_RETRIES = 4
ATTACHMENT_VISIBILITY_WAIT_SEC = 1.0

LOG_FILE = "cb_attachment_import.log"
RUN_LOCK_FILE = "cb_attachment_import.lock"

SUCCESS_CSV = "attachment_import_success.csv"
FAILED_CSV = "attachment_import_failed.csv"
NOT_FOUND_CSV = "attachment_folder_ids_not_found.csv"
SKIPPED_CSV = "attachment_import_skipped.csv"
DUPLICATE_MATCH_CSV = "attachment_duplicate_item_matches.csv"

EXCEL_REPORT_PREFIX = "attachment_import_run_report"


# =========================================================
# TRACKER CONFIGURATION
# =========================================================

TRACKER_SEARCH_CONFIG = [
    {
        "logical_name": "Issue",
        "tracker_id": 294498,
        "tracker_name": "Issue",
        "sbm_field_name": "SBM Item Id",
    },
    {
        "logical_name": "Retex",
        "tracker_id": 294309,
        "tracker_name": "Retex",
        "sbm_field_name": "SBM Retex Id",
    },
    {
        "logical_name": "SDT",
        "tracker_id": 295425,
        "tracker_name": "A-EMS Specification",
        "sbm_field_name": "SBM SDT Id",
    },
    {
        "logical_name": "MDT",
        "tracker_id": 295368,
        "tracker_name": "A-EMS Module",
        "sbm_field_name": "SBM MDT Id",
    },
    {
        "logical_name": "Change Request",
        "tracker_id": 293926,
        "tracker_name": "Change Request",
        "sbm_field_name": "SBM CR Id",
    },
    {
        "logical_name": "Tag Management",
        "tracker_id": 293706,
        "tracker_name": "Tag Management",
        "sbm_field_name": "SBM Tag Id",
    },
    {
        "logical_name": "New Function",
        "tracker_id": 301069,
        "tracker_name": "New Function",
        "sbm_field_name": "SBM NF Id",
    },
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger_object = logging.getLogger("cb_attachment_import")
    logger_object.setLevel(logging.INFO)
    logger_object.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(
        LOG_FILE,
        mode="a",
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    logger_object.addHandler(console_handler)
    logger_object.addHandler(file_handler)

    return logger_object


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(value):
    return re.sub(
        r"\s+",
        " ",
        str(value or "").strip(),
    ).lower()


def normalize_sbm_id(value):
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    return re.sub(r"\s+", "", text).upper()


def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def get_project_ids_csv():
    valid_project_ids = []

    for project_id in PROJECT_IDS:
        if project_id is None:
            continue

        project_id_text = str(project_id).strip()

        if project_id_text:
            valid_project_ids.append(project_id_text)

    if not valid_project_ids:
        raise ValueError(
            "PROJECT_IDS is empty. Please configure at least one project ID."
        )

    return ",".join(valid_project_ids)


def iter_attachment_folders(root_dir):
    root = Path(root_dir)

    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(
            "ATTACHMENT_ROOT_DIR does not exist or is not a directory: "
            + str(root_dir)
        )

    folders = [
        path
        for path in root.iterdir()
        if path.is_dir()
    ]

    folders.sort(key=lambda path: path.name.upper())

    return folders


def iter_files_inside_folder(folder):
    if ONLY_DIRECT_FILES:
        files = [
            path
            for path in folder.iterdir()
            if path.is_file()
        ]
    else:
        files = [
            path
            for path in folder.rglob("*")
            if path.is_file()
        ]

    files.sort(key=lambda path: str(path).upper())

    return files


def is_pid_running(pid):
    if not pid:
        return False

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_run_lock():
    if os.path.exists(RUN_LOCK_FILE):
        try:
            existing_pid_text = Path(RUN_LOCK_FILE).read_text(
                encoding="utf-8"
            ).strip()

            existing_pid = int(existing_pid_text)

            if is_pid_running(existing_pid):
                raise RuntimeError(
                    "Another run appears active. Lock file="
                    + RUN_LOCK_FILE
                    + ", PID="
                    + str(existing_pid)
                )

        except ValueError:
            pass

        logger.warning(
            "Removing stale lock file: %s",
            RUN_LOCK_FILE,
        )

        os.remove(RUN_LOCK_FILE)

    Path(RUN_LOCK_FILE).write_text(
        str(os.getpid()),
        encoding="utf-8",
    )

    logger.info(
        "Run lock acquired: %s",
        RUN_LOCK_FILE,
    )


def release_run_lock():
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)

            logger.info(
                "Run lock released: %s",
                RUN_LOCK_FILE,
            )

    except Exception as exception:
        logger.warning(
            "Unable to release lock file %s: %s",
            RUN_LOCK_FILE,
            exception,
        )


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:

    def __init__(
        self,
        base_url,
        username,
        password,
        verify_ssl=True,
        timeout=60,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()

        self.session.auth = HTTPBasicAuth(
            username,
            password,
        )

        self.session.verify = verify_ssl

        self.session.headers.update({
            "Accept": "application/json"
        })

        retry = Retry(
            total=5,
            connect=5,
            read=5,
            status=5,
            backoff_factor=1,
            status_forcelist=(
                429,
                500,
                502,
                503,
                504,
            ),
            allowed_methods=frozenset([
                "GET",
                "POST",
                "PUT",
                "PATCH",
                "DELETE",
            ]),
            raise_on_status=False,
        )

        adapter = HTTPAdapter(max_retries=retry)

        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def build_url(self, path):
        return self.base_url + "/" + path.lstrip("/")

    def request(self, method, path, **kwargs):
        url = self.build_url(path)

        kwargs.setdefault("timeout", self.timeout)

        response = self.session.request(
            method,
            url,
            **kwargs,
        )

        safe_sleep()

        if response.status_code >= 400:
            response_text = (
                response.text[:3000]
                if response.text
                else ""
            )

            raise RuntimeError(
                "Codebeamer API error "
                + str(response.status_code)
                + " for "
                + method
                + " "
                + url
                + ": "
                + response_text
            )

        if response.status_code == 204 or not response.text:
            return None

        try:
            return response.json()
        except Exception:
            return response.text

    def get(self, path, **kwargs):
        return self.request(
            "GET",
            path,
            **kwargs,
        )

    def post(self, path, **kwargs):
        return self.request(
            "POST",
            path,
            **kwargs,
        )

    def post_raw(self, path, **kwargs):
        url = self.build_url(path)

        kwargs.setdefault("timeout", self.timeout)

        response = self.session.post(
            url,
            **kwargs,
        )

        safe_sleep()

        return response


# =========================================================
# QUERY RESPONSE HELPERS
# =========================================================

def extract_items_from_query_response(data):
    if data is None:
        return []

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in (
            "items",
            "itemRefs",
            "results",
            "data",
        ):
            value = data.get(key)

            if isinstance(value, list):
                return value

    return []


def extract_item_id(item_reference):
    if not isinstance(item_reference, dict):
        return None

    for key in ("id", "itemId"):
        value = item_reference.get(key)

        if value is not None:
            try:
                return int(value)
            except Exception:
                pass

    nested_item = item_reference.get("item")

    if isinstance(nested_item, dict):
        value = nested_item.get("id")

        if value is not None:
            try:
                return int(value)
            except Exception:
                pass

    return None


def extract_item_name(item_reference):
    if not isinstance(item_reference, dict):
        return ""

    for key in ("name", "summary"):
        value = item_reference.get(key)

        if value:
            return str(value)

    nested_item = item_reference.get("item")

    if isinstance(nested_item, dict):
        value = nested_item.get("name")

        if value:
            return str(value)

    return ""


# =========================================================
# TRACKER AND ITEM HELPERS
# =========================================================

def get_tracker_detail(codebeamer, tracker_id):
    try:
        data = codebeamer.get(
            "/v3/trackers/" + str(tracker_id)
        )

        if isinstance(data, dict):
            return data

    except Exception as exception:
        logger.warning(
            "Unable to fetch tracker detail for tracker_id=%s. Error=%s",
            tracker_id,
            exception,
        )

    return {}


def log_tracker_debug(codebeamer, tracker_id, tracker_name):
    detail = get_tracker_detail(
        codebeamer,
        tracker_id,
    )

    if not detail:
        logger.warning(
            "Tracker debug: no detail returned for tracker_name=%s "
            "tracker_id=%s",
            tracker_name,
            tracker_id,
        )
        return

    project_information = detail.get("project") or {}

    logger.info(
        "Tracker debug: configured_tracker_name='%s', "
        "tracker_id=%s, api_tracker_name='%s', "
        "api_project_id='%s', api_project_name='%s'",
        tracker_name,
        tracker_id,
        detail.get("name"),
        project_information.get("id"),
        project_information.get("name"),
    )


def get_item_detail(codebeamer, item_id):
    data = codebeamer.get(
        "/v3/items/" + str(item_id)
    )

    if isinstance(data, dict):
        return data

    return {}


def extract_field_values_from_item_detail(item_detail):
    if not isinstance(item_detail, dict):
        return []

    for key in (
        "customFields",
        "fields",
        "fieldValues",
    ):
        value = item_detail.get(key)

        if isinstance(value, list):
            return value

    return []


def field_value_to_text(field_value):
    if not isinstance(field_value, dict):
        return None

    for key in ("value", "text", "name"):
        value = field_value.get(key)

        if (
            value is not None
            and not isinstance(value, (dict, list))
        ):
            return str(value).strip()

    values = field_value.get("values")

    if isinstance(values, list) and values:
        parts = []

        for value in values:
            if isinstance(value, dict):
                part = (
                    value.get("name")
                    or value.get("value")
                    or value.get("id")
                    or ""
                )
            else:
                part = value

            part_text = str(part).strip()

            if part_text:
                parts.append(part_text)

        return ";".join(parts)

    return None


def extract_field_value_by_name(item_detail, field_name):
    target_field_name = normalize_name(field_name)

    field_values = extract_field_values_from_item_detail(
        item_detail
    )

    for field_value in field_values:
        current_field_name = normalize_name(
            field_value.get("name")
        )

        if current_field_name == target_field_name:
            return field_value_to_text(field_value)

    return None


def log_sample_field_names_for_items(
    codebeamer,
    tracker_name,
    item_references,
    sample_size=3,
):
    logger.warning(
        "Debugging field names for tracker '%s'. "
        "Showing sample of %s item(s).",
        tracker_name,
        sample_size,
    )

    count = 0

    for item_reference in item_references:
        if count >= sample_size:
            break

        item_id = extract_item_id(item_reference)

        if not item_id:
            continue

        try:
            detail = get_item_detail(
                codebeamer,
                item_id,
            )

            fields = extract_field_values_from_item_detail(
                detail
            )

            field_names = [
                str(field.get("name"))
                for field in fields
                if field.get("name")
            ]

            logger.warning(
                "Sample item_id=%s item_name='%s' field_names=%s",
                item_id,
                detail.get("name"),
                field_names,
            )

            count += 1

        except Exception as exception:
            logger.warning(
                "Unable to inspect item_id=%s. Error=%s",
                item_id,
                exception,
            )


# =========================================================
# CODEBEAMER ITEM SEARCH
# =========================================================

def run_item_query(
    codebeamer,
    tracker_id,
    query_string,
    page_size=PAGE_SIZE,
):
    all_items = []
    seen_item_ids = set()
    page = 1

    while True:
        logger.info(
            "Querying tracker_id=%s page=%s query=%s",
            tracker_id,
            page,
            query_string,
        )

        data = codebeamer.post(
            "/v3/items/query",
            params={
                "page": page,
                "pageSize": page_size,
            },
            json={
                "queryString": query_string,
            },
        )

        items = extract_items_from_query_response(data)

        if not items:
            break

        new_items = []

        for item in items:
            item_id = extract_item_id(item)

            if item_id and item_id in seen_item_ids:
                continue

            if item_id:
                seen_item_ids.add(item_id)

            new_items.append(item)

        if not new_items:
            logger.warning(
                "Page %s repeated previously returned item IDs "
                "for tracker_id=%s. Stopping pagination.",
                page,
                tracker_id,
            )
            break

        all_items.extend(new_items)

        logger.info(
            "Tracker %s: loaded page %s with %s item(s), "
            "new item(s)=%s",
            tracker_id,
            page,
            len(items),
            len(new_items),
        )

        if len(items) < page_size:
            break

        page += 1

    return all_items


def query_tracker_items(
    codebeamer,
    tracker_id,
    tracker_name,
    page_size=PAGE_SIZE,
):
    project_ids_csv = get_project_ids_csv()

    log_tracker_debug(
        codebeamer,
        tracker_id,
        tracker_name,
    )

    query_with_project = (
        "tracker.id IN ("
        + str(tracker_id)
        + ") AND project.id IN ("
        + project_ids_csv
        + ")"
    )

    items = run_item_query(
        codebeamer,
        tracker_id,
        query_with_project,
        page_size,
    )

    if items:
        return items

    logger.warning(
        "No items returned for tracker_id=%s tracker_name='%s' "
        "with project filter project_ids=%s. "
        "Trying tracker-only query.",
        tracker_id,
        tracker_name,
        project_ids_csv,
    )

    tracker_only_query = (
        "tracker.id IN ("
        + str(tracker_id)
        + ")"
    )

    fallback_items = run_item_query(
        codebeamer,
        tracker_id,
        tracker_only_query,
        page_size,
    )

    if fallback_items:
        logger.warning(
            "Fallback tracker-only query returned %s item(s) "
            "for tracker_id=%s tracker_name='%s'.",
            len(fallback_items),
            tracker_id,
            tracker_name,
        )

    return fallback_items


def build_sbm_id_index_for_tracker(
    codebeamer,
    tracker_id,
    tracker_name,
    logical_name,
    sbm_field_name,
):
    logger.info(
        "Scanning tracker '%s' tracker_id=%s by field '%s'",
        tracker_name,
        tracker_id,
        sbm_field_name,
    )

    index = {}
    duplicate_rows = []

    item_references = query_tracker_items(
        codebeamer,
        tracker_id,
        tracker_name,
    )

    logger.info(
        "Tracker '%s' returned %s item references",
        tracker_name,
        len(item_references),
    )

    for item_reference in item_references:
        item_id = extract_item_id(item_reference)

        if not item_id:
            continue

        try:
            detail = get_item_detail(
                codebeamer,
                item_id,
            )

            item_name = (
                detail.get("name")
                or extract_item_name(item_reference)
                or str(item_id)
            )

            raw_sbm_id = extract_field_value_by_name(
                detail,
                sbm_field_name,
            )

            sbm_id = normalize_sbm_id(raw_sbm_id)

            if not sbm_id:
                continue

            row = {
                "logical_name": logical_name,
                "tracker_id": tracker_id,
                "tracker_name": tracker_name,
                "sbm_field_name": sbm_field_name,
                "sbm_id": sbm_id,
                "item_id": item_id,
                "item_name": item_name,
            }

            index.setdefault(sbm_id, []).append(row)

        except Exception as exception:
            logger.warning(
                "Failed reading item detail. tracker=%s item=%s error=%s",
                tracker_name,
                item_id,
                exception,
            )

    if item_references and not index:
        logger.warning(
            "Tracker '%s' returned item references but indexed "
            "0 SBM IDs using field '%s'.",
            tracker_name,
            sbm_field_name,
        )

        log_sample_field_names_for_items(
            codebeamer,
            tracker_name,
            item_references,
            3,
        )

    for sbm_id, matches in index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_row = dict(match)
                duplicate_row["duplicate_count"] = len(matches)
                duplicate_rows.append(duplicate_row)

    logger.info(
        "Tracker '%s' indexed %s unique SBM IDs",
        tracker_name,
        len(index),
    )

    return index, duplicate_rows


def build_global_sbm_index(codebeamer):
    global_index = {}
    duplicate_rows = []
    skipped_tracker_rows = []

    for configuration in TRACKER_SEARCH_CONFIG:
        tracker_id = configuration.get("tracker_id")

        if not tracker_id:
            skipped_tracker_rows.append({
                "reason": "Tracker ID not configured; tracker skipped",
                "logical_name": configuration.get("logical_name"),
                "tracker_name": configuration.get("tracker_name"),
                "sbm_field_name": configuration.get("sbm_field_name"),
            })
            continue

        tracker_index, tracker_duplicates = (
            build_sbm_id_index_for_tracker(
                codebeamer,
                int(tracker_id),
                configuration["tracker_name"],
                configuration["logical_name"],
                configuration["sbm_field_name"],
            )
        )

        for sbm_id, matches in tracker_index.items():
            global_index.setdefault(sbm_id, []).extend(matches)

        duplicate_rows.extend(tracker_duplicates)

    existing_duplicate_keys = {
        (
            row.get("sbm_id"),
            row.get("tracker_id"),
            row.get("item_id"),
        )
        for row in duplicate_rows
    }

    for sbm_id, matches in global_index.items():
        if len(matches) <= 1:
            continue

        for match in matches:
            duplicate_key = (
                sbm_id,
                match.get("tracker_id"),
                match.get("item_id"),
            )

            if duplicate_key in existing_duplicate_keys:
                continue

            duplicate_row = dict(match)
            duplicate_row["duplicate_count"] = len(matches)
            duplicate_rows.append(duplicate_row)

            existing_duplicate_keys.add(duplicate_key)

    return (
        global_index,
        duplicate_rows,
        skipped_tracker_rows,
    )


# =========================================================
# ATTACHMENT HELPERS
# =========================================================

def extract_attachments_from_response(data):
    if data is None:
        return []

    if isinstance(data, list):
        return [
            attachment
            for attachment in data
            if isinstance(attachment, dict)
        ]

    if isinstance(data, dict):
        for key in (
            "attachments",
            "items",
            "data",
            "results",
        ):
            value = data.get(key)

            if isinstance(value, list):
                return [
                    attachment
                    for attachment in value
                    if isinstance(attachment, dict)
                ]

        if (
            data.get("id") is not None
            and (
                data.get("name")
                or data.get("fileName")
                or data.get("filename")
            )
        ):
            return [data]

    return []


def extract_attachment_name(attachment):
    if not isinstance(attachment, dict):
        return ""

    for key in (
        "name",
        "fileName",
        "filename",
    ):
        value = attachment.get(key)

        if value:
            return str(value).strip()

    return ""


def extract_attachment_id(attachment):
    if not isinstance(attachment, dict):
        return None

    value = attachment.get("id")

    if value is None:
        return None

    try:
        return int(value)
    except Exception:
        return None


def extract_attachment_size(attachment):
    if not isinstance(attachment, dict):
        return None

    for key in (
        "size",
        "fileSize",
        "fileSizeBytes",
    ):
        value = attachment.get(key)

        if value is None:
            continue

        try:
            return int(value)
        except Exception:
            pass

    return None


def canonical_attachment_name(filename):
    decoded_filename = unquote(
        str(filename or "")
    )

    decoded_filename = (
        decoded_filename
        .strip()
        .casefold()
    )

    return "".join(
        character
        for character in decoded_filename
        if character.isalnum()
    )


def names_are_equivalent(source_name, codebeamer_name):
    if source_name.casefold() == codebeamer_name.casefold():
        return True

    return (
        canonical_attachment_name(source_name)
        == canonical_attachment_name(codebeamer_name)
    )


def get_existing_attachments(codebeamer, item_id):
    try:
        data = codebeamer.get(
            "/v3/items/"
            + str(item_id)
            + "/attachments"
        )

        return extract_attachments_from_response(data)

    except Exception as exception:
        logger.warning(
            "Could not read existing attachments for item %s. Error=%s",
            item_id,
            exception,
        )

        return []


def find_matching_attachment(
    attachments,
    file_path,
    expected_attachment_id=None,
    expected_sha512=None,
):
    local_file_size = file_path.stat().st_size

    if expected_attachment_id is not None:
        for attachment in attachments:
            if (
                extract_attachment_id(attachment)
                == expected_attachment_id
            ):
                return attachment

    if expected_sha512:
        normalized_expected_hash = (
            str(expected_sha512)
            .strip()
            .lower()
        )

        for attachment in attachments:
            remote_hash = str(
                attachment.get("sha512") or ""
            ).strip().lower()

            if (
                remote_hash
                and remote_hash == normalized_expected_hash
            ):
                return attachment

    for attachment in attachments:
        remote_name = extract_attachment_name(
            attachment
        )

        if not remote_name:
            continue

        if not names_are_equivalent(
            file_path.name,
            remote_name,
        ):
            continue

        remote_size = extract_attachment_size(
            attachment
        )

        if (
            remote_size is None
            or remote_size == local_file_size
        ):
            return attachment

    return None


# =========================================================
# ATTACHMENT UPLOAD
# =========================================================

def upload_attachment_once(
    codebeamer,
    item_id,
    file_path,
):
    mime_type = (
        mimetypes.guess_type(
            str(file_path)
        )[0]
        or "application/octet-stream"
    )

    with open(file_path, "rb") as file_object:
        files = {
            "attachments": (
                file_path.name,
                file_object,
                mime_type,
            )
        }

        form_data = {
            "description": ATTACHMENT_DESCRIPTION
        }

        response = codebeamer.post_raw(
            "/v3/items/"
            + str(item_id)
            + "/attachments",
            files=files,
            data=form_data,
        )

    response_text = (
        response.text[:3000]
        if response.text
        else ""
    )

    parsed_response = None

    try:
        parsed_response = response.json()
    except Exception:
        parsed_response = None

    created_attachments = extract_attachments_from_response(
        parsed_response
    )

    if response.status_code >= 400:
        return (
            False,
            "HTTP "
            + str(response.status_code)
            + ": "
            + response_text,
            created_attachments,
            response.status_code,
        )

    return (
        True,
        "HTTP "
        + str(response.status_code)
        + ": "
        + response_text,
        created_attachments,
        response.status_code,
    )


def upload_attachment_verified(
    codebeamer,
    item_id,
    file_path,
):
    logger.info(
        "Trying attachment upload. item=%s file=%s "
        "multipart_field=attachments",
        item_id,
        file_path.name,
    )

    (
        http_success,
        response_message,
        created_attachments,
        response_status,
    ) = upload_attachment_once(
        codebeamer,
        item_id,
        file_path,
    )

    if not http_success:
        return (
            False,
            response_message,
            "",
            None,
            "UPLOAD_REJECTED",
        )

    if not created_attachments:
        return (
            False,
            (
                "Upload returned HTTP "
                + str(response_status)
                + ", but the response did not contain "
                + "a created attachment object. Response="
                + response_message
            ),
            "",
            None,
            "EMPTY_SUCCESS_RESPONSE",
        )

    created_attachment = created_attachments[0]

    returned_attachment_id = extract_attachment_id(
        created_attachment
    )

    returned_file_name = extract_attachment_name(
        created_attachment
    )

    returned_file_size = extract_attachment_size(
        created_attachment
    )

    returned_sha512 = str(
        created_attachment.get("sha512") or ""
    ).strip().lower()

    local_file_size = file_path.stat().st_size

    if (
        returned_file_size is not None
        and returned_file_size != local_file_size
    ):
        return (
            False,
            (
                "Upload response size mismatch. Local size="
                + str(local_file_size)
                + ", Codebeamer size="
                + str(returned_file_size)
                + ". Response="
                + response_message
            ),
            returned_file_name,
            returned_attachment_id,
            "SIZE_MISMATCH",
        )

    for attempt_number in range(
        1,
        ATTACHMENT_VISIBILITY_RETRIES + 1,
    ):
        if attempt_number > 1:
            time.sleep(
                ATTACHMENT_VISIBILITY_WAIT_SEC
            )

        existing_attachments = get_existing_attachments(
            codebeamer,
            item_id,
        )

        matching_attachment = find_matching_attachment(
            existing_attachments,
            file_path,
            returned_attachment_id,
            returned_sha512 if returned_sha512 else None,
        )

        if matching_attachment:
            actual_file_name = (
                extract_attachment_name(
                    matching_attachment
                )
                or returned_file_name
            )

            actual_attachment_id = (
                extract_attachment_id(
                    matching_attachment
                )
                or returned_attachment_id
            )

            return (
                True,
                (
                    "Attachment created and verified through GET. "
                    + "Original filename='"
                    + file_path.name
                    + "', Codebeamer filename='"
                    + actual_file_name
                    + "', attachment_id="
                    + str(actual_attachment_id)
                ),
                actual_file_name,
                actual_attachment_id,
                "POST_AND_GET_VERIFIED",
            )

    # A non-empty HTTP 200 POST response containing an attachment
    # object proves that Codebeamer created the attachment.
    #
    # The result must not be marked failed merely because the GET
    # attachment listing has not yet refreshed or because Codebeamer
    # sanitized the uploaded filename.
    return (
        True,
        (
            "Attachment created and verified from POST response. "
            + "Original filename='"
            + file_path.name
            + "', Codebeamer filename='"
            + returned_file_name
            + "', attachment_id="
            + str(returned_attachment_id)
        ),
        returned_file_name,
        returned_attachment_id,
        "POST_RESPONSE_VERIFIED",
    )


# =========================================================
# CSV REPORT
# =========================================================

def write_csv(path, rows):
    if not rows:
        logger.info(
            "No rows for report: %s",
            path,
        )

        if os.path.exists(path):
            try:
                os.remove(path)

                logger.info(
                    "Removed old report because the current run "
                    "has no records: %s",
                    path,
                )

            except Exception as exception:
                logger.warning(
                    "Unable to remove old report %s: %s",
                    path,
                    exception,
                )

        return

    fieldnames = sorted({
        key
        for row in rows
        for key in row.keys()
    })

    with open(
        path,
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as file_object:
        writer = csv.DictWriter(
            file_object,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(rows)

    logger.info(
        "CSV report written: %s rows=%s",
        path,
        len(rows),
    )


# =========================================================
# EXCEL REPORT
# =========================================================

def get_run_timestamp():
    return datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )


def get_report_datetime_text():
    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


def get_cb_web_base_url(api_base_url):
    base_url = api_base_url.rstrip("/")

    if base_url.endswith("/api"):
        return base_url[:-4]

    return base_url


def build_cb_item_url(item_id):
    if not item_id:
        return ""

    return (
        get_cb_web_base_url(CB_BASE_URL)
        + "/issue/"
        + str(item_id)
    )


def enrich_report_row(
    row,
    run_status,
    report_generated_at,
):
    enriched_row = dict(row)

    source_sbm_id = (
        enriched_row.get("folder_sbm_id")
        or enriched_row.get("sbm_id")
        or enriched_row.get("source_sbm_id")
        or ""
    )

    item_id = (
        enriched_row.get("item_id")
        or enriched_row.get("codebeamer_item_id")
        or ""
    )

    enriched_row["run_status"] = run_status
    enriched_row["report_generated_at"] = report_generated_at
    enriched_row["source_sbm_id"] = source_sbm_id

    if item_id:
        enriched_row["codebeamer_item_id"] = item_id
        enriched_row["codebeamer_item_url"] = build_cb_item_url(
            item_id
        )

        enriched_row["attachment_linkage"] = (
            str(source_sbm_id)
            + " -> Codebeamer Item ID "
            + str(item_id)
        )
    else:
        enriched_row["codebeamer_item_id"] = ""
        enriched_row["codebeamer_item_url"] = ""

        enriched_row["attachment_linkage"] = (
            str(source_sbm_id)
            + " -> NOT FOUND"
        )

    return enriched_row


def sanitize_sheet_name(sheet_name):
    for character in (
        "\\",
        "/",
        "*",
        "[",
        "]",
        ":",
        "?",
    ):
        sheet_name = sheet_name.replace(
            character,
            " ",
        )

    return sheet_name[:31]


def preferred_field_order(all_fields):
    preferred_fields = [
        "run_status",
        "report_generated_at",
        "source_sbm_id",
        "folder_sbm_id",
        "sbm_id",
        "attachment_linkage",
        "codebeamer_item_id",
        "item_id",
        "codebeamer_item_url",
        "logical_name",
        "tracker_id",
        "tracker_name",
        "sbm_field_name",
        "item_name",
        "file_name",
        "codebeamer_file_name",
        "attachment_id",
        "verification_method",
        "file_path",
        "file_size_bytes",
        "folder",
        "status",
        "reason",
        "error",
        "message",
        "duplicate_count",
    ]

    ordered_fields = [
        field
        for field in preferred_fields
        if field in all_fields
    ]

    remaining_fields = sorted([
        field
        for field in all_fields
        if field not in ordered_fields
    ])

    return ordered_fields + remaining_fields


def write_rows_to_sheet(worksheet, rows):
    if not rows:
        worksheet.append([
            "No records available"
        ])

        worksheet["A1"].font = Font(bold=True)
        worksheet.column_dimensions["A"].width = 30

        return

    all_fields = list({
        key
        for row in rows
        for key in row.keys()
    })

    fieldnames = preferred_field_order(
        all_fields
    )

    worksheet.append(fieldnames)

    header_fill = PatternFill(
        "solid",
        fgColor="D9EAF7",
    )

    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
        )

    for row in rows:
        worksheet.append([
            row.get(field, "")
            for field in fieldnames
        ])

    if "codebeamer_item_url" in fieldnames:
        url_column_index = (
            fieldnames.index(
                "codebeamer_item_url"
            )
            + 1
        )

        for row_index in range(
            2,
            worksheet.max_row + 1,
        ):
            cell = worksheet.cell(
                row=row_index,
                column=url_column_index,
            )

            if cell.value:
                cell.hyperlink = cell.value
                cell.style = "Hyperlink"

    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions

    for column_cells in worksheet.columns:
        maximum_length = 0

        column_letter = get_column_letter(
            column_cells[0].column
        )

        for cell in column_cells:
            cell_text = (
                str(cell.value)
                if cell.value is not None
                else ""
            )

            maximum_length = max(
                maximum_length,
                len(cell_text),
            )

        worksheet.column_dimensions[
            column_letter
        ].width = min(
            maximum_length + 2,
            80,
        )


def write_summary_sheet(
    workbook,
    report_generated_at,
    success_rows,
    failed_rows,
    not_found_rows,
    skipped_rows,
    duplicate_rows,
):
    worksheet = workbook.active
    worksheet.title = "Summary"

    total_records = (
        len(success_rows)
        + len(failed_rows)
        + len(not_found_rows)
        + len(skipped_rows)
        + len(duplicate_rows)
    )

    summary_rows = [
        [
            "Report Generated At",
            report_generated_at,
        ],
        [
            "Attachment Root Directory",
            ATTACHMENT_ROOT_DIR,
        ],
        [
            "Project IDs",
            ", ".join(
                str(project_id)
                for project_id in PROJECT_IDS
            ),
        ],
        [
            "Total Records In Excel",
            total_records,
        ],
        [
            "Total Success",
            len(success_rows),
        ],
        [
            "Total Failed",
            len(failed_rows),
        ],
        [
            "Total Not Found",
            len(not_found_rows),
        ],
        [
            "Total Skipped",
            len(skipped_rows),
        ],
        [
            "Total Duplicate Matches",
            len(duplicate_rows),
        ],
    ]

    for summary_row in summary_rows:
        worksheet.append(summary_row)

    title_fill = PatternFill(
        "solid",
        fgColor="D9EAF7",
    )

    for cell in worksheet["A"]:
        cell.font = Font(bold=True)
        cell.fill = title_fill

    worksheet.column_dimensions["A"].width = 35
    worksheet.column_dimensions["B"].width = 100


def write_excel_run_report(
    success_rows,
    failed_rows,
    not_found_rows,
    skipped_rows,
    duplicate_rows,
):
    report_generated_at = get_report_datetime_text()
    timestamp = get_run_timestamp()

    excel_file_name = (
        EXCEL_REPORT_PREFIX
        + "_"
        + timestamp
        + ".xlsx"
    )

    success_enriched = [
        enrich_report_row(
            row,
            "SUCCESS",
            report_generated_at,
        )
        for row in success_rows
    ]

    failed_enriched = [
        enrich_report_row(
            row,
            "FAILED",
            report_generated_at,
        )
        for row in failed_rows
    ]

    not_found_enriched = [
        enrich_report_row(
            row,
            "NOT_FOUND",
            report_generated_at,
        )
        for row in not_found_rows
    ]

    skipped_enriched = [
        enrich_report_row(
            row,
            "SKIPPED",
            report_generated_at,
        )
        for row in skipped_rows
    ]

    duplicate_enriched = [
        enrich_report_row(
            row,
            "DUPLICATE_MATCH",
            report_generated_at,
        )
        for row in duplicate_rows
    ]

    all_rows = (
        success_enriched
        + failed_enriched
        + not_found_enriched
        + skipped_enriched
        + duplicate_enriched
    )

    workbook = Workbook()

    write_summary_sheet(
        workbook,
        report_generated_at,
        success_enriched,
        failed_enriched,
        not_found_enriched,
        skipped_enriched,
        duplicate_enriched,
    )

    sheet_data = [
        ("All Details", all_rows),
        ("Success", success_enriched),
        ("Failed", failed_enriched),
        ("Not Found", not_found_enriched),
        ("Skipped", skipped_enriched),
        ("Duplicate Matches", duplicate_enriched),
    ]

    for sheet_name, rows in sheet_data:
        worksheet = workbook.create_sheet(
            title=sanitize_sheet_name(
                sheet_name
            )
        )

        write_rows_to_sheet(
            worksheet,
            rows,
        )

    workbook.save(excel_file_name)

    logger.info(
        "Excel run report written: %s",
        excel_file_name,
    )

    return excel_file_name


# =========================================================
# MAIN ATTACHMENT PROCESS
# =========================================================

def process_attachment_folders(
    codebeamer,
    global_index,
):
    success_rows = []
    failed_rows = []
    not_found_rows = []
    skipped_rows = []

    folders = iter_attachment_folders(
        ATTACHMENT_ROOT_DIR
    )

    logger.info(
        "Found %s folders under attachment root: %s",
        len(folders),
        ATTACHMENT_ROOT_DIR,
    )

    for folder in folders:
        folder_sbm_id = normalize_sbm_id(
            folder.name
        )

        if not folder_sbm_id:
            skipped_rows.append({
                "folder": str(folder),
                "reason": "Folder name is blank or invalid",
            })
            continue

        files = iter_files_inside_folder(
            folder
        )

        if not files:
            skipped_rows.append({
                "folder_sbm_id": folder_sbm_id,
                "folder": str(folder),
                "reason": "No files found inside folder",
            })

            logger.info(
                "Folder %s skipped: no files",
                folder_sbm_id,
            )

            continue

        matches = global_index.get(
            folder_sbm_id,
            [],
        )

        if not matches:
            for file_path in files:
                not_found_rows.append({
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "file_size_bytes": file_path.stat().st_size,
                    "file_count": len(files),
                    "reason": (
                        "No matching Codebeamer item found in "
                        "configured trackers/projects/fields"
                    ),
                })

            logger.warning(
                "No Codebeamer item found for folder/SBM ID: %s",
                folder_sbm_id,
            )

            continue

        logger.info(
            "Folder %s matched %s Codebeamer item(s); file count=%s",
            folder_sbm_id,
            len(matches),
            len(files),
        )

        for match in matches:
            item_id = int(match["item_id"])

            if SKIP_IF_FILENAME_ALREADY_ATTACHED:
                existing_attachments = get_existing_attachments(
                    codebeamer,
                    item_id,
                )
            else:
                existing_attachments = []

            for file_path in files:
                if not file_path.is_file():
                    continue

                common_row = {
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "file_path": str(file_path),
                    "file_name": file_path.name,
                    "file_size_bytes": file_path.stat().st_size,
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": item_id,
                    "item_name": match.get("item_name"),
                }

                existing_match = None

                if SKIP_IF_FILENAME_ALREADY_ATTACHED:
                    existing_match = find_matching_attachment(
                        existing_attachments,
                        file_path,
                    )

                if existing_match:
                    codebeamer_file_name = extract_attachment_name(
                        existing_match
                    )

                    existing_attachment_id = extract_attachment_id(
                        existing_match
                    )

                    skipped_row = dict(common_row)

                    skipped_row.update({
                        "codebeamer_file_name": codebeamer_file_name,
                        "attachment_id": existing_attachment_id,
                        "reason": (
                            "Equivalent attachment already exists. "
                            "Duplicate check used sanitized filename "
                            "and file size."
                        ),
                    })

                    skipped_rows.append(
                        skipped_row
                    )

                    logger.info(
                        "Skipped duplicate attachment. "
                        "item=%s source_file=%s "
                        "codebeamer_file=%s attachment_id=%s",
                        item_id,
                        file_path.name,
                        codebeamer_file_name,
                        existing_attachment_id,
                    )

                    continue

                (
                    upload_success,
                    upload_message,
                    codebeamer_file_name,
                    attachment_id,
                    verification_method,
                ) = upload_attachment_verified(
                    codebeamer,
                    item_id,
                    file_path,
                )

                if upload_success:
                    success_row = dict(common_row)

                    success_row.update({
                        "codebeamer_file_name": codebeamer_file_name,
                        "attachment_id": attachment_id,
                        "verification_method": verification_method,
                        "status": "ATTACHED_AND_VERIFIED",
                        "message": upload_message,
                    })

                    success_rows.append(
                        success_row
                    )

                    logger.info(
                        "Attached successfully. item=%s "
                        "source_file=%s codebeamer_file=%s "
                        "attachment_id=%s verification=%s",
                        item_id,
                        file_path.name,
                        codebeamer_file_name,
                        attachment_id,
                        verification_method,
                    )

                    existing_attachments.append({
                        "id": attachment_id,
                        "name": codebeamer_file_name,
                        "size": file_path.stat().st_size,
                    })

                else:
                    failed_row = dict(common_row)

                    failed_row.update({
                        "codebeamer_file_name": codebeamer_file_name,
                        "attachment_id": attachment_id,
                        "verification_method": verification_method,
                        "error": upload_message,
                    })

                    failed_rows.append(
                        failed_row
                    )

                    logger.error(
                        "Attachment failed. item=%s file=%s error=%s",
                        item_id,
                        file_path,
                        upload_message,
                    )

    return (
        success_rows,
        failed_rows,
        not_found_rows,
        skipped_rows,
    )


# =========================================================
# MAIN
# =========================================================

def main():
    acquire_run_lock()

    try:
        logger.info(
            "Starting Codebeamer attachment folder import"
        )

        logger.info(
            "Attachment root directory: %s",
            ATTACHMENT_ROOT_DIR,
        )

        logger.info(
            "Project IDs configured: %s",
            PROJECT_IDS,
        )

        codebeamer = CodebeamerClient(
            base_url=CB_BASE_URL,
            username=CB_USER,
            password=CB_PASS,
            verify_ssl=VERIFY_SSL,
            timeout=TIMEOUT,
        )

        (
            global_index,
            duplicate_rows,
            skipped_tracker_rows,
        ) = build_global_sbm_index(
            codebeamer
        )

        logger.info(
            "Global SBM index contains %s unique SBM IDs",
            len(global_index),
        )

        (
            success_rows,
            failed_rows,
            not_found_rows,
            skipped_rows,
        ) = process_attachment_folders(
            codebeamer,
            global_index,
        )

        skipped_rows.extend(
            skipped_tracker_rows
        )

        write_csv(
            SUCCESS_CSV,
            success_rows,
        )

        write_csv(
            FAILED_CSV,
            failed_rows,
        )

        write_csv(
            NOT_FOUND_CSV,
            not_found_rows,
        )

        write_csv(
            SKIPPED_CSV,
            skipped_rows,
        )

        write_csv(
            DUPLICATE_MATCH_CSV,
            duplicate_rows,
        )

        excel_report_file = write_excel_run_report(
            success_rows,
            failed_rows,
            not_found_rows,
            skipped_rows,
            duplicate_rows,
        )

        logger.info(
            "Run-wise Excel report created: %s",
            excel_report_file,
        )

        logger.info(
            "Attachment import completed. "
            "Success=%s Failed=%s NotFound=%s "
            "Skipped=%s DuplicateMatches=%s "
            "ExcelReport=%s",
            len(success_rows),
            len(failed_rows),
            len(not_found_rows),
            len(skipped_rows),
            len(duplicate_rows),
            excel_report_file,
        )

    finally:
        release_run_lock()


if __name__ == "__main__":
    main()
