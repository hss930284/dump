#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import csv
import time
import logging
import mimetypes
import zipfile
from pathlib import Path
from datetime import datetime
from urllib.parse import unquote

import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# =========================================================
# CONFIGURATION
# =========================================================

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 60
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_IDS = [48, 47]

ATTACHMENT_ROOT_DIR = r"D:\SBM_ATTACHMENTS"

ONLY_DIRECT_FILES = True
SKIP_IF_FILENAME_ALREADY_ATTACHED = True

ATTACHMENT_DESCRIPTION = "Attachment migrated from SBM source folder."

PAGE_SIZE = 50

ATTACHMENT_VISIBILITY_RETRIES = 4
ATTACHMENT_VISIBILITY_WAIT_SEC = 1.0

# Automatically package these blocked file types as ZIP.
ZIP_BLOCKED_FILE_TYPES = True

BLOCKED_FILE_EXTENSIONS = {
    ".html",
    ".htm",
}

# The generated ZIP is created beside the original HTML file.
# Example:
# Identifications.html
# Identifications.html.zip
GENERATED_ZIP_SUFFIX = ".zip"

LOG_FILE = "cb_attachment_import.log"
RUN_LOCK_FILE = "cb_attachment_import.lock"

SUCCESS_CSV = "attachment_import_success.csv"
FAILED_CSV = "attachment_import_failed.csv"
NOT_FOUND_CSV = "attachment_folder_ids_not_found.csv"
SKIPPED_CSV = "attachment_import_skipped.csv"
DUPLICATE_MATCH_CSV = "attachment_duplicate_item_matches.csv"

EXCEL_REPORT_PREFIX = "attachment_import_run_report"


# =========================================================
# TRACKER CONFIGURATION
# =========================================================

TRACKER_SEARCH_CONFIG = [
    {
        "logical_name": "Issue",
        "tracker_id": 294498,
        "tracker_name": "Issue",
        "sbm_field_name": "SBM Item Id",
    },
    {
        "logical_name": "Retex",
        "tracker_id": 294309,
        "tracker_name": "Retex",
        "sbm_field_name": "SBM Retex Id",
    },
    {
        "logical_name": "SDT",
        "tracker_id": 295425,
        "tracker_name": "A-EMS Specification",
        "sbm_field_name": "SBM SDT Id",
    },
    {
        "logical_name": "MDT",
        "tracker_id": 295368,
        "tracker_name": "A-EMS Module",
        "sbm_field_name": "SBM MDT Id",
    },
    {
        "logical_name": "Change Request",
        "tracker_id": 293926,
        "tracker_name": "Change Request",
        "sbm_field_name": "SBM CR Id",
    },
    {
        "logical_name": "Tag Management",
        "tracker_id": 293706,
        "tracker_name": "Tag Management",
        "sbm_field_name": "SBM Tag Id",
    },
    {
        "logical_name": "New Function",
        "tracker_id": 301069,
        "tracker_name": "New Function",
        "sbm_field_name": "SBM NF Id",
    },
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger_object = logging.getLogger("cb_attachment_import")
    logger_object.setLevel(logging.INFO)
    logger_object.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(
        LOG_FILE,
        mode="a",
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    logger_object.addHandler(console_handler)
    logger_object.addHandler(file_handler)

    return logger_object


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(value):
    return re.sub(
        r"\s+",
        " ",
        str(value or "").strip(),
    ).lower()


def normalize_sbm_id(value):
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    return re.sub(r"\s+", "", text).upper()


def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def get_project_ids_csv():
    valid_project_ids = []

    for project_id in PROJECT_IDS:
        if project_id is None:
            continue

        project_id_text = str(project_id).strip()

        if project_id_text:
            valid_project_ids.append(project_id_text)

    if not valid_project_ids:
        raise ValueError(
            "PROJECT_IDS is empty. "
            "Please configure at least one project ID."
        )

    return ",".join(valid_project_ids)


def is_generated_html_zip(file_path):
    """
    Returns True when the file is a ZIP generated from an HTML/HTM file.

    Examples:
    file.html.zip
    file.htm.zip
    """

    lower_name = file_path.name.lower()

    for blocked_extension in BLOCKED_FILE_EXTENSIONS:
        generated_suffix = (
            blocked_extension.lower()
            + GENERATED_ZIP_SUFFIX.lower()
        )

        if lower_name.endswith(generated_suffix):
            original_name = file_path.name[
                :-len(GENERATED_ZIP_SUFFIX)
            ]

            original_path = file_path.with_name(
                original_name
            )

            if original_path.exists():
                return True

    return False


def iter_attachment_folders(root_dir):
    root = Path(root_dir)

    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(
            "ATTACHMENT_ROOT_DIR does not exist "
            "or is not a directory: "
            + str(root_dir)
        )

    folders = [
        path
        for path in root.iterdir()
        if path.is_dir()
    ]

    folders.sort(
        key=lambda path: path.name.upper()
    )

    return folders


def iter_files_inside_folder(folder):
    """
    Returns source files that should be processed.

    Generated .html.zip or .htm.zip files are excluded when
    the corresponding original HTML/HTM file exists.

    This prevents the ZIP from being processed twice:
    1. Once when the HTML is converted.
    2. Again as a separate ZIP file.
    """

    if ONLY_DIRECT_FILES:
        candidate_files = [
            path
            for path in folder.iterdir()
            if path.is_file()
        ]
    else:
        candidate_files = [
            path
            for path in folder.rglob("*")
            if path.is_file()
        ]

    files = []

    for file_path in candidate_files:
        if is_generated_html_zip(file_path):
            logger.info(
                "Generated HTML ZIP excluded from direct processing: %s",
                file_path,
            )
            continue

        files.append(file_path)

    files.sort(
        key=lambda path: str(path).upper()
    )

    return files


def is_pid_running(pid):
    if not pid:
        return False

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_run_lock():
    if os.path.exists(RUN_LOCK_FILE):
        try:
            existing_pid_text = Path(
                RUN_LOCK_FILE
            ).read_text(
                encoding="utf-8"
            ).strip()

            existing_pid = int(
                existing_pid_text
            )

            if is_pid_running(existing_pid):
                raise RuntimeError(
                    "Another run appears active. "
                    "Lock file="
                    + RUN_LOCK_FILE
                    + ", PID="
                    + str(existing_pid)
                )

        except ValueError:
            pass

        logger.warning(
            "Removing stale lock file: %s",
            RUN_LOCK_FILE,
        )

        os.remove(RUN_LOCK_FILE)

    Path(RUN_LOCK_FILE).write_text(
        str(os.getpid()),
        encoding="utf-8",
    )

    logger.info(
        "Run lock acquired: %s",
        RUN_LOCK_FILE,
    )


def release_run_lock():
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)

            logger.info(
                "Run lock released: %s",
                RUN_LOCK_FILE,
            )

    except Exception as exception:
        logger.warning(
            "Unable to release lock file %s: %s",
            RUN_LOCK_FILE,
            exception,
        )


# =========================================================
# HTML TO ZIP HELPERS
# =========================================================

def should_package_file_as_zip(file_path):
    if not ZIP_BLOCKED_FILE_TYPES:
        return False

    return (
        file_path.suffix.lower()
        in BLOCKED_FILE_EXTENSIONS
    )


def get_generated_zip_path(file_path):
    """
    Example:
    Identifications.html
    becomes:
    Identifications.html.zip
    """

    return file_path.with_name(
        file_path.name + GENERATED_ZIP_SUFFIX
    )


def validate_generated_zip(zip_file_path, expected_file_name):
    """
    Confirms that the ZIP exists, is readable and contains
    the expected original attachment filename.
    """

    if not zip_file_path.exists():
        return False

    if not zip_file_path.is_file():
        return False

    if zip_file_path.stat().st_size <= 0:
        return False

    try:
        with zipfile.ZipFile(
            zip_file_path,
            mode="r",
        ) as zip_file:
            bad_entry = zip_file.testzip()

            if bad_entry is not None:
                logger.warning(
                    "ZIP validation failed. "
                    "Corrupt ZIP entry=%s ZIP=%s",
                    bad_entry,
                    zip_file_path,
                )
                return False

            zip_names = zip_file.namelist()

            if expected_file_name not in zip_names:
                logger.warning(
                    "ZIP does not contain expected file. "
                    "Expected=%s ZIP=%s Contents=%s",
                    expected_file_name,
                    zip_file_path,
                    zip_names,
                )
                return False

        return True

    except Exception as exception:
        logger.warning(
            "Unable to validate generated ZIP. "
            "ZIP=%s Error=%s",
            zip_file_path,
            exception,
        )
        return False


def create_zip_for_blocked_file(file_path):
    """
    Creates or reuses a ZIP for HTML/HTM files.

    Existing ZIP reuse rules:
    - ZIP must be newer than or the same age as the source.
    - ZIP must be valid.
    - ZIP must contain the expected original filename.
    """

    if not file_path.exists():
        raise FileNotFoundError(
            "Source file does not exist: "
            + str(file_path)
        )

    if not file_path.is_file():
        raise ValueError(
            "Source path is not a file: "
            + str(file_path)
        )

    zip_file_path = get_generated_zip_path(
        file_path
    )

    reuse_existing_zip = False

    if zip_file_path.exists():
        source_modified_time = (
            file_path.stat().st_mtime
        )

        zip_modified_time = (
            zip_file_path.stat().st_mtime
        )

        if (
            zip_modified_time
            >= source_modified_time
        ):
            reuse_existing_zip = (
                validate_generated_zip(
                    zip_file_path,
                    file_path.name,
                )
            )

    if reuse_existing_zip:
        logger.info(
            "Using existing valid ZIP package. "
            "Source=%s ZIP=%s",
            file_path,
            zip_file_path,
        )

        return zip_file_path

    if zip_file_path.exists():
        logger.info(
            "Removing outdated or invalid ZIP package: %s",
            zip_file_path,
        )

        zip_file_path.unlink()

    logger.info(
        "Creating ZIP package for blocked file type. "
        "Source=%s ZIP=%s",
        file_path,
        zip_file_path,
    )

    try:
        with zipfile.ZipFile(
            zip_file_path,
            mode="w",
            compression=zipfile.ZIP_DEFLATED,
            allowZip64=True,
        ) as zip_file:
            zip_file.write(
                file_path,
                arcname=file_path.name,
            )

    except Exception:
        if zip_file_path.exists():
            try:
                zip_file_path.unlink()
            except Exception:
                pass

        raise

    if not validate_generated_zip(
        zip_file_path,
        file_path.name,
    ):
        if zip_file_path.exists():
            try:
                zip_file_path.unlink()
            except Exception:
                pass

        raise RuntimeError(
            "Generated ZIP failed validation: "
            + str(zip_file_path)
        )

    logger.info(
        "ZIP package created and validated. "
        "Source=%s ZIP=%s ZIPSize=%s",
        file_path,
        zip_file_path,
        zip_file_path.stat().st_size,
    )

    return zip_file_path


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:

    def __init__(
        self,
        base_url,
        username,
        password,
        verify_ssl=True,
        timeout=60,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()

        self.session.auth = HTTPBasicAuth(
            username,
            password,
        )

        self.session.verify = verify_ssl

        self.session.headers.update({
            "Accept": "application/json"
        })

        retry = Retry(
            total=5,
            connect=5,
            read=5,
            status=5,
            backoff_factor=1,
            status_forcelist=(
                429,
                500,
                502,
                503,
                504,
            ),
            allowed_methods=frozenset([
                "GET",
                "POST",
                "PUT",
                "PATCH",
                "DELETE",
            ]),
            raise_on_status=False,
        )

        adapter = HTTPAdapter(
            max_retries=retry
        )

        self.session.mount(
            "http://",
            adapter,
        )

        self.session.mount(
            "https://",
            adapter,
        )

    def build_url(self, path):
        return (
            self.base_url
            + "/"
            + path.lstrip("/")
        )

    def request(
        self,
        method,
        path,
        **kwargs
    ):
        url = self.build_url(path)

        kwargs.setdefault(
            "timeout",
            self.timeout,
        )

        response = self.session.request(
            method,
            url,
            **kwargs,
        )

        safe_sleep()

        if response.status_code >= 400:
            response_text = (
                response.text[:3000]
                if response.text
                else ""
            )

            raise RuntimeError(
                "Codebeamer API error "
                + str(response.status_code)
                + " for "
                + method
                + " "
                + url
                + ": "
                + response_text
            )

        if (
            response.status_code == 204
            or not response.text
        ):
            return None

        try:
            return response.json()
        except Exception:
            return response.text

    def get(self, path, **kwargs):
        return self.request(
            "GET",
            path,
            **kwargs,
        )

    def post(self, path, **kwargs):
        return self.request(
            "POST",
            path,
            **kwargs,
        )

    def post_raw(self, path, **kwargs):
        url = self.build_url(path)

        kwargs.setdefault(
            "timeout",
            self.timeout,
        )

        response = self.session.post(
            url,
            **kwargs,
        )

        safe_sleep()

        return response


# =========================================================
# QUERY RESPONSE HELPERS
# =========================================================

def extract_items_from_query_response(data):
    if data is None:
        return []

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in (
            "items",
            "itemRefs",
            "results",
            "data",
        ):
            value = data.get(key)

            if isinstance(value, list):
                return value

    return []


def extract_item_id(item_reference):
    if not isinstance(
        item_reference,
        dict,
    ):
        return None

    for key in ("id", "itemId"):
        value = item_reference.get(key)

        if value is not None:
            try:
                return int(value)
            except Exception:
                pass

    nested_item = item_reference.get(
        "item"
    )

    if isinstance(nested_item, dict):
        value = nested_item.get("id")

        if value is not None:
            try:
                return int(value)
            except Exception:
                pass

    return None


def extract_item_name(item_reference):
    if not isinstance(
        item_reference,
        dict,
    ):
        return ""

    for key in ("name", "summary"):
        value = item_reference.get(key)

        if value:
            return str(value)

    nested_item = item_reference.get(
        "item"
    )

    if isinstance(nested_item, dict):
        value = nested_item.get("name")

        if value:
            return str(value)

    return ""


# =========================================================
# TRACKER AND ITEM HELPERS
# =========================================================

def get_tracker_detail(
    codebeamer,
    tracker_id,
):
    try:
        data = codebeamer.get(
            "/v3/trackers/"
            + str(tracker_id)
        )

        if isinstance(data, dict):
            return data

    except Exception as exception:
        logger.warning(
            "Unable to fetch tracker detail "
            "for tracker_id=%s. Error=%s",
            tracker_id,
            exception,
        )

    return {}


def log_tracker_debug(
    codebeamer,
    tracker_id,
    tracker_name,
):
    detail = get_tracker_detail(
        codebeamer,
        tracker_id,
    )

    if not detail:
        logger.warning(
            "Tracker debug: no detail returned "
            "for tracker_name=%s tracker_id=%s",
            tracker_name,
            tracker_id,
        )
        return

    project_information = (
        detail.get("project")
        or {}
    )

    logger.info(
        "Tracker debug: "
        "configured_tracker_name='%s', "
        "tracker_id=%s, "
        "api_tracker_name='%s', "
        "api_project_id='%s', "
        "api_project_name='%s'",
        tracker_name,
        tracker_id,
        detail.get("name"),
        project_information.get("id"),
        project_information.get("name"),
    )


def get_item_detail(
    codebeamer,
    item_id,
):
    data = codebeamer.get(
        "/v3/items/"
        + str(item_id)
    )

    if isinstance(data, dict):
        return data

    return {}


def extract_field_values_from_item_detail(
    item_detail,
):
    if not isinstance(
        item_detail,
        dict,
    ):
        return []

    for key in (
        "customFields",
        "fields",
        "fieldValues",
    ):
        value = item_detail.get(key)

        if isinstance(value, list):
            return value

    return []


def field_value_to_text(field_value):
    if not isinstance(
        field_value,
        dict,
    ):
        return None

    for key in (
        "value",
        "text",
        "name",
    ):
        value = field_value.get(key)

        if (
            value is not None
            and not isinstance(
                value,
                (dict, list),
            )
        ):
            return str(value).strip()

    values = field_value.get(
        "values"
    )

    if isinstance(values, list):
        parts = []

        for value in values:
            if isinstance(value, dict):
                part = (
                    value.get("name")
                    or value.get("value")
                    or value.get("id")
                    or ""
                )
            else:
                part = value

            part_text = str(part).strip()

            if part_text:
                parts.append(part_text)

        if parts:
            return ";".join(parts)

    return None


def extract_field_value_by_name(
    item_detail,
    field_name,
):
    target_name = normalize_name(
        field_name
    )

    fields = (
        extract_field_values_from_item_detail(
            item_detail
        )
    )

    for field_value in fields:
        current_name = normalize_name(
            field_value.get("name")
        )

        if current_name == target_name:
            return field_value_to_text(
                field_value
            )

    return None


def log_sample_field_names_for_items(
    codebeamer,
    tracker_name,
    item_references,
    sample_size=3,
):
    count = 0

    for item_reference in item_references:
        if count >= sample_size:
            break

        item_id = extract_item_id(
            item_reference
        )

        if not item_id:
            continue

        try:
            detail = get_item_detail(
                codebeamer,
                item_id,
            )

            fields = (
                extract_field_values_from_item_detail(
                    detail
                )
            )

            field_names = [
                str(field.get("name"))
                for field in fields
                if field.get("name")
            ]

            logger.warning(
                "Sample item_id=%s "
                "item_name='%s' field_names=%s",
                item_id,
                detail.get("name"),
                field_names,
            )

            count += 1

        except Exception as exception:
            logger.warning(
                "Unable to inspect item_id=%s. Error=%s",
                item_id,
                exception,
            )


# =========================================================
# CODEBEAMER ITEM SEARCH
# =========================================================

def run_item_query(
    codebeamer,
    tracker_id,
    query_string,
    page_size=PAGE_SIZE,
):
    all_items = []
    seen_item_ids = set()
    page = 1

    while True:
        logger.info(
            "Querying tracker_id=%s "
            "page=%s query=%s",
            tracker_id,
            page,
            query_string,
        )

        data = codebeamer.post(
            "/v3/items/query",
            params={
                "page": page,
                "pageSize": page_size,
            },
            json={
                "queryString": query_string
            },
        )

        items = (
            extract_items_from_query_response(
                data
            )
        )

        if not items:
            break

        new_items = []

        for item in items:
            item_id = extract_item_id(
                item
            )

            if (
                item_id
                and item_id in seen_item_ids
            ):
                continue

            if item_id:
                seen_item_ids.add(
                    item_id
                )

            new_items.append(item)

        if not new_items:
            logger.warning(
                "Page %s repeated previous "
                "item IDs for tracker_id=%s. "
                "Stopping pagination.",
                page,
                tracker_id,
            )
            break

        all_items.extend(
            new_items
        )

        logger.info(
            "Tracker %s: loaded page %s "
            "with %s item(s), new=%s",
            tracker_id,
            page,
            len(items),
            len(new_items),
        )

        if len(items) < page_size:
            break

        page += 1

    return all_items


def query_tracker_items(
    codebeamer,
    tracker_id,
    tracker_name,
):
    project_ids_csv = (
        get_project_ids_csv()
    )

    log_tracker_debug(
        codebeamer,
        tracker_id,
        tracker_name,
    )

    project_query = (
        "tracker.id IN ("
        + str(tracker_id)
        + ") AND project.id IN ("
        + project_ids_csv
        + ")"
    )

    items = run_item_query(
        codebeamer,
        tracker_id,
        project_query,
    )

    if items:
        return items

    logger.warning(
        "No items returned with project filter "
        "for tracker_id=%s. "
        "Trying tracker-only query.",
        tracker_id,
    )

    tracker_query = (
        "tracker.id IN ("
        + str(tracker_id)
        + ")"
    )

    return run_item_query(
        codebeamer,
        tracker_id,
        tracker_query,
    )


def build_sbm_id_index_for_tracker(
    codebeamer,
    tracker_id,
    tracker_name,
    logical_name,
    sbm_field_name,
):
    logger.info(
        "Scanning tracker '%s' tracker_id=%s "
        "by field '%s'",
        tracker_name,
        tracker_id,
        sbm_field_name,
    )

    index = {}
    duplicate_rows = []

    item_references = query_tracker_items(
        codebeamer,
        tracker_id,
        tracker_name,
    )

    logger.info(
        "Tracker '%s' returned %s item references",
        tracker_name,
        len(item_references),
    )

    for item_reference in item_references:
        item_id = extract_item_id(
            item_reference
        )

        if not item_id:
            continue

        try:
            detail = get_item_detail(
                codebeamer,
                item_id,
            )

            item_name = (
                detail.get("name")
                or extract_item_name(
                    item_reference
                )
                or str(item_id)
            )

            raw_sbm_id = (
                extract_field_value_by_name(
                    detail,
                    sbm_field_name,
                )
            )

            sbm_id = normalize_sbm_id(
                raw_sbm_id
            )

            if not sbm_id:
                continue

            row = {
                "logical_name": logical_name,
                "tracker_id": tracker_id,
                "tracker_name": tracker_name,
                "sbm_field_name": sbm_field_name,
                "sbm_id": sbm_id,
                "item_id": item_id,
                "item_name": item_name,
            }

            index.setdefault(
                sbm_id,
                [],
            ).append(row)

        except Exception as exception:
            logger.warning(
                "Failed reading item detail. "
                "tracker=%s item=%s error=%s",
                tracker_name,
                item_id,
                exception,
            )

    if item_references and not index:
        logger.warning(
            "Tracker '%s' returned items but "
            "indexed 0 SBM IDs using field '%s'.",
            tracker_name,
            sbm_field_name,
        )

        log_sample_field_names_for_items(
            codebeamer,
            tracker_name,
            item_references,
        )

    for sbm_id, matches in index.items():
        if len(matches) > 1:
            for match in matches:
                duplicate_row = dict(
                    match
                )

                duplicate_row[
                    "duplicate_count"
                ] = len(matches)

                duplicate_rows.append(
                    duplicate_row
                )

    logger.info(
        "Tracker '%s' indexed %s unique SBM IDs",
        tracker_name,
        len(index),
    )

    return index, duplicate_rows


def build_global_sbm_index(
    codebeamer,
):
    global_index = {}
    duplicate_rows = []
    skipped_tracker_rows = []

    for configuration in TRACKER_SEARCH_CONFIG:
        tracker_id = configuration.get(
            "tracker_id"
        )

        if not tracker_id:
            skipped_tracker_rows.append({
                "reason": (
                    "Tracker ID not configured; "
                    "tracker skipped"
                ),
                "logical_name": configuration.get(
                    "logical_name"
                ),
                "tracker_name": configuration.get(
                    "tracker_name"
                ),
                "sbm_field_name": configuration.get(
                    "sbm_field_name"
                ),
            })
            continue

        (
            tracker_index,
            tracker_duplicates,
        ) = build_sbm_id_index_for_tracker(
            codebeamer,
            int(tracker_id),
            configuration["tracker_name"],
            configuration["logical_name"],
            configuration["sbm_field_name"],
        )

        for sbm_id, matches in tracker_index.items():
            global_index.setdefault(
                sbm_id,
                [],
            ).extend(matches)

        duplicate_rows.extend(
            tracker_duplicates
        )

    return (
        global_index,
        duplicate_rows,
        skipped_tracker_rows,
    )


# =========================================================
# ATTACHMENT HELPERS
# =========================================================

def extract_attachments_from_response(data):
    if data is None:
        return []

    if isinstance(data, list):
        return [
            attachment
            for attachment in data
            if isinstance(
                attachment,
                dict,
            )
        ]

    if isinstance(data, dict):
        for key in (
            "attachments",
            "items",
            "data",
            "results",
        ):
            value = data.get(key)

            if isinstance(value, list):
                return [
                    attachment
                    for attachment in value
                    if isinstance(
                        attachment,
                        dict,
                    )
                ]

        if (
            data.get("id") is not None
            and (
                data.get("name")
                or data.get("fileName")
                or data.get("filename")
            )
        ):
            return [data]

    return []


def extract_attachment_name(
    attachment,
):
    if not isinstance(
        attachment,
        dict,
    ):
        return ""

    for key in (
        "name",
        "fileName",
        "filename",
    ):
        value = attachment.get(key)

        if value:
            return str(value).strip()

    return ""


def extract_attachment_id(
    attachment,
):
    if not isinstance(
        attachment,
        dict,
    ):
        return None

    value = attachment.get("id")

    try:
        return int(value)
    except Exception:
        return None


def extract_attachment_size(
    attachment,
):
    if not isinstance(
        attachment,
        dict,
    ):
        return None

    for key in (
        "size",
        "fileSize",
        "fileSizeBytes",
    ):
        value = attachment.get(key)

        if value is None:
            continue

        try:
            return int(value)
        except Exception:
            pass

    return None


def canonical_attachment_name(
    filename,
):
    decoded_filename = unquote(
        str(filename or "")
    )

    decoded_filename = (
        decoded_filename
        .strip()
        .casefold()
    )

    return "".join(
        character
        for character in decoded_filename
        if character.isalnum()
    )


def names_are_equivalent(
    source_name,
    codebeamer_name,
):
    if (
        source_name.casefold()
        == codebeamer_name.casefold()
    ):
        return True

    return (
        canonical_attachment_name(
            source_name
        )
        == canonical_attachment_name(
            codebeamer_name
        )
    )


def get_existing_attachments(
    codebeamer,
    item_id,
):
    try:
        data = codebeamer.get(
            "/v3/items/"
            + str(item_id)
            + "/attachments"
        )

        return (
            extract_attachments_from_response(
                data
            )
        )

    except Exception as exception:
        logger.warning(
            "Could not read attachments "
            "for item %s. Error=%s",
            item_id,
            exception,
        )

        return []


def find_matching_attachment(
    attachments,
    file_path,
    expected_attachment_id=None,
    expected_sha512=None,
):
    local_file_size = (
        file_path.stat().st_size
    )

    if expected_attachment_id is not None:
        for attachment in attachments:
            if (
                extract_attachment_id(
                    attachment
                )
                == expected_attachment_id
            ):
                return attachment

    if expected_sha512:
        normalized_hash = str(
            expected_sha512
        ).strip().lower()

        for attachment in attachments:
            remote_hash = str(
                attachment.get("sha512")
                or ""
            ).strip().lower()

            if (
                remote_hash
                and remote_hash
                == normalized_hash
            ):
                return attachment

    for attachment in attachments:
        remote_name = (
            extract_attachment_name(
                attachment
            )
        )

        if not remote_name:
            continue

        if not names_are_equivalent(
            file_path.name,
            remote_name,
        ):
            continue

        remote_size = (
            extract_attachment_size(
                attachment
            )
        )

        if (
            remote_size is None
            or remote_size
            == local_file_size
        ):
            return attachment

    return None


# =========================================================
# ATTACHMENT UPLOAD
# =========================================================

def upload_attachment_once(
    codebeamer,
    item_id,
    file_path,
):
    mime_type = (
        mimetypes.guess_type(
            str(file_path)
        )[0]
        or "application/octet-stream"
    )

    with open(
        file_path,
        "rb",
    ) as file_object:
        files = {
            "attachments": (
                file_path.name,
                file_object,
                mime_type,
            )
        }

        form_data = {
            "description": (
                ATTACHMENT_DESCRIPTION
            )
        }

        response = codebeamer.post_raw(
            "/v3/items/"
            + str(item_id)
            + "/attachments",
            files=files,
            data=form_data,
        )

    response_text = (
        response.text[:3000]
        if response.text
        else ""
    )

    try:
        parsed_response = response.json()
    except Exception:
        parsed_response = None

    created_attachments = (
        extract_attachments_from_response(
            parsed_response
        )
    )

    if response.status_code >= 400:
        return (
            False,
            "HTTP "
            + str(response.status_code)
            + ": "
            + response_text,
            created_attachments,
            response.status_code,
        )

    return (
        True,
        "HTTP "
        + str(response.status_code)
        + ": "
        + response_text,
        created_attachments,
        response.status_code,
    )


def upload_attachment_verified(
    codebeamer,
    item_id,
    file_path,
):
    logger.info(
        "Trying attachment upload. "
        "item=%s file=%s "
        "multipart_field=attachments",
        item_id,
        file_path.name,
    )

    (
        http_success,
        response_message,
        created_attachments,
        response_status,
    ) = upload_attachment_once(
        codebeamer,
        item_id,
        file_path,
    )

    if not http_success:
        return (
            False,
            response_message,
            "",
            None,
            "UPLOAD_REJECTED",
        )

    if not created_attachments:
        return (
            False,
            (
                "Upload returned HTTP "
                + str(response_status)
                + ", but no created attachment "
                + "object was returned. Response="
                + response_message
            ),
            "",
            None,
            "EMPTY_SUCCESS_RESPONSE",
        )

    created_attachment = (
        created_attachments[0]
    )

    returned_attachment_id = (
        extract_attachment_id(
            created_attachment
        )
    )

    returned_file_name = (
        extract_attachment_name(
            created_attachment
        )
    )

    returned_file_size = (
        extract_attachment_size(
            created_attachment
        )
    )

    returned_sha512 = str(
        created_attachment.get("sha512")
        or ""
    ).strip().lower()

    local_file_size = (
        file_path.stat().st_size
    )

    if (
        returned_file_size is not None
        and returned_file_size
        != local_file_size
    ):
        return (
            False,
            (
                "Upload response size mismatch. "
                + "Local size="
                + str(local_file_size)
                + ", Codebeamer size="
                + str(returned_file_size)
            ),
            returned_file_name,
            returned_attachment_id,
            "SIZE_MISMATCH",
        )

    for attempt_number in range(
        1,
        ATTACHMENT_VISIBILITY_RETRIES + 1,
    ):
        if attempt_number > 1:
            time.sleep(
                ATTACHMENT_VISIBILITY_WAIT_SEC
            )

        existing_attachments = (
            get_existing_attachments(
                codebeamer,
                item_id,
            )
        )

        matching_attachment = (
            find_matching_attachment(
                existing_attachments,
                file_path,
                returned_attachment_id,
                (
                    returned_sha512
                    if returned_sha512
                    else None
                ),
            )
        )

        if matching_attachment:
            actual_file_name = (
                extract_attachment_name(
                    matching_attachment
                )
                or returned_file_name
            )

            actual_attachment_id = (
                extract_attachment_id(
                    matching_attachment
                )
                or returned_attachment_id
            )

            return (
                True,
                (
                    "Attachment created and "
                    "verified through GET. "
                    + "Source='"
                    + file_path.name
                    + "', Codebeamer='"
                    + actual_file_name
                    + "', attachment_id="
                    + str(actual_attachment_id)
                ),
                actual_file_name,
                actual_attachment_id,
                "POST_AND_GET_VERIFIED",
            )

    return (
        True,
        (
            "Attachment created and verified "
            "from POST response. Source='"
            + file_path.name
            + "', Codebeamer='"
            + returned_file_name
            + "', attachment_id="
            + str(returned_attachment_id)
        ),
        returned_file_name,
        returned_attachment_id,
        "POST_RESPONSE_VERIFIED",
    )


# =========================================================
# REPORT HELPERS
# =========================================================

def write_csv(path, rows):
    if not rows:
        logger.info(
            "No rows for report: %s",
            path,
        )

        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass

        return

    fieldnames = sorted({
        key
        for row in rows
        for key in row.keys()
    })

    with open(
        path,
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as file_object:
        writer = csv.DictWriter(
            file_object,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(rows)

    logger.info(
        "CSV report written: %s rows=%s",
        path,
        len(rows),
    )


def get_run_timestamp():
    return datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )


def get_report_datetime_text():
    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


def get_cb_web_base_url(
    api_base_url,
):
    base_url = api_base_url.rstrip("/")

    if base_url.endswith("/api"):
        return base_url[:-4]

    return base_url


def build_cb_item_url(item_id):
    if not item_id:
        return ""

    return (
        get_cb_web_base_url(
            CB_BASE_URL
        )
        + "/issue/"
        + str(item_id)
    )


def enrich_report_row(
    row,
    run_status,
    report_generated_at,
):
    enriched_row = dict(row)

    source_sbm_id = (
        enriched_row.get(
            "folder_sbm_id"
        )
        or enriched_row.get("sbm_id")
        or ""
    )

    item_id = (
        enriched_row.get("item_id")
        or enriched_row.get(
            "codebeamer_item_id"
        )
        or ""
    )

    enriched_row[
        "run_status"
    ] = run_status

    enriched_row[
        "report_generated_at"
    ] = report_generated_at

    enriched_row[
        "source_sbm_id"
    ] = source_sbm_id

    enriched_row[
        "codebeamer_item_id"
    ] = item_id

    enriched_row[
        "codebeamer_item_url"
    ] = build_cb_item_url(
        item_id
    )

    if item_id:
        enriched_row[
            "attachment_linkage"
        ] = (
            str(source_sbm_id)
            + " -> Codebeamer Item ID "
            + str(item_id)
        )
    else:
        enriched_row[
            "attachment_linkage"
        ] = (
            str(source_sbm_id)
            + " -> NOT FOUND"
        )

    return enriched_row


def sanitize_sheet_name(
    sheet_name,
):
    for character in (
        "\\",
        "/",
        "*",
        "[",
        "]",
        ":",
        "?",
    ):
        sheet_name = sheet_name.replace(
            character,
            " ",
        )

    return sheet_name[:31]


def preferred_field_order(
    all_fields,
):
    preferred_fields = [
        "run_status",
        "report_generated_at",
        "source_sbm_id",
        "folder_sbm_id",
        "attachment_linkage",
        "codebeamer_item_id",
        "item_id",
        "codebeamer_item_url",
        "logical_name",
        "tracker_id",
        "tracker_name",
        "sbm_field_name",
        "item_name",
        "original_file_name",
        "original_file_path",
        "original_file_size_bytes",
        "packaged_as_zip",
        "zip_conversion_status",
        "file_name",
        "file_path",
        "file_size_bytes",
        "codebeamer_file_name",
        "attachment_id",
        "verification_method",
        "status",
        "reason",
        "error",
        "message",
        "duplicate_count",
    ]

    ordered_fields = [
        field
        for field in preferred_fields
        if field in all_fields
    ]

    remaining_fields = sorted([
        field
        for field in all_fields
        if field not in ordered_fields
    ])

    return (
        ordered_fields
        + remaining_fields
    )


def write_rows_to_sheet(
    worksheet,
    rows,
):
    if not rows:
        worksheet.append([
            "No records available"
        ])

        worksheet["A1"].font = Font(
            bold=True
        )

        worksheet.column_dimensions[
            "A"
        ].width = 30

        return

    all_fields = list({
        key
        for row in rows
        for key in row.keys()
    })

    fieldnames = (
        preferred_field_order(
            all_fields
        )
    )

    worksheet.append(
        fieldnames
    )

    header_fill = PatternFill(
        "solid",
        fgColor="D9EAF7",
    )

    for cell in worksheet[1]:
        cell.font = Font(
            bold=True
        )

        cell.fill = header_fill

        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
        )

    for row in rows:
        worksheet.append([
            row.get(field, "")
            for field in fieldnames
        ])

    if (
        "codebeamer_item_url"
        in fieldnames
    ):
        url_column = (
            fieldnames.index(
                "codebeamer_item_url"
            )
            + 1
        )

        for row_number in range(
            2,
            worksheet.max_row + 1,
        ):
            cell = worksheet.cell(
                row=row_number,
                column=url_column,
            )

            if cell.value:
                cell.hyperlink = (
                    cell.value
                )

                cell.style = (
                    "Hyperlink"
                )

    worksheet.freeze_panes = "A2"

    worksheet.auto_filter.ref = (
        worksheet.dimensions
    )

    for column_cells in worksheet.columns:
        column_letter = (
            get_column_letter(
                column_cells[0].column
            )
        )

        maximum_length = max(
            len(str(cell.value or ""))
            for cell in column_cells
        )

        worksheet.column_dimensions[
            column_letter
        ].width = min(
            maximum_length + 2,
            80,
        )


def write_excel_run_report(
    success_rows,
    failed_rows,
    not_found_rows,
    skipped_rows,
    duplicate_rows,
):
    generated_at = (
        get_report_datetime_text()
    )

    excel_file_name = (
        EXCEL_REPORT_PREFIX
        + "_"
        + get_run_timestamp()
        + ".xlsx"
    )

    success_enriched = [
        enrich_report_row(
            row,
            "SUCCESS",
            generated_at,
        )
        for row in success_rows
    ]

    failed_enriched = [
        enrich_report_row(
            row,
            "FAILED",
            generated_at,
        )
        for row in failed_rows
    ]

    not_found_enriched = [
        enrich_report_row(
            row,
            "NOT_FOUND",
            generated_at,
        )
        for row in not_found_rows
    ]

    skipped_enriched = [
        enrich_report_row(
            row,
            "SKIPPED",
            generated_at,
        )
        for row in skipped_rows
    ]

    duplicate_enriched = [
        enrich_report_row(
            row,
            "DUPLICATE_MATCH",
            generated_at,
        )
        for row in duplicate_rows
    ]

    all_rows = (
        success_enriched
        + failed_enriched
        + not_found_enriched
        + skipped_enriched
        + duplicate_enriched
    )

    workbook = Workbook()

    summary_sheet = workbook.active
    summary_sheet.title = "Summary"

    summary_data = [
        ["Report Generated At", generated_at],
        ["Attachment Root Directory", ATTACHMENT_ROOT_DIR],
        ["Project IDs", ", ".join(map(str, PROJECT_IDS))],
        ["Total Success", len(success_rows)],
        ["Total Failed", len(failed_rows)],
        ["Total Not Found", len(not_found_rows)],
        ["Total Skipped", len(skipped_rows)],
        ["Total Duplicate Matches", len(duplicate_rows)],
    ]

    for summary_row in summary_data:
        summary_sheet.append(
            summary_row
        )

    for cell in summary_sheet["A"]:
        cell.font = Font(
            bold=True
        )

        cell.fill = PatternFill(
            "solid",
            fgColor="D9EAF7",
        )

    summary_sheet.column_dimensions[
        "A"
    ].width = 35

    summary_sheet.column_dimensions[
        "B"
    ].width = 100

    sheet_data = [
        ("All Details", all_rows),
        ("Success", success_enriched),
        ("Failed", failed_enriched),
        ("Not Found", not_found_enriched),
        ("Skipped", skipped_enriched),
        (
            "Duplicate Matches",
            duplicate_enriched,
        ),
    ]

    for sheet_name, rows in sheet_data:
        worksheet = workbook.create_sheet(
            title=sanitize_sheet_name(
                sheet_name
            )
        )

        write_rows_to_sheet(
            worksheet,
            rows,
        )

    workbook.save(
        excel_file_name
    )

    logger.info(
        "Excel run report written: %s",
        excel_file_name,
    )

    return excel_file_name


# =========================================================
# MAIN ATTACHMENT PROCESS
# =========================================================

def process_attachment_folders(
    codebeamer,
    global_index,
):
    success_rows = []
    failed_rows = []
    not_found_rows = []
    skipped_rows = []

    folders = (
        iter_attachment_folders(
            ATTACHMENT_ROOT_DIR
        )
    )

    logger.info(
        "Found %s folders under "
        "attachment root: %s",
        len(folders),
        ATTACHMENT_ROOT_DIR,
    )

    for folder in folders:
        folder_sbm_id = (
            normalize_sbm_id(
                folder.name
            )
        )

        if not folder_sbm_id:
            skipped_rows.append({
                "folder": str(folder),
                "reason": (
                    "Folder name is blank "
                    "or invalid"
                ),
            })
            continue

        source_files = (
            iter_files_inside_folder(
                folder
            )
        )

        if not source_files:
            skipped_rows.append({
                "folder_sbm_id": (
                    folder_sbm_id
                ),
                "folder": str(folder),
                "reason": (
                    "No source files "
                    "found inside folder"
                ),
            })
            continue

        matches = global_index.get(
            folder_sbm_id,
            [],
        )

        if not matches:
            for original_file_path in source_files:
                not_found_rows.append({
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "original_file_path": str(
                        original_file_path
                    ),
                    "original_file_name": (
                        original_file_path.name
                    ),
                    "original_file_size_bytes": (
                        original_file_path.stat().st_size
                    ),
                    "reason": (
                        "No matching Codebeamer "
                        "item found"
                    ),
                })

            logger.warning(
                "No Codebeamer item found "
                "for folder/SBM ID: %s",
                folder_sbm_id,
            )
            continue

        logger.info(
            "Folder %s matched %s "
            "Codebeamer item(s); "
            "source file count=%s",
            folder_sbm_id,
            len(matches),
            len(source_files),
        )

        for match in matches:
            item_id = int(
                match["item_id"]
            )

            if (
                SKIP_IF_FILENAME_ALREADY_ATTACHED
            ):
                existing_attachments = (
                    get_existing_attachments(
                        codebeamer,
                        item_id,
                    )
                )
            else:
                existing_attachments = []

            for original_file_path in source_files:
                if not original_file_path.is_file():
                    continue

                upload_file_path = (
                    original_file_path
                )

                packaged_as_zip = False
                zip_conversion_status = (
                    "NOT_REQUIRED"
                )

                if should_package_file_as_zip(
                    original_file_path
                ):
                    try:
                        upload_file_path = (
                            create_zip_for_blocked_file(
                                original_file_path
                            )
                        )

                        packaged_as_zip = True
                        zip_conversion_status = (
                            "HTML_PACKAGED_AS_ZIP"
                        )

                        logger.info(
                            "HTML attachment will be "
                            "uploaded as ZIP. "
                            "Original=%s Upload=%s",
                            original_file_path,
                            upload_file_path,
                        )

                    except Exception as exception:
                        failed_rows.append({
                            "folder_sbm_id": folder_sbm_id,
                            "folder": str(folder),
                            "original_file_path": str(
                                original_file_path
                            ),
                            "original_file_name": (
                                original_file_path.name
                            ),
                            "original_file_size_bytes": (
                                original_file_path.stat().st_size
                            ),
                            "packaged_as_zip": True,
                            "zip_conversion_status": (
                                "ZIP_CREATION_FAILED"
                            ),
                            "logical_name": match["logical_name"],
                            "tracker_id": match["tracker_id"],
                            "tracker_name": match["tracker_name"],
                            "sbm_field_name": match["sbm_field_name"],
                            "item_id": item_id,
                            "item_name": match.get("item_name"),
                            "verification_method": (
                                "ZIP_CREATION_FAILED"
                            ),
                            "error": str(exception),
                        })

                        logger.error(
                            "Unable to create ZIP "
                            "for HTML attachment. "
                            "Source=%s Error=%s",
                            original_file_path,
                            exception,
                        )
                        continue

                common_row = {
                    "folder_sbm_id": folder_sbm_id,
                    "folder": str(folder),
                    "original_file_path": str(
                        original_file_path
                    ),
                    "original_file_name": (
                        original_file_path.name
                    ),
                    "original_file_size_bytes": (
                        original_file_path.stat().st_size
                    ),
                    "packaged_as_zip": (
                        packaged_as_zip
                    ),
                    "zip_conversion_status": (
                        zip_conversion_status
                    ),
                    "file_path": str(
                        upload_file_path
                    ),
                    "file_name": (
                        upload_file_path.name
                    ),
                    "file_size_bytes": (
                        upload_file_path.stat().st_size
                    ),
                    "logical_name": match["logical_name"],
                    "tracker_id": match["tracker_id"],
                    "tracker_name": match["tracker_name"],
                    "sbm_field_name": match["sbm_field_name"],
                    "item_id": item_id,
                    "item_name": match.get("item_name"),
                }

                existing_match = None

                if (
                    SKIP_IF_FILENAME_ALREADY_ATTACHED
                ):
                    existing_match = (
                        find_matching_attachment(
                            existing_attachments,
                            upload_file_path,
                        )
                    )

                if existing_match:
                    skipped_row = dict(
                        common_row
                    )

                    skipped_row.update({
                        "codebeamer_file_name": (
                            extract_attachment_name(
                                existing_match
                            )
                        ),
                        "attachment_id": (
                            extract_attachment_id(
                                existing_match
                            )
                        ),
                        "reason": (
                            "Equivalent attachment "
                            "already exists. Duplicate "
                            "check used the upload filename, "
                            "Codebeamer-sanitized filename "
                            "and file size."
                        ),
                    })

                    skipped_rows.append(
                        skipped_row
                    )

                    logger.info(
                        "Skipped duplicate attachment. "
                        "item=%s original=%s upload=%s "
                        "codebeamer=%s",
                        item_id,
                        original_file_path.name,
                        upload_file_path.name,
                        extract_attachment_name(
                            existing_match
                        ),
                    )
                    continue

                (
                    upload_success,
                    upload_message,
                    codebeamer_file_name,
                    attachment_id,
                    verification_method,
                ) = upload_attachment_verified(
                    codebeamer,
                    item_id,
                    upload_file_path,
                )

                if upload_success:
                    success_row = dict(
                        common_row
                    )

                    success_row.update({
                        "codebeamer_file_name": (
                            codebeamer_file_name
                        ),
                        "attachment_id": (
                            attachment_id
                        ),
                        "verification_method": (
                            verification_method
                        ),
                        "status": (
                            "ATTACHED_AND_VERIFIED"
                        ),
                        "message": (
                            upload_message
                        ),
                    })

                    success_rows.append(
                        success_row
                    )

                    existing_attachments.append({
                        "id": attachment_id,
                        "name": codebeamer_file_name,
                        "size": (
                            upload_file_path.stat().st_size
                        ),
                    })

                    logger.info(
                        "Attached successfully. "
                        "item=%s original=%s "
                        "uploaded=%s codebeamer=%s "
                        "attachment_id=%s",
                        item_id,
                        original_file_path.name,
                        upload_file_path.name,
                        codebeamer_file_name,
                        attachment_id,
                    )

                else:
                    failed_row = dict(
                        common_row
                    )

                    failed_row.update({
                        "codebeamer_file_name": (
                            codebeamer_file_name
                        ),
                        "attachment_id": (
                            attachment_id
                        ),
                        "verification_method": (
                            verification_method
                        ),
                        "error": (
                            upload_message
                        ),
                    })

                    failed_rows.append(
                        failed_row
                    )

                    logger.error(
                        "Attachment failed. "
                        "item=%s original=%s "
                        "upload=%s error=%s",
                        item_id,
                        original_file_path,
                        upload_file_path,
                        upload_message,
                    )

    return (
        success_rows,
        failed_rows,
        not_found_rows,
        skipped_rows,
    )


# =========================================================
# MAIN
# =========================================================

def main():
    acquire_run_lock()

    try:
        logger.info(
            "Starting Codebeamer "
            "attachment folder import"
        )

        logger.info(
            "Attachment root directory: %s",
            ATTACHMENT_ROOT_DIR,
        )

        logger.info(
            "Project IDs configured: %s",
            PROJECT_IDS,
        )

        logger.info(
            "HTML-to-ZIP conversion enabled: %s",
            ZIP_BLOCKED_FILE_TYPES,
        )

        codebeamer = CodebeamerClient(
            base_url=CB_BASE_URL,
            username=CB_USER,
            password=CB_PASS,
            verify_ssl=VERIFY_SSL,
            timeout=TIMEOUT,
        )

        (
            global_index,
            duplicate_rows,
            skipped_tracker_rows,
        ) = build_global_sbm_index(
            codebeamer
        )

        logger.info(
            "Global SBM index contains "
            "%s unique SBM IDs",
            len(global_index),
        )

        (
            success_rows,
            failed_rows,
            not_found_rows,
            skipped_rows,
        ) = process_attachment_folders(
            codebeamer,
            global_index,
        )

        skipped_rows.extend(
            skipped_tracker_rows
        )

        write_csv(
            SUCCESS_CSV,
            success_rows,
        )

        write_csv(
            FAILED_CSV,
            failed_rows,
        )

        write_csv(
            NOT_FOUND_CSV,
            not_found_rows,
        )

        write_csv(
            SKIPPED_CSV,
            skipped_rows,
        )

        write_csv(
            DUPLICATE_MATCH_CSV,
            duplicate_rows,
        )

        excel_report_file = (
            write_excel_run_report(
                success_rows,
                failed_rows,
                not_found_rows,
                skipped_rows,
                duplicate_rows,
            )
        )

        logger.info(
            "Attachment import completed. "
            "Success=%s Failed=%s "
            "NotFound=%s Skipped=%s "
            "DuplicateMatches=%s "
            "ExcelReport=%s",
            len(success_rows),
            len(failed_rows),
            len(not_found_rows),
            len(skipped_rows),
            len(duplicate_rows),
            excel_report_file,
        )

    finally:
        release_run_lock()


if __name__ == "__main__":
    main()