import re
import os
import json
import time
import logging

import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

# =========================================================
# CONFIGURATION
# =========================================================

# ---------- MySQL ----------
MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"   # replace if needed
TABLE_NAME = "sbm_issue"

SOURCE_SQL = f"""
SELECT *
FROM {TABLE_NAME}
-- WHERE Item_Id = 'IS150597'
-- LIMIT 20
"""

# ---------- Codebeamer ----------
CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"   # replace if needed
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

PROJECT_ID = 48

# ---------- Trackers ----------
ISSUE_TRACKER_ID = 294498
ISSUE_TRACKER_NAME = "Issue"

RETEX_TRACKER_ID = 294309
RETEX_TRACKER_NAME = "Retex"
RETEX_TO_ISSUE_FIELD_NAME = "Issue"

AEMS_FUNCTION_TRACKER_ID = 295319
AEMS_FUNCTION_TRACKER_NAME = "A-EMS Function"

AEMS_SPECIFICATION_TRACKER_ID = 295425
AEMS_SPECIFICATION_TRACKER_NAME = "A-EMS Specification"

AEMS_MODULE_TRACKER_ID = 295368
AEMS_MODULE_TRACKER_NAME = "A-EMS Module"

FIRST_VEHICLE_APPLICATION_TRACKER_ID = 295575
FIRST_VEHICLE_APPLICATION_TRACKER_NAME = "First Vehicle Application"

FIRST_ENGINE_APPLICATION_TRACKER_ID = 295532
FIRST_ENGINE_APPLICATION_TRACKER_NAME = "First Engine Application"

# ---------- Forced mandatory member/user values ----------
PILOT_FORCE_NAME = "cbadmin"
PILOT_FORCE_ID = 1
PILOT_REFERENCE_TYPE = "UserReference"  # if this fails, change to "MemberReference"

# ---------- Forced mandatory choice defaults ----------
NEW_OR_EVOLUTION_FORCE_VALUE = "New"

# Optional forced defaults for mandatory create fields
TROUBLE_TYPE_FORCE_VALUE = None
CONTEXT_FORCE_VALUE = None
PERIMETER_FORCE_VALUE = None

# ---------- Mandatory issue fields required at CREATE ----------
MANDATORY_ISSUE_CREATE_FIELDS = [
    "Trouble Type",
    "Pilot",
    "Context",
    "Perimeter",
]

# ---------- Source -> Codebeamer choice translations ----------
TROUBLE_TYPE_TO_CB = {
    "Calibration": "Calibration",
    "Software": "Software",
}

CONTEXT_TO_CB = {
    "Proving ground (Test course) / Vehicule": "Proving ground (Test course) / Vehicule",
    "System Validation": "System Validation",
    "HIL validation": "HIL validation",
    "Plant": "Plant",
}

PERIMETER_TO_CB = {
    "ASXX": "ASXX",
    "CMB": "CMB",
    "CMBA": "CMBA",
    "Safety AEMS": "Safety AEMS",
    "SYS": "SYS",
}

# ---------- New project placeholder IDs ----------
PLACEHOLDER_REFERENCE_ITEMS = {
    AEMS_SPECIFICATION_TRACKER_NAME: {
        "id": 146663,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    AEMS_MODULE_TRACKER_NAME: {
        "id": 146667,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    AEMS_FUNCTION_TRACKER_NAME: {
        "id": 146669,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    FIRST_ENGINE_APPLICATION_TRACKER_NAME: {
        "id": 146671,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    FIRST_VEHICLE_APPLICATION_TRACKER_NAME: {
        "id": 146673,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
}

# ---------- Placeholder text values ----------
PLACEHOLDER_TEXT_VALUES = {
    "Detailed_Context": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Expected_Behavior": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Observed_Behavior": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Impact": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Solution_Description": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
}

# ---------- Speed / behavior ----------
VERIFY_SSL = True
TIMEOUT = 20

UPSERT_MODE = "update_if_in_state_else_create"

STATE_FILE_CSV = "codebeamer_state.csv"
CREATED_MAP_CSV = "created_updated_items.csv"
FAILED_ROWS_CSV = "failed_rows.csv"
SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_report.csv"
LOG_FILE = "codebeamer_import.log"

SOURCE_KEY_COLUMN = "Item_Id"
SUMMARY_SOURCE_COLUMN = "Title"

SLEEP_BETWEEN_REQUESTS_SEC = 0.0

LINK_PASS_DELAY_SEC = 0
LINK_RETRY_ATTEMPTS = 1
LINK_RETRY_SLEEP_SEC = 0

# Optional: temporarily skip known-heavy / known-problem issue-side fields
SKIP_ISSUE_REFERENCE_FIELDS = set([
    # "Impacted Specification",
    # "Detected Specification",
    # "Corrective SDTs",
])

# =========================================================
# REFERENCE TRACKER RULES
# =========================================================

REFERENCE_TRACKER_RULES = [
    # Retex: child tracker item points back to Issue
    {
        "state_key": "Retex",
        "source_column": "Retex",
        "tracker_name": RETEX_TRACKER_NAME,
        "tracker_id": RETEX_TRACKER_ID,
        "mode": "child_points_to_issue",
        "child_reference_field": RETEX_TO_ISSUE_FIELD_NAME,
        "multi_value": False,
        "use_placeholder_if_empty": False,
    },

    # Issue-side visible reference fields
    {
        "state_key": "Introduction_Specifications",
        "source_column": "Introduction_Specifications",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Introduction Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Specifications_AEMS",
        "source_column": "Impacted_Specifications_AEMS",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Corrective_SDTs",
        "source_column": "Corrective_SDTs",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Corrective SDTs",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Modules_AEMS",
        "source_column": "Impacted_Modules_AEMS",
        "tracker_name": AEMS_MODULE_TRACKER_NAME,
        "tracker_id": AEMS_MODULE_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Modules",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Vehicles",
        "source_column": "Impacted_Vehicles",
        "tracker_name": FIRST_VEHICLE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_VEHICLE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Vehicles",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },

    # Issue-side detected reference fields
    {
        "state_key": "Detected_Module_AEMS",
        "source_column": "Detected_Module_AEMS",
        "tracker_name": AEMS_MODULE_TRACKER_NAME,
        "tracker_id": AEMS_MODULE_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Module",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Specifications_AEMS",
        "source_column": "Detected_Specifications_AEMS",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Vehicle",
        "source_column": "Detected_Vehicle",
        "tracker_name": FIRST_VEHICLE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_VEHICLE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Vehicle",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Engine",
        "source_column": "Detected_Engine",
        "tracker_name": FIRST_ENGINE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_ENGINE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Engine",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
]

# =========================================================
# SAFE ISSUE FIELD MAPPING
# =========================================================

SAFE_ISSUE_MAPPING = {
    "Title": {"mode": "name"},

    # Mandatory-at-create scalar fields
    "IS_Category": {"field": "IS Category", "kind": "choice"},
    "Trouble_type": {"field": "Trouble Type", "kind": "choice"},
    "Severity": {"field": "Severity", "kind": "choice"},
    "Pilot": {"field": "Pilot", "kind": "member"},
    "Perimeter": {"field": "Perimeter", "kind": "choice"},
    "Context_Test_condition": {"field": "Context", "kind": "choice"},
    "Responsibility": {"field": "Responsibility", "kind": "choice"},
    "Detailed_Context": {"field": "Detailed Context"},
    "Expected_Behavior": {"field": "Expected Behavior"},
    "Observed_Behavior": {"field": "Observed Behavior"},
    "Impact": {"field": "Impact"},
    "Solution_Description": {"field": "Solution Description"},

    # Optional scalar fields
    "Delivered_Solution": {"field": "Delivered Solution"},
    "Corrected_Software": {"field": "Corrected Software"},
    "ECU_Part_Version": {"field": "ECU/Part Version"},
    "Impacted_Technical_Definition": {"field": "Impacted Technical Definition"},
    "Safety_Impact": {"field": "Safety Impact", "kind": "choice"},
    "Regulation_Impact": {"field": "Regulation Impact", "kind": "choice"},
    "Detected_Software_AEMS": {"field": "Detected Software", "kind": "choice"},
    "Detected_SOF_AEMS": {"field": "Detected SOF", "kind": "choice"},
    "ECU_Part_Name": {"field": "ECU/Part Name", "kind": "choice"},
    "Auto_Impact_Specifications_AEMS": {"field": "Auto Impact Specification", "kind": "choice"},
    "Auto_Impact_Projects_AEMS": {"field": "Auto Impact Projects", "kind": "choice"},
    "Auto_Impact_SOFs": {"field": "Auto Impact SOFs", "kind": "choice"},
    "Auto_Impacts_BCCs": {"field": "Auto Impact BCCs", "kind": "choice"},
    "Auto_Impacts_Modules": {"field": "Auto Impact Modules", "kind": "choice"},
    "Impacted_Software_AEMS": {"field": "Impacted Software", "kind": "choice"},
    "Impacted_Projects": {"field": "Impacted Projects", "kind": "choice"},
    "Planned_Model_Delivery": {"field": "Planned Model Delivery", "kind": "choice"},
    "Expected_Resolution_Date": {"field": "Expected Resolution Date"},
}

# =========================================================
# OPTIONAL VALUE TRANSLATION
# =========================================================

STATE_TO_CB_STATUS = {
    "Analysis": "Analysis",
    "Defining the Solution": "Defining the Solution",
    "Waiting for Solution": "Waiting for Solution",
    "Solution Available": "Solution Available",
    "Solution Validated": "Solution Validated",
}

SEVERITY_TO_CB_SEVERITY = {
    "K1 Blocking": "K1 Blocking",
    "K2 Very Disturbing": "K2 Very Disturbing",
    "K3 Disturbing": "K3 Disturbing",
    "K4 Minor": "K4 Minor",
}

# =========================================================
# SKIP REASONS
# =========================================================

INTENTIONAL_SKIP_COLUMNS = {
    "Submitter": "User lookup required; skipped for now",
    "Owner": "User/member lookup required; skipped for now",
    "Secondary_Owner": "User/member lookup required; skipped for now",
    "Last_Modified_Date": "System-managed field",
    "Last_Modifier": "System-managed field",
    "Last_State_Change_Date": "System-managed field",
    "Last_State_Changer": "System-managed field",
    "Open_Date": "Workflow/system-managed field",
    "Close_Date": "Workflow/system-managed field",
    "State": "Skipped during create/direct update; Status is applied LAST after references are linked",
    SOURCE_KEY_COLUMN: "Source ID is tracked in local CSV state instead of replacing Codebeamer IDs",
}

USER_MEMBER_FIELDS_TO_SKIP = {
    "Owner": "Issue tracker field 'Owner' is a Members field; requires user/member lookup",
    "Secondary_Owner": "User/member lookup required",
    "Submitter": "User lookup required",
}

REFERENCE_ITEM_FIELDS_TO_SKIP = {
    "Introduction_Module_Version": "Target field 'Introduction Module Version' needs tracker item lookup / reference handling",
    "Impacted_Engines": "Target field 'Impacted Engines' needs tracker item lookup / reference handling",
    "Corrected_Specifications": "Target field 'Corrected Specification' needs tracker item lookup / reference handling",
    "Change_Request_No": "Possible candidate for 'Linked CR/DMFI'; add later when confirmed",
}

SPECIAL_SKIP_FIELDS = {
    "Applicability": "Applicability is a table field; needs dedicated table payload builder",
}

# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger = logging.getLogger("cb_sync")
    logger.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.INFO)

    logger.handlers.clear()
    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger

logger = setup_logging()

# =========================================================
# HELPERS
# =========================================================

def normalize_name(s):
    return re.sub(r"\s+", " ", str(s).strip()).lower()

def is_blank(v):
    if pd.isna(v):
        return True
    if isinstance(v, str):
        s = v.strip()
        if s in ("", "(None)", "None", "nan", "NaN", "--", "null", "NULL"):
            return True
    return False

def clean_text(v):
    if is_blank(v):
        return None
    s = str(v).replace("\r", "").replace("_x000D_", "").strip()
    return s if s else None

def split_multi_reference_values(v):
    txt = clean_text(v)
    if not txt:
        return []
    parts = [p.strip() for p in str(txt).split(",")]
    cleaned = []
    seen = set()
    for p in parts:
        if is_blank(p):
            continue
        key = normalize_name(p)
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(p)
    return cleaned

def get_effective_value_for_source_column(src_col, row):
    if src_col == "Pilot" and PILOT_FORCE_NAME:
        return PILOT_FORCE_NAME

    if src_col == "New_or_Evolution":
        raw_noe = row.get(src_col) if src_col in row.index else None
        if is_blank(raw_noe):
            return NEW_OR_EVOLUTION_FORCE_VALUE
        return raw_noe

    if src_col == "Trouble_type":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and TROUBLE_TYPE_FORCE_VALUE:
            return TROUBLE_TYPE_FORCE_VALUE
        return raw

    if src_col == "Context_Test_condition":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and CONTEXT_FORCE_VALUE:
            return CONTEXT_FORCE_VALUE
        return raw

    if src_col == "Perimeter":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and PERIMETER_FORCE_VALUE:
            return PERIMETER_FORCE_VALUE
        return raw

    raw = row.get(src_col)

    if is_blank(raw) and src_col in PLACEHOLDER_TEXT_VALUES:
        return PLACEHOLDER_TEXT_VALUES[src_col]

    return raw

def get_placeholder_reference_for_tracker(tracker_name):
    ph = PLACEHOLDER_REFERENCE_ITEMS.get(tracker_name)
    if not ph:
        return None
    ph_id = ph.get("id")
    ph_name = ph.get("name")
    if ph_id is None or not ph_name:
        return None
    return {"id": int(ph_id), "name": str(ph_name)}

def to_iso_datetime_string(v):
    if is_blank(v):
        return None
    dt = pd.to_datetime(v, errors="coerce")
    if pd.isna(dt):
        return None
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000")

def to_bool_or_none(v):
    if is_blank(v):
        return None
    s = str(v).strip().lower()
    if s in ("yes", "true", "1", "y"):
        return True
    if s in ("no", "false", "0", "n"):
        return False
    return None

def to_int_or_none(v):
    if is_blank(v):
        return None
    try:
        return int(float(v))
    except Exception:
        return None

def to_float_or_none(v):
    if is_blank(v):
        return None
    try:
        return float(v)
    except Exception:
        return None

def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)

def first_non_null_sample(df, col):
    if col not in df.columns:
        return None
    ser = df[col].dropna()
    if ser.empty:
        return None
    return clean_text(ser.iloc[0])

# =========================================================
# LOCAL STATE
# =========================================================

def load_state(path):
    state = {}
    if not os.path.exists(path):
        return state

    df = pd.read_csv(path, dtype=str)
    for _, row in df.iterrows():
        src = str(row.get("source_item_id", "")).strip().upper()
        if not src:
            continue

        child_refs = {}
        raw_child_refs = row.get("child_refs_json")
        if raw_child_refs and str(raw_child_refs).strip():
            try:
                parsed = json.loads(raw_child_refs)
                if isinstance(parsed, dict):
                    child_refs = parsed
            except Exception:
                child_refs = {}

        legacy_retex = row.get("retex_codebeamer_item_id")
        if legacy_retex and "Retex" not in child_refs:
            child_refs["Retex"] = {"__legacy_single__": legacy_retex}

        state[src] = {
            "source_item_id": src,
            "issue_codebeamer_item_id": row.get("issue_codebeamer_item_id"),
            "retex_codebeamer_item_id": row.get("retex_codebeamer_item_id"),
            "child_refs_json": json.dumps(child_refs) if child_refs else "{}",
            "title": row.get("title"),
            "status": row.get("status"),
        }
    return state

def save_state(path, state):
    rows = []
    for _, value in state.items():
        row = dict(value)
        try:
            child_refs = json.loads(row.get("child_refs_json") or "{}")
        except Exception:
            child_refs = {}

        retex_visible = None
        if isinstance(child_refs.get("Retex"), dict):
            vals = list(child_refs["Retex"].values())
            if vals:
                retex_visible = vals[0]

        row["retex_codebeamer_item_id"] = retex_visible
        rows.append(row)

    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")

def get_child_refs_from_state_entry(entry):
    if not entry:
        return {}

    raw = entry.get("child_refs_json")
    if not raw:
        refs = {}
    else:
        try:
            refs = json.loads(raw)
            if not isinstance(refs, dict):
                refs = {}
        except Exception:
            refs = {}

    normalized = {}
    for state_key, value in refs.items():
        if isinstance(value, dict):
            normalized[state_key] = {str(k): str(v) for k, v in value.items()}
        elif isinstance(value, list):
            normalized[state_key] = {f"__idx_{i}": str(v) for i, v in enumerate(value)}
        elif value is not None:
            normalized[state_key] = {"__single__": str(value)}
        else:
            normalized[state_key] = {}

    legacy_retex = entry.get("retex_codebeamer_item_id")
    if legacy_retex and "Retex" not in normalized:
        normalized["Retex"] = {"__legacy_single__": str(legacy_retex)}

    return normalized

def update_state_entry(state, src_key, issue_cb_id, title, status, child_refs=None):
    existing = state.get(src_key, {})
    current_child_refs = get_child_refs_from_state_entry(existing)

    if child_refs:
        for state_key, value_map in child_refs.items():
            if state_key not in current_child_refs:
                current_child_refs[state_key] = {}
            for source_value, item_id in value_map.items():
                if item_id is not None:
                    current_child_refs[state_key][str(source_value)] = str(item_id)

    state[src_key] = {
        "source_item_id": src_key,
        "issue_codebeamer_item_id": str(issue_cb_id) if issue_cb_id else existing.get("issue_codebeamer_item_id"),
        "retex_codebeamer_item_id": None,
        "child_refs_json": json.dumps(current_child_refs, ensure_ascii=False),
        "title": title or existing.get("title"),
        "status": status or existing.get("status"),
    }

# =========================================================
# REFERENCE ITEM REUSE CACHE
# =========================================================

REFERENCE_ITEM_CACHE = {}

def make_reference_cache_key(tracker_id, source_value):
    return tracker_id, normalize_name(source_value)

def prime_reference_cache_from_state(state, active_reference_rules):
    tracker_by_state_key = {r["state_key"]: r["tracker_id"] for r in active_reference_rules}
    seeded = 0
    for entry in state.values():
        child_refs = get_child_refs_from_state_entry(entry)
        for state_key, value_map in child_refs.items():
            tracker_id = tracker_by_state_key.get(state_key)
            if not tracker_id:
                continue
            for source_value, item_id in value_map.items():
                if not source_value or not item_id:
                    continue
                try:
                    REFERENCE_ITEM_CACHE[make_reference_cache_key(tracker_id, source_value)] = int(item_id)
                    seeded += 1
                except Exception:
                    pass
    logger.info("Seeded reference reuse cache from state: %s entries", seeded)

# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url, username, password, verify_ssl=True, timeout=60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Content-Type": "application/json"})

        retry = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path):
        return f"{self.base_url}{path}"

    def get(self, path, params=None):
        safe_sleep()
        r = self.session.get(self._url(path), params=params, timeout=self.timeout)
        self._raise_for_status(r)
        return r.json()

    def post(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.post(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def put(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.put(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    @staticmethod
    def _raise_for_status(r):
        try:
            r.raise_for_status()
        except requests.HTTPError:
            raise RuntimeError(f"HTTP {r.status_code} | URL={r.url} | Response={r.text}")

# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb, tracker_id):
    refs = cb.get(f"/v3/trackers/{tracker_id}/fields")
    field_map = {}
    for ref in refs:
        fid = ref["id"]
        detail = cb.get(f"/v3/trackers/{tracker_id}/fields/{fid}")
        field_map[normalize_name(detail["name"])] = detail
    return field_map

def load_item_fields(cb, item_id):
    data = cb.get(f"/v3/items/{item_id}/fields")
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("fieldValues"), list):
        return data["fieldValues"]
    return []

def resolve_reference_rules(df_columns, rules):
    active_rules = []
    for rule in rules:
        source_col = rule["source_column"]
        if source_col not in df_columns:
            logger.info("Skipping rule because source column is not present in SQL result: %s", source_col)
            continue
        active_rules.append(dict(rule))
    return active_rules

def validate_existing_item_in_tracker(cb, item_id, expected_tracker_id):
    try:
        item = cb.get(f"/v3/items/{item_id}")
    except Exception as ex:
        return False, f"Item {item_id} not accessible: {ex}"

    tracker = item.get("tracker") or {}
    tracker_id = tracker.get("id")

    if str(tracker_id) != str(expected_tracker_id):
        return False, f"Item {item_id} belongs to tracker {tracker_id}, expected {expected_tracker_id}"

    return True, "OK"

def log_field_debug(issue_tracker_fields, field_name):
    meta = issue_tracker_fields.get(normalize_name(field_name))
    if not meta:
        logger.warning("Field '%s' not found in tracker metadata", field_name)
        return

    logger.info(
        "Field debug | name=%s | id=%s | valueModel=%s | type=%s | options_count=%s",
        meta.get("name"),
        meta.get("id"),
        meta.get("valueModel"),
        meta.get("type"),
        len(meta.get("options") or [])
    )

# =========================================================
# FIELD VALUE BUILDERS
# =========================================================

def build_field_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None

    field_id = field_meta["id"]
    field_name = field_meta["name"]
    value_model = field_meta.get("valueModel")

    if value_model == "TextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "TextFieldValue",
            "value": txt
        }

    if value_model == "WikiTextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "WikiTextFieldValue",
            "value": txt
        }

    if value_model == "DateFieldValue":
        dt = to_iso_datetime_string(raw_value)
        if not dt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DateFieldValue",
            "value": dt
        }

    if value_model == "IntegerFieldValue":
        iv = to_int_or_none(raw_value)
        if iv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "IntegerFieldValue",
            "value": iv
        }

    if value_model == "DecimalFieldValue":
        dv = to_float_or_none(raw_value)
        if dv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DecimalFieldValue",
            "value": dv
        }

    if value_model == "BoolFieldValue":
        bv = to_bool_or_none(raw_value)
        if bv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "BoolFieldValue",
            "value": bv
        }

    return None

def build_choice_field_value(field_meta, raw_value, value_map=None):
    if is_blank(raw_value):
        return None, None

    source_text = clean_text(raw_value)
    if not source_text:
        return None, None

    target_text = value_map.get(source_text, source_text) if value_map else source_text

    options = field_meta.get("options") or []
    if not options:
        return None, f"Field '{field_meta.get('name')}' has no options metadata exposed by API; cannot resolve choice '{target_text}'"

    matched = None
    for opt in options:
        if normalize_name(opt.get("name")) == normalize_name(target_text):
            matched = opt
            break

    if not matched:
        available = [o.get("name") for o in options]
        return None, f"Choice '{target_text}' not found for field '{field_meta.get('name')}'. Available options: {available}"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": matched["id"],
            "name": matched.get("name"),
            "type": matched.get("type", "ChoiceOptionReference")
        }]
    }, None

def build_member_field_value(field_meta, member_id, member_name):
    if not member_id or not member_name:
        return None, f"Member value missing for field '{field_meta.get('name')}'"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": int(member_id),
            "name": str(member_name),
            "type": PILOT_REFERENCE_TYPE
        }]
    }, None

def build_tracker_item_reference_field_value(field_meta, tracker_item_refs):
    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": tracker_item_refs
    }

# =========================================================
# OPTIMIZED PASS 3 HELPERS
# =========================================================

def build_reference_values_list(child_ids_and_names):
    """
    Build a deduplicated TrackerItemReference list for bulk field update.
    child_ids_and_names = [(child_id, child_name), ...]
    """
    values = []
    seen = set()

    for child_id, child_name in child_ids_and_names:
        key = str(child_id)
        if key in seen:
            continue
        seen.add(key)
        values.append({
            "id": int(child_id),
            "name": str(child_name),
            "type": "TrackerItemReference"
        })

    return values

def set_tracker_item_reference_field_on_item(cb, item_id, tracker_fields, reference_field_name, child_ids_and_names):
    """
    Replace/set the full reference field in ONE PUT using all child refs.
    """
    field_meta = tracker_fields.get(normalize_name(reference_field_name))
    if not field_meta:
        raise RuntimeError(
            f"Tracker field '{reference_field_name}' not found. Please verify the exact field name."
        )

    payload_value = {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": build_reference_values_list(child_ids_and_names)
    }

    update_item_fields(cb, item_id, [payload_value])

# =========================================================
# CHILD TRACKER ITEM CREATION (TRACKER-SPECIFIC)
# =========================================================

def build_child_item_payload(tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    """
    Build tracker-specific child item create payload.
    """
    description_lines = []
    if source_item_id:
        description_lines.append(f"Source Item Id: {source_item_id}")
    if issue_title:
        description_lines.append(f"Issue Title: {issue_title}")
    if source_value:
        description_lines.append("")
        description_lines.append("Imported Reference Value:")
        description_lines.append(source_value)

    description_text = "\n".join(description_lines).strip() if description_lines else None

    payload = {
        "name": source_value,
        "descriptionFormat": "PlainText",
        "description": description_text
    }

    custom_fields = []

    # A-EMS Specification requires "New or Evolution?" = New
    if tracker_name == AEMS_SPECIFICATION_TRACKER_NAME:
        field_meta = tracker_fields.get(normalize_name("New or Evolution?"))
        if not field_meta:
            raise RuntimeError(
                f"Mandatory child field 'New or Evolution?' not found in tracker metadata for '{tracker_name}'"
            )

        fv, err = build_choice_field_value(field_meta, "New")
        if not fv:
            raise RuntimeError(
                f"Unable to resolve mandatory child field 'New or Evolution?' for '{tracker_name}': {err}"
            )
        custom_fields.append(fv)

    # A-EMS Function requires Description too
    if tracker_name == AEMS_FUNCTION_TRACKER_NAME:
        if not payload.get("description"):
            payload["description"] = f"Imported child item for source value: {source_value}"
            payload["descriptionFormat"] = "PlainText"

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}
    return payload

def create_reference_tracker_item(cb, tracker_id, tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    payload = build_child_item_payload(
        tracker_name=tracker_name,
        tracker_fields=tracker_fields,
        source_value=source_value,
        issue_title=issue_title,
        source_item_id=source_item_id,
    )
    created = cb.post(f"/v3/trackers/{tracker_id}/items", payload)
    return created["id"], created

def get_or_create_reference_tracker_item(cb, tracker_id, tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    key = (tracker_id, normalize_name(source_value))
    cached_id = REFERENCE_ITEM_CACHE.get(key)
    if cached_id:
        return cached_id, {"id": cached_id}, False

    child_id, created = create_reference_tracker_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        tracker_fields=tracker_fields,
        source_value=source_value,
        issue_title=issue_title,
        source_item_id=source_item_id
    )
    REFERENCE_ITEM_CACHE[key] = child_id
    return child_id, created, True

# =========================================================
# ISSUE CREATE / UPDATE
# =========================================================

def create_issue_item(cb, issue_tracker_id, row, issue_tracker_fields):
    """
    Create Issue item with mandatory scalar fields only.
    """
    name = clean_text(get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row)) or "Imported Issue"

    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
    description_lines = []
    if src_id:
        description_lines.append(f"Source Item Id: {src_id}")

    detailed_context = clean_text(get_effective_value_for_source_column("Detailed_Context", row))
    if detailed_context:
        description_lines.append("")
        description_lines.append("Detailed Context:")
        description_lines.append(detailed_context)

    payload = {
        "name": name,
        "descriptionFormat": "PlainText",
        "description": "\n".join(description_lines).strip() if description_lines else None
    }

    create_custom_fields = []
    mandatory_build_errors = []
    optional_build_warnings = []

    mandatory_norm = {normalize_name(x) for x in MANDATORY_ISSUE_CREATE_FIELDS}

    for src_col, cfg in SAFE_ISSUE_MAPPING.items():
        if src_col not in row.index and src_col not in ("Pilot",):
            continue

        if cfg.get("mode") == "name":
            continue

        raw_value = get_effective_value_for_source_column(src_col, row)

        target_field_name = cfg["field"]
        is_mandatory_target = normalize_name(target_field_name) in mandatory_norm

        field_meta = issue_tracker_fields.get(normalize_name(target_field_name))
        if not field_meta:
            msg = f"{src_col} -> {target_field_name}: target field not found in tracker metadata"
            if is_mandatory_target:
                mandatory_build_errors.append(msg)
            else:
                optional_build_warnings.append(msg)
            continue

        kind = cfg.get("kind")

        if kind == "choice":
            value_map = None
            if src_col == "Severity" and target_field_name == "Severity":
                value_map = SEVERITY_TO_CB_SEVERITY
            elif src_col == "Trouble_type":
                value_map = TROUBLE_TYPE_TO_CB
            elif src_col == "Context_Test_condition":
                value_map = CONTEXT_TO_CB
            elif src_col == "Perimeter":
                value_map = PERIMETER_TO_CB

            fv, err = build_choice_field_value(field_meta, raw_value, value_map=value_map)
            if fv:
                create_custom_fields.append(fv)
            else:
                if is_mandatory_target:
                    mandatory_build_errors.append(
                        f"{src_col} -> {target_field_name}: {err or 'value missing/unresolved'} | raw={raw_value!r}"
                    )
                elif not is_blank(raw_value):
                    optional_build_warnings.append(
                        f"{src_col} -> {target_field_name}: {err or 'value missing/unresolved'} | raw={raw_value!r}"
                    )
            continue

        if kind == "member":
            fv, err = build_member_field_value(field_meta, PILOT_FORCE_ID, PILOT_FORCE_NAME)
            if fv:
                create_custom_fields.append(fv)
            else:
                if is_mandatory_target:
                    mandatory_build_errors.append(f"{src_col} -> {target_field_name}: {err}")
                else:
                    optional_build_warnings.append(f"{src_col} -> {target_field_name}: {err}")
            continue

        fv = build_field_value(field_meta, raw_value)
        if fv:
            create_custom_fields.append(fv)
        elif is_mandatory_target and not is_blank(raw_value):
            mandatory_build_errors.append(
                f"{src_col} -> {target_field_name}: unsupported or unresolved field value | raw={raw_value!r}"
            )

    included_field_names = {
        normalize_name(x.get("name")) for x in create_custom_fields if x.get("name")
    }

    missing_mandatory = [
        f for f in MANDATORY_ISSUE_CREATE_FIELDS
        if normalize_name(f) not in included_field_names
    ]

    if missing_mandatory or mandatory_build_errors:
        raise RuntimeError(
            "Issue create payload validation failed before POST. "
            f"Missing mandatory fields: {missing_mandatory}. "
            f"Mandatory build errors: {mandatory_build_errors}"
        )

    for warn in optional_build_warnings:
        logger.warning("Skipping optional create field: %s", warn)

    if create_custom_fields:
        payload["customFields"] = create_custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    created = cb.post(f"/v3/trackers/{issue_tracker_id}/items", payload)
    return created["id"], created

def update_item_fields(cb, item_id, field_values):
    if not field_values:
        return
    payload = {"fieldValues": field_values}
    cb.put(f"/v3/items/{item_id}/fields", payload)

def update_status_last(cb, issue_item_id, issue_tracker_fields, raw_status_value):
    status_text = clean_text(raw_status_value)
    if not status_text:
        return

    field_meta = issue_tracker_fields.get(normalize_name("Status"))
    if not field_meta:
        raise RuntimeError("Issue tracker field 'Status' not found in metadata.")

    fv, err = build_choice_field_value(
        field_meta=field_meta,
        raw_value=status_text,
        value_map=STATE_TO_CB_STATUS
    )
    if err:
        raise RuntimeError(f"Unable to resolve Status '{status_text}': {err}")

    update_item_fields(cb, issue_item_id, [fv])

# =========================================================
# REFERENCE LINK HELPERS
# =========================================================

def merge_tracker_item_reference_on_item(cb, item_id, tracker_fields, reference_field_name, referenced_item_id, referenced_item_name):
    field_meta = tracker_fields.get(normalize_name(reference_field_name))
    if not field_meta:
        raise RuntimeError(
            f"Tracker field '{reference_field_name}' not found on item tracker. "
            f"Please verify the exact field name in tracker metadata."
        )

    current_fields = load_item_fields(cb, item_id)

    existing_values = []
    for fv in current_fields:
        fv_field_id = fv.get("fieldId")
        fv_name = fv.get("name")
        if fv_field_id == field_meta["id"] or normalize_name(fv_name) == normalize_name(field_meta["name"]):
            vals = fv.get("values") or []
            if isinstance(vals, list):
                existing_values = vals
            break

    already_exists = any(str(v.get("id")) == str(referenced_item_id) for v in existing_values if isinstance(v, dict))

    merged_values = list(existing_values)
    if not already_exists:
        merged_values.append({
            "id": referenced_item_id,
            "name": referenced_item_name,
            "type": "TrackerItemReference"
        })

    payload_value = build_tracker_item_reference_field_value(field_meta, merged_values)
    update_item_fields(cb, item_id, [payload_value])

def link_reference_with_retry(
    cb,
    item_id,
    tracker_fields,
    reference_field_name,
    referenced_item_id,
    referenced_item_name,
    attempts=LINK_RETRY_ATTEMPTS,
    sleep_sec=LINK_RETRY_SLEEP_SEC,
):
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            merge_tracker_item_reference_on_item(
                cb=cb,
                item_id=item_id,
                tracker_fields=tracker_fields,
                reference_field_name=reference_field_name,
                referenced_item_id=referenced_item_id,
                referenced_item_name=referenced_item_name
            )
            return
        except Exception as ex:
            last_error = ex
            logger.warning(
                "Link attempt %s/%s failed for item_id=%s, field=%s, ref_id=%s, ref_name=%s | error=%s",
                attempt, attempts, item_id, reference_field_name, referenced_item_id, referenced_item_name, ex
            )
            if attempt < attempts:
                time.sleep(sleep_sec)

    raise RuntimeError(
        f"Failed to link reference after {attempts} attempts: "
        f"item_id={item_id}, field={reference_field_name}, ref_id={referenced_item_id}, ref_name={referenced_item_name}, last_error={last_error}"
    )

# =========================================================
# PASS HELPERS
# =========================================================

def build_issue_scalar_field_updates(row, issue_tracker_fields, skipped_columns):
    issue_field_values = []
    mandatory_norm = {normalize_name(x) for x in MANDATORY_ISSUE_CREATE_FIELDS}

    for src_col, cfg in SAFE_ISSUE_MAPPING.items():
        if src_col not in row.index and src_col not in ("Pilot",):
            continue

        if cfg.get("mode") == "name":
            continue

        raw_value = get_effective_value_for_source_column(src_col, row)

        target_field_name = cfg["field"]
        field_meta = issue_tracker_fields.get(normalize_name(target_field_name))
        if not field_meta:
            if not is_blank(raw_value) or normalize_name(target_field_name) in mandatory_norm:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": f"Mapped Issue target field '{target_field_name}' not found",
                    "sample_value": clean_text(raw_value)
                })
            continue

        kind = cfg.get("kind")

        if kind == "choice":
            value_map = None
            if src_col == "Severity" and target_field_name == "Severity":
                value_map = SEVERITY_TO_CB_SEVERITY
            elif src_col == "Trouble_type":
                value_map = TROUBLE_TYPE_TO_CB
            elif src_col == "Context_Test_condition":
                value_map = CONTEXT_TO_CB
            elif src_col == "Perimeter":
                value_map = PERIMETER_TO_CB

            fv, err = build_choice_field_value(field_meta, raw_value, value_map=value_map)
            if fv:
                issue_field_values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": err,
                    "sample_value": clean_text(raw_value)
                })
            continue

        if kind == "member":
            fv, err = build_member_field_value(field_meta, PILOT_FORCE_ID, PILOT_FORCE_NAME)
            if fv:
                issue_field_values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": err,
                    "sample_value": PILOT_FORCE_NAME
                })
            continue

        fv = build_field_value(field_meta, raw_value)
        if fv:
            issue_field_values.append(fv)

    return issue_field_values

def pass1_create_or_update_issues(cb, df, state, issue_tracker_fields, skipped_columns, failed_rows):
    logger.info("PASS 1: create/update Issue items only")

    for idx, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        src_key = src_id.upper() if src_id else None
        title = clean_text(get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row))

        try:
            existing = state.get(src_key) if src_key else None
            issue_cb_id = None
            result_mode = None

            existing_issue_id = existing.get("issue_codebeamer_item_id") if existing else None

            if UPSERT_MODE == "update_if_in_state_else_create" and existing_issue_id:
                candidate_issue_id = int(existing_issue_id)

                is_valid, validation_reason = validate_existing_item_in_tracker(
                    cb=cb,
                    item_id=candidate_issue_id,
                    expected_tracker_id=ISSUE_TRACKER_ID
                )

                if is_valid:
                    issue_cb_id = candidate_issue_id
                    result_mode = "UPDATED_EXISTING_ISSUE_FROM_STATE"
                    logger.info(
                        "Updating existing Issue item from state: source=%s -> issue_cb_id=%s",
                        src_id, issue_cb_id
                    )
                else:
                    logger.warning(
                        "Ignoring stale/invalid state for source=%s, saved issue_cb_id=%s. Reason: %s",
                        src_id, candidate_issue_id, validation_reason
                    )
                    issue_cb_id, _created_issue = create_issue_item(
                        cb, ISSUE_TRACKER_ID, row, issue_tracker_fields
                    )
                    result_mode = "CREATED_ISSUE_REPLACED_INVALID_STATE"
                    logger.info(
                        "Created fresh Issue item after invalid state: source=%s -> issue_cb_id=%s",
                        src_id, issue_cb_id
                    )
            else:
                if UPSERT_MODE == "create_only" and existing_issue_id:
                    issue_cb_id = int(existing_issue_id)
                    result_mode = "SKIPPED_ALREADY_IN_STATE"
                    logger.info(
                        "Skipping already-known Issue item: source=%s -> issue_cb_id=%s",
                        src_id, issue_cb_id
                    )
                else:
                    issue_cb_id, _created_issue = create_issue_item(
                        cb, ISSUE_TRACKER_ID, row, issue_tracker_fields
                    )
                    result_mode = "CREATED_ISSUE"
                    logger.info("Created Issue item: source=%s -> issue_cb_id=%s", src_id, issue_cb_id)

            if src_key and issue_cb_id:
                update_state_entry(
                    state=state,
                    src_key=src_key,
                    issue_cb_id=issue_cb_id,
                    title=title,
                    status=result_mode,
                    child_refs=None
                )

            issue_field_values = build_issue_scalar_field_updates(
                row=row,
                issue_tracker_fields=issue_tracker_fields,
                skipped_columns=skipped_columns
            )

            if issue_cb_id and issue_field_values and result_mode != "SKIPPED_ALREADY_IN_STATE":
                update_item_fields(cb, issue_cb_id, issue_field_values)

        except Exception as ex:
            logger.exception("PASS 1 failed for source=%s", src_id)
            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "PASS_1_ISSUE_CREATE_UPDATE",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(STATE_FILE_CSV, state)

    save_state(STATE_FILE_CSV, state)

def pass2_create_child_items(cb, df, state, active_reference_rules, child_tracker_fields_cache, failed_rows):
    logger.info("PASS 2: create child tracker items only (no linking yet)")

    for idx, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        src_key = src_id.upper() if src_id else None
        title = clean_text(get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row))

        if not src_key:
            continue

        st = state.get(src_key, {})
        issue_cb_id = st.get("issue_codebeamer_item_id")
        if not issue_cb_id:
            logger.warning("PASS 2 skipping source=%s because issue ID is missing in state", src_id)
            continue

        existing_child_refs = get_child_refs_from_state_entry(st)
        per_row_child_refs_to_save = {}

        try:
            for rule in active_reference_rules:
                source_col = rule["source_column"]
                if source_col not in row.index:
                    continue

                raw_source_value = row.get(source_col)

                if rule.get("multi_value"):
                    source_values = split_multi_reference_values(raw_source_value)
                else:
                    one_value = clean_text(raw_source_value)
                    source_values = [one_value] if one_value else []

                if not source_values and rule["mode"] == "issue_points_to_child" and rule.get("use_placeholder_if_empty", False):
                    placeholder_ref = get_placeholder_reference_for_tracker(rule["tracker_name"])
                    if placeholder_ref:
                        source_values = [placeholder_ref["name"]]

                if not source_values:
                    continue

                state_key = rule["state_key"]
                existing_value_map = existing_child_refs.get(state_key, {})
                tracker_fields = child_tracker_fields_cache[rule["tracker_id"]]

                for source_value in source_values:
                    existing_child_id = existing_value_map.get(source_value)
                    if existing_child_id:
                        child_cb_id = int(existing_child_id)
                        logger.info(
                            "PASS 2 reusing child item from state/cache: source=%s, rule=%s, value=%s -> child_cb_id=%s",
                            src_id, state_key, source_value, child_cb_id
                        )
                    else:
                        placeholder_ref = get_placeholder_reference_for_tracker(rule["tracker_name"])
                        if placeholder_ref and source_value == placeholder_ref["name"] and rule["mode"] == "issue_points_to_child":
                            child_cb_id = placeholder_ref["id"]
                            logger.info(
                                "PASS 2 using placeholder child item: source=%s, rule=%s -> child_cb_id=%s",
                                src_id, state_key, child_cb_id
                            )
                        else:
                            child_cb_id, _created_child, was_created = get_or_create_reference_tracker_item(
                                cb=cb,
                                tracker_id=rule["tracker_id"],
                                tracker_name=rule["tracker_name"],
                                tracker_fields=tracker_fields,
                                source_value=source_value,
                                issue_title=title,
                                source_item_id=src_id
                            )
                            logger.info(
                                "PASS 2 %s child tracker item: source=%s, rule=%s, value=%s -> child_cb_id=%s",
                                "created" if was_created else "reused",
                                src_id, state_key, source_value, child_cb_id
                            )

                    if state_key not in per_row_child_refs_to_save:
                        per_row_child_refs_to_save[state_key] = {}
                    per_row_child_refs_to_save[state_key][source_value] = child_cb_id

            if per_row_child_refs_to_save:
                update_state_entry(
                    state=state,
                    src_key=src_key,
                    issue_cb_id=int(issue_cb_id),
                    title=title,
                    status="CHILD_ITEMS_CREATED",
                    child_refs=per_row_child_refs_to_save
                )

        except Exception as ex:
            logger.exception("PASS 2 failed for source=%s", src_id)
            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "PASS_2_CHILD_CREATE",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(STATE_FILE_CSV, state)

    save_state(STATE_FILE_CSV, state)

def pass3_link_child_items_and_status(cb, df, state, issue_tracker_fields, active_reference_rules, child_tracker_fields_cache, failed_rows):
    logger.info("PASS 3: link saved child items and update status (optimized batching)")

    if LINK_PASS_DELAY_SEC and LINK_PASS_DELAY_SEC > 0:
        logger.info("Waiting %.1f seconds before linking pass...", LINK_PASS_DELAY_SEC)
        time.sleep(LINK_PASS_DELAY_SEC)

    for idx, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        src_key = src_id.upper() if src_id else None
        title = clean_text(get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row))

        if not src_key:
            continue

        st = state.get(src_key, {})
        issue_cb_id = st.get("issue_codebeamer_item_id")
        if not issue_cb_id:
            logger.warning("PASS 3 skipping source=%s because issue ID is missing in state", src_id)
            continue

        issue_cb_id_int = int(issue_cb_id)
        existing_child_refs = get_child_refs_from_state_entry(st)

        try:
            # Collect issue-side refs grouped by target Issue field
            issue_field_ref_map = {}

            # child->issue links (Retex-like)
            child_to_issue_links = []

            for rule in active_reference_rules:
                source_col = rule["source_column"]
                if source_col not in row.index:
                    continue

                raw_source_value = row.get(source_col)

                if rule.get("multi_value"):
                    source_values = split_multi_reference_values(raw_source_value)
                else:
                    one_value = clean_text(raw_source_value)
                    source_values = [one_value] if one_value else []

                if not source_values and rule["mode"] == "issue_points_to_child" and rule.get("use_placeholder_if_empty", False):
                    placeholder_ref = get_placeholder_reference_for_tracker(rule["tracker_name"])
                    if placeholder_ref:
                        source_values = [placeholder_ref["name"]]

                if not source_values:
                    continue

                state_key = rule["state_key"]
                existing_value_map = existing_child_refs.get(state_key, {})

                for source_value in source_values:
                    existing_child_id = existing_value_map.get(source_value)
                    if not existing_child_id:
                        logger.warning(
                            "PASS 3 skipping link because child ID not found in state: source=%s, rule=%s, value=%s",
                            src_id, state_key, source_value
                        )
                        continue

                    child_cb_id = int(existing_child_id)

                    if rule["mode"] == "issue_points_to_child":
                        field_name = rule["issue_reference_field"]

                        if field_name in SKIP_ISSUE_REFERENCE_FIELDS:
                            logger.warning(
                                "PASS 3 skipping configured issue reference field: source=%s | field=%s",
                                src_id, field_name
                            )
                            continue

                        if field_name not in issue_field_ref_map:
                            issue_field_ref_map[field_name] = []
                        issue_field_ref_map[field_name].append((child_cb_id, source_value))

                    elif rule["mode"] == "child_points_to_issue":
                        child_to_issue_links.append((rule, child_cb_id, source_value))

            # 1) Bulk update Issue-side reference fields
            for field_name, child_refs in issue_field_ref_map.items():
                try:
                    logger.info(
                        "PASS 3 bulk linking issue field: source=%s | issue_id=%s | field=%s | refs=%s",
                        src_id, issue_cb_id_int, field_name, len(child_refs)
                    )
                    set_tracker_item_reference_field_on_item(
                        cb=cb,
                        item_id=issue_cb_id_int,
                        tracker_fields=issue_tracker_fields,
                        reference_field_name=field_name,
                        child_ids_and_names=child_refs
                    )
                except Exception as bulk_ex:
                    logger.error(
                        "PASS 3 bulk link failed but continuing: source=%s | field=%s | error=%s",
                        src_id, field_name, bulk_ex
                    )
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "PASS_3_BULK_ISSUE_FIELD_LINK",
                        "error": str(bulk_ex),
                        "field": field_name,
                        "issue_id": issue_cb_id_int
                    })

            # 2) Child -> Issue links (Retex etc.)
            for rule, child_cb_id, source_value in child_to_issue_links:
                try:
                    child_tracker_fields = child_tracker_fields_cache[rule["tracker_id"]]
                    logger.info(
                        "PASS 3 linking child->issue: source=%s | child_id=%s | field=%s | issue_id=%s",
                        src_id, child_cb_id, rule["child_reference_field"], issue_cb_id_int
                    )
                    link_reference_with_retry(
                        cb=cb,
                        item_id=child_cb_id,
                        tracker_fields=child_tracker_fields,
                        reference_field_name=rule["child_reference_field"],
                        referenced_item_id=issue_cb_id_int,
                        referenced_item_name=title or f"Issue {issue_cb_id_int}"
                    )
                except Exception as link_ex:
                    logger.error(
                        "PASS 3 child->issue link failed but continuing: source=%s | child_id=%s | field=%s | error=%s",
                        src_id, child_cb_id, rule["child_reference_field"], link_ex
                    )
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "PASS_3_CHILD_TO_ISSUE_LINK",
                        "error": str(link_ex),
                        "field": rule["child_reference_field"],
                        "child_id": child_cb_id,
                        "issue_id": issue_cb_id_int
                    })

            # 3) Status update last
            source_status = row.get("State")
            if not is_blank(source_status):
                try:
                    update_status_last(
                        cb=cb,
                        issue_item_id=issue_cb_id_int,
                        issue_tracker_fields=issue_tracker_fields,
                        raw_status_value=source_status
                    )
                except Exception as status_ex:
                    logger.error(
                        "PASS 3 status update failed but continuing: source=%s | issue_id=%s | error=%s",
                        src_id, issue_cb_id_int, status_ex
                    )
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "PASS_3_STATUS_UPDATE",
                        "error": str(status_ex),
                        "issue_id": issue_cb_id_int
                    })

            update_state_entry(
                state=state,
                src_key=src_key,
                issue_cb_id=issue_cb_id_int,
                title=title,
                status="LINKED_AND_STATUS_UPDATED",
                child_refs=None
            )

        except Exception as ex:
            logger.exception("PASS 3 failed for source=%s", src_id)
            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "PASS_3_ROW_LEVEL",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(STATE_FILE_CSV, state)

    save_state(STATE_FILE_CSV, state)

# =========================================================
# MAIN
# =========================================================

def main():
    logger.info("Loading local state...")
    state = load_state(STATE_FILE_CSV)

    logger.info("Connecting to MySQL...")
    conn_url = URL.create(
        "mysql+mysqlconnector",
        username=MYSQL_USER,
        password=MYSQL_PASS,
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        database=MYSQL_DB,
        query={"charset": "utf8mb4"}
    )
    engine = create_engine(conn_url)

    logger.info("Reading source rows...")
    df = pd.read_sql(text(SOURCE_SQL), engine)
    if df.empty:
        logger.info("No source rows found. Exiting.")
        return

    df = df.astype(object).where(pd.notna(df), None)
    logger.info("Loaded %s source rows.", len(df))

    logger.info("Connecting to Codebeamer...")
    cb = CodebeamerClient(
        CB_BASE_URL,
        CB_USER,
        CB_PASS,
        verify_ssl=VERIFY_SSL,
        timeout=TIMEOUT
    )

    logger.info("Using Issue tracker id: %s", ISSUE_TRACKER_ID)

    logger.info("Loading Issue tracker fields...")
    issue_tracker_fields = load_tracker_fields(cb, ISSUE_TRACKER_ID)

    active_reference_rules = resolve_reference_rules(list(df.columns), REFERENCE_TRACKER_RULES)
    logger.info("Active reference rules: %s", [r["source_column"] for r in active_reference_rules])

    prime_reference_cache_from_state(state, active_reference_rules)

    log_field_debug(issue_tracker_fields, "Trouble Type")
    log_field_debug(issue_tracker_fields, "Pilot")
    log_field_debug(issue_tracker_fields, "Context")
    log_field_debug(issue_tracker_fields, "Detailed Context")
    log_field_debug(issue_tracker_fields, "Perimeter")

    # Load child tracker fields for ALL active child trackers
    child_tracker_fields_cache = {}
    unique_child_tracker_ids = sorted({r["tracker_id"] for r in active_reference_rules})
    for tracker_id in unique_child_tracker_ids:
        logger.info("Loading child tracker fields for tracker id=%s", tracker_id)
        child_tracker_fields_cache[tracker_id] = load_tracker_fields(cb, tracker_id)

    skipped_columns = []
    reference_source_columns = {r["source_column"] for r in active_reference_rules}

    for col in df.columns:
        if col in SAFE_ISSUE_MAPPING:
            continue

        if col in reference_source_columns:
            continue

        if col in USER_MEMBER_FIELDS_TO_SKIP:
            skipped_columns.append({
                "source_column": col,
                "reason": USER_MEMBER_FIELDS_TO_SKIP[col],
                "sample_value": first_non_null_sample(df, col)
            })
        elif col in REFERENCE_ITEM_FIELDS_TO_SKIP:
            skipped_columns.append({
                "source_column": col,
                "reason": REFERENCE_ITEM_FIELDS_TO_SKIP[col],
                "sample_value": first_non_null_sample(df, col)
            })
        elif col in SPECIAL_SKIP_FIELDS:
            skipped_columns.append({
                "source_column": col,
                "reason": SPECIAL_SKIP_FIELDS[col],
                "sample_value": first_non_null_sample(df, col)
            })
        elif col in INTENTIONAL_SKIP_COLUMNS:
            skipped_columns.append({
                "source_column": col,
                "reason": INTENTIONAL_SKIP_COLUMNS[col],
                "sample_value": first_non_null_sample(df, col)
            })
        else:
            skipped_columns.append({
                "source_column": col,
                "reason": "Not in safe mapping / no confirmed supported target field type",
                "sample_value": first_non_null_sample(df, col)
            })

    failed_rows = []

    pass1_create_or_update_issues(
        cb=cb,
        df=df,
        state=state,
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns,
        failed_rows=failed_rows
    )

    pass2_create_child_items(
        cb=cb,
        df=df,
        state=state,
        active_reference_rules=active_reference_rules,
        child_tracker_fields_cache=child_tracker_fields_cache,
        failed_rows=failed_rows
    )

    pass3_link_child_items_and_status(
        cb=cb,
        df=df,
        state=state,
        issue_tracker_fields=issue_tracker_fields,
        active_reference_rules=active_reference_rules,
        child_tracker_fields_cache=child_tracker_fields_cache,
        failed_rows=failed_rows
    )

    save_state(STATE_FILE_CSV, state)

    refreshed_rows = []
    for _, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        if not src_id:
            continue
        src_key = src_id.upper()
        st = state.get(src_key, {})
        refreshed_rows.append({
            "source_item_id": src_id,
            "issue_codebeamer_item_id": st.get("issue_codebeamer_item_id"),
            "retex_codebeamer_item_id": st.get("retex_codebeamer_item_id"),
            "title": clean_text(get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row)),
            "status": st.get("status"),
            "child_refs_json": st.get("child_refs_json"),
        })

    if refreshed_rows:
        pd.DataFrame(refreshed_rows).to_csv(CREATED_MAP_CSV, index=False, encoding="utf-8-sig")
        logger.info("Created/updated report written: %s", CREATED_MAP_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(FAILED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.info("Failed rows report written: %s", FAILED_ROWS_CSV)
    else:
        logger.info("No failed rows.")

    if skipped_columns:
        skip_df = pd.DataFrame(skipped_columns).drop_duplicates(subset=["source_column", "reason"])
        skip_df.to_csv(SKIPPED_COLUMNS_REPORT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Skipped columns report written: %s", SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("No skipped columns.")

    logger.info("Issue + reference tracker sync completed successfully.")

if __name__ == "__main__":
    main()