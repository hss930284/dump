import re
import os
import json
import time
import logging
import subprocess
import mimetypes

import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL


# =========================================================
# CONFIGURATION
# =========================================================

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "horse"
MYSQL_USER = "root"
MYSQL_PASS = "root"

TABLE_NAME = "sbm_issue"

SOURCE_SQL = f"""
SELECT *
FROM `{TABLE_NAME}`
-- WHERE `Item_Id` = 'IS138422'
LIMIT 20
"""

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 20
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_ID = 48

ISSUE_TRACKER_ID = 294498
ISSUE_TRACKER_NAME = "Issue"

RETEX_TRACKER_ID = 294309
RETEX_TRACKER_NAME = "Retex"

RETEX_TO_ISSUE_FIELD_NAME = "Issue"

ISSUE_SBM_ITEM_ID_FIELD_NAME = "SBM Item Id"
RETEX_SBM_ITEM_ID_FIELD_NAME = "SBM Retex Id"

# =========================================================
# MIGRATED DATA CONFIG
# =========================================================

MIGRATED_DATA_FIELD_NAME = "Migrated Data ?"
MIGRATED_DATA_VALUE = "Yes"

SOURCE_KEY_COLUMN = "Item_Id"
SUMMARY_SOURCE_COLUMN = "Title"
RETEX_SOURCE_COLUMN = "Retex"

AEMS_FUNCTION_TRACKER_ID = 295319
AEMS_FUNCTION_TRACKER_NAME = "H-EMS Function"

AEMS_SPECIFICATION_TRACKER_ID = 295425
AEMS_SPECIFICATION_TRACKER_NAME = "H-EMS Specification"

AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME = "SBM SDT Id"
CORRECTIVE_SDTS_SOURCE_COLUMN = "Corrective_SDTs"

DETECTED_ENGINE_SOURCE_COLUMN_CANDIDATES = ["Detected Engine", "Detected_Engine"]
DETECTED_VEHICLE_SOURCE_COLUMN_CANDIDATES = ["Detected Vehicle", "Detected_Vehicle"]

AEMS_MODULE_TRACKER_ID = 295368
AEMS_MODULE_TRACKER_NAME = "H-EMS Module"

FIRST_VEHICLE_APPLICATION_TRACKER_ID = 295575
FIRST_VEHICLE_APPLICATION_TRACKER_NAME = "First Vehicle Application"

FIRST_ENGINE_APPLICATION_TRACKER_ID = 295532
FIRST_ENGINE_APPLICATION_TRACKER_NAME = "First Engine Application"

PILOT_FORCE_NAME = "cbadmin"
PILOT_FORCE_ID = 1
PILOT_REFERENCE_TYPE = "UserReference"

NEW_OR_EVOLUTION_FORCE_VALUE = "New"

TROUBLE_TYPE_FORCE_VALUE = None
CONTEXT_FORCE_VALUE = None
PERIMETER_FORCE_VALUE = None

MANDATORY_ISSUE_CREATE_FIELDS = [
    "Trouble Type",
    "Pilot",
    "Context",
    "Perimeter",
]

TROUBLE_TYPE_TO_CB = {
    "Calibration": "Calibration",
    "Software": "Software",
}

CONTEXT_TO_CB = {
    "Proving ground (Test course) / Vehicule": "Proving ground (Test course) / Vehicule",
    "System Validation": "System Validation",
    "HIL validation": "HIL validation",
    "Plant": "Plant",
}

PERIMETER_TO_CB = {
    "ASXX": "ASXX",
    "CMB": "CMB",
    "CMBA": "CMBA",
    "Safety AEMS": "Safety AEMS",
    "SYS": "SYS",
}

PLACEHOLDER_REFERENCE_ITEMS = {
    AEMS_SPECIFICATION_TRACKER_NAME: {"id": 146663, "name": "[PLACEHOLDER - DELETE LATER]"},
    AEMS_MODULE_TRACKER_NAME: {"id": 146667, "name": "[PLACEHOLDER - DELETE LATER]"},
    AEMS_FUNCTION_TRACKER_NAME: {"id": 146669, "name": "[PLACEHOLDER - DELETE LATER]"},
    FIRST_ENGINE_APPLICATION_TRACKER_NAME: {"id": 146671, "name": "[PLACEHOLDER - DELETE LATER]"},
    FIRST_VEHICLE_APPLICATION_TRACKER_NAME: {"id": 146673, "name": "[PLACEHOLDER - DELETE LATER]"},
}

PLACEHOLDER_TEXT_VALUES = {
    "Detailed_Context": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Expected_Behavior": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Observed_Behavior": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Impact": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
    "Solution_Description": "[MIGRATION PLACEHOLDER - SOURCE EMPTY]",
}

CREATED_MAP_CSV = "created_updated_issue_retex.csv"
FAILED_ROWS_CSV = "failed_rows_issue_retex.csv"
SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_issue_retex.csv"
CHANGE_AUDIT_CSV = "changed_fields_issue_retex.csv"
DUPLICATE_SOURCE_ROWS_CSV = "duplicate_source_rows_issue_retex.csv"
DUPLICATE_EXISTING_ISSUES_CSV = "duplicate_existing_issues_by_sbm_item_id.csv"
DUPLICATE_EXISTING_RETEX_CSV = "duplicate_existing_retex_by_sbm_retex_id.csv"
DUPLICATE_EXISTING_AEMS_SPEC_CSV = "duplicate_existing_aems_spec_by_sbm_item_id.csv"

MYSQL_CREATED_ITEM_EXPORT_DIR = r"D:\SBM"

ATTACH_CREATED_EXCEL_TO_ISSUE = True
ATTACH_EXCEL_TO_EXISTING_ISSUE = True

PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT = True

ATTACHMENT_MANIFEST_CSV = "issue_excel_attachment_manifest_v3.csv"

TRUST_MANIFEST_TO_SKIP_ATTACHMENT = False

ATTACHMENT_DESCRIPTION_TEXT = "MySQL source row export attached during migration."

LOG_FILE = "codebeamer_issue_retex_import.log"
RUN_LOCK_FILE = "codebeamer_issue_retex_import.lock"

LINK_RETRY_ATTEMPTS = 1
LINK_RETRY_SLEEP_SEC = 0

SKIP_ISSUE_REFERENCE_FIELDS = set([
    # "Impacted Specification",
    # "Detected Specification",
    # "Corrective SDTs",
])

REFERENCE_TRACKER_RULES = [
    {
        "state_key": "Retex",
        "source_column": RETEX_SOURCE_COLUMN,
        "tracker_name": RETEX_TRACKER_NAME,
        "tracker_id": RETEX_TRACKER_ID,
        "mode": "child_points_to_issue",
        "child_reference_field": RETEX_TO_ISSUE_FIELD_NAME,
        "multi_value": False,
        "use_placeholder_if_empty": False,
    },
    {
        "state_key": "Introduction_Specifications",
        "source_column": "Introduction_Specifications",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Introduction Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Specifications_AEMS",
        "source_column": "Impacted_Specifications_AEMS",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Corrective_SDTs",
        "source_column": CORRECTIVE_SDTS_SOURCE_COLUMN,
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Corrective SDTs",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Modules_AEMS",
        "source_column": "Impacted_Modules_AEMS",
        "tracker_name": AEMS_MODULE_TRACKER_NAME,
        "tracker_id": AEMS_MODULE_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Modules",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Impacted_Vehicles",
        "source_column": "Impacted_Vehicles",
        "tracker_name": FIRST_VEHICLE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_VEHICLE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Impacted Vehicles",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Module_AEMS",
        "source_column": "Detected_Module_AEMS",
        "tracker_name": AEMS_MODULE_TRACKER_NAME,
        "tracker_id": AEMS_MODULE_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Module",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Specifications_AEMS",
        "source_column": "Detected_Specifications_AEMS",
        "tracker_name": AEMS_SPECIFICATION_TRACKER_NAME,
        "tracker_id": AEMS_SPECIFICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Specification",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Vehicle",
        "source_columns": DETECTED_VEHICLE_SOURCE_COLUMN_CANDIDATES,
        "tracker_name": FIRST_VEHICLE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_VEHICLE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Vehicle",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
    {
        "state_key": "Detected_Engine",
        "source_columns": DETECTED_ENGINE_SOURCE_COLUMN_CANDIDATES,
        "tracker_name": FIRST_ENGINE_APPLICATION_TRACKER_NAME,
        "tracker_id": FIRST_ENGINE_APPLICATION_TRACKER_ID,
        "mode": "issue_points_to_child",
        "issue_reference_field": "Detected Engine",
        "multi_value": True,
        "use_placeholder_if_empty": True,
    },
]

SAFE_ISSUE_MAPPING = {
    "Item_Id": {"field": ISSUE_SBM_ITEM_ID_FIELD_NAME},
    "Title": {"mode": "name"},
    "IS_Category": {"field": "IS Category", "kind": "choice"},
    "Trouble_type": {"field": "Trouble Type", "kind": "choice"},
    "Severity": {"field": "Severity", "kind": "choice"},
    "Pilot": {"field": "Pilot", "kind": "member"},
    "Perimeter": {"field": "Perimeter", "kind": "choice"},
    "Context_Test_condition": {"field": "Context", "kind": "choice"},
    "Responsibility": {"field": "Responsibility", "kind": "choice"},
    "Detailed_Context": {"field": "Detailed Context"},
    "Expected_Behavior": {"field": "Expected Behavior"},
    "Observed_Behavior": {"field": "Observed Behavior"},
    "Impact": {"field": "Impact"},
    "Solution_Description": {"field": "Solution Description"},
    "Delivered_Solution": {"field": "Delivered Solution"},
    "Corrected_Software": {"field": "Corrected Software"},
    "ECU_Part_Version": {"field": "ECU/Part Version"},
    "Impacted_Technical_Definition": {"field": "Impacted Technical Definition"},
    "Safety_Impact": {"field": "Safety Impact", "kind": "choice"},
    "Regulation_Impact": {"field": "Regulation Impact", "kind": "choice"},
    "Detected_Software_AEMS": {"field": "Detected Software", "kind": "choice"},
    "Detected_SOF_AEMS": {"field": "Detected SOF", "kind": "choice"},
    "ECU_Part_Name": {"field": "ECU/Part Name", "kind": "choice"},
    "Auto_Impact_Specifications_AEMS": {"field": "Auto Impact Specification", "kind": "choice"},
    "Auto_Impact_Projects_AEMS": {"field": "Auto Impact Projects", "kind": "choice"},
    "Auto_Impact_SOFs": {"field": "Auto Impact SOFs", "kind": "choice"},
    "Auto_Impacts_BCCs": {"field": "Auto Impact BCCs", "kind": "choice"},
    "Auto_Impacts_Modules": {"field": "Auto Impact Modules", "kind": "choice"},
    "Impacted_Software_AEMS": {"field": "Impacted Software", "kind": "choice"},
    "Impacted_Projects": {"field": "Impacted Projects", "kind": "choice"},
    "Planned_Model_Delivery": {"field": "Planned Model Delivery", "kind": "choice"},
    "Expected_Resolution_Date": {"field": "Expected Resolution Date"},
}

STATE_TO_CB_STATUS = {
    "Analysis": "Analysis",
    "Defining the Solution": "Defining the Solution",
    "Waiting for Solution": "Waiting for Solution",
    "Solution Available": "Solution Available",
    "Solution Validated": "Solution Validated",
}

SEVERITY_TO_CB_SEVERITY = {
    "K1 Blocking": "K1 Blocking",
    "K2 Very Disturbing": "K2 Very Disturbing",
    "K3 Disturbing": "K3 Disturbing",
    "K4 Minor": "K4 Minor",
}

INTENTIONAL_SKIP_COLUMNS = {
    "Submitter": "User lookup required; skipped for now",
    "Owner": "User/member lookup required; skipped for now",
    "Secondary_Owner": "User/member lookup required; skipped for now",
    "Last_Modified_Date": "System-managed field",
    "Last_Modifier": "System-managed field",
    "Last_State_Change_Date": "System-managed field",
    "Last_State_Changer": "System-managed field",
    "Open_Date": "Workflow/system-managed field",
    "Close_Date": "Workflow/system-managed field",
    "State": "Status is applied last after references are linked",
}

USER_MEMBER_FIELDS_TO_SKIP = {
    "Owner": "Issue tracker field 'Owner' is a Members field; requires user/member lookup",
    "Secondary_Owner": "User/member lookup required",
    "Submitter": "User lookup required",
}

REFERENCE_ITEM_FIELDS_TO_SKIP = {
    "Introduction_Module_Version": "Target field needs tracker item lookup / reference handling",
    "Impacted_Engines": "Target field needs tracker item lookup / reference handling",
    "Corrected_Specifications": "Target field needs tracker item lookup / reference handling",
    "Change_Request_No": "Possible candidate for 'Linked CR/DMFI'; add later when confirmed",
}

SPECIAL_SKIP_FIELDS = {
    "Applicability": "Applicability is a table field; needs dedicated table payload builder",
}


# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger_obj = logging.getLogger("cb_issue_retex_sync")
    logger_obj.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.INFO)

    logger_obj.handlers.clear()
    logger_obj.addHandler(fh)
    logger_obj.addHandler(ch)

    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(s):
    return re.sub(r"\s+", " ", str(s).strip()).lower()


def normalize_cache_key(s):
    return re.sub(r"\s+", "", str(s).strip()).lower()


def is_blank(v):
    if v is None:
        return True

    try:
        if pd.isna(v):
            return True
    except Exception:
        pass

    if isinstance(v, str):
        s = v.strip()
        if s in ("", "(None)", "None", "nan", "NaN", "--", "null", "NULL"):
            return True

    return False


def clean_text(v):
    if is_blank(v):
        return None

    s = str(v).replace("\r", "").replace("_x000D_", "").strip()
    return s if s else None


def extract_retex_id(value):
    txt = clean_text(value)

    if not txt:
        return None

    return txt.split(":", 1)[0].strip()


def extract_retex_title_for_codebeamer(value):
    txt = clean_text(value)

    if not txt:
        return None

    parts = [p.strip() for p in txt.split(":")]

    if len(parts) >= 3:
        return ":".join(parts[2:]).strip()

    if len(parts) == 2:
        return parts[1].strip()

    return txt


def parse_sbm_id_title_value(value):
    txt = clean_text(value)

    if not txt:
        return None, None

    if ":" not in txt:
        return None, txt

    sbm_id, title = txt.split(":", 1)

    sbm_id = clean_text(sbm_id)
    title = clean_text(title)

    return sbm_id, title


def extract_sbm_id_from_reference_value(value):
    sbm_id, _title = parse_sbm_id_title_value(value)
    return sbm_id


def extract_title_from_reference_value(value):
    _sbm_id, title = parse_sbm_id_title_value(value)
    return title or clean_text(value)


def get_rule_tracker_id(rule):
    return rule.get("tracker_id") or rule.get("target_tracker_id")


def get_rule_tracker_name(rule):
    return rule.get("tracker_name") or rule.get("target_tracker_name")


def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def split_multi_reference_values(v):
    txt = clean_text(v)

    if not txt:
        return []

    parts = [p.strip() for p in str(txt).split(",")]
    cleaned = []
    seen = set()

    for p in parts:
        if is_blank(p):
            continue

        key = normalize_name(p)

        if key in seen:
            continue

        seen.add(key)
        cleaned.append(p)

    return cleaned


def first_non_null_sample(df, col):
    if col not in df.columns:
        return None

    ser = df[col].dropna()

    if ser.empty:
        return None

    return clean_text(ser.iloc[0])


def get_effective_value_for_source_column(src_col, row):
    if src_col == "Pilot" and PILOT_FORCE_NAME:
        return PILOT_FORCE_NAME

    if src_col == "New_or_Evolution":
        raw_noe = row.get(src_col) if src_col in row.index else None
        if is_blank(raw_noe):
            return NEW_OR_EVOLUTION_FORCE_VALUE
        return raw_noe

    if src_col == "Trouble_type":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and TROUBLE_TYPE_FORCE_VALUE:
            return TROUBLE_TYPE_FORCE_VALUE
        return raw

    if src_col == "Context_Test_condition":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and CONTEXT_FORCE_VALUE:
            return CONTEXT_FORCE_VALUE
        return raw

    if src_col == "Perimeter":
        raw = row.get(src_col) if src_col in row.index else None
        if is_blank(raw) and PERIMETER_FORCE_VALUE:
            return PERIMETER_FORCE_VALUE
        return raw

    raw = row.get(src_col) if src_col in row.index else None

    if is_blank(raw) and src_col in PLACEHOLDER_TEXT_VALUES:
        return PLACEHOLDER_TEXT_VALUES[src_col]

    return raw


def get_placeholder_reference_for_tracker(tracker_name):
    ph = PLACEHOLDER_REFERENCE_ITEMS.get(tracker_name)

    if not ph:
        return None

    ph_id = ph.get("id")
    ph_name = ph.get("name")

    if ph_id is None or not ph_name:
        return None

    return {
        "id": int(ph_id),
        "name": str(ph_name)
    }


def to_iso_datetime_string(v):
    if is_blank(v):
        return None

    dt = pd.to_datetime(v, errors="coerce")

    if pd.isna(dt):
        return None

    return dt.strftime("%Y-%m-%dT%H:%M:%S.000")


def to_bool_or_none(v):
    if is_blank(v):
        return None

    s = str(v).strip().lower()

    if s in ("yes", "true", "1", "y"):
        return True

    if s in ("no", "false", "0", "n"):
        return False

    return None


def to_int_or_none(v):
    if is_blank(v):
        return None

    try:
        return int(float(v))
    except Exception:
        return None


def to_float_or_none(v):
    if is_blank(v):
        return None

    try:
        return float(v)
    except Exception:
        return None


# =========================================================
# RUN LOCK / SOURCE DEDUP
# =========================================================

def is_pid_running(pid):
    if not pid:
        return False

    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True
        )

        output = result.stdout.strip()

        if not output or "No tasks are running" in output:
            return False

        return str(pid) in output

    except Exception:
        return False


def read_pid_from_lock_file(lock_file):
    try:
        with open(lock_file, "r", encoding="utf-8") as f:
            content = f.read()

        match = re.search(r"PID:\s*(\d+)", content)

        if match:
            return int(match.group(1))

    except Exception:
        pass

    return None


def acquire_run_lock():
    if os.path.exists(RUN_LOCK_FILE):
        existing_pid = read_pid_from_lock_file(RUN_LOCK_FILE)

        if existing_pid and is_pid_running(existing_pid):
            raise RuntimeError(
                f"Another import run is still active. "
                f"Lock file exists: {RUN_LOCK_FILE}. "
                f"Running PID: {existing_pid}"
            )

        logger.warning(
            "Stale lock file found and removed automatically: %s",
            RUN_LOCK_FILE
        )

        os.remove(RUN_LOCK_FILE)

    with open(RUN_LOCK_FILE, "w", encoding="utf-8") as f:
        f.write(f"Started at: {pd.Timestamp.now()}\n")
        f.write(f"PID: {os.getpid()}\n")

    logger.info("Run lock acquired: %s", RUN_LOCK_FILE)


def release_run_lock():
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)
            logger.info("Run lock released: %s", RUN_LOCK_FILE)
    except Exception as ex:
        logger.warning("Unable to remove run lock file %s. Error=%s", RUN_LOCK_FILE, ex)


def deduplicate_source_rows_by_item_id(df):
    if SOURCE_KEY_COLUMN not in df.columns:
        return df

    df = df.copy()

    df["_normalized_source_key"] = df[SOURCE_KEY_COLUMN].apply(
        lambda x: clean_text(x).upper() if clean_text(x) else None
    )

    duplicate_mask = df.duplicated(subset=["_normalized_source_key"], keep="first")
    duplicate_count = int(duplicate_mask.sum())

    if duplicate_count > 0:
        duplicate_df = df.loc[duplicate_mask].drop(columns=["_normalized_source_key"])

        duplicate_df.to_csv(
            DUPLICATE_SOURCE_ROWS_CSV,
            index=False,
            encoding="utf-8-sig"
        )

        logger.warning(
            "Duplicate source rows found. duplicate_count=%s. Report=%s",
            duplicate_count,
            DUPLICATE_SOURCE_ROWS_CSV
        )

    df = df.drop_duplicates(subset=["_normalized_source_key"], keep="first")
    df = df.drop(columns=["_normalized_source_key"])

    return df


# =========================================================
# GLOBAL CACHES / REPORT ROWS
# =========================================================

ISSUE_EXISTING_BY_SBM_ITEM_ID = {}
RETEX_EXISTING_BY_SBM_ITEM_ID = {}
AEMS_SPEC_EXISTING_BY_SBM_ITEM_ID = {}

DUPLICATE_EXISTING_ISSUE_ROWS = []
DUPLICATE_EXISTING_RETEX_ROWS = []
DUPLICATE_EXISTING_AEMS_SPEC_ROWS = []

REFERENCE_ITEM_CACHE = {}
REFERENCE_TRACKER_EXISTING_CACHE = {}

CHANGE_AUDIT_ROWS = []
PROCESSED_SOURCE_IDS_THIS_RUN = set()

ATTACHMENT_MANIFEST_ROWS = []
ATTACHMENT_MANIFEST_KEYS = set()


# =========================================================
# ATTACHMENT MANIFEST HELPERS
# =========================================================

def build_stable_excel_file_name(source_item_id, tracker_name, codebeamer_item_id):
    safe_source_item_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(source_item_id).strip())
    safe_tracker_name = re.sub(r"[^A-Za-z0-9_-]", "_", str(tracker_name).strip())

    return f"{safe_tracker_name}_{safe_source_item_id}_CB_{codebeamer_item_id}.xlsx"


def build_attachment_manifest_key(source_item_id, issue_item_id, excel_file_name):
    return (
        clean_text(source_item_id).upper() if clean_text(source_item_id) else "",
        str(issue_item_id).strip() if issue_item_id else "",
        str(excel_file_name).strip().lower() if excel_file_name else ""
    )


def load_attachment_manifest():
    ATTACHMENT_MANIFEST_ROWS.clear()
    ATTACHMENT_MANIFEST_KEYS.clear()

    if not os.path.exists(ATTACHMENT_MANIFEST_CSV):
        logger.info(
            "Attachment manifest not found. A new one will be created: %s",
            ATTACHMENT_MANIFEST_CSV
        )
        return

    try:
        df_manifest = pd.read_csv(ATTACHMENT_MANIFEST_CSV, dtype=str).fillna("")

        for _, row in df_manifest.iterrows():
            source_item_id = row.get("source_item_id")
            issue_item_id = row.get("issue_codebeamer_item_id")
            excel_file_name = row.get("excel_file_name")
            attached_status = row.get("attached_status")

            if str(attached_status).strip().upper() == "YES":
                key = build_attachment_manifest_key(
                    source_item_id=source_item_id,
                    issue_item_id=issue_item_id,
                    excel_file_name=excel_file_name
                )
                ATTACHMENT_MANIFEST_KEYS.add(key)

            ATTACHMENT_MANIFEST_ROWS.append(dict(row))

        logger.info(
            "Attachment manifest loaded: rows=%s | attached_keys=%s | file=%s",
            len(ATTACHMENT_MANIFEST_ROWS),
            len(ATTACHMENT_MANIFEST_KEYS),
            ATTACHMENT_MANIFEST_CSV
        )

    except Exception as ex:
        logger.warning(
            "Unable to load attachment manifest. Continuing without manifest cache. file=%s | error=%s",
            ATTACHMENT_MANIFEST_CSV,
            ex
        )


def is_attachment_already_recorded_in_manifest(source_item_id, issue_item_id, excel_file_name):
    if not PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT:
        return False

    key = build_attachment_manifest_key(
        source_item_id=source_item_id,
        issue_item_id=issue_item_id,
        excel_file_name=excel_file_name
    )

    return key in ATTACHMENT_MANIFEST_KEYS


def add_attachment_manifest_row(source_item_id, issue_item_id, excel_file_path, issue_mode, attached_status, action):
    excel_file_name = os.path.basename(excel_file_path) if excel_file_path else None

    row = {
        "source_item_id": source_item_id,
        "issue_codebeamer_item_id": issue_item_id,
        "excel_file_name": excel_file_name,
        "excel_file_path": excel_file_path,
        "issue_mode": issue_mode,
        "attached_status": attached_status,
        "action": action,
        "logged_at": str(pd.Timestamp.now())
    }

    ATTACHMENT_MANIFEST_ROWS.append(row)

    if str(attached_status).strip().upper() == "YES":
        key = build_attachment_manifest_key(
            source_item_id=source_item_id,
            issue_item_id=issue_item_id,
            excel_file_name=excel_file_name
        )
        ATTACHMENT_MANIFEST_KEYS.add(key)


def write_attachment_manifest():
    if not ATTACHMENT_MANIFEST_ROWS:
        logger.info("No attachment manifest rows to write.")
        return

    pd.DataFrame(ATTACHMENT_MANIFEST_ROWS).drop_duplicates(
        subset=[
            "source_item_id",
            "issue_codebeamer_item_id",
            "excel_file_name",
            "attached_status",
            "action"
        ],
        keep="first"
    ).to_csv(
        ATTACHMENT_MANIFEST_CSV,
        index=False,
        encoding="utf-8-sig"
    )

    logger.info("Attachment manifest written: %s", ATTACHMENT_MANIFEST_CSV)


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url, username, password, verify_ssl=True, timeout=60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Content-Type": "application/json"})

        retry = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )

        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path):
        return f"{self.base_url}{path}"

    def get(self, path, params=None):
        safe_sleep()
        r = self.session.get(self._url(path), params=params, timeout=self.timeout)
        self._raise_for_status(r)
        return r.json()

    def post(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.post(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def put(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.put(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def post_multipart(self, path, files=None, data=None, params=None):
        safe_sleep()

        old_content_type = self.session.headers.pop("Content-Type", None)

        try:
            headers = {
                "Accept": "application/json"
            }

            r = self.session.post(
                self._url(path),
                params=params,
                files=files,
                data=data or {},
                headers=headers,
                timeout=self.timeout
            )

            self._raise_for_status(r)

            return r.json() if r.text.strip() else {}

        finally:
            if old_content_type:
                self.session.headers["Content-Type"] = old_content_type

    @staticmethod
    def _raise_for_status(r):
        try:
            r.raise_for_status()
        except requests.HTTPError:
            raise RuntimeError(f"HTTP {r.status_code} | URL={r.url} | Response={r.text}")
        
# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb, tracker_id):
    refs = cb.get(f"/v3/trackers/{tracker_id}/fields")

    field_map = {}

    for ref in refs:
        fid = ref["id"]
        detail = cb.get(f"/v3/trackers/{tracker_id}/fields/{fid}")
        field_map[normalize_name(detail["name"])] = detail

    return field_map


def get_item_detail(cb, item_id):
    return cb.get(f"/v3/items/{item_id}")


def get_tracker_item_name(cb, item_id):
    try:
        item = get_item_detail(cb, item_id)
        return item.get("name") or str(item_id)
    except Exception:
        return str(item_id)


def load_item_fields_robust(cb, item_id):
    all_fields = []

    try:
        fields_response = cb.get(f"/v3/items/{item_id}/fields")

        if isinstance(fields_response, list):
            all_fields.extend(fields_response)

        elif isinstance(fields_response, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = fields_response.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load /fields for item_id=%s. Error=%s", item_id, ex)

    try:
        item_detail = cb.get(f"/v3/items/{item_id}")

        if isinstance(item_detail, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = item_detail.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load item detail fields for item_id=%s. Error=%s", item_id, ex)

    return all_fields


def extract_items_from_query_response(data):
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("items", "itemRefs", "results", "data"):
            val = data.get(key)
            if isinstance(val, list):
                return val

    return []


def extract_item_id_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("id", "itemId"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("id", "itemId"):
                value = nested.get(key)
                if value:
                    return value

    uri = item_ref.get("uri") or item_ref.get("url")

    if uri:
        m = re.search(r"/items/(\d+)", str(uri))
        if m:
            return int(m.group(1))

    return None


def extract_item_name_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("name", "title"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("name", "title"):
                value = nested.get(key)
                if value:
                    return value

    return None


def extract_field_value_by_name_from_fields(field_values, field_name):
    target_key = normalize_name(field_name)

    if not isinstance(field_values, list):
        return None

    for fv in field_values:
        if not isinstance(fv, dict):
            continue

        possible_names = [
            fv.get("name"),
            fv.get("fieldName"),
            fv.get("label"),
        ]

        field_obj = fv.get("field")
        if isinstance(field_obj, dict):
            possible_names.extend([
                field_obj.get("name"),
                field_obj.get("fieldName"),
                field_obj.get("label"),
            ])

        if not any(normalize_name(x) == target_key for x in possible_names if x):
            continue

        if fv.get("value") is not None:
            val = fv.get("value")

            if isinstance(val, dict):
                return clean_text(
                    val.get("name")
                    or val.get("value")
                    or val.get("text")
                    or val.get("label")
                    or val.get("id")
                )

            return clean_text(val)

        if fv.get("text") is not None:
            return clean_text(fv.get("text"))

        values = fv.get("values")

        if isinstance(values, list) and values:
            names = []

            for item in values:
                if isinstance(item, dict):
                    names.append(
                        clean_text(
                            item.get("name")
                            or item.get("value")
                            or item.get("text")
                            or item.get("label")
                            or item.get("id")
                        )
                    )
                else:
                    names.append(clean_text(item))

            names = [x for x in names if x]

            if names:
                return ", ".join(names)

    return None


def validate_existing_item_in_tracker(cb, item_id, expected_tracker_id):
    try:
        item = get_item_detail(cb, item_id)
    except Exception as ex:
        return False, f"Item {item_id} not accessible: {ex}"

    tracker = item.get("tracker") or {}
    tracker_id = tracker.get("id")

    if str(tracker_id) != str(expected_tracker_id):
        return False, f"Item {item_id} belongs to tracker {tracker_id}, expected {expected_tracker_id}"

    return True, "OK"


def log_field_debug(tracker_fields, field_name):
    meta = tracker_fields.get(normalize_name(field_name))

    if not meta:
        logger.warning("Field '%s' not found in tracker metadata", field_name)
        return

    logger.info(
        "Field debug | name=%s | id=%s | valueModel=%s | type=%s | options_count=%s",
        meta.get("name"),
        meta.get("id"),
        meta.get("valueModel"),
        meta.get("type"),
        len(meta.get("options") or [])
    )


def resolve_reference_rules(df_columns, rules):
    active_rules = []

    for rule in rules:
        source_col = rule.get("source_column") or rule.get("source_logical")
        source_columns = rule.get("source_columns")

        if source_columns:
            matched_source_col = None

            for candidate_col in source_columns:
                if candidate_col in df_columns:
                    matched_source_col = candidate_col
                    break

            if not matched_source_col:
                logger.info(
                    "Skipping rule because none of the source columns are present: %s",
                    source_columns
                )
                continue

            active_rule = dict(rule)
            active_rule["source_column"] = matched_source_col
            active_rules.append(active_rule)
            continue

        if not source_col:
            logger.warning("Skipping reference rule because source column key is missing: %s", rule)
            continue

        if source_col not in df_columns:
            logger.info("Skipping rule because source column is not present: %s", source_col)
            continue

        tracker_id = get_rule_tracker_id(rule)

        if not tracker_id:
            logger.warning("Skipping rule because tracker_id/target_tracker_id is missing: %s", rule)
            continue

        active_rules.append(dict(rule))

    return active_rules


# =========================================================
# CODEBEAMER ATTACHMENT CHECK HELPERS
# =========================================================

def extract_attachment_file_name(attachment_obj):
    if not isinstance(attachment_obj, dict):
        return None

    for key in (
        "fileName",
        "filename",
        "name",
        "title",
        "originalFileName",
        "originalFilename"
    ):
        value = attachment_obj.get(key)
        if value:
            return clean_text(value)

    file_obj = attachment_obj.get("file")

    if isinstance(file_obj, dict):
        for key in (
            "fileName",
            "filename",
            "name",
            "title",
            "originalFileName",
            "originalFilename"
        ):
            value = file_obj.get(key)
            if value:
                return clean_text(value)

    attachment_ref = attachment_obj.get("attachment")

    if isinstance(attachment_ref, dict):
        for key in (
            "fileName",
            "filename",
            "name",
            "title",
            "originalFileName",
            "originalFilename"
        ):
            value = attachment_ref.get(key)
            if value:
                return clean_text(value)

    return None


def extract_attachments_from_response(data):
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("attachments", "items", "data", "results", "itemRefs"):
            val = data.get(key)
            if isinstance(val, list):
                return val

    return []


def get_existing_attachment_file_names(cb, issue_item_id):
    existing_names = set()

    if not issue_item_id:
        return existing_names

    possible_paths = [
        f"/v3/items/{issue_item_id}/attachments",
        f"/v3/items/{issue_item_id}/comments/attachments",
    ]

    for path in possible_paths:
        try:
            data = cb.get(path)
            attachments = extract_attachments_from_response(data)

            for att in attachments:
                file_name = extract_attachment_file_name(att)

                if file_name:
                    existing_names.add(file_name.strip().lower())

            if existing_names:
                logger.info(
                    "Existing attachment names loaded from Codebeamer: issue_id=%s | count=%s | path=%s",
                    issue_item_id,
                    len(existing_names),
                    path
                )
                return existing_names

        except Exception as ex:
            logger.warning(
                "Unable to read Codebeamer attachments from path=%s | issue_id=%s | error=%s",
                path,
                issue_item_id,
                ex
            )

    logger.info(
        "No existing attachment names detected from Codebeamer for issue_id=%s. Upload will be attempted if needed.",
        issue_item_id
    )

    return existing_names


def is_excel_already_attached_to_issue(cb, source_item_id, issue_item_id, excel_file_name):
    if not PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT:
        return False

    existing_attachment_names = get_existing_attachment_file_names(
        cb=cb,
        issue_item_id=issue_item_id
    )

    if excel_file_name and excel_file_name.strip().lower() in existing_attachment_names:
        logger.info(
            "Excel attachment already exists in Codebeamer. Skipping upload: source=%s | issue_id=%s | file=%s",
            source_item_id,
            issue_item_id,
            excel_file_name
        )

        add_attachment_manifest_row(
            source_item_id=source_item_id,
            issue_item_id=issue_item_id,
            excel_file_path=os.path.join(MYSQL_CREATED_ITEM_EXPORT_DIR, excel_file_name),
            issue_mode="FOUND_IN_CODEBEAMER",
            attached_status="YES",
            action="FOUND_ALREADY_ATTACHED_IN_CODEBEAMER"
        )

        return True

    if TRUST_MANIFEST_TO_SKIP_ATTACHMENT:
        if is_attachment_already_recorded_in_manifest(
            source_item_id=source_item_id,
            issue_item_id=issue_item_id,
            excel_file_name=excel_file_name
        ):
            logger.info(
                "Excel attachment recorded in manifest and TRUST_MANIFEST_TO_SKIP_ATTACHMENT=True. Skipping upload: source=%s | issue_id=%s | file=%s",
                source_item_id,
                issue_item_id,
                excel_file_name
            )
            return True

    logger.info(
        "Excel attachment not found in Codebeamer. Upload required: source=%s | issue_id=%s | file=%s",
        source_item_id,
        issue_item_id,
        excel_file_name
    )

    return False


# =========================================================
# EXISTING ITEM SCANS
# =========================================================

def scan_existing_tracker_by_field(cb, tracker_id, tracker_name, field_name, target_cache, duplicate_rows, page_size=500):
    logger.info("Scanning existing %s items by field '%s'...", tracker_name, field_name)

    target_cache.clear()
    duplicate_rows.clear()

    page = 1
    total_loaded = 0
    total_cached = 0
    total_without_key = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({tracker_id})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query existing %s items. Error=%s", tracker_name, ex)
            return

        items = extract_items_from_query_response(data)

        logger.info(
            "Existing %s query page=%s returned %s item(s)",
            tracker_name,
            page,
            len(items)
        )

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            item_name = extract_item_name_from_query_item(item_ref) or str(item_id)
            fields = load_item_fields_robust(cb, item_id)

            total_loaded += 1

            key_value = extract_field_value_by_name_from_fields(fields, field_name)

            if not key_value:
                total_without_key += 1
                logger.warning(
                    "Existing %s item has no readable '%s'. item_id=%s | name=%s",
                    tracker_name,
                    field_name,
                    item_id,
                    item_name
                )
                continue

            key = clean_text(key_value).upper()

            if not key:
                total_without_key += 1
                continue

            if key not in target_cache:
                target_cache[key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": field_name
                }

                total_cached += 1

            else:
                existing = target_cache[key]

                duplicate_rows.append({
                    "tracker_name": tracker_name,
                    "field_name": field_name,
                    "field_value": key,
                    "cached_item_id": existing.get("id"),
                    "duplicate_item_id": item_id,
                    "cached_item_name": existing.get("name"),
                    "duplicate_item_name": item_name,
                    "action": "DUPLICATE_FOUND_EXISTING_CODEBEAMER"
                })

                logger.warning(
                    "Duplicate %s item found for %s=%s. Cached=%s duplicate=%s",
                    tracker_name,
                    field_name,
                    key,
                    existing.get("id"),
                    item_id
                )

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "%s scan completed. loaded=%s | cached=%s | without_key=%s | duplicates=%s",
        tracker_name,
        total_loaded,
        total_cached,
        total_without_key,
        len(duplicate_rows)
    )


def find_existing_issue_by_sbm_item_id(src_key):
    if not src_key:
        return None

    key = clean_text(src_key)

    if not key:
        return None

    key = key.upper()
    existing = ISSUE_EXISTING_BY_SBM_ITEM_ID.get(key)

    if existing:
        logger.info(
            "Existing Issue found by %s: %s -> item_id=%s",
            ISSUE_SBM_ITEM_ID_FIELD_NAME,
            key,
            existing.get("id")
        )
        return existing.get("id")

    return None


def find_existing_retex_by_sbm_item_id(retex_key):
    if not retex_key:
        return None

    key = extract_retex_id(retex_key)

    if not key:
        return None

    key = key.upper()
    existing = RETEX_EXISTING_BY_SBM_ITEM_ID.get(key)

    if existing:
        logger.info(
            "Existing Retex found by %s: %s -> item_id=%s",
            RETEX_SBM_ITEM_ID_FIELD_NAME,
            key,
            existing.get("id")
        )
        return existing.get("id")

    return None


def find_existing_aems_spec_by_sbm_item_id(spec_key):
    if not spec_key:
        return None

    key = clean_text(spec_key)

    if not key:
        return None

    key = key.upper()
    existing = AEMS_SPEC_EXISTING_BY_SBM_ITEM_ID.get(key)

    if existing:
        logger.info(
            "Existing H-EMS Specification found by %s: %s -> item_id=%s",
            AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME,
            key,
            existing.get("id")
        )
        return existing.get("id")

    return None

# =========================================================
# MYSQL ROW EXCEL EXPORT + ATTACHMENT
# =========================================================

def export_issue_mysql_row_to_excel(row, source_item_id, tracker_name, codebeamer_item_id, issue_mode):
    """
    Creates one stable Excel file for each Issue tracker item.

    Correct behavior:
    - If file already exists locally, it will NOT recreate/download again.
    - Same source Item_Id + same Codebeamer issue item id = same Excel filename.
    """

    if not source_item_id:
        return None

    os.makedirs(MYSQL_CREATED_ITEM_EXPORT_DIR, exist_ok=True)

    excel_file_name = build_stable_excel_file_name(
        source_item_id=source_item_id,
        tracker_name=tracker_name,
        codebeamer_item_id=codebeamer_item_id
    )

    excel_file_path = os.path.join(MYSQL_CREATED_ITEM_EXPORT_DIR, excel_file_name)

    if (
        PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT
        and os.path.exists(excel_file_path)
    ):
        logger.info(
            "Excel already exists locally. Skipping Excel creation: mode=%s | source=%s | issue_id=%s | file=%s",
            issue_mode,
            source_item_id,
            codebeamer_item_id,
            excel_file_path
        )

        add_attachment_manifest_row(
            source_item_id=source_item_id,
            issue_item_id=codebeamer_item_id,
            excel_file_path=excel_file_path,
            issue_mode=issue_mode,
            attached_status="LOCAL_FILE_EXISTS",
            action="SKIPPED_EXCEL_CREATION_LOCAL_FILE_EXISTS"
        )

        return excel_file_path

    row_data = {}

    for column_name in row.index:
        value = row.get(column_name)

        if is_blank(value):
            row_data[column_name] = None
        else:
            row_data[column_name] = clean_text(value)

    export_df = pd.DataFrame([row_data])

    export_df.to_excel(
        excel_file_path,
        index=False,
        engine="openpyxl"
    )

    logger.info(
        "Issue MySQL row exported: mode=%s | tracker=%s | source_item_id=%s | cb_item_id=%s | file=%s",
        issue_mode,
        tracker_name,
        source_item_id,
        codebeamer_item_id,
        excel_file_path
    )

    add_attachment_manifest_row(
        source_item_id=source_item_id,
        issue_item_id=codebeamer_item_id,
        excel_file_path=excel_file_path,
        issue_mode=issue_mode,
        attached_status="LOCAL_FILE_CREATED",
        action="CREATED_LOCAL_EXCEL_FILE"
    )

    return excel_file_path


def export_created_tracker_mysql_row_to_excel(row, source_item_id, tracker_name, codebeamer_item_id):
    return export_issue_mysql_row_to_excel(
        row=row,
        source_item_id=source_item_id,
        tracker_name=tracker_name,
        codebeamer_item_id=codebeamer_item_id,
        issue_mode="CREATED"
    )


def export_existing_tracker_mysql_row_to_excel(row, source_item_id, tracker_name, codebeamer_item_id):
    return export_issue_mysql_row_to_excel(
        row=row,
        source_item_id=source_item_id,
        tracker_name=tracker_name,
        codebeamer_item_id=codebeamer_item_id,
        issue_mode="EXISTING"
    )


def attach_excel_file_to_issue_item(cb, issue_item_id, excel_file_path, source_item_id, issue_mode):
    """
    Attaches Excel file to Issue item.

    Correct duplicate prevention:
    - Does NOT trust manifest to skip upload.
    - Checks actual Codebeamer Comments & Attachments first.
    - If attachment is not found in Codebeamer, upload is attempted.
    """

    if not issue_item_id:
        return None, "NO_ISSUE_ID"

    if not excel_file_path:
        return None, "NO_EXCEL_FILE"

    if not os.path.exists(excel_file_path):
        raise RuntimeError(f"Excel file not found for attachment: {excel_file_path}")

    file_name = os.path.basename(excel_file_path)

    already_attached = is_excel_already_attached_to_issue(
        cb=cb,
        source_item_id=source_item_id,
        issue_item_id=issue_item_id,
        excel_file_name=file_name
    )

    if already_attached:
        add_attachment_manifest_row(
            source_item_id=source_item_id,
            issue_item_id=issue_item_id,
            excel_file_path=excel_file_path,
            issue_mode=issue_mode,
            attached_status="YES",
            action="SKIPPED_UPLOAD_ALREADY_ATTACHED_IN_CODEBEAMER"
        )

        return {
            "skipped": True,
            "reason": "ALREADY_ATTACHED_IN_CODEBEAMER",
            "file_name": file_name
        }, "ALREADY_ATTACHED"

    mime_type, _ = mimetypes.guess_type(excel_file_path)

    if not mime_type:
        mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    logger.info(
        "Uploading Excel attachment to Issue item: source_item_id=%s | issue_id=%s | file=%s | mime=%s",
        source_item_id,
        issue_item_id,
        excel_file_path,
        mime_type
    )

    with open(excel_file_path, "rb") as file_obj:
        files = {
            "attachments": (
                file_name,
                file_obj,
                mime_type
            )
        }

        data = {
            "description": ATTACHMENT_DESCRIPTION_TEXT
        }

        response = cb.post_multipart(
            path=f"/v3/items/{issue_item_id}/attachments",
            files=files,
            data=data
        )

    logger.info(
        "Excel attachment uploaded successfully: source_item_id=%s | issue_id=%s | file=%s | response=%s",
        source_item_id,
        issue_item_id,
        file_name,
        response
    )

    add_attachment_manifest_row(
        source_item_id=source_item_id,
        issue_item_id=issue_item_id,
        excel_file_path=excel_file_path,
        issue_mode=issue_mode,
        attached_status="YES",
        action="UPLOADED_ATTACHMENT_TO_CODEBEAMER"
    )

    return response, "UPLOADED"


def export_and_attach_mysql_row_excel_to_issue(cb, row, source_item_id, issue_item_id, issue_mode):
    """
    Common helper used for both:
    1. Newly created Issue items
    2. Already existing Issue items

    Correct behavior:
    - Reuses local Excel if already present.
    - Still checks Codebeamer and attaches if missing.
    - Skips upload only if Codebeamer confirms same filename already exists.
    """

    exported_excel_file = export_issue_mysql_row_to_excel(
        row=row,
        source_item_id=source_item_id,
        tracker_name=ISSUE_TRACKER_NAME,
        codebeamer_item_id=issue_item_id,
        issue_mode=issue_mode
    )

    response, attach_status = attach_excel_file_to_issue_item(
        cb=cb,
        issue_item_id=issue_item_id,
        excel_file_path=exported_excel_file,
        source_item_id=source_item_id,
        issue_mode=issue_mode
    )

    return exported_excel_file, attach_status


# =========================================================
# COMPARISON HELPERS
# =========================================================

def canonicalize_value_for_compare(value):
    if is_blank(value):
        return None

    if isinstance(value, list):
        cleaned = [clean_text(v) for v in value if not is_blank(v)]
        cleaned = [v for v in cleaned if v]
        return "|".join(sorted(cleaned, key=lambda x: x.lower()))

    txt = clean_text(value)

    if txt is None:
        return None

    txt = re.sub(r"\s+", " ", txt).strip()

    if "," in txt:
        parts = [p.strip() for p in txt.split(",") if p.strip()]
        return "|".join(sorted(parts, key=lambda x: x.lower()))

    return txt


def field_value_to_comparable_value(field_value):
    if not field_value:
        return None

    fv_type = field_value.get("type")

    if fv_type in (
        "TextFieldValue",
        "WikiTextFieldValue",
        "DateFieldValue",
        "IntegerFieldValue",
        "DecimalFieldValue",
        "BoolFieldValue",
    ):
        return canonicalize_value_for_compare(field_value.get("value"))

    if fv_type == "ChoiceFieldValue":
        values = field_value.get("values") or []
        names = []

        for v in values:
            if isinstance(v, dict):
                names.append(clean_text(v.get("name") or v.get("value") or v.get("id")))
            else:
                names.append(clean_text(v))

        names = [n for n in names if n]
        return canonicalize_value_for_compare(names)

    return canonicalize_value_for_compare(field_value.get("value"))


def extract_existing_single_field_value(field_value):
    if not field_value:
        return None

    if "value" in field_value and field_value.get("value") is not None:
        return canonicalize_value_for_compare(field_value.get("value"))

    values = field_value.get("values")

    if isinstance(values, list):
        names = []

        for v in values:
            if isinstance(v, dict):
                names.append(clean_text(v.get("name") or v.get("value") or v.get("id")))
            else:
                names.append(clean_text(v))

        names = [n for n in names if n]
        return canonicalize_value_for_compare(names)

    return None


def get_existing_field_values(cb, item_id):
    result = {}

    try:
        fields = load_item_fields_robust(cb, item_id)
    except Exception as ex:
        logger.warning("Unable to load existing fields for item_id=%s. Error=%s", item_id, ex)
        return result

    for fv in fields:
        if not isinstance(fv, dict):
            continue

        field_name = fv.get("name")

        if not field_name:
            field_obj = fv.get("field")
            if isinstance(field_obj, dict):
                field_name = field_obj.get("name")

        if not field_name:
            continue

        result[normalize_name(field_name)] = extract_existing_single_field_value(fv)

    return result


def filter_changed_field_values(cb, item_id, source_item_id, candidate_field_values, object_type):
    existing_values = get_existing_field_values(cb, item_id)
    changed_fields = []

    for fv in candidate_field_values:
        field_name = fv.get("name")

        if not field_name:
            continue

        old_value = existing_values.get(normalize_name(field_name))
        new_value = field_value_to_comparable_value(fv)

        old_cmp = canonicalize_value_for_compare(old_value)
        new_cmp = canonicalize_value_for_compare(new_value)

        if old_cmp != new_cmp:
            changed_fields.append(fv)

            CHANGE_AUDIT_ROWS.append({
                "object_type": object_type,
                "source_item_id": source_item_id,
                "codebeamer_item_id": item_id,
                "field_name": field_name,
                "old_value": old_cmp,
                "new_value": new_cmp,
                "action": "UPDATED_FIELD"
            })

            logger.info(
                "%s field changed: source=%s | item_id=%s | field=%s | old=%s | new=%s",
                object_type,
                source_item_id,
                item_id,
                field_name,
                old_cmp,
                new_cmp
            )

    return changed_fields


# =========================================================
# FIELD BUILDERS
# =========================================================

def build_field_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None

    field_id = field_meta["id"]
    field_name = field_meta["name"]
    value_model = field_meta.get("valueModel")

    if value_model == "TextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "TextFieldValue",
            "value": txt
        }

    if value_model == "WikiTextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "WikiTextFieldValue",
            "value": txt
        }

    if value_model == "DateFieldValue":
        dt = to_iso_datetime_string(raw_value)
        if not dt:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DateFieldValue",
            "value": dt
        }

    if value_model == "IntegerFieldValue":
        iv = to_int_or_none(raw_value)
        if iv is None:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "IntegerFieldValue",
            "value": iv
        }

    if value_model == "DecimalFieldValue":
        dv = to_float_or_none(raw_value)
        if dv is None:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DecimalFieldValue",
            "value": dv
        }

    if value_model == "BoolFieldValue":
        bv = to_bool_or_none(raw_value)
        if bv is None:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "BoolFieldValue",
            "value": bv
        }

    return None


def build_choice_field_value(field_meta, raw_value, value_map=None):
    if is_blank(raw_value):
        return None, None

    source_text = clean_text(raw_value)

    if not source_text:
        return None, None

    target_text = value_map.get(source_text, source_text) if value_map else source_text

    options = field_meta.get("options") or []

    if not options:
        return None, f"Field '{field_meta.get('name')}' has no options metadata exposed by API; cannot resolve choice '{target_text}'"

    matched = None

    for opt in options:
        if normalize_name(opt.get("name")) == normalize_name(target_text):
            matched = opt
            break

    if not matched:
        available = [o.get("name") for o in options]
        return None, f"Choice '{target_text}' not found for field '{field_meta.get('name')}'. Available options: {available}"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": matched["id"],
            "name": matched.get("name"),
            "type": matched.get("type", "ChoiceOptionReference")
        }]
    }, None


def build_member_field_value(field_meta, member_id, member_name):
    if not member_id or not member_name:
        return None, f"Member value missing for field '{field_meta.get('name')}'"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": int(member_id),
            "name": str(member_name),
            "type": PILOT_REFERENCE_TYPE
        }]
    }, None


def build_reference_values_list(child_ids_and_names):
    values = []
    seen = set()

    for child_id, child_name in child_ids_and_names:
        if not child_id:
            continue

        key = str(child_id)

        if key in seen:
            continue

        seen.add(key)

        values.append({
            "id": int(child_id),
            "name": str(child_name),
            "type": "TrackerItemReference"
        })

    return values


def build_tracker_item_reference_field_value(field_meta, tracker_item_refs):
    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": tracker_item_refs
    }


def update_item_fields(cb, item_id, field_values):
    if not field_values:
        return

    payload = {"fieldValues": field_values}
    cb.put(f"/v3/items/{item_id}/fields", payload)


# =========================================================
# MIGRATED DATA LOGIC
# =========================================================

def build_migrated_data_field_value(issue_tracker_fields, skipped_columns):
    migrated_meta = issue_tracker_fields.get(normalize_name(MIGRATED_DATA_FIELD_NAME))

    if not migrated_meta:
        skipped_columns.append({
            "source_column": MIGRATED_DATA_FIELD_NAME,
            "reason": f"Target field '{MIGRATED_DATA_FIELD_NAME}' not found in Issue tracker",
            "sample_value": MIGRATED_DATA_VALUE
        })
        return None

    fv, err = build_choice_field_value(
        field_meta=migrated_meta,
        raw_value=MIGRATED_DATA_VALUE
    )

    if fv:
        return fv

    skipped_columns.append({
        "source_column": MIGRATED_DATA_FIELD_NAME,
        "reason": err or "Unable to build Migrated Data ? value",
        "sample_value": MIGRATED_DATA_VALUE
    })

    return None


def force_set_migrated_data_yes(cb, issue_item_id, issue_tracker_fields, skipped_columns, source_item_id=None):
    fv = build_migrated_data_field_value(
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns
    )

    if not fv:
        logger.warning(
            "Unable to force set '%s'='%s' for source=%s | issue_id=%s",
            MIGRATED_DATA_FIELD_NAME,
            MIGRATED_DATA_VALUE,
            source_item_id,
            issue_item_id
        )
        return 0

    update_item_fields(cb, issue_item_id, [fv])

    CHANGE_AUDIT_ROWS.append({
        "object_type": "Issue",
        "source_item_id": source_item_id,
        "codebeamer_item_id": issue_item_id,
        "field_name": MIGRATED_DATA_FIELD_NAME,
        "old_value": None,
        "new_value": MIGRATED_DATA_VALUE,
        "action": "FORCE_SET_MIGRATED_DATA_YES"
    })

    logger.info(
        "Force set '%s'='%s': source=%s | issue_id=%s",
        MIGRATED_DATA_FIELD_NAME,
        MIGRATED_DATA_VALUE,
        source_item_id,
        issue_item_id
    )

    return 1


def update_item_name(cb, item_id, new_name):
    clean_name = clean_text(new_name)

    if not clean_name:
        return False

    item = get_item_detail(cb, item_id)
    current_name = clean_text(item.get("name"))

    if current_name == clean_name:
        return False

    cb.put(f"/v3/items/{item_id}", {
        "name": clean_name
    })

    logger.info(
        "Item title updated: item_id=%s | old=%s | new=%s",
        item_id,
        current_name,
        clean_name
    )

    return True

# =========================================================
# ISSUE BUILD / CREATE / UPDATE
# =========================================================

def build_issue_description(row):
    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
    detailed_context = clean_text(
        get_effective_value_for_source_column("Detailed_Context", row)
    )

    lines = []

    if src_id:
        lines.append(f"Source Item Id: {src_id}")

    if detailed_context:
        lines.append("")
        lines.append("Detailed Context:")
        lines.append(detailed_context)

    return "\n".join(lines).strip() if lines else None


def build_issue_scalar_field_values(row, issue_tracker_fields, skipped_columns):
    values = []

    for src_col, cfg in SAFE_ISSUE_MAPPING.items():
        if src_col not in row.index and src_col not in ("Pilot",):
            continue

        if cfg.get("mode") == "name":
            continue

        raw_value = get_effective_value_for_source_column(src_col, row)

        if is_blank(raw_value):
            continue

        target_field_name = cfg["field"]
        field_meta = issue_tracker_fields.get(normalize_name(target_field_name))

        if not field_meta:
            skipped_columns.append({
                "source_column": src_col,
                "reason": f"Mapped Issue target field '{target_field_name}' not found",
                "sample_value": clean_text(raw_value)
            })
            continue

        kind = cfg.get("kind")

        if kind == "choice":
            value_map = None

            if src_col == "Severity" and target_field_name == "Severity":
                value_map = SEVERITY_TO_CB_SEVERITY
            elif src_col == "Trouble_type":
                value_map = TROUBLE_TYPE_TO_CB
            elif src_col == "Context_Test_condition":
                value_map = CONTEXT_TO_CB
            elif src_col == "Perimeter":
                value_map = PERIMETER_TO_CB

            fv, err = build_choice_field_value(
                field_meta=field_meta,
                raw_value=raw_value,
                value_map=value_map
            )

            if fv:
                values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": err,
                    "sample_value": clean_text(raw_value)
                })

            continue

        if kind == "member":
            fv, err = build_member_field_value(
                field_meta=field_meta,
                member_id=PILOT_FORCE_ID,
                member_name=PILOT_FORCE_NAME
            )

            if fv:
                values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": err,
                    "sample_value": PILOT_FORCE_NAME
                })

            continue

        fv = build_field_value(field_meta, raw_value)

        if fv:
            values.append(fv)
        else:
            skipped_columns.append({
                "source_column": src_col,
                "reason": f"Unsupported or unresolved Issue field '{target_field_name}'",
                "sample_value": clean_text(raw_value)
            })

    migrated_fv = build_migrated_data_field_value(
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns
    )

    if migrated_fv:
        values.append(migrated_fv)

    return values


def validate_issue_create_payload(field_values):
    included_field_names = {
        normalize_name(x.get("name")) for x in field_values if x.get("name")
    }

    missing_mandatory = [
        f for f in MANDATORY_ISSUE_CREATE_FIELDS
        if normalize_name(f) not in included_field_names
    ]

    if missing_mandatory:
        raise RuntimeError(
            "Issue create payload validation failed before POST. "
            f"Missing mandatory fields: {missing_mandatory}"
        )


def create_issue_item(cb, row, issue_tracker_fields, skipped_columns):
    title = clean_text(
        get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row)
    ) or "Imported Issue"

    scalar_values = build_issue_scalar_field_values(
        row=row,
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns
    )

    validate_issue_create_payload(scalar_values)

    payload = {
        "name": title,
        "descriptionFormat": "PlainText",
        "description": build_issue_description(row)
    }

    if scalar_values:
        payload["customFields"] = scalar_values

    payload = {k: v for k, v in payload.items() if v is not None}

    created = cb.post(f"/v3/trackers/{ISSUE_TRACKER_ID}/items", payload)

    return created["id"], created


def update_issue_item(cb, issue_id, row, issue_tracker_fields, skipped_columns):
    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))

    candidate_fields = build_issue_scalar_field_values(
        row=row,
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns
    )

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=issue_id,
        source_item_id=src_id,
        candidate_field_values=candidate_fields,
        object_type="Issue"
    )

    if changed_fields:
        update_item_fields(cb, issue_id, changed_fields)

        logger.info(
            "Updated Issue changed fields: source=%s | issue_id=%s | count=%s",
            src_id,
            issue_id,
            len(changed_fields)
        )
    else:
        CHANGE_AUDIT_ROWS.append({
            "object_type": "Issue",
            "source_item_id": src_id,
            "codebeamer_item_id": issue_id,
            "field_name": None,
            "old_value": None,
            "new_value": None,
            "action": "NO_CHANGE"
        })

        logger.info(
            "No Issue field changes detected: source=%s | issue_id=%s",
            src_id,
            issue_id
        )

    return len(changed_fields)


def update_status_last(cb, issue_item_id, issue_tracker_fields, raw_status_value, source_item_id=None):
    status_text = clean_text(raw_status_value)

    if not status_text:
        return 0

    field_meta = issue_tracker_fields.get(normalize_name("Status"))

    if not field_meta:
        raise RuntimeError("Issue tracker field 'Status' not found in metadata.")

    fv, err = build_choice_field_value(
        field_meta=field_meta,
        raw_value=status_text,
        value_map=STATE_TO_CB_STATUS
    )

    if not fv:
        raise RuntimeError(f"Unable to resolve Status '{status_text}': {err}")

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=issue_item_id,
        source_item_id=source_item_id,
        candidate_field_values=[fv],
        object_type="IssueStatus"
    )

    if changed_fields:
        update_item_fields(cb, issue_item_id, changed_fields)
        logger.info(
            "Updated Issue Status: source=%s | issue_id=%s | status=%s",
            source_item_id,
            issue_item_id,
            status_text
        )
        return 1

    return 0
# =========================================================
# REFERENCE / CHILD ITEM HELPERS
# =========================================================

def scan_existing_reference_tracker_by_name(cb, tracker_id, tracker_name, page_size=500):
    logger.info(
        "Scanning existing reference tracker by name: %s (%s)",
        tracker_name,
        tracker_id
    )

    page = 1
    total_loaded = 0
    total_cached = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({tracker_id})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query %s. Error=%s", tracker_name, ex)
            return

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            try:
                item = get_item_detail(cb, item_id)
            except Exception:
                item = item_ref

            item_name = (
                item.get("name")
                or extract_item_name_from_query_item(item_ref)
                or str(item_id)
            )

            total_loaded += 1

            key = (tracker_id, normalize_cache_key(item_name))

            if key not in REFERENCE_TRACKER_EXISTING_CACHE:
                REFERENCE_TRACKER_EXISTING_CACHE[key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": "name"
                }

                total_cached += 1

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "Reference scan completed: %s | loaded=%s | cached=%s",
        tracker_name,
        total_loaded,
        total_cached
    )


def build_child_item_payload(tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    description_lines = []

    retex_id_value = (
        extract_retex_id(source_value)
        if tracker_name == RETEX_TRACKER_NAME
        else None
    )

    spec_sbm_id_value = None
    spec_title_value = None

    if tracker_name == AEMS_SPECIFICATION_TRACKER_NAME:
        spec_sbm_id_value, spec_title_value = parse_sbm_id_title_value(source_value)

    if source_item_id:
        description_lines.append(f"Source Item Id: {source_item_id}")

    if issue_title:
        description_lines.append(f"Issue Title: {issue_title}")

    if source_value:
        description_lines.append("")
        description_lines.append("Imported Reference Value:")
        description_lines.append(str(source_value))

    description_text = "\n".join(description_lines).strip() if description_lines else None

    name_value = clean_text(source_value)

    if tracker_name == RETEX_TRACKER_NAME:
        name_value = extract_retex_title_for_codebeamer(source_value) or name_value

    if tracker_name == AEMS_SPECIFICATION_TRACKER_NAME:
        name_value = spec_title_value or name_value

    if tracker_name in (
        FIRST_ENGINE_APPLICATION_TRACKER_NAME,
        FIRST_VEHICLE_APPLICATION_TRACKER_NAME
    ):
        name_value = clean_text(source_value)

    payload = {
        "name": name_value or "Imported Reference",
        "descriptionFormat": "PlainText",
        "description": description_text
    }

    custom_fields = []

    if tracker_name == RETEX_TRACKER_NAME:
        retex_sbm_meta = tracker_fields.get(
            normalize_name(RETEX_SBM_ITEM_ID_FIELD_NAME)
        )

        if retex_sbm_meta and retex_id_value:
            fv = build_field_value(retex_sbm_meta, retex_id_value)
            if fv:
                custom_fields.append(fv)

    if tracker_name == AEMS_SPECIFICATION_TRACKER_NAME:
        spec_sbm_meta = tracker_fields.get(
            normalize_name(AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME)
        )

        if spec_sbm_meta and spec_sbm_id_value:
            fv = build_field_value(spec_sbm_meta, spec_sbm_id_value)
            if fv:
                custom_fields.append(fv)

        field_meta = tracker_fields.get(normalize_name("New or Evolution?"))

        if not field_meta:
            raise RuntimeError(
                f"Mandatory child field 'New or Evolution?' not found in tracker metadata for '{tracker_name}'"
            )

        fv, err = build_choice_field_value(field_meta, NEW_OR_EVOLUTION_FORCE_VALUE)

        if not fv:
            raise RuntimeError(
                f"Unable to resolve mandatory child field 'New or Evolution?' "
                f"for '{tracker_name}': {err}"
            )

        custom_fields.append(fv)

    if tracker_name == AEMS_FUNCTION_TRACKER_NAME:
        if not payload.get("description"):
            payload["description"] = f"Imported child item for source value: {source_value}"
            payload["descriptionFormat"] = "PlainText"

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    return payload


def create_reference_tracker_item(cb, tracker_id, tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    payload = build_child_item_payload(
        tracker_name=tracker_name,
        tracker_fields=tracker_fields,
        source_value=source_value,
        issue_title=issue_title,
        source_item_id=source_item_id
    )

    created = cb.post(f"/v3/trackers/{tracker_id}/items", payload)

    return created["id"], created


def get_or_create_reference_tracker_item(cb, tracker_id, tracker_name, tracker_fields, source_value, issue_title, source_item_id):
    value = clean_text(source_value)

    if not value:
        return None, None, False

    if tracker_id == RETEX_TRACKER_ID:
        retex_id_value = extract_retex_id(value)

        if not retex_id_value:
            return None, None, False

        existing_retex_id = find_existing_retex_by_sbm_item_id(retex_id_value)

        if existing_retex_id:
            return int(existing_retex_id), {"id": int(existing_retex_id)}, False

        key = (tracker_id, normalize_cache_key(retex_id_value))

    elif tracker_id == AEMS_SPECIFICATION_TRACKER_ID:
        spec_sbm_id_value, spec_title_value = parse_sbm_id_title_value(value)

        if spec_sbm_id_value:
            existing_spec_id = find_existing_aems_spec_by_sbm_item_id(spec_sbm_id_value)

            if existing_spec_id:
                existing_name = spec_title_value or value
                return int(existing_spec_id), {
                    "id": int(existing_spec_id),
                    "name": existing_name
                }, False

            key = (tracker_id, normalize_cache_key(spec_sbm_id_value))

            cached_id = REFERENCE_ITEM_CACHE.get(key)
            if cached_id:
                return int(cached_id), {"id": int(cached_id)}, False

            existing_by_sbm_key = REFERENCE_TRACKER_EXISTING_CACHE.get(key)
            if existing_by_sbm_key:
                item_id = int(existing_by_sbm_key["id"])
                REFERENCE_ITEM_CACHE[key] = item_id
                return item_id, {"id": item_id}, False

            if spec_title_value:
                title_key = (tracker_id, normalize_cache_key(spec_title_value))
                existing_by_title = REFERENCE_TRACKER_EXISTING_CACHE.get(title_key)

                if existing_by_title:
                    item_id = int(existing_by_title["id"])
                    REFERENCE_ITEM_CACHE[key] = item_id

                    AEMS_SPEC_EXISTING_BY_SBM_ITEM_ID[spec_sbm_id_value.upper()] = {
                        "id": item_id,
                        "name": spec_title_value,
                        "matched_by": "title_fallback_then_update_sbm_sdt_id"
                    }

                    return item_id, {
                        "id": item_id,
                        "name": spec_title_value
                    }, False

        else:
            key = (tracker_id, normalize_cache_key(value))

    else:
        key = (tracker_id, normalize_cache_key(value))

    cached_id = REFERENCE_ITEM_CACHE.get(key)

    if cached_id:
        return int(cached_id), {"id": int(cached_id)}, False

    existing = REFERENCE_TRACKER_EXISTING_CACHE.get(key)

    if existing:
        item_id = int(existing["id"])
        REFERENCE_ITEM_CACHE[key] = item_id
        return item_id, {"id": item_id, "name": existing.get("name")}, False

    child_id, created = create_reference_tracker_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        tracker_fields=tracker_fields,
        source_value=value,
        issue_title=issue_title,
        source_item_id=source_item_id
    )

    REFERENCE_ITEM_CACHE[key] = int(child_id)

    created_name = value

    if tracker_id == RETEX_TRACKER_ID:
        created_name = extract_retex_title_for_codebeamer(value) or value

    if tracker_id == AEMS_SPECIFICATION_TRACKER_ID:
        spec_sbm_id_value, spec_title_value = parse_sbm_id_title_value(value)
        created_name = spec_title_value or value

    REFERENCE_TRACKER_EXISTING_CACHE[key] = {
        "id": int(child_id),
        "name": created_name,
        "matched_by": "created"
    }

    if tracker_id == RETEX_TRACKER_ID:
        retex_id_value = extract_retex_id(value)

        if retex_id_value:
            RETEX_EXISTING_BY_SBM_ITEM_ID[retex_id_value.upper()] = {
                "id": int(child_id),
                "name": created_name,
                "matched_by": "created"
            }

    if tracker_id == AEMS_SPECIFICATION_TRACKER_ID:
        spec_sbm_id_value, _spec_title_value = parse_sbm_id_title_value(value)

        if spec_sbm_id_value:
            AEMS_SPEC_EXISTING_BY_SBM_ITEM_ID[spec_sbm_id_value.upper()] = {
                "id": int(child_id),
                "name": created_name,
                "matched_by": "created"
            }

    return int(child_id), created, True
def update_retex_item_if_needed(cb, retex_id, retex_value, issue_title, source_item_id, retex_tracker_fields):
    candidate_fields = []

    retex_id_value = extract_retex_id(retex_value)
    cleaned_title = extract_retex_title_for_codebeamer(retex_value)

    retex_sbm_meta = retex_tracker_fields.get(
        normalize_name(RETEX_SBM_ITEM_ID_FIELD_NAME)
    )

    if retex_sbm_meta and retex_id_value:
        fv = build_field_value(retex_sbm_meta, retex_id_value)

        if fv:
            candidate_fields.append(fv)

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=retex_id,
        source_item_id=source_item_id,
        candidate_field_values=candidate_fields,
        object_type="Retex"
    )

    if changed_fields:
        update_item_fields(cb, retex_id, changed_fields)

        logger.info(
            "Updated Retex changed fields: source=%s | retex_id=%s | count=%s",
            source_item_id,
            retex_id,
            len(changed_fields)
        )

    try:
        if cleaned_title:
            title_updated = update_item_name(cb, retex_id, cleaned_title)

            if title_updated:
                CHANGE_AUDIT_ROWS.append({
                    "object_type": "Retex",
                    "source_item_id": source_item_id,
                    "codebeamer_item_id": retex_id,
                    "field_name": "name",
                    "old_value": None,
                    "new_value": cleaned_title,
                    "action": "UPDATED_RETEX_TITLE"
                })

    except Exception as ex:
        logger.warning(
            "Failed to update Retex title: item_id=%s | source=%s | cleaned_title=%s | error=%s",
            retex_id,
            source_item_id,
            cleaned_title,
            ex
        )

    return len(changed_fields)


def update_aems_spec_item_if_needed(cb, spec_id, spec_value, issue_title, source_item_id, spec_tracker_fields):
    candidate_fields = []

    spec_sbm_id_value, spec_title_value = parse_sbm_id_title_value(spec_value)

    spec_sbm_meta = spec_tracker_fields.get(
        normalize_name(AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME)
    )

    if spec_sbm_meta and spec_sbm_id_value:
        fv = build_field_value(spec_sbm_meta, spec_sbm_id_value)

        if fv:
            candidate_fields.append(fv)

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=spec_id,
        source_item_id=source_item_id,
        candidate_field_values=candidate_fields,
        object_type="H-EMS Specification"
    )

    if changed_fields:
        update_item_fields(cb, spec_id, changed_fields)

        logger.info(
            "Updated H-EMS Specification changed fields: source=%s | spec_id=%s | count=%s",
            source_item_id,
            spec_id,
            len(changed_fields)
        )

    try:
        if spec_title_value:
            title_updated = update_item_name(cb, spec_id, spec_title_value)

            if title_updated:
                CHANGE_AUDIT_ROWS.append({
                    "object_type": "H-EMS Specification",
                    "source_item_id": source_item_id,
                    "codebeamer_item_id": spec_id,
                    "field_name": "name",
                    "old_value": None,
                    "new_value": spec_title_value,
                    "action": "UPDATED_AEMS_SPEC_TITLE"
                })

    except Exception as ex:
        logger.warning(
            "Failed to update H-EMS Specification title: item_id=%s | source=%s | title=%s | error=%s",
            spec_id,
            source_item_id,
            spec_title_value,
            ex
        )

    return len(changed_fields)


# =========================================================
# LINK HELPERS
# =========================================================

def merge_tracker_item_reference_on_item(cb, item_id, tracker_fields, reference_field_name, referenced_item_id, referenced_item_name):
    field_meta = tracker_fields.get(normalize_name(reference_field_name))

    if not field_meta:
        raise RuntimeError(
            f"Tracker field '{reference_field_name}' not found. Please verify the exact field name."
        )

    current_fields = load_item_fields_robust(cb, item_id)

    existing_values = []

    for fv in current_fields:
        if not isinstance(fv, dict):
            continue

        fv_field_id = fv.get("fieldId")
        fv_name = fv.get("name")

        if fv_field_id == field_meta["id"] or normalize_name(fv_name) == normalize_name(field_meta["name"]):
            vals = fv.get("values") or []

            if isinstance(vals, list):
                existing_values = vals

            break

    already_exists = any(
        str(v.get("id")) == str(referenced_item_id)
        for v in existing_values
        if isinstance(v, dict)
    )

    merged_values = list(existing_values)

    if not already_exists:
        merged_values.append({
            "id": int(referenced_item_id),
            "name": str(referenced_item_name),
            "type": "TrackerItemReference"
        })

    payload_value = build_tracker_item_reference_field_value(
        field_meta,
        merged_values
    )

    if not already_exists:
        update_item_fields(cb, item_id, [payload_value])

        logger.info(
            "Reference linked: item_id=%s | field=%s | referenced_item_id=%s",
            item_id,
            reference_field_name,
            referenced_item_id
        )

    else:
        logger.info(
            "Reference already exists, skipping duplicate link: item_id=%s | field=%s | referenced_item_id=%s",
            item_id,
            reference_field_name,
            referenced_item_id
        )


def link_reference_with_retry(cb, item_id, tracker_fields, reference_field_name, referenced_item_id, referenced_item_name):
    last_error = None

    for attempt in range(1, LINK_RETRY_ATTEMPTS + 1):
        try:
            merge_tracker_item_reference_on_item(
                cb=cb,
                item_id=item_id,
                tracker_fields=tracker_fields,
                reference_field_name=reference_field_name,
                referenced_item_id=referenced_item_id,
                referenced_item_name=referenced_item_name
            )

            return

        except Exception as ex:
            last_error = ex

            logger.warning(
                "Link attempt %s/%s failed for item_id=%s | field=%s | ref_id=%s | error=%s",
                attempt,
                LINK_RETRY_ATTEMPTS,
                item_id,
                reference_field_name,
                referenced_item_id,
                ex
            )

            if attempt < LINK_RETRY_ATTEMPTS:
                time.sleep(LINK_RETRY_SLEEP_SEC)

    raise RuntimeError(
        f"Failed to link reference after {LINK_RETRY_ATTEMPTS} attempts: "
        f"item_id={item_id}, field={reference_field_name}, ref_id={referenced_item_id}, last_error={last_error}"
    )


def set_tracker_item_reference_field_on_item(cb, item_id, tracker_fields, reference_field_name, child_ids_and_names):
    field_meta = tracker_fields.get(normalize_name(reference_field_name))

    if not field_meta:
        raise RuntimeError(
            f"Tracker field '{reference_field_name}' not found. Please verify the exact field name."
        )

    tracker_item_refs = build_reference_values_list(child_ids_and_names)

    if not tracker_item_refs:
        logger.info(
            "No references to set: item_id=%s | field=%s",
            item_id,
            reference_field_name
        )
        return

    payload_value = {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": tracker_item_refs
    }

    update_item_fields(cb, item_id, [payload_value])

    logger.info(
        "Reference field set: item_id=%s | field=%s | refs=%s",
        item_id,
        reference_field_name,
        len(tracker_item_refs)
    )
    # =========================================================
# MAIN PROCESS
# =========================================================

def process_issue_retex_rows(
    cb,
    df,
    issue_tracker_fields,
    child_tracker_fields_cache,
    active_reference_rules,
    skipped_columns,
    failed_rows
):
    processed_rows = []

    for idx, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        src_key = src_id.upper() if src_id else None

        title = clean_text(
            get_effective_value_for_source_column(SUMMARY_SOURCE_COLUMN, row)
        ) or "Imported Issue"

        if not src_key:
            failed_rows.append({
                "row_index": idx,
                "source_item_id": None,
                "title": title,
                "phase": "SOURCE_VALIDATION",
                "error": "Missing Item_Id"
            })
            continue

        if src_key in PROCESSED_SOURCE_IDS_THIS_RUN:
            processed_rows.append({
                "source_item_id": src_id,
                "issue_codebeamer_item_id": None,
                "retex_codebeamer_item_id": None,
                "mysql_row_excel_file": None,
                "excel_attached_to_issue": "NO",
                "excel_attach_status": "SKIPPED_DUPLICATE_SOURCE_ROW",
                "migrated_data_set_yes": "NO",
                "title": title,
                "status": "SKIPPED_DUPLICATE_SOURCE_ROW_ALREADY_PROCESSED_THIS_RUN",
                "matched_by": ISSUE_SBM_ITEM_ID_FIELD_NAME
            })
            continue

        PROCESSED_SOURCE_IDS_THIS_RUN.add(src_key)

        issue_cb_id = None
        retex_cb_id = None
        result_mode = None
        exported_excel_file = None
        excel_attached_to_issue = "NO"
        excel_attach_status = "NOT_ATTEMPTED"
        migrated_changed = 0

        try:
            existing_issue_id = find_existing_issue_by_sbm_item_id(src_key)

            if existing_issue_id:
                is_valid, reason = validate_existing_item_in_tracker(
                    cb=cb,
                    item_id=existing_issue_id,
                    expected_tracker_id=ISSUE_TRACKER_ID
                )

                if not is_valid:
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "EXISTING_ISSUE_VALIDATION",
                        "error": reason,
                        "issue_id": existing_issue_id
                    })
                    continue

                issue_cb_id = int(existing_issue_id)

                changed_count = update_issue_item(
                    cb=cb,
                    issue_id=issue_cb_id,
                    row=row,
                    issue_tracker_fields=issue_tracker_fields,
                    skipped_columns=skipped_columns
                )

                result_mode = (
                    "UPDATED_EXISTING_ISSUE_BY_SBM_ITEM_ID"
                    if changed_count > 0
                    else "NO_CHANGE_EXISTING_ISSUE_BY_SBM_ITEM_ID"
                )

                if ATTACH_EXCEL_TO_EXISTING_ISSUE:
                    try:
                        exported_excel_file, excel_attach_status = export_and_attach_mysql_row_excel_to_issue(
                            cb=cb,
                            row=row,
                            source_item_id=src_id,
                            issue_item_id=issue_cb_id,
                            issue_mode="EXISTING"
                        )

                        if excel_attach_status in ("UPLOADED", "ALREADY_ATTACHED"):
                            excel_attached_to_issue = "YES"

                        if excel_attach_status == "UPLOADED":
                            CHANGE_AUDIT_ROWS.append({
                                "object_type": "Issue",
                                "source_item_id": src_id,
                                "codebeamer_item_id": issue_cb_id,
                                "field_name": "Excel Attachment",
                                "old_value": None,
                                "new_value": exported_excel_file,
                                "action": "ATTACHED_MYSQL_ROW_EXCEL_TO_EXISTING_ISSUE"
                            })

                            result_mode = f"{result_mode}_EXCEL_ATTACHED"

                        elif excel_attach_status == "ALREADY_ATTACHED":
                            result_mode = f"{result_mode}_EXCEL_ALREADY_ATTACHED_SKIPPED"

                        else:
                            result_mode = f"{result_mode}_EXCEL_ATTACHMENT_STATUS_{excel_attach_status}"

                    except Exception as attach_ex:
                        logger.error(
                            "Excel attachment handling failed for existing Issue: source=%s | issue_id=%s | error=%s",
                            src_id,
                            issue_cb_id,
                            attach_ex
                        )

                        failed_rows.append({
                            "row_index": idx,
                            "source_item_id": src_id,
                            "title": title,
                            "phase": "EXCEL_ATTACHMENT_UPLOAD_EXISTING_ISSUE",
                            "error": str(attach_ex),
                            "issue_id": issue_cb_id,
                            "excel_file": exported_excel_file
                        })

                        result_mode = f"{result_mode}_EXCEL_ATTACHMENT_FAILED"

                else:
                    excel_attach_status = "DISABLED_FOR_EXISTING_ISSUE"

            else:
                issue_cb_id, _created_issue = create_issue_item(
                    cb=cb,
                    row=row,
                    issue_tracker_fields=issue_tracker_fields,
                    skipped_columns=skipped_columns
                )

                result_mode = "CREATED_ISSUE"

                if ATTACH_CREATED_EXCEL_TO_ISSUE:
                    try:
                        exported_excel_file, excel_attach_status = export_and_attach_mysql_row_excel_to_issue(
                            cb=cb,
                            row=row,
                            source_item_id=src_id,
                            issue_item_id=issue_cb_id,
                            issue_mode="CREATED"
                        )

                        if excel_attach_status in ("UPLOADED", "ALREADY_ATTACHED"):
                            excel_attached_to_issue = "YES"

                        if excel_attach_status == "UPLOADED":
                            CHANGE_AUDIT_ROWS.append({
                                "object_type": "Issue",
                                "source_item_id": src_id,
                                "codebeamer_item_id": issue_cb_id,
                                "field_name": "Excel Attachment",
                                "old_value": None,
                                "new_value": exported_excel_file,
                                "action": "ATTACHED_MYSQL_ROW_EXCEL_TO_CREATED_ISSUE"
                            })

                            result_mode = "CREATED_ISSUE_EXCEL_ATTACHED"

                        elif excel_attach_status == "ALREADY_ATTACHED":
                            result_mode = "CREATED_ISSUE_EXCEL_ALREADY_ATTACHED_SKIPPED"

                        else:
                            result_mode = f"CREATED_ISSUE_EXCEL_ATTACHMENT_STATUS_{excel_attach_status}"

                    except Exception as attach_ex:
                        logger.error(
                            "Excel attachment handling failed but Issue was created: source=%s | issue_id=%s | error=%s",
                            src_id,
                            issue_cb_id,
                            attach_ex
                        )

                        failed_rows.append({
                            "row_index": idx,
                            "source_item_id": src_id,
                            "title": title,
                            "phase": "EXCEL_ATTACHMENT_UPLOAD_CREATED_ISSUE",
                            "error": str(attach_ex),
                            "issue_id": issue_cb_id,
                            "excel_file": exported_excel_file
                        })

                        excel_attach_status = "FAILED"
                        result_mode = "CREATED_ISSUE_EXCEL_ATTACHMENT_FAILED"

                else:
                    exported_excel_file = export_issue_mysql_row_to_excel(
                        row=row,
                        source_item_id=src_id,
                        tracker_name=ISSUE_TRACKER_NAME,
                        codebeamer_item_id=issue_cb_id,
                        issue_mode="CREATED"
                    )

                    excel_attach_status = "DISABLED"
                    result_mode = "CREATED_ISSUE_EXCEL_EXPORT_DONE_ATTACHMENT_DISABLED"

                ISSUE_EXISTING_BY_SBM_ITEM_ID[src_key] = {
                    "id": int(issue_cb_id),
                    "name": title,
                    "matched_by": "created"
                }

                CHANGE_AUDIT_ROWS.append({
                    "object_type": "Issue",
                    "source_item_id": src_id,
                    "codebeamer_item_id": issue_cb_id,
                    "field_name": None,
                    "old_value": None,
                    "new_value": None,
                    "action": "CREATED_ISSUE"
                })

            try:
                migrated_changed = force_set_migrated_data_yes(
                    cb=cb,
                    issue_item_id=issue_cb_id,
                    issue_tracker_fields=issue_tracker_fields,
                    skipped_columns=skipped_columns,
                    source_item_id=src_id
                )

                if migrated_changed:
                    result_mode = f"{result_mode}_MIGRATED_DATA_SET_YES"

            except Exception as migrated_ex:
                logger.error(
                    "Migrated Data update failed but continuing: source=%s | issue_id=%s | error=%s",
                    src_id,
                    issue_cb_id,
                    migrated_ex
                )

                failed_rows.append({
                    "row_index": idx,
                    "source_item_id": src_id,
                    "title": title,
                    "phase": "MIGRATED_DATA_UPDATE",
                    "error": str(migrated_ex),
                    "issue_id": issue_cb_id
                })

            issue_field_ref_map = {}
            child_to_issue_links = []

            for rule in active_reference_rules:
                rule_tracker_id = get_rule_tracker_id(rule)
                rule_tracker_name = get_rule_tracker_name(rule)

                if not rule_tracker_id:
                    continue

                source_col = rule.get("source_column") or rule.get("source_logical")

                if not source_col or source_col not in row.index:
                    continue

                raw_source_value = row.get(source_col)

                if rule.get("multi_value"):
                    source_values = split_multi_reference_values(raw_source_value)
                else:
                    one_value = clean_text(raw_source_value)
                    source_values = [one_value] if one_value else []

                if (
                    not source_values
                    and rule.get("mode") == "issue_points_to_child"
                    and rule.get("use_placeholder_if_empty", False)
                ):
                    placeholder_ref = get_placeholder_reference_for_tracker(rule_tracker_name)

                    if placeholder_ref:
                        source_values = [placeholder_ref["name"]]

                if not source_values:
                    continue

                tracker_fields = child_tracker_fields_cache.get(rule_tracker_id)

                if not tracker_fields:
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "CHILD_TRACKER_FIELDS_MISSING",
                        "error": f"Tracker fields not loaded for tracker_id={rule_tracker_id}",
                        "tracker_id": rule_tracker_id,
                        "tracker_name": rule_tracker_name
                    })
                    continue

                for source_value in source_values:
                    child_cb_id = None
                    child_name = source_value
                    was_created = False

                    placeholder_ref = get_placeholder_reference_for_tracker(rule_tracker_name)

                    if (
                        rule.get("mode") == "issue_points_to_child"
                        and placeholder_ref
                        and source_value == placeholder_ref["name"]
                    ):
                        child_cb_id = placeholder_ref["id"]
                        child_name = placeholder_ref["name"]

                    else:
                        child_cb_id, _created_child, was_created = get_or_create_reference_tracker_item(
                            cb=cb,
                            tracker_id=rule_tracker_id,
                            tracker_name=rule_tracker_name,
                            tracker_fields=tracker_fields,
                            source_value=source_value,
                            issue_title=title,
                            source_item_id=src_id
                        )

                        if rule_tracker_id == RETEX_TRACKER_ID and child_cb_id:
                            retex_cb_id = int(child_cb_id)
                            child_name = extract_retex_title_for_codebeamer(source_value) or source_value

                            update_retex_item_if_needed(
                                cb=cb,
                                retex_id=retex_cb_id,
                                retex_value=source_value,
                                issue_title=title,
                                source_item_id=src_id,
                                retex_tracker_fields=tracker_fields
                            )

                        if rule_tracker_id == AEMS_SPECIFICATION_TRACKER_ID and child_cb_id:
                            _spec_sbm_id_value, spec_title_value = parse_sbm_id_title_value(source_value)

                            if spec_title_value:
                                child_name = spec_title_value

                            update_aems_spec_item_if_needed(
                                cb=cb,
                                spec_id=int(child_cb_id),
                                spec_value=source_value,
                                issue_title=title,
                                source_item_id=src_id,
                                spec_tracker_fields=tracker_fields
                            )

                        logger.info(
                            "%s child item: source=%s | rule=%s | value=%s | child_id=%s",
                            "Created" if was_created else "Reused",
                            src_id,
                            rule.get("state_key"),
                            source_value,
                            child_cb_id
                        )

                    if not child_cb_id:
                        continue

                    if rule.get("mode") == "issue_points_to_child":
                        field_name = rule.get("issue_reference_field")

                        if not field_name:
                            continue

                        if field_name in SKIP_ISSUE_REFERENCE_FIELDS:
                            logger.warning("Skipping configured issue reference field: %s", field_name)
                            continue

                        issue_field_ref_map.setdefault(field_name, [])
                        issue_field_ref_map[field_name].append((child_cb_id, child_name))

                    elif rule.get("mode") == "child_points_to_issue":
                        child_to_issue_links.append(
                            (rule, rule_tracker_id, child_cb_id, child_name)
                        )

            for field_name, child_refs in issue_field_ref_map.items():
                try:
                    set_tracker_item_reference_field_on_item(
                        cb=cb,
                        item_id=issue_cb_id,
                        tracker_fields=issue_tracker_fields,
                        reference_field_name=field_name,
                        child_ids_and_names=child_refs
                    )

                    logger.info(
                        "Issue reference field linked: source=%s | issue_id=%s | field=%s | refs=%s",
                        src_id,
                        issue_cb_id,
                        field_name,
                        len(child_refs)
                    )

                except Exception as link_ex:
                    logger.error(
                        "Issue-side reference link failed but continuing: source=%s | field=%s | error=%s",
                        src_id,
                        field_name,
                        link_ex
                    )

                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "ISSUE_SIDE_REFERENCE_LINK",
                        "error": str(link_ex),
                        "field": field_name,
                        "issue_id": issue_cb_id
                    })

            for rule, rule_tracker_id, child_cb_id, child_name in child_to_issue_links:
                try:
                    child_reference_field = rule.get("child_reference_field")

                    if not child_reference_field:
                        raise RuntimeError(f"child_reference_field missing in rule: {rule}")

                    child_tracker_fields = child_tracker_fields_cache.get(rule_tracker_id)

                    if not child_tracker_fields:
                        raise RuntimeError(f"Tracker fields not loaded for tracker_id={rule_tracker_id}")

                    link_reference_with_retry(
                        cb=cb,
                        item_id=child_cb_id,
                        tracker_fields=child_tracker_fields,
                        reference_field_name=child_reference_field,
                        referenced_item_id=issue_cb_id,
                        referenced_item_name=title or f"Issue {issue_cb_id}"
                    )

                except Exception as link_ex:
                    logger.error(
                        "Child-to-Issue link failed but continuing: source=%s | child_id=%s | field=%s | error=%s",
                        src_id,
                        child_cb_id,
                        rule.get("child_reference_field"),
                        link_ex
                    )

                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "CHILD_TO_ISSUE_LINK",
                        "error": str(link_ex),
                        "field": rule.get("child_reference_field"),
                        "child_id": child_cb_id,
                        "issue_id": issue_cb_id
                    })

            source_status = row.get("State")

            if not is_blank(source_status):
                try:
                    status_changed = update_status_last(
                        cb=cb,
                        issue_item_id=issue_cb_id,
                        issue_tracker_fields=issue_tracker_fields,
                        raw_status_value=source_status,
                        source_item_id=src_id
                    )

                    if status_changed:
                        result_mode = f"{result_mode}_STATUS_UPDATED"

                except Exception as status_ex:
                    logger.error(
                        "Status update failed but continuing: source=%s | issue_id=%s | error=%s",
                        src_id,
                        issue_cb_id,
                        status_ex
                    )

                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "STATUS_UPDATE",
                        "error": str(status_ex),
                        "issue_id": issue_cb_id
                    })

            processed_rows.append({
                "source_item_id": src_id,
                "issue_codebeamer_item_id": issue_cb_id,
                "retex_codebeamer_item_id": retex_cb_id,
                "mysql_row_excel_file": exported_excel_file,
                "excel_attached_to_issue": excel_attached_to_issue,
                "excel_attach_status": excel_attach_status,
                "migrated_data_set_yes": "YES" if migrated_changed else "NO",
                "title": title,
                "status": result_mode,
                "matched_by": ISSUE_SBM_ITEM_ID_FIELD_NAME
            })

            logger.info(
                "Row result: source=%s | issue_id=%s | retex_id=%s | excel=%s | attached=%s | attach_status=%s | migrated_data=%s | status=%s",
                src_id,
                issue_cb_id,
                retex_cb_id,
                exported_excel_file,
                excel_attached_to_issue,
                excel_attach_status,
                "YES" if migrated_changed else "NO",
                result_mode
            )

        except Exception as ex:
            logger.exception("Failed for source=%s", src_id)

            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "ISSUE_RETEX_CREATE_UPDATE",
                "error": str(ex)
            })

    return processed_rows
# =========================================================
# REPORTS
# =========================================================

def write_reports(processed_rows, failed_rows, skipped_columns):
    if processed_rows:
        pd.DataFrame(processed_rows).to_csv(
            CREATED_MAP_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.info("Created/updated report written: %s", CREATED_MAP_CSV)
    else:
        logger.info("No processed rows.")

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(
            FAILED_ROWS_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.info("Failed rows report written: %s", FAILED_ROWS_CSV)
    else:
        logger.info("No failed rows.")

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates(
            subset=["source_column", "reason"]
        ).to_csv(
            SKIPPED_COLUMNS_REPORT_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.info("Skipped columns report written: %s", SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("No skipped columns.")

    if CHANGE_AUDIT_ROWS:
        pd.DataFrame(CHANGE_AUDIT_ROWS).to_csv(
            CHANGE_AUDIT_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.info("Change audit report written: %s", CHANGE_AUDIT_CSV)
    else:
        logger.info("No change audit rows.")

    if DUPLICATE_EXISTING_ISSUE_ROWS:
        pd.DataFrame(DUPLICATE_EXISTING_ISSUE_ROWS).to_csv(
            DUPLICATE_EXISTING_ISSUES_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.warning(
            "Duplicate existing Issue report written: %s",
            DUPLICATE_EXISTING_ISSUES_CSV
        )

    if DUPLICATE_EXISTING_RETEX_ROWS:
        pd.DataFrame(DUPLICATE_EXISTING_RETEX_ROWS).to_csv(
            DUPLICATE_EXISTING_RETEX_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.warning(
            "Duplicate existing Retex report written: %s",
            DUPLICATE_EXISTING_RETEX_CSV
        )

    if DUPLICATE_EXISTING_AEMS_SPEC_ROWS:
        pd.DataFrame(DUPLICATE_EXISTING_AEMS_SPEC_ROWS).to_csv(
            DUPLICATE_EXISTING_AEMS_SPEC_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.warning(
            "Duplicate existing H-EMS Specification report written: %s",
            DUPLICATE_EXISTING_AEMS_SPEC_CSV
        )

    write_attachment_manifest()


# =========================================================
# MAIN
# =========================================================

def main():
    acquire_run_lock()

    try:
        load_attachment_manifest()

        logger.info("Connecting to MySQL...")

        conn_url = URL.create(
            "mysql+mysqlconnector",
            username=MYSQL_USER,
            password=MYSQL_PASS,
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            database=MYSQL_DB,
            query={"charset": "utf8mb4"}
        )

        engine = create_engine(conn_url)

        logger.info("Reading source rows from MySQL table: %s", TABLE_NAME)

        df = pd.read_sql(text(SOURCE_SQL), engine)

        if df.empty:
            logger.info("No source rows found. Exiting.")
            write_attachment_manifest()
            return

        df = df.astype(object).where(pd.notna(df), None)

        logger.info("Loaded %s raw Issue rows from MySQL.", len(df))

        df = deduplicate_source_rows_by_item_id(df)

        logger.info(
            "Loaded %s unique Issue rows after Item_Id deduplication.",
            len(df)
        )

        required_columns = [
            SOURCE_KEY_COLUMN,
            SUMMARY_SOURCE_COLUMN,
        ]

        missing = [c for c in required_columns if c not in df.columns]

        if missing:
            raise RuntimeError(
                f"Missing required source columns in MySQL result: {missing}. "
                f"Available columns: {list(df.columns)}"
            )

        logger.info("Connecting to Codebeamer...")

        cb = CodebeamerClient(
            CB_BASE_URL,
            CB_USER,
            CB_PASS,
            verify_ssl=VERIFY_SSL,
            timeout=TIMEOUT
        )

        logger.info("Loading Issue tracker fields...")

        issue_tracker_fields = load_tracker_fields(
            cb=cb,
            tracker_id=ISSUE_TRACKER_ID
        )

        log_field_debug(issue_tracker_fields, ISSUE_SBM_ITEM_ID_FIELD_NAME)
        log_field_debug(issue_tracker_fields, "Trouble Type")
        log_field_debug(issue_tracker_fields, "Pilot")
        log_field_debug(issue_tracker_fields, "Context")
        log_field_debug(issue_tracker_fields, "Detailed Context")
        log_field_debug(issue_tracker_fields, "Perimeter")
        log_field_debug(issue_tracker_fields, "Status")
        log_field_debug(issue_tracker_fields, MIGRATED_DATA_FIELD_NAME)

        active_reference_rules = resolve_reference_rules(
            list(df.columns),
            REFERENCE_TRACKER_RULES
        )

        logger.info(
            "Active reference rules: %s",
            [
                r.get("source_column") or r.get("source_logical")
                for r in active_reference_rules
            ]
        )

        child_tracker_fields_cache = {}

        unique_child_tracker_ids = sorted({
            get_rule_tracker_id(r)
            for r in active_reference_rules
            if get_rule_tracker_id(r)
        })

        for tracker_id in unique_child_tracker_ids:
            logger.info(
                "Loading child tracker fields for tracker id=%s",
                tracker_id
            )

            child_tracker_fields_cache[tracker_id] = load_tracker_fields(
                cb=cb,
                tracker_id=tracker_id
            )

        if RETEX_TRACKER_ID in child_tracker_fields_cache:
            log_field_debug(
                child_tracker_fields_cache[RETEX_TRACKER_ID],
                RETEX_SBM_ITEM_ID_FIELD_NAME
            )

            log_field_debug(
                child_tracker_fields_cache[RETEX_TRACKER_ID],
                RETEX_TO_ISSUE_FIELD_NAME
            )

        if AEMS_SPECIFICATION_TRACKER_ID in child_tracker_fields_cache:
            log_field_debug(
                child_tracker_fields_cache[AEMS_SPECIFICATION_TRACKER_ID],
                AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME
            )

            log_field_debug(
                child_tracker_fields_cache[AEMS_SPECIFICATION_TRACKER_ID],
                "New or Evolution?"
            )

        if FIRST_ENGINE_APPLICATION_TRACKER_ID in child_tracker_fields_cache:
            logger.info(
                "First Engine Application tracker loaded for Detected Engine title creation/linking."
            )

        if FIRST_VEHICLE_APPLICATION_TRACKER_ID in child_tracker_fields_cache:
            logger.info(
                "First Vehicle Application tracker loaded for Detected Vehicle title creation/linking."
            )

        logger.info(
            "Scanning existing Issue tracker by %s...",
            ISSUE_SBM_ITEM_ID_FIELD_NAME
        )

        scan_existing_tracker_by_field(
            cb=cb,
            tracker_id=ISSUE_TRACKER_ID,
            tracker_name=ISSUE_TRACKER_NAME,
            field_name=ISSUE_SBM_ITEM_ID_FIELD_NAME,
            target_cache=ISSUE_EXISTING_BY_SBM_ITEM_ID,
            duplicate_rows=DUPLICATE_EXISTING_ISSUE_ROWS
        )

        logger.info(
            "Scanning existing Retex tracker by %s...",
            RETEX_SBM_ITEM_ID_FIELD_NAME
        )

        scan_existing_tracker_by_field(
            cb=cb,
            tracker_id=RETEX_TRACKER_ID,
            tracker_name=RETEX_TRACKER_NAME,
            field_name=RETEX_SBM_ITEM_ID_FIELD_NAME,
            target_cache=RETEX_EXISTING_BY_SBM_ITEM_ID,
            duplicate_rows=DUPLICATE_EXISTING_RETEX_ROWS
        )

        logger.info(
            "Scanning existing H-EMS Specification tracker by %s...",
            AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME
        )

        scan_existing_tracker_by_field(
            cb=cb,
            tracker_id=AEMS_SPECIFICATION_TRACKER_ID,
            tracker_name=AEMS_SPECIFICATION_TRACKER_NAME,
            field_name=AEMS_SPEC_SBM_ITEM_ID_FIELD_NAME,
            target_cache=AEMS_SPEC_EXISTING_BY_SBM_ITEM_ID,
            duplicate_rows=DUPLICATE_EXISTING_AEMS_SPEC_ROWS
        )

        logger.info("Scanning existing reference trackers by name...")

        scanned_tracker_ids = set()

        for rule in active_reference_rules:
            tracker_id = get_rule_tracker_id(rule)
            tracker_name = get_rule_tracker_name(rule)

            if not tracker_id:
                continue

            if tracker_id in scanned_tracker_ids:
                continue

            scan_existing_reference_tracker_by_name(
                cb=cb,
                tracker_id=tracker_id,
                tracker_name=tracker_name or str(tracker_id)
            )

            scanned_tracker_ids.add(tracker_id)

        skipped_columns = []
        failed_rows = []

        reference_source_columns = {
            r.get("source_column") or r.get("source_logical")
            for r in active_reference_rules
            if r.get("source_column") or r.get("source_logical")
        }

        for col in df.columns:
            if col in SAFE_ISSUE_MAPPING:
                continue

            if col in reference_source_columns:
                continue

            if col in USER_MEMBER_FIELDS_TO_SKIP:
                skipped_columns.append({
                    "source_column": col,
                    "reason": USER_MEMBER_FIELDS_TO_SKIP[col],
                    "sample_value": first_non_null_sample(df, col)
                })

            elif col in REFERENCE_ITEM_FIELDS_TO_SKIP:
                skipped_columns.append({
                    "source_column": col,
                    "reason": REFERENCE_ITEM_FIELDS_TO_SKIP[col],
                    "sample_value": first_non_null_sample(df, col)
                })

            elif col in SPECIAL_SKIP_FIELDS:
                skipped_columns.append({
                    "source_column": col,
                    "reason": SPECIAL_SKIP_FIELDS[col],
                    "sample_value": first_non_null_sample(df, col)
                })

            elif col in INTENTIONAL_SKIP_COLUMNS:
                skipped_columns.append({
                    "source_column": col,
                    "reason": INTENTIONAL_SKIP_COLUMNS[col],
                    "sample_value": first_non_null_sample(df, col)
                })

            else:
                skipped_columns.append({
                    "source_column": col,
                    "reason": "Not in safe mapping / no confirmed supported target field type",
                    "sample_value": first_non_null_sample(df, col)
                })

        logger.info("Starting Issue + Retex create/update/link pass...")

        processed_rows = process_issue_retex_rows(
            cb=cb,
            df=df,
            issue_tracker_fields=issue_tracker_fields,
            child_tracker_fields_cache=child_tracker_fields_cache,
            active_reference_rules=active_reference_rules,
            skipped_columns=skipped_columns,
            failed_rows=failed_rows
        )

        write_reports(
            processed_rows=processed_rows,
            failed_rows=failed_rows,
            skipped_columns=skipped_columns
        )

        logger.info("Issue + Retex sync completed successfully.")

    finally:
        try:
            write_attachment_manifest()
        except Exception as ex:
            logger.warning(
                "Unable to write attachment manifest in finally block. Error=%s",
                ex
            )

        release_run_lock()


if __name__ == "__main__":
    main()

