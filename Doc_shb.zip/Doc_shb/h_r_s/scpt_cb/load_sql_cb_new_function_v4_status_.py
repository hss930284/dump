#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Codebeamer New Function migration script
Source  : MySQL table sbm_nf
Target  : Codebeamer tracker "New Function"

Corrections included:
1. Date handling retained.
2. Status is handled separately after create/update.
3. Status is not sent inside customFields.
4. Status ID is enriched from available transitions if not available in tracker field metadata.
5. Numeric LOV mapping added for:
      - ECM
      - SW Specification
      - Tuning
      - Operating Conditions
   Codebeamer LOV values expected: 1, 2, 3, 4, 5
6. Robust support for numeric source values:
      1, 1.0, "1", "1.0", " 1 ", "Level 1", etc.
"""

import os
import re
import json
import time
import logging
import datetime as dt
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL


# =========================================================
# CONFIGURATION
# =========================================================

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"
TABLE_NAME = "sbm_nf"

SOURCE_SQL = f"""
SELECT *
FROM `{TABLE_NAME}`
WHERE `Item Id` = 'Horse New Function 010045'
LIMIT 1
"""

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = os.getenv("CB_USER", "cbadmin")
CB_PASS = os.getenv("CB_PASS", "cbadmin")

VERIFY_SSL = True
TIMEOUT = 30
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_ID = 48
NEW_FUNCTION_TRACKER_ID = 301069
NEW_FUNCTION_TRACKER_NAME = "New Function"

SOURCE_KEY_COLUMN = "Item Id"
SUMMARY_SOURCE_COLUMN = "Title"

NEW_FUNCTION_SBM_ID_FIELD_NAME = "SBM NF Id"
NEW_FUNCTION_TITLE_FIELD_NAME = "New Function"

MIGRATED_DATA_FIELD_NAME = "Migrated Data ?"
MIGRATED_DATA_VALUE = "Yes"

DEFAULT_MEMBER_ID = 1
DEFAULT_MEMBER_NAME = "cbadmin"

FORCE_MEMBER_FIELDS_TO_DEFAULT = set()

CREATED_UPDATED_CSV = "created_updated_new_function.csv"
FAILED_ROWS_CSV = "failed_rows_new_function.csv"
SKIPPED_COLUMNS_CSV = "skipped_columns_new_function.csv"
DUPLICATE_SOURCE_ROWS_CSV = "duplicate_source_rows_new_function.csv"
DUPLICATE_EXISTING_CSV = "duplicate_existing_new_function_by_sbm_nf_id.csv"
LOG_FILE = "codebeamer_new_function_import.log"
RUN_LOCK_FILE = "codebeamer_new_function_import.lock"

CB_DATE_FORMAT_CANDIDATES = [
    "iso_z",
    "iso_offset",
    "iso_no_tz",
    "date_only",
    "ui_text",
]


# =========================================================
# LOV / VALUE MAPPING
# =========================================================

SKIP_VALUE = "__CB_SKIP_VALUE__"

EMPTY_TO_SKIP = {
    "": SKIP_VALUE,
    "-": SKIP_VALUE,
    "none": SKIP_VALUE,
    "(none)": SKIP_VALUE,
    "null": SKIP_VALUE,
    "nan": SKIP_VALUE,
    "[deleted field]": SKIP_VALUE,
    "deleted field": SKIP_VALUE,
}

NF_STATUS_TO_CB_STATUS = {
    **EMPTY_TO_SKIP,

    "New Project": "New Project",
    "NEW PROJECT": "New Project",
    "new project": "New Project",

    "Cotation": SKIP_VALUE,
    "COTATION": SKIP_VALUE,
    "cotation": SKIP_VALUE,

    "Cotation Validated": "Cotation Validated",
    "COTATION VALIDATED": "Cotation Validated",
    "cotation validated": "Cotation Validated",

    "SDR#0": "SDR#0",
    "SDR0": "SDR#0",
    "sdr0": "SDR#0",

    "SDR#1": "SDR#1",
    "SDR1": "SDR#1",
    "sdr1": "SDR#1",

    "SDR#2": "SDR#2",
    "SDR2": "SDR#2",
    "sdr2": "SDR#2",

    "SDR#3": "SDR#3",
    "SDR3": "SDR#3",
    "sdr3": "SDR#3",

    "SDR#4": "SDR#4",
    "SDR4": "SDR#4",
    "sdr4": "SDR#4",

    "SDR#5": "SDR#5",
    "SDR5": "SDR#5",
    "sdr5": "SDR#5",

    "Industrialisation": "Industrialisation",
    "INDUSTRIALISATION": "Industrialisation",
    "industrialisation": "Industrialisation",

    "Industialisation": "Industialisation",
    "INDUSTIALISATION": "Industialisation",
    "industialisation": "Industialisation",

    "Closed": "Closed",
    "CLOSED": "Closed",
    "closed": "Closed",
}

PERIMETER_TO_CB = {
    **EMPTY_TO_SKIP,
    "Diesel": "Diesel",
    "Electric": "Electric",
    "Gasoline": "Gasoline",
    "Others": "Others",
    "TA": "TA",
    "Transverse": "Transverse",
    "Hybrid": "Hybrid",
}

NUMERIC_1_TO_5_TO_CB = {
    **EMPTY_TO_SKIP,

    "1": "1",
    "2": "2",
    "3": "3",
    "4": "4",
    "5": "5",

    "1.0": "1",
    "2.0": "2",
    "3.0": "3",
    "4.0": "4",
    "5.0": "5",

    1: "1",
    2: "2",
    3: "3",
    4: "4",
    5: "5",

    1.0: "1",
    2.0: "2",
    3.0: "3",
    4.0: "4",
    5.0: "5",
}

NUMERIC_LOV_1_TO_5_FIELDS = {
    "SW Specification",
    "ECM",
    "Tuning",
    "Operating Conditions",
}

TECHNICAL_JUSTIFICATION_TO_CB = {
    **EMPTY_TO_SKIP,
    "Valorization Price": "Valorization Price",
    "Customer performance": "Customer performance",
    "Regulatory": "Regulatory",
    "Safety": "Safety",
    "Fiability": "Fiability",
}

COMPLEXITY_TO_CB = {
    **EMPTY_TO_SKIP,
    "Simple": "Simple",
    "Standard": "Standard",
    "Complex": "Complex",
}

RESOLUTION_TO_CB = {
    **EMPTY_TO_SKIP,
    "Invalid": "Invalid",
    "Duplicate": "Duplicate",
    "Later": "Later",
    "Partly Implemented": "Partly Implemented",
    "Implemented": "Implemented",
}

TYPE_TO_CB = {
    **EMPTY_TO_SKIP,
    "Folder": "Folder",
    "Information": "Information",
    "Functional": "Functional",
    "Non-functional": "Non-functional",
    "Constraint": "Constraint",
    "Legal": "Legal",
    "Compatibility": "Compatibility",
    "Integration": "Integration",
    "Installation": "Installation",
    "Maintainability": "Maintainability",
    "Performance": "Performance",
    "Scalability": "Scalability",
    "Security": "Security",
    "Usability": "Usability",
}

CHOICE_FIELDS_WITH_UNDEFINED_LOV = {
    "Pilot Program Line",
    "Derived Program Line",
    "Technological Bricks",
    "SOAN Cotation",
    "SFAN Cotation",
    "Date AEDR1",
}


# =========================================================
# SOURCE -> CODEBEAMER FIELD MAPPING
# =========================================================

SAFE_NF_MAPPING: Dict[str, Dict[str, Any]] = {
    "Item Id": {"field": NEW_FUNCTION_SBM_ID_FIELD_NAME},
    "Title": {"mode": "name_and_field", "field": NEW_FUNCTION_TITLE_FIELD_NAME},
    "Description": {"field": "Description", "kind": "wikitext"},

    "State": {"field": "Status", "kind": "status", "value_map": NF_STATUS_TO_CB_STATUS},

    "Type": {"field": "Type", "kind": "choice", "value_map": TYPE_TO_CB, "optional": True},
    "Complexity": {"field": "Complexity", "kind": "choice", "value_map": COMPLEXITY_TO_CB, "optional": True},
    "Resolution": {"field": "Resolution", "kind": "choice", "value_map": RESOLUTION_TO_CB, "optional": True},

    "Pilot": {"field": "Pilot", "kind": "member"},
    "Owner": {"field": "Owner", "kind": "member"},
    "Submitter": {"field": "Original Submitted by", "kind": "member"},
    "Instructors": {"field": "System FO", "kind": "member"},
    "Validators": {"field": "Validators", "kind": "member"},

    "Perimeter": {"field": "Perimeter", "kind": "choice", "value_map": PERIMETER_TO_CB},
    "Technical Context": {"field": "Technical justification", "kind": "choice", "value_map": TECHNICAL_JUSTIFICATION_TO_CB},

    "SW Specification": {"field": "SW Specification", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB},
    "ECM": {"field": "ECM", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB},
    "Tuning": {"field": "Tuning", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB},
    "Operating Conditions": {"field": "Operating Conditions", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB},

    "Diag": {"field": "Diag", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB, "optional": True},
    "Inovation Cotation": {"field": "Inovation Cotation", "kind": "choice", "value_map": NUMERIC_1_TO_5_TO_CB, "optional": True},

    "Justification": {"field": "Justification", "optional": True},
    "Cotation of complexity level (M equivalent)": {"field": "Cotation of complexity level (M equivalent)", "optional": True},
    "Corresponding NDL": {"field": "Corresponding ND", "kind": "wikitext"},
    "Comments (Cotation NFL)": {"field": "Comments (Cotation NFL)", "optional": True},
    "Cotation Date": {"field": "Cotation Date", "kind": "date"},

    "FpDR0 / SDR1 Status": {"field": "SDR1 Status"},
    "N° IDOC FpDR0 / SDR1": {"field": "N° IDOC SDR1"},
    "Date FpDR0 / SDR1": {"field": "Date SDR1", "kind": "text_date"},

    "FpDR1 / SDR2 or QDR1 Status": {"field": "SDR2 or QDR1 Status"},
    "N° IDOC FpDR1 / SDR2 or QDR1": {"field": "N° IDOC SDR2 or QDR1"},
    "Date FpDR1 / SDR2 or QDR1": {"field": "Date SDR2 or QDR1", "kind": "text_date"},

    "FpDR2 / SDR3 Status": {"field": "SDR3 Status"},
    "N° IDOC FpDR2 / SDR3": {"field": "N° IDOC SDR3"},
    "Date FpDR2 / SDR3": {"field": "Date SDR3", "kind": "text_date"},

    "FpDR3 / SDR4 or QDR2 Status": {"field": "SDR4 or QDR2 Status"},
    "N° IDOC FpDR3 / SDR4 or QDR2": {"field": "N° IDOC SDR4 or QDR2"},
    "Date FpDR3 / SDR4 or QDR2": {"field": "Date SDR4 or QDR2", "kind": "text_date"},

    "FpDR4 / SDR5 or QDR3 Status": {"field": "SDR5 or QDR3"},
    "N° IDOC FpDR4 / SDR5 or QDR3": {"field": "N° IDOC SDR5 or QDR3"},
    "Date FpDR4 / SDR5 or QDR3": {"field": "Date SDR5 or QDR3", "kind": "text_date"},
}

APPEND_TO_DESCRIPTION_FIELDS = [
    "State",
    "Active/Inactive",
    "Project",
    "Technical Context",
    "Pilot Program Line (QC)",
    "Program Line (QC)",
    "Technological Bricks",
    "Engine",
    "Vehicle",
    "Expected deliveries",
    "Global NF Cotation",
    "Cotation Decision",
    "Associated DMFI",
    "Instructors",
    "SCDR#0 date prev",
    "SCDR#0 date real",
    "SCDR#0 status",
    "Close Date",
    "Associated Attachments",
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging() -> logging.Logger:
    logger_obj = logging.getLogger("cb_new_function_sync")
    logger_obj.setLevel(logging.INFO)
    logger_obj.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger_obj.addHandler(sh)

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    logger_obj.addHandler(fh)

    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "").replace("\u00a0", " ").strip()).lower()


def normalize_key(s: Any) -> str:
    return re.sub(r"\s+", "", str(s or "").replace("\u00a0", " ").strip()).lower()


def is_blank(v: Any) -> bool:
    if v is None:
        return True

    try:
        if pd.isna(v):
            return True
    except Exception:
        pass

    txt = str(v).replace("\u00a0", " ").strip()
    return txt == "" or txt.lower() in {
        "nan",
        "none",
        "null",
        "(none)",
        "-",
        "[deleted field]",
        "deleted field",
    }


def clean_text(v: Any) -> Optional[str]:
    if is_blank(v):
        return None

    txt = str(v).replace("\u00a0", " ").replace("_x000D_", "\n").strip()
    txt = re.sub(r"\r\n?", "\n", txt)
    txt = re.sub(r"[ \t]+", " ", txt)
    return txt.strip()


def safe_sleep() -> None:
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def parse_any_date(v: Any) -> Optional[pd.Timestamp]:
    if is_blank(v):
        return None

    if isinstance(v, (pd.Timestamp, dt.datetime, dt.date)):
        parsed = pd.to_datetime(v, errors="coerce")
    else:
        txt = clean_text(v)
        if not txt:
            return None
        parsed = pd.to_datetime(txt, errors="coerce")

    if pd.isna(parsed):
        return None

    return parsed


def to_iso_date(v: Any) -> Optional[str]:
    parsed = parse_any_date(v)

    if parsed is None:
        return clean_text(v)

    return parsed.date().isoformat()


def format_cb_date_value(v: Any, date_format: str) -> Optional[str]:
    parsed = parse_any_date(v)

    if parsed is None:
        return None

    date_part = parsed.date()

    if date_format == "iso_z":
        return f"{date_part.isoformat()}T00:00:00.000Z"

    if date_format == "iso_offset":
        return f"{date_part.isoformat()}T00:00:00.000+0000"

    if date_format == "iso_no_tz":
        return f"{date_part.isoformat()}T00:00:00.000"

    if date_format == "date_only":
        return date_part.isoformat()

    if date_format == "ui_text":
        return parsed.strftime("%b %d %Y")

    return f"{date_part.isoformat()}T00:00:00.000Z"


def apply_value_map(raw_value: Any, value_map: Optional[Dict[Any, Any]]) -> Tuple[Any, bool]:
    if not value_map:
        return raw_value, False

    if raw_value in value_map:
        mapped = value_map[raw_value]
    else:
        txt = clean_text(raw_value)
        mapped = value_map.get(txt, value_map.get((txt or "").lower(), raw_value))

    if mapped == SKIP_VALUE:
        return None, True

    return mapped, False


def normalize_numeric_lov_1_to_5(raw_value: Any) -> Tuple[Optional[str], bool]:
    """
    Normalizes values for Codebeamer choice fields where LOV is:
        1, 2, 3, 4, 5

    Supports:
        1
        1.0
        "1"
        "1.0"
        " 1 "
        "Level 1"
        "1 - Low"
    """

    if is_blank(raw_value):
        return None, True

    txt = clean_text(raw_value)

    if not txt:
        return None, True

    txt_lower = txt.lower()

    if txt_lower in EMPTY_TO_SKIP:
        return None, True

    if raw_value in NUMERIC_1_TO_5_TO_CB:
        mapped = NUMERIC_1_TO_5_TO_CB[raw_value]
        return mapped, mapped == SKIP_VALUE

    if txt in NUMERIC_1_TO_5_TO_CB:
        mapped = NUMERIC_1_TO_5_TO_CB[txt]
        return mapped, mapped == SKIP_VALUE

    try:
        num = float(txt)

        if num.is_integer():
            int_val = int(num)

            if int_val in [1, 2, 3, 4, 5]:
                return str(int_val), False

    except Exception:
        pass

    match = re.search(r"\b([1-5])(?:\.0+)?\b", txt)

    if match:
        return match.group(1), False

    return txt, False


def read_pid_from_lock_file(lock_file: str) -> Optional[int]:
    try:
        return int(open(lock_file, "r", encoding="utf-8").read().strip())
    except Exception:
        return None


def is_pid_running(pid: Optional[int]) -> bool:
    if not pid:
        return False

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_run_lock() -> None:
    if os.path.exists(RUN_LOCK_FILE):
        existing_pid = read_pid_from_lock_file(RUN_LOCK_FILE)

        if is_pid_running(existing_pid):
            raise RuntimeError(
                f"Another run is already active. Lock={RUN_LOCK_FILE}, PID={existing_pid}"
            )

        logger.warning("Removing stale lock file: %s", RUN_LOCK_FILE)
        os.remove(RUN_LOCK_FILE)

    with open(RUN_LOCK_FILE, "w", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    logger.info("Run lock acquired: %s", RUN_LOCK_FILE)


def release_run_lock() -> None:
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)
            logger.info("Run lock released: %s", RUN_LOCK_FILE)
    except Exception as ex:
        logger.warning("Unable to remove lock file. Error=%s", ex)


def is_date_parse_error(ex: Exception) -> bool:
    msg = str(ex).lower()
    return "date format" in msg or "parse date" in msg or "couldn't parse date" in msg


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        verify_ssl: bool = True,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
        })

        retry = Retry(
            total=3,
            connect=3,
            read=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        )

        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        return self.base_url + "/" + path.lstrip("/")

    def request(self, method: str, path: str, **kwargs) -> Any:
        safe_sleep()
        url = self._url(path)

        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)

        if not resp.ok:
            raise RuntimeError(
                f"Codebeamer {method} {url} failed: "
                f"HTTP {resp.status_code}: {resp.text[:3000]}"
            )

        if not resp.text:
            return None

        try:
            return resp.json()
        except Exception:
            return resp.text

    def get(self, path: str, **kwargs) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, payload: Dict[str, Any], **kwargs) -> Any:
        return self.request(
            "POST",
            path,
            data=json.dumps(payload, ensure_ascii=False),
            **kwargs,
        )

    def put(self, path: str, payload: Dict[str, Any], **kwargs) -> Any:
        return self.request(
            "PUT",
            path,
            data=json.dumps(payload, ensure_ascii=False),
            **kwargs,
        )


# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb: CodebeamerClient, tracker_id: int) -> Dict[str, Dict[str, Any]]:
    data = cb.get(f"/v3/trackers/{tracker_id}/fields")
    fields = data.get("fields", data) if isinstance(data, dict) else data

    if not isinstance(fields, list):
        raise RuntimeError(
            f"Unexpected tracker fields response for tracker {tracker_id}: {type(fields)}"
        )

    result = {}

    for f in fields:
        name = f.get("name") or f.get("label")
        if name:
            result[normalize_name(name)] = f

    logger.info("Loaded %s fields from tracker %s", len(result), tracker_id)
    return result


def get_item_detail(cb: CodebeamerClient, item_id: int) -> Dict[str, Any]:
    return cb.get(f"/v3/items/{item_id}")


def load_item_fields_robust(cb: CodebeamerClient, item_id: int) -> List[Dict[str, Any]]:
    item = get_item_detail(cb, item_id)
    fields = item.get("customFields") or item.get("fields") or []

    if fields:
        return fields

    try:
        data = cb.get(f"/v3/items/{item_id}/fields")
        return data.get("fields", data) if isinstance(data, dict) else data
    except Exception:
        return []


def extract_items_from_query_response(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ["items", "itemRefs", "trackerItems", "content"]:
            val = data.get(key)
            if isinstance(val, list):
                return val

        page = data.get("page")
        if isinstance(page, dict):
            for key in ["items", "content"]:
                val = page.get(key)
                if isinstance(val, list):
                    return val

    return []


def extract_item_id(item: Dict[str, Any]) -> Optional[int]:
    if not isinstance(item, dict):
        return None

    for key in ["id", "itemId"]:
        if item.get(key):
            return int(item[key])

    if isinstance(item.get("item"), dict) and item["item"].get("id"):
        return int(item["item"]["id"])

    return None


def extract_item_name(item: Dict[str, Any]) -> Optional[str]:
    if not isinstance(item, dict):
        return None

    return item.get("name") or item.get("itemName") or (item.get("item") or {}).get("name")


def extract_field_value_by_name(field_values: List[Dict[str, Any]], field_name: str) -> Any:
    target = normalize_name(field_name)

    for fv in field_values or []:
        if normalize_name(fv.get("name")) == target:
            if "value" in fv:
                return fv.get("value")

            if "values" in fv:
                vals = fv.get("values") or []
                if isinstance(vals, list):
                    return ", ".join([
                        str(x.get("name") or x.get("id") or x)
                        for x in vals
                    ])

            return fv

    return None


def scan_existing_nf_by_sbm_id(
    cb: CodebeamerClient,
    tracker_id: int,
) -> Tuple[Dict[str, Dict[str, Any]], List[Dict[str, Any]]]:

    logger.info("Scanning existing New Function items by '%s'...", NEW_FUNCTION_SBM_ID_FIELD_NAME)

    cache: Dict[str, Dict[str, Any]] = {}
    duplicates: List[Dict[str, Any]] = []

    page = 1
    page_size = 500

    while True:
        data = None
        last_error = None

        endpoints = [
            f"/v3/trackers/{tracker_id}/items?page={page}&pageSize={page_size}",
            f"/v3/items/query?page={page}&pageSize={page_size}&queryString=tracker.id IN ({tracker_id})",
        ]

        for endpoint in endpoints:
            try:
                data = cb.get(endpoint)
                break
            except Exception as ex:
                last_error = ex

        if data is None:
            raise RuntimeError(f"Unable to scan tracker items. Last error={last_error}")

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id(item_ref)

            if not item_id:
                continue

            try:
                fields = load_item_fields_robust(cb, item_id)
                sbm_id = clean_text(
                    extract_field_value_by_name(fields, NEW_FUNCTION_SBM_ID_FIELD_NAME)
                )

                if not sbm_id:
                    continue

                key = normalize_key(sbm_id)

                rec = {
                    "codebeamer_item_id": item_id,
                    "name": extract_item_name(item_ref) or str(item_id),
                    "sbm_nf_id": sbm_id,
                }

                if key in cache:
                    duplicates.append({
                        "sbm_nf_id": sbm_id,
                        "first_item_id": cache[key]["codebeamer_item_id"],
                        "duplicate_item_id": item_id,
                    })
                else:
                    cache[key] = rec

            except Exception as ex:
                logger.warning("Could not inspect existing item %s. Error=%s", item_id, ex)

        if len(items) < page_size:
            break

        page += 1

    logger.info("Existing New Function cache size: %s", len(cache))
    return cache, duplicates


# =========================================================
# FIELD VALUE BUILDERS
# =========================================================

def get_field_meta(
    tracker_fields: Dict[str, Dict[str, Any]],
    field_name: str,
) -> Optional[Dict[str, Any]]:
    return tracker_fields.get(normalize_name(field_name))


def build_text_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
) -> Optional[Dict[str, Any]]:

    val = clean_text(raw_value)

    if val is None:
        return None

    return {
        "fieldId": field_meta["id"],
        "name": field_meta.get("name"),
        "type": "TextFieldValue",
        "value": val,
    }


def build_wikitext_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
) -> Optional[Dict[str, Any]]:

    val = clean_text(raw_value)

    if val is None:
        return None

    return {
        "fieldId": field_meta["id"],
        "name": field_meta.get("name"),
        "type": "WikiTextFieldValue",
        "value": val,
    }


def build_date_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
    date_format: str,
) -> Optional[Dict[str, Any]]:

    val = format_cb_date_value(raw_value, date_format)

    if val is None:
        return None

    return {
        "fieldId": field_meta["id"],
        "name": field_meta.get("name"),
        "type": "DateFieldValue",
        "value": val,
    }


def get_choice_options(field_meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    for key in ["options", "values", "allowedValues", "choiceOptions"]:
        val = field_meta.get(key)
        if isinstance(val, list):
            return val

    return []


def find_choice_option(
    field_meta: Dict[str, Any],
    raw_value: Any,
) -> Optional[Dict[str, Any]]:

    val = clean_text(raw_value)

    if not val:
        return None

    target = normalize_name(val)

    for opt in get_choice_options(field_meta):
        name = opt.get("name") or opt.get("label") or opt.get("value")

        if normalize_name(name) == target:
            return {
                "id": opt.get("id"),
                "name": name,
                "type": opt.get("type", "ChoiceOptionReference"),
            }

    return None


def build_choice_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:

    val = clean_text(raw_value)

    if not val:
        return None, None

    opt = find_choice_option(field_meta, val)

    if not opt:
        return None, (
            f"Choice option not found for field '{field_meta.get('name')}' value '{val}'"
        )

    return {
        "fieldId": field_meta["id"],
        "name": field_meta.get("name"),
        "type": "ChoiceFieldValue",
        "values": [opt],
    }, None


def build_member_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
    field_name: str,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:

    source_member = clean_text(raw_value)

    if not source_member and field_name not in FORCE_MEMBER_FIELDS_TO_DEFAULT:
        return None, None

    if field_name in FORCE_MEMBER_FIELDS_TO_DEFAULT and DEFAULT_MEMBER_ID and DEFAULT_MEMBER_NAME:
        member_ref = {
            "id": DEFAULT_MEMBER_ID,
            "name": DEFAULT_MEMBER_NAME,
            "type": "UserReference",
        }

        return {
            "fieldId": field_meta["id"],
            "name": field_meta.get("name"),
            "type": "ChoiceFieldValue",
            "values": [member_ref],
        }, None

    return None, (
        f"Member/User field '{field_name}' skipped; source value='{source_member}'. "
        f"Add user lookup or force default."
    )


def build_field_value(
    field_meta: Dict[str, Any],
    raw_value: Any,
    kind: Optional[str],
    target_field_name: str,
    date_format: str,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:

    if is_blank(raw_value):
        return None, None

    if kind == "choice":
        return build_choice_field_value(field_meta, raw_value)

    if kind in {"member", "user"}:
        return build_member_field_value(field_meta, raw_value, target_field_name)

    if kind == "date":
        fv = build_date_field_value(field_meta, raw_value, date_format)

        if fv is None:
            return None, f"Invalid date for field '{target_field_name}': {raw_value}"

        return fv, None

    if kind == "wikitext":
        return build_wikitext_field_value(field_meta, raw_value), None

    if kind == "text_date":
        return build_text_field_value(field_meta, to_iso_date(raw_value)), None

    return build_text_field_value(field_meta, raw_value), None


# =========================================================
# STATUS HELPERS
# =========================================================

def get_status_meta(tracker_fields: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    return tracker_fields.get(normalize_name("Status"))


def build_nf_status_reference(
    row: pd.Series,
    tracker_fields: Dict[str, Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:

    if "State" not in row.index:
        skipped_columns.append({
            "source_column": "State",
            "target_field": "Status",
            "reason": "Source column State not found",
        })
        return None

    raw_state = row.get("State")
    mapped_state, should_skip = apply_value_map(raw_state, NF_STATUS_TO_CB_STATUS)

    if should_skip or is_blank(mapped_state):
        skipped_columns.append({
            "source_column": "State",
            "target_field": "Status",
            "source_value": clean_text(raw_state),
            "reason": "Status skipped because source value is blank or mapped to SKIP_VALUE",
        })
        logger.warning(
            "Status skipped. Source State=%s mapped=%s",
            clean_text(raw_state),
            clean_text(mapped_state),
        )
        return None

    status_meta = get_status_meta(tracker_fields)

    if status_meta:
        option = find_choice_option(status_meta, mapped_state)

        if option:
            status_ref = {
                "id": option.get("id"),
                "name": option.get("name"),
                "type": option.get("type", "ChoiceOptionReference"),
            }

            logger.info(
                "Prepared Status from tracker metadata. State='%s' mapped='%s' id=%s name=%s",
                clean_text(raw_state),
                clean_text(mapped_state),
                status_ref.get("id"),
                status_ref.get("name"),
            )

            return status_ref

    status_ref = {
        "name": clean_text(mapped_state),
        "type": "ChoiceOptionReference",
    }

    logger.warning(
        "Status option id not available from tracker metadata. "
        "Using name-only Status reference. Source State='%s' mapped='%s'",
        clean_text(raw_state),
        clean_text(mapped_state),
    )

    return status_ref


def extract_transition_list(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in [
            "transitions",
            "actions",
            "workflowTransitions",
            "availableTransitions",
            "itemTransitions",
            "content",
            "items",
        ]:
            val = data.get(key)
            if isinstance(val, list):
                return val

        page = data.get("page")
        if isinstance(page, dict):
            for key in ["content", "items"]:
                val = page.get(key)
                if isinstance(val, list):
                    return val

    return []


def load_available_transitions(cb: CodebeamerClient, item_id: int) -> List[Dict[str, Any]]:
    endpoint = f"/v3/items/{item_id}/transitions"

    try:
        data = cb.get(endpoint)
        transitions = extract_transition_list(data)

        logger.info(
            "Loaded %s available transitions for item=%s",
            len(transitions),
            item_id,
        )

        return transitions

    except Exception as ex:
        logger.warning(
            "Unable to load transitions for item=%s error=%s",
            item_id,
            ex,
        )
        return []


def enrich_status_ref_from_available_transitions(
    cb: CodebeamerClient,
    item_id: int,
    status_ref: Dict[str, Any],
    skipped_columns: List[Dict[str, Any]],
    source_value: Any,
) -> Dict[str, Any]:

    if status_ref.get("id"):
        return status_ref

    target_status_name = clean_text(status_ref.get("name"))

    if not target_status_name:
        return status_ref

    transitions = load_available_transitions(cb, item_id)

    if not transitions:
        skipped_columns.append({
            "source_column": "State",
            "target_field": "Status",
            "source_value": clean_text(source_value),
            "mapped_value": target_status_name,
            "reason": "Unable to enrich Status id because no transitions were returned",
        })
        return status_ref

    logger.info(
        "Available transitions for item=%s: %s",
        item_id,
        json.dumps(transitions, ensure_ascii=False)[:3000],
    )

    for transition in transitions:
        to_status = transition.get("toStatus") or transition.get("targetStatus")

        if isinstance(to_status, dict):
            to_status_name = clean_text(
                to_status.get("name")
                or to_status.get("label")
                or to_status.get("value")
            )

            if to_status_name and normalize_name(to_status_name) == normalize_name(target_status_name):
                enriched_ref = {
                    "id": to_status.get("id"),
                    "name": to_status_name,
                    "type": to_status.get("type", "ChoiceOptionReference"),
                }

                logger.info(
                    "Enriched Status from transition. item=%s status=%s id=%s transition_id=%s",
                    item_id,
                    enriched_ref.get("name"),
                    enriched_ref.get("id"),
                    transition.get("id"),
                )

                return enriched_ref

    skipped_columns.append({
        "source_column": "State",
        "target_field": "Status",
        "source_value": clean_text(source_value),
        "mapped_value": target_status_name,
        "reason": "Could not find matching toStatus in available transitions",
    })

    logger.warning(
        "Could not enrich Status id from transitions. item=%s target_status=%s",
        item_id,
        target_status_name,
    )

    return status_ref


def update_status_last(
    cb: CodebeamerClient,
    item_id: int,
    tracker_fields: Dict[str, Dict[str, Any]],
    row: pd.Series,
    skipped_columns: List[Dict[str, Any]],
) -> None:

    status_ref = build_nf_status_reference(row, tracker_fields, skipped_columns)

    if not status_ref:
        return

    source_state = row.get("State")

    status_ref = enrich_status_ref_from_available_transitions(
        cb=cb,
        item_id=item_id,
        status_ref=status_ref,
        skipped_columns=skipped_columns,
        source_value=source_state,
    )

    target_status_name = status_ref.get("name")

    if not target_status_name:
        skipped_columns.append({
            "source_column": "State",
            "target_field": "Status",
            "source_value": clean_text(source_state),
            "reason": "Prepared status reference has no name",
        })
        return

    if not status_ref.get("id"):
        skipped_columns.append({
            "source_column": "State",
            "target_field": "Status",
            "source_value": clean_text(source_state),
            "mapped_value": target_status_name,
            "reason": "Prepared status reference still has no id after transition lookup",
        })
        logger.warning(
            "Status update skipped because id is missing. item=%s status=%s",
            item_id,
            target_status_name,
        )
        return

    attempts = []

    try:
        item = get_item_detail(cb, item_id)

        item["status"] = {
            "id": status_ref.get("id"),
            "name": status_ref.get("name"),
            "type": status_ref.get("type", "ChoiceOptionReference"),
        }

        cb.put(f"/v3/items/{item_id}", item)

        logger.info(
            "Status updated by top-level item PUT. item=%s status_id=%s status=%s",
            item_id,
            status_ref.get("id"),
            status_ref.get("name"),
        )
        return

    except Exception as ex:
        attempts.append(f"top-level PUT failed: {ex}")
        logger.warning(
            "Top-level status update failed. item=%s status_id=%s status=%s error=%s",
            item_id,
            status_ref.get("id"),
            status_ref.get("name"),
            ex,
        )

    status_meta = get_status_meta(tracker_fields)

    if status_meta:
        status_field_value = {
            "fieldId": status_meta["id"],
            "name": status_meta.get("name", "Status"),
            "type": "ChoiceFieldValue",
            "values": [
                {
                    "id": status_ref.get("id"),
                    "name": status_ref.get("name"),
                    "type": status_ref.get("type", "ChoiceOptionReference"),
                }
            ],
        }

        try:
            cb.put(f"/v3/items/{item_id}/fields", {"fieldValues": [status_field_value]})

            logger.info(
                "Status updated by /fields. item=%s status_id=%s status=%s",
                item_id,
                status_ref.get("id"),
                status_ref.get("name"),
            )
            return

        except Exception as ex:
            attempts.append(f"/fields fieldValues failed: {ex}")
            logger.warning(
                "Status /fields update failed. item=%s status_id=%s status=%s error=%s",
                item_id,
                status_ref.get("id"),
                status_ref.get("name"),
                ex,
            )

    skipped_columns.append({
        "source_column": "State",
        "target_field": "Status",
        "source_value": clean_text(source_state),
        "mapped_value": target_status_name,
        "status_id": status_ref.get("id"),
        "reason": "Unable to apply status. " + " || ".join(attempts),
    })


# =========================================================
# PAYLOAD BUILDERS
# =========================================================

def build_description(row: pd.Series) -> str:
    base = clean_text(row.get("Description")) or "Imported New Function from SBM."

    lines = [base]
    extra_lines = []

    for col in APPEND_TO_DESCRIPTION_FIELDS:
        if col in row.index:
            val = clean_text(row.get(col))
            if val:
                extra_lines.append(f"* **{col}:** {val}")

    if extra_lines:
        lines.append("\n----\n")
        lines.append("h3. Migrated source details")
        lines.extend(extra_lines)

    return "\n".join(lines)


def build_scalar_field_values(
    row: pd.Series,
    tracker_fields: Dict[str, Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
    date_format: str = "iso_z",
) -> List[Dict[str, Any]]:

    values: List[Dict[str, Any]] = []
    seen_field_ids = set()

    for src_col, rule in SAFE_NF_MAPPING.items():
        if src_col not in row.index:
            if not rule.get("optional"):
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": "Source column not found in MySQL result",
                })
            continue

        if rule.get("mode") == "name":
            continue

        target_field = rule.get("field")

        if not target_field:
            continue

        if rule.get("kind") == "status" or normalize_name(target_field) == normalize_name("Status"):
            continue

        meta = get_field_meta(tracker_fields, target_field)

        if not meta:
            skipped_columns.append({
                "source_column": src_col,
                "target_field": target_field,
                "reason": "Target field not found in Codebeamer tracker",
            })
            continue

        if target_field in CHOICE_FIELDS_WITH_UNDEFINED_LOV:
            skipped_columns.append({
                "source_column": src_col,
                "target_field": target_field,
                "source_value": clean_text(row.get(src_col)),
                "reason": "CB choice LOV undefined/placeholder; preserved in Description",
            })
            continue

        raw_value = build_description(row) if target_field == "Description" else row.get(src_col)

        if target_field in NUMERIC_LOV_1_TO_5_FIELDS:
            raw_value, should_skip = normalize_numeric_lov_1_to_5(raw_value)
        else:
            raw_value, should_skip = apply_value_map(raw_value, rule.get("value_map"))

        if should_skip:
            skipped_columns.append({
                "source_column": src_col,
                "target_field": target_field,
                "source_value": clean_text(row.get(src_col)),
                "reason": "Value skipped because it is blank/deleted/null or mapped to SKIP_VALUE",
            })
            continue

        fv, warning = build_field_value(
            meta,
            raw_value,
            rule.get("kind"),
            target_field,
            date_format,
        )

        if warning:
            skipped_columns.append({
                "source_column": src_col,
                "target_field": target_field,
                "source_value": clean_text(row.get(src_col)),
                "mapped_value": clean_text(raw_value),
                "reason": warning,
            })

        if fv and fv.get("fieldId") not in seen_field_ids:
            values.append(fv)
            seen_field_ids.add(fv.get("fieldId"))

    migrated_meta = get_field_meta(tracker_fields, MIGRATED_DATA_FIELD_NAME)

    if migrated_meta:
        fv, warning = build_choice_field_value(migrated_meta, MIGRATED_DATA_VALUE)

        if fv:
            values.append(fv)
        elif warning:
            skipped_columns.append({
                "source_column": "<constant>",
                "target_field": MIGRATED_DATA_FIELD_NAME,
                "source_value": MIGRATED_DATA_VALUE,
                "reason": warning,
            })

    return values


def get_item_name(row: pd.Series) -> str:
    return (
        clean_text(row.get(SUMMARY_SOURCE_COLUMN))
        or clean_text(row.get(SOURCE_KEY_COLUMN))
        or "Imported New Function"
    )


def extract_created_item_id(data: Any) -> Optional[int]:
    if isinstance(data, dict):
        if data.get("id"):
            return int(data["id"])

        if isinstance(data.get("item"), dict) and data["item"].get("id"):
            return int(data["item"]["id"])

        if isinstance(data.get("itemRef"), dict) and data["itemRef"].get("id"):
            return int(data["itemRef"]["id"])

    return None


def log_date_fields(field_values: List[Dict[str, Any]], date_format: str) -> None:
    for fv in field_values:
        if fv.get("type") == "DateFieldValue":
            logger.info(
                "Prepared DateFieldValue using format=%s | field=%s | fieldId=%s | value=%s",
                date_format,
                fv.get("name"),
                fv.get("fieldId"),
                fv.get("value"),
            )


def remove_date_fields(
    field_values: List[Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
    reason: str,
) -> List[Dict[str, Any]]:

    non_date_values = []

    for fv in field_values:
        if fv.get("type") == "DateFieldValue":
            skipped_columns.append({
                "source_column": "<date field>",
                "target_field": fv.get("name"),
                "source_value": fv.get("value"),
                "reason": reason,
            })
        else:
            non_date_values.append(fv)

    return non_date_values


def make_create_payload(
    row: pd.Series,
    field_values: List[Dict[str, Any]],
    include_tracker_ref: bool = False,
) -> Dict[str, Any]:

    payload = {
        "name": get_item_name(row),
        "description": build_description(row),
        "customFields": field_values,
    }

    if include_tracker_ref:
        payload["tracker"] = {
            "id": NEW_FUNCTION_TRACKER_ID,
            "name": NEW_FUNCTION_TRACKER_NAME,
            "type": "TrackerReference",
        }

    return payload


# =========================================================
# CREATE / UPDATE
# =========================================================

def create_nf_item(
    cb: CodebeamerClient,
    row: pd.Series,
    tracker_fields: Dict[str, Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
) -> int:

    create_endpoint = f"/v3/trackers/{NEW_FUNCTION_TRACKER_ID}/items"
    last_error = None

    for date_format in CB_DATE_FORMAT_CANDIDATES:
        field_values = build_scalar_field_values(
            row,
            tracker_fields,
            skipped_columns,
            date_format=date_format,
        )

        log_date_fields(field_values, date_format)

        payloads_to_try = [
            make_create_payload(row, field_values, include_tracker_ref=False),
            make_create_payload(row, field_values, include_tracker_ref=True),
        ]

        for idx, payload in enumerate(payloads_to_try, start=1):
            try:
                logger.info(
                    "Trying create payload #%s using date_format=%s endpoint=%s",
                    idx,
                    date_format,
                    create_endpoint,
                )

                data = cb.post(create_endpoint, payload)
                item_id = extract_created_item_id(data)

                if item_id:
                    logger.info("Created Codebeamer New Function item id=%s", item_id)

                    update_status_last(
                        cb=cb,
                        item_id=int(item_id),
                        tracker_fields=tracker_fields,
                        row=row,
                        skipped_columns=skipped_columns,
                    )

                    return int(item_id)

                last_error = RuntimeError(
                    f"Create response did not contain item id. Response={data}"
                )

            except Exception as ex:
                last_error = ex
                logger.warning(
                    "Create failed using date_format=%s payload #%s: %s",
                    date_format,
                    idx,
                    ex,
                )

                if not is_date_parse_error(ex):
                    break

        if last_error and not is_date_parse_error(last_error):
            break

    logger.warning(
        "All create attempts with DateFieldValue failed. Retrying create without date fields."
    )

    field_values = build_scalar_field_values(
        row,
        tracker_fields,
        skipped_columns,
        date_format="iso_z",
    )

    field_values_without_dates = remove_date_fields(
        field_values,
        skipped_columns,
        "Skipped because Codebeamer rejected all tested date formats during create",
    )

    payloads_without_dates = [
        make_create_payload(row, field_values_without_dates, include_tracker_ref=False),
        make_create_payload(row, field_values_without_dates, include_tracker_ref=True),
    ]

    for idx, payload in enumerate(payloads_without_dates, start=1):
        try:
            logger.info(
                "Trying create without DateFieldValue fields payload #%s endpoint=%s",
                idx,
                create_endpoint,
            )

            data = cb.post(create_endpoint, payload)
            item_id = extract_created_item_id(data)

            if item_id:
                logger.info(
                    "Created Codebeamer New Function item id=%s without date fields",
                    item_id,
                )

                update_status_last(
                    cb=cb,
                    item_id=int(item_id),
                    tracker_fields=tracker_fields,
                    row=row,
                    skipped_columns=skipped_columns,
                )

                return int(item_id)

            last_error = RuntimeError(
                f"Create without date fields did not contain item id. Response={data}"
            )

        except Exception as ex:
            last_error = ex
            logger.warning("Create without date fields payload #%s failed: %s", idx, ex)

    raise RuntimeError(f"All create payload attempts failed. Last error={last_error}")


def update_item_name(cb: CodebeamerClient, item_id: int, new_name: str) -> None:
    try:
        item = get_item_detail(cb, item_id)
        item["name"] = new_name
        cb.put(f"/v3/items/{item_id}", item)
    except Exception as ex:
        logger.warning("Unable to update item name for %s. Error=%s", item_id, ex)


def update_item_fields(
    cb: CodebeamerClient,
    item_id: int,
    field_values: List[Dict[str, Any]],
) -> None:

    if not field_values:
        return

    last_error = None

    payloads = [
        {"fieldValues": field_values},
        {"customFields": field_values},
    ]

    for payload in payloads:
        try:
            cb.put(f"/v3/items/{item_id}/fields", payload)
            return
        except Exception as ex:
            last_error = ex

    raise RuntimeError(
        f"Unable to update item fields for item {item_id}. Last error={last_error}"
    )


def update_nf_item(
    cb: CodebeamerClient,
    item_id: int,
    row: pd.Series,
    tracker_fields: Dict[str, Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
) -> None:

    update_item_name(cb, item_id, get_item_name(row))

    last_error = None

    for date_format in CB_DATE_FORMAT_CANDIDATES:
        field_values = build_scalar_field_values(
            row,
            tracker_fields,
            skipped_columns,
            date_format=date_format,
        )

        log_date_fields(field_values, date_format)

        try:
            logger.info(
                "Trying update fields for item=%s using date_format=%s",
                item_id,
                date_format,
            )

            update_item_fields(cb, item_id, field_values)

            update_status_last(
                cb=cb,
                item_id=item_id,
                tracker_fields=tracker_fields,
                row=row,
                skipped_columns=skipped_columns,
            )

            return

        except Exception as ex:
            last_error = ex
            logger.warning(
                "Update fields failed for item=%s using date_format=%s: %s",
                item_id,
                date_format,
                ex,
            )

            if not is_date_parse_error(ex):
                raise

    logger.warning(
        "All update attempts with DateFieldValue failed for item=%s. Retrying without date fields.",
        item_id,
    )

    field_values = build_scalar_field_values(
        row,
        tracker_fields,
        skipped_columns,
        date_format="iso_z",
    )

    field_values_without_dates = remove_date_fields(
        field_values,
        skipped_columns,
        "Skipped because Codebeamer rejected all tested date formats during update",
    )

    try:
        update_item_fields(cb, item_id, field_values_without_dates)

        update_status_last(
            cb=cb,
            item_id=item_id,
            tracker_fields=tracker_fields,
            row=row,
            skipped_columns=skipped_columns,
        )

        return

    except Exception as ex:
        raise RuntimeError(
            f"Unable to update item {item_id}. Last date error={last_error}. "
            f"Retry without date fields also failed={ex}"
        )


# =========================================================
# SOURCE DATA
# =========================================================

def get_mysql_engine():
    url = URL.create(
        "mysql+pymysql",
        username=MYSQL_USER,
        password=MYSQL_PASS,
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        database=MYSQL_DB,
        query={"charset": "utf8mb4"},
    )

    return create_engine(url, pool_pre_ping=True)


def load_source_dataframe() -> pd.DataFrame:
    engine = get_mysql_engine()

    with engine.connect() as conn:
        df = pd.read_sql(text(SOURCE_SQL), conn)

    logger.info("Loaded %s source rows from MySQL table %s", len(df), TABLE_NAME)
    return df


def deduplicate_source_rows(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if SOURCE_KEY_COLUMN not in df.columns:
        raise RuntimeError(
            f"Source key column '{SOURCE_KEY_COLUMN}' not found. Columns={list(df.columns)}"
        )

    dup_mask = df.duplicated(subset=[SOURCE_KEY_COLUMN], keep="first")
    duplicates = df[dup_mask].copy()
    clean_df = df[~dup_mask].copy()

    if not duplicates.empty:
        duplicates.to_csv(DUPLICATE_SOURCE_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.warning("Duplicate source rows written: %s", DUPLICATE_SOURCE_ROWS_CSV)

    return clean_df, duplicates


# =========================================================
# MAIN PROCESS
# =========================================================

def validate_config() -> None:
    if not NEW_FUNCTION_TRACKER_ID or NEW_FUNCTION_TRACKER_ID == 0:
        raise RuntimeError("Please set NEW_FUNCTION_TRACKER_ID before running the script.")

    if not CB_BASE_URL.startswith("http"):
        raise RuntimeError("CB_BASE_URL is invalid.")

    if "/api" not in CB_BASE_URL:
        logger.warning(
            "CB_BASE_URL does not contain /api. Current value=%s",
            CB_BASE_URL,
        )


def process_rows(
    cb: CodebeamerClient,
    df: pd.DataFrame,
    tracker_fields: Dict[str, Dict[str, Any]],
    existing_cache: Dict[str, Dict[str, Any]],
):
    processed_rows = []
    failed_rows = []
    skipped_columns = []

    for idx, row in df.iterrows():
        source_id = clean_text(row.get(SOURCE_KEY_COLUMN))

        if not source_id:
            failed_rows.append({
                "row_index": idx,
                "reason": f"Missing {SOURCE_KEY_COLUMN}",
            })
            continue

        key = normalize_key(source_id)

        try:
            if key in existing_cache:
                item_id = existing_cache[key]["codebeamer_item_id"]

                logger.info(
                    "Updating existing New Function: source=%s cb_item=%s",
                    source_id,
                    item_id,
                )

                update_nf_item(cb, item_id, row, tracker_fields, skipped_columns)
                mode = "UPDATED_EXISTING"

            else:
                logger.info("Creating New Function: source=%s", source_id)

                item_id = create_nf_item(cb, row, tracker_fields, skipped_columns)

                existing_cache[key] = {
                    "codebeamer_item_id": item_id,
                    "sbm_nf_id": source_id,
                    "name": get_item_name(row),
                }

                mode = "CREATED"

            processed_rows.append({
                "source_sbm_nf_id": source_id,
                "codebeamer_item_id": item_id,
                "mode": mode,
                "name": get_item_name(row),
            })

        except Exception as ex:
            logger.exception("Failed row source=%s", source_id)

            failed_rows.append({
                "source_sbm_nf_id": source_id,
                "row_index": idx,
                "reason": str(ex),
            })

    return processed_rows, failed_rows, skipped_columns


def write_reports(
    processed_rows: List[Dict[str, Any]],
    failed_rows: List[Dict[str, Any]],
    skipped_columns: List[Dict[str, Any]],
    duplicate_existing_rows: List[Dict[str, Any]],
) -> None:

    if processed_rows:
        pd.DataFrame(processed_rows).to_csv(
            CREATED_UPDATED_CSV,
            index=False,
            encoding="utf-8-sig",
        )
        logger.info("Created/updated report written: %s", CREATED_UPDATED_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(
            FAILED_ROWS_CSV,
            index=False,
            encoding="utf-8-sig",
        )
        logger.warning("Failed rows report written: %s", FAILED_ROWS_CSV)

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates().to_csv(
            SKIPPED_COLUMNS_CSV,
            index=False,
            encoding="utf-8-sig",
        )
        logger.info("Skipped columns report written: %s", SKIPPED_COLUMNS_CSV)

    if duplicate_existing_rows:
        pd.DataFrame(duplicate_existing_rows).to_csv(
            DUPLICATE_EXISTING_CSV,
            index=False,
            encoding="utf-8-sig",
        )
        logger.warning("Duplicate existing report written: %s", DUPLICATE_EXISTING_CSV)


def main() -> None:
    validate_config()
    acquire_run_lock()

    try:
        df = load_source_dataframe()
        df, _dups = deduplicate_source_rows(df)

        cb = CodebeamerClient(
            CB_BASE_URL,
            CB_USER,
            CB_PASS,
            VERIFY_SSL,
            TIMEOUT,
        )

        tracker_fields = load_tracker_fields(cb, NEW_FUNCTION_TRACKER_ID)

        existing_cache, duplicate_existing_rows = scan_existing_nf_by_sbm_id(
            cb,
            NEW_FUNCTION_TRACKER_ID,
        )

        processed_rows, failed_rows, skipped_columns = process_rows(
            cb,
            df,
            tracker_fields,
            existing_cache,
        )

        write_reports(
            processed_rows,
            failed_rows,
            skipped_columns,
            duplicate_existing_rows,
        )

        logger.info(
            "Done. processed=%s failed=%s skipped=%s",
            len(processed_rows),
            len(failed_rows),
            len(skipped_columns),
        )

    finally:
        release_run_lock()


if __name__ == "__main__":
    main()