import re
import os
import json
import time
import logging
from collections import defaultdict

import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

# =========================================================
# CONFIGURATION
# =========================================================

# ---------- MySQL ----------
MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"   # replace if needed

NF_TABLE_NAME = "sbm_nf"
CR_TABLE_NAME = "sbm_cr"

NF_SOURCE_SQL = f"""
SELECT *
FROM {NF_TABLE_NAME}
-- WHERE `Item ID` = 'NF-AEMS-001'
-- LIMIT 20
"""

CR_SOURCE_SQL = f"""
SELECT *
FROM {CR_TABLE_NAME}
-- WHERE `Item ID` IN ('HCR004081','HCR005846','HCR006210')
-- LIMIT 20
"""

# ---------- Codebeamer ----------
CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"   # replace if needed
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 20

# ---------- Projects / Trackers ----------
NF_PROJECT_ID = 50
CR_PROJECT_ID = 48

NF_TRACKER_ID = 301069
NF_TRACKER_NAME = "New Function"

CR_TRACKER_ID = 293926
CR_TRACKER_NAME = "Change Request"

# ---------- Reused reference trackers ----------
FIRST_ENGINE_APPLICATION_TRACKER_ID = 295532
FIRST_ENGINE_APPLICATION_TRACKER_NAME = "First Engine Application"

FIRST_VEHICLE_APPLICATION_TRACKER_ID = 295575
FIRST_VEHICLE_APPLICATION_TRACKER_NAME = "First Vehicle Application"

HEMS_FUNCTION_TRACKER_ID = 295319
HEMS_FUNCTION_TRACKER_NAME = "H-EMS Function"

HEMS_SUB_FUNCTION_TRACKER_ID = 295486
HEMS_SUB_FUNCTION_TRACKER_NAME = "H-EMS Sub-Function"

# ---------- Placeholder reference items ----------
PLACEHOLDER_REFERENCE_ITEMS = {
    FIRST_ENGINE_APPLICATION_TRACKER_NAME: {
        "id": 146671,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    FIRST_VEHICLE_APPLICATION_TRACKER_NAME: {
        "id": 146673,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
    HEMS_FUNCTION_TRACKER_NAME: {
        "id": 146669,
        "name": "[PLACEHOLDER - DELETE LATER]"
    },
}

# ---------- Forced member/user defaults ----------
DEFAULT_USER_NAME = "cbadmin"
DEFAULT_USER_ID = 1
DEFAULT_USER_REFERENCE_TYPE = "UserReference"  # change to MemberReference if your API needs that

# ---------- Defaults / placeholders ----------
DEFAULT_SW_TYPE = "AEMS"
DEFAULT_TEXT_PLACEHOLDER = "-"
DEFAULT_SCOPE_FALLBACK = "--"          # Scope Of Change default
DEFAULT_PERIMETER_FALLBACK = "--"      # Perimeter default

# Delivery-specific shared logic
DELIVERY_SOURCE_DEFAULT = "--"         # business-side normalized missing/null marker
DELIVERY_CB_DEFAULT = "Unset"          # current CB-side valid default for delivery fields

DEFAULT_MINIMAL_CR_TITLE_PREFIX = "Imported minimal CR - "
DEFAULT_MINIMAL_NF_TITLE_PREFIX = "Imported minimal NF - "
DEFAULT_MINIMAL_NF_SOURCE_PREFIX = "NF-PLACEHOLDER-"

EXPECTED_DELIVERY_ALLOWED = {"Unset"} | {f"MD{i}" for i in range(1, 41)}

# ---------- File outputs ----------
NF_STATE_FILE_CSV = "codebeamer_nf_state.csv"
CR_STATE_FILE_CSV = "codebeamer_cr_state.csv"

NF_CREATED_MAP_CSV = "created_updated_nf.csv"
CR_CREATED_MAP_CSV = "created_updated_cr.csv"

NF_FAILED_ROWS_CSV = "failed_rows_nf.csv"
CR_FAILED_ROWS_CSV = "failed_rows_cr.csv"

NF_SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_nf.csv"
CR_SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_cr.csv"

LOG_FILE = "codebeamer_nf_cr_import.log"

UPSERT_MODE = "update_if_in_state_else_create"

SLEEP_BETWEEN_REQUESTS_SEC = 0.0

# =========================================================
# SOURCE COLUMN ALIASES
# =========================================================

NF_SOURCE_COLUMN_ALIASES = {
    "item_id": ["Item ID", "Item_Id", "ITEM_ID", "item_id"],
    "title": ["Title", "TITLE", "title"],
    "description": ["Description", "DESCRIPTION", "description"],
    "cr": ["CR", "Cr", "cr"],
}

CR_SOURCE_COLUMN_ALIASES = {
    "item_id": ["Item ID", "Item_Id", "ITEM_ID", "item_id"],
    "title": ["Title", "TITLE", "title"],
    "description": ["Description", "DESCRIPTION", "description"],
    "perimeter": ["Perimeter", "PERIMETER", "perimeter"],
    "program_line": ["Program Line", "Program_Line", "PROGRAM_LINE", "program_line"],
    "assigned_delivery": ["Assigned Delivery", "Assigned_Delivery", "ASSIGNED_DELIVERY", "assigned_delivery"],
    "expected_delivery": ["Expected Delivery", "Expected_Delivery", "EXPECTED_DELIVERY", "expected_delivery"],
    "archi_sw": ["Archi SW", "Archi_SW", "ARCHI_SW", "archi_sw"],
    "project": ["Project", "PROJECT", "project"],
    "first_engine_application": [
        "First engine application", "First_engine_application", "FIRST_ENGINE_APPLICATION", "first_engine_application"
    ],
    "first_vehicle_application": [
        "First vehicle application", "First_vehicle_application", "FIRST_VEHICLE_APPLICATION", "first_vehicle_application"
    ],
    "function_sub_function": [
        "Function & Sub Function",
        "Function & Sub_Function",
        "Function_and_Sub_Function",
        "Function_Sub_Function",
        "FUNCTION_SUB_FUNCTION",
        "function_sub_function",
    ],
    "sw_type": ["SW type", "SW_type", "SW_Type", "sw_type"],
    "change_purpose": ["Change Purpose", "Change_Purpose", "change_purpose"],
    "scope_of_change": ["Scope Of Change", "Scope_of_Change", "scope_of_change"],
    "software_target": ["Software Target", "Software_Target", "software_target"],
    "milestone_project_to_come": [
        "Milestone project to come", "Milestone_project_to_come", "milestone_project_to_come"
    ],
    "justification": ["Justification", "JUSTIFICATION", "justification"],
}

# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger = logging.getLogger("cb_nf_cr_sync")
    logger.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.INFO)

    logger.handlers.clear()
    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger

logger = setup_logging()

# =========================================================
# HELPERS
# =========================================================

def normalize_name(s):
    return re.sub(r"\s+", " ", str(s).strip()).lower()

def is_blank(v):
    if pd.isna(v):
        return True
    if v is None:
        return True
    if isinstance(v, str):
        s = v.strip()
        if s in ("", "(None)", "None", "nan", "NaN", "null", "NULL", ".", "- "):
            return True
    return False

def clean_text(v):
    if is_blank(v):
        return None
    s = str(v).replace("\r", "").replace("_x000D_", "").strip()
    return s if s else None

def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)

def split_csv_values(v):
    txt = clean_text(v)
    if not txt:
        return []
    parts = [p.strip() for p in str(txt).split(",")]
    cleaned = []
    seen = set()
    for p in parts:
        if is_blank(p):
            continue
        key = normalize_name(p)
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(p)
    return cleaned

def to_iso_datetime_string(v):
    if is_blank(v):
        return None
    dt = pd.to_datetime(v, errors="coerce")
    if pd.isna(dt):
        return None
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000")

def to_bool_or_none(v):
    if is_blank(v):
        return None
    s = str(v).strip().lower()
    if s in ("yes", "true", "1", "y"):
        return True
    if s in ("no", "false", "0", "n"):
        return False
    return None

def to_int_or_none(v):
    if is_blank(v):
        return None
    try:
        return int(float(v))
    except Exception:
        return None

def to_float_or_none(v):
    if is_blank(v):
        return None
    try:
        return float(v)
    except Exception:
        return None

def resolve_source_columns(df_columns, alias_map):
    resolved = {}
    norm_lookup = {normalize_name(c): c for c in df_columns}
    for logical_name, aliases in alias_map.items():
        actual = None
        for alias in aliases:
            found = norm_lookup.get(normalize_name(alias))
            if found:
                actual = found
                break
        resolved[logical_name] = actual
    return resolved

def get_row_value(row, actual_col):
    if not actual_col:
        return None
    return row.get(actual_col)

def first_non_null_sample(df, col):
    if not col or col not in df.columns:
        return None
    ser = df[col].dropna()
    if ser.empty:
        return None
    return clean_text(ser.iloc[0])

def get_placeholder_reference_for_tracker(tracker_name):
    ph = PLACEHOLDER_REFERENCE_ITEMS.get(tracker_name)
    if not ph:
        return None
    ph_id = ph.get("id")
    ph_name = ph.get("name")
    if ph_id is None or not ph_name:
        return None
    return {"id": int(ph_id), "name": str(ph_name)}

def normalize_scope_of_change_value(raw):
    """
    Actual tracker/API options:
      Unset, Fixes, Novelty, --
    Business rule:
      default to '--'
    """
    txt = clean_text(raw)
    if not txt:
        return DEFAULT_SCOPE_FALLBACK

    s = txt.strip().lower()

    if "fix" in s:
        return "Fixes"
    if "novel" in s:
        return "Novelty"

    if s in {"unset", "--", "-", "none", "null", "(none)"}:
        return DEFAULT_SCOPE_FALLBACK

    return DEFAULT_SCOPE_FALLBACK

def normalize_md_delivery_source_value(raw):
    """
    Shared source normalizer for:
      - Expected Delivery
      - Assigned Delivery

    Business rule:
      missing/null/blank/-- -> '--'

    Source may contain:
      MD1, MD01, MD02 ... MD40

    Returns either:
      '--' or 'MD1'..'MD40'
    """
    txt = clean_text(raw)
    if not txt:
        return DELIVERY_SOURCE_DEFAULT

    s = txt.strip().upper()

    if s in {"UNSET", "--", "-", "NONE", "NULL"}:
        return DELIVERY_SOURCE_DEFAULT

    m = re.fullmatch(r"MD0*([1-9]|[1-3][0-9]|40)", s)
    if m:
        num = int(m.group(1))
        return f"MD{num}"

    return DELIVERY_SOURCE_DEFAULT

def resolve_delivery_cb_value(raw):
    """
    Convert normalized delivery source value into the actual CB value.

    Example:
      '--' -> 'Unset'   (current tracker behavior)
      'MD02' -> 'MD2'
    """
    normalized = normalize_md_delivery_source_value(raw)

    if normalized == DELIVERY_SOURCE_DEFAULT:
        return DELIVERY_CB_DEFAULT

    return normalized

def normalize_perimeter_value(raw):
    """
    Actual tracker/API options:
      Unset, TV, GE, DE, --
    Business mapping required:
      TV / GE / DE / --
    Default:
      --
    """
    txt = clean_text(raw)
    if not txt:
        return DEFAULT_PERIMETER_FALLBACK

    s = txt.strip().upper()

    if s in {"TV", "GE", "DE"}:
        return s

    if s in {"--", "-", "UNSET", "NONE", "NULL"}:
        return DEFAULT_PERIMETER_FALLBACK

    return DEFAULT_PERIMETER_FALLBACK

def log_choice_field_options(tracker_fields, field_name):
    meta = tracker_fields.get(normalize_name(field_name))
    if not meta:
        logger.warning("Field '%s' not found in tracker metadata", field_name)
        return

    options = meta.get("options") or []
    option_names = [o.get("name") for o in options]

    logger.info(
        "Choice field options | field=%s | count=%s | options=%s",
        field_name, len(option_names), option_names
    )

# =========================================================
# LOCAL STATE
# =========================================================

def load_state(path, item_id_field_name):
    """
    Safe loader:
    - if file doesn't exist -> {}
    - if file exists but is 0 bytes -> {}
    - if file exists but is empty CSV -> {}
    - if header exists but no rows -> {}
    """
    state = {}

    if not os.path.exists(path):
        return state

    try:
        if os.path.getsize(path) == 0:
            logger.warning("State file exists but is empty (0 bytes): %s. Treating as empty state.", path)
            return state
    except OSError:
        return state

    try:
        df = pd.read_csv(path, dtype=str)
    except pd.errors.EmptyDataError:
        logger.warning("State file has no parsable CSV data: %s. Treating as empty state.", path)
        return state
    except Exception as ex:
        logger.warning("Unable to read state file %s (%s). Treating as empty state.", path, ex)
        return state

    if df.empty:
        return state

    if item_id_field_name not in df.columns:
        logger.warning(
            "State file %s does not contain expected column '%s'. Treating as empty state.",
            path, item_id_field_name
        )
        return state

    for _, row in df.iterrows():
        src = str(row.get(item_id_field_name, "")).strip().upper()
        if not src:
            continue

        refs = {}
        raw_refs = row.get("refs_json")
        if raw_refs and str(raw_refs).strip():
            try:
                parsed = json.loads(raw_refs)
                if isinstance(parsed, dict):
                    refs = parsed
            except Exception:
                refs = {}

        state[src] = {
            item_id_field_name: src,
            "codebeamer_item_id": row.get("codebeamer_item_id"),
            "title": row.get("title"),
            "status": row.get("status"),
            "refs_json": json.dumps(refs, ensure_ascii=False),
        }

    return state

def save_state(path, state, item_id_field_name):
    """
    Safe saver:
    - if state has rows -> write them
    - if state is empty -> still write header row so next read_csv won't fail
    """
    rows = []
    for _, value in state.items():
        row = dict(value)
        row[item_id_field_name] = row.get(item_id_field_name)
        rows.append(row)

    if rows:
        df = pd.DataFrame(rows)
    else:
        df = pd.DataFrame(columns=[
            item_id_field_name,
            "codebeamer_item_id",
            "title",
            "status",
            "refs_json"
        ])

    df.to_csv(path, index=False, encoding="utf-8-sig")

def get_refs_from_state_entry(entry):
    if not entry:
        return {}
    raw = entry.get("refs_json")
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    return {}

def update_state_entry(state, item_id_field_name, src_key, cb_id, title, status, refs=None):
    existing = state.get(src_key, {})
    current_refs = get_refs_from_state_entry(existing)

    if refs:
        for bucket, value_map in refs.items():
            if bucket not in current_refs:
                current_refs[bucket] = {}
            if isinstance(value_map, dict):
                for k, v in value_map.items():
                    if v is not None:
                        current_refs[bucket][str(k)] = str(v)

    state[src_key] = {
        item_id_field_name: src_key,
        "codebeamer_item_id": str(cb_id) if cb_id else existing.get("codebeamer_item_id"),
        "title": title or existing.get("title"),
        "status": status or existing.get("status"),
        "refs_json": json.dumps(current_refs, ensure_ascii=False),
    }

# =========================================================
# REFERENCE REUSE CACHE
# =========================================================

REFERENCE_ITEM_CACHE = {}

def make_reference_cache_key(tracker_id, source_value):
    return tracker_id, normalize_name(source_value)

def seed_reference_cache_from_cr_state(cr_state):
    seeded = 0
    for entry in cr_state.values():
        refs = get_refs_from_state_entry(entry)
        for bucket_name, value_map in refs.items():
            if not isinstance(value_map, dict):
                continue

            tracker_id = None
            if bucket_name == "first_engine_application_refs":
                tracker_id = FIRST_ENGINE_APPLICATION_TRACKER_ID
            elif bucket_name == "first_vehicle_application_refs":
                tracker_id = FIRST_VEHICLE_APPLICATION_TRACKER_ID
            elif bucket_name == "hems_function_refs":
                tracker_id = HEMS_FUNCTION_TRACKER_ID
            elif bucket_name == "hems_sub_function_refs":
                tracker_id = HEMS_SUB_FUNCTION_TRACKER_ID

            if not tracker_id:
                continue

            for source_value, item_id in value_map.items():
                if not source_value or not item_id:
                    continue
                try:
                    REFERENCE_ITEM_CACHE[make_reference_cache_key(tracker_id, source_value)] = int(item_id)
                    seeded += 1
                except Exception:
                    pass
    logger.info("Seeded reference reuse cache from CR state: %s entries", seeded)

# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url, username, password, verify_ssl=True, timeout=60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Content-Type": "application/json"})

        retry = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path):
        return f"{self.base_url}{path}"

    def get(self, path, params=None):
        safe_sleep()
        r = self.session.get(self._url(path), params=params, timeout=self.timeout)
        self._raise_for_status(r)
        return r.json()

    def post(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.post(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def put(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.put(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    @staticmethod
    def _raise_for_status(r):
        try:
            r.raise_for_status()
        except requests.HTTPError:
            raise RuntimeError(f"HTTP {r.status_code} | URL={r.url} | Response={r.text}")

# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb, tracker_id):
    refs = cb.get(f"/v3/trackers/{tracker_id}/fields")
    field_map = {}
    for ref in refs:
        fid = ref["id"]
        detail = cb.get(f"/v3/trackers/{tracker_id}/fields/{fid}")
        field_map[normalize_name(detail["name"])] = detail
    return field_map

def validate_existing_item_in_tracker(cb, item_id, expected_tracker_id):
    try:
        item = cb.get(f"/v3/items/{item_id}")
    except Exception as ex:
        return False, f"Item {item_id} not accessible: {ex}"

    tracker = item.get("tracker") or {}
    tracker_id = tracker.get("id")

    if str(tracker_id) != str(expected_tracker_id):
        return False, f"Item {item_id} belongs to tracker {tracker_id}, expected {expected_tracker_id}"

    return True, "OK"

# =========================================================
# FIELD VALUE BUILDERS
# =========================================================

def build_field_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None

    field_id = field_meta["id"]
    field_name = field_meta["name"]
    value_model = field_meta.get("valueModel")

    if value_model == "TextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "TextFieldValue",
            "value": txt
        }

    if value_model == "WikiTextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "WikiTextFieldValue",
            "value": txt
        }

    if value_model == "DateFieldValue":
        dt = to_iso_datetime_string(raw_value)
        if not dt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DateFieldValue",
            "value": dt
        }

    if value_model == "IntegerFieldValue":
        iv = to_int_or_none(raw_value)
        if iv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "IntegerFieldValue",
            "value": iv
        }

    if value_model == "DecimalFieldValue":
        dv = to_float_or_none(raw_value)
        if dv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DecimalFieldValue",
            "value": dv
        }

    if value_model == "BoolFieldValue":
        bv = to_bool_or_none(raw_value)
        if bv is None:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "BoolFieldValue",
            "value": bv
        }

    return None

def build_choice_field_value(field_meta, raw_value, preferred_fallbacks=None, use_first_option_if_needed=False):
    """
    Priority:
      1) source raw_value
      2) preferred_fallbacks in order
      3) first available option (if enabled)
    """
    options = field_meta.get("options") or []
    if not options:
        return None, f"Field '{field_meta.get('name')}' has no options metadata exposed by API"

    candidates = []
    src_txt = clean_text(raw_value)
    if src_txt:
        candidates.append(src_txt)

    for x in (preferred_fallbacks or []):
        xx = clean_text(x)
        if xx and normalize_name(xx) not in {normalize_name(c) for c in candidates}:
            candidates.append(xx)

    matched = None
    for candidate in candidates:
        for opt in options:
            opt_name = opt.get("name")
            if normalize_name(opt_name) == normalize_name(candidate):
                matched = opt
                break
        if matched:
            break

    if not matched and use_first_option_if_needed and options:
        matched = options[0]

    if not matched:
        available = [o.get("name") for o in options]
        return None, (
            f"Choice unresolved for field '{field_meta.get('name')}'. "
            f"Candidates={candidates}. Available={available}"
        )

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": matched["id"],
            "name": matched.get("name"),
            "type": matched.get("type", "ChoiceOptionReference")
        }]
    }, None

def build_member_field_value(field_meta, member_id, member_name):
    if not member_id or not member_name:
        return None, f"Member value missing for field '{field_meta.get('name')}'"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": int(member_id),
            "name": str(member_name),
            "type": DEFAULT_USER_REFERENCE_TYPE
        }]
    }, None

def build_tracker_item_reference_field_value(field_meta, tracker_item_refs):
    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": tracker_item_refs
    }

def build_reference_values_list(child_ids_and_names):
    values = []
    seen = set()
    for child_id, child_name in child_ids_and_names:
        key = str(child_id)
        if key in seen:
            continue
        seen.add(key)
        values.append({
            "id": int(child_id),
            "name": str(child_name),
            "type": "TrackerItemReference"
        })
    return values

# =========================================================
# GENERIC ITEM UPDATE
# =========================================================

def update_item_fields(cb, item_id, field_values):
    if not field_values:
        return
    payload = {"fieldValues": field_values}
    cb.put(f"/v3/items/{item_id}/fields", payload)

# =========================================================
# REFERENCE ITEM CREATION / REUSE
# =========================================================

def build_reference_item_payload(tracker_name, source_value, parent_title=None, source_item_id=None):
    description_lines = []
    if source_item_id:
        description_lines.append(f"Source Item Id: {source_item_id}")
    if parent_title:
        description_lines.append(f"Parent/Origin Title: {parent_title}")
    if source_value:
        description_lines.append("")
        description_lines.append("Imported Reference Value:")
        description_lines.append(source_value)

    description_text = "\n".join(description_lines).strip() if description_lines else None

    payload = {
        "name": source_value,
        "descriptionFormat": "PlainText",
        "description": description_text or f"Imported reference item: {source_value}"
    }

    return {k: v for k, v in payload.items() if v is not None}

def create_reference_tracker_item(cb, tracker_id, tracker_name, source_value, parent_title=None, source_item_id=None):
    payload = build_reference_item_payload(
        tracker_name=tracker_name,
        source_value=source_value,
        parent_title=parent_title,
        source_item_id=source_item_id
    )
    created = cb.post(f"/v3/trackers/{tracker_id}/items", payload)
    return created["id"], created

def get_or_create_reference_tracker_item(cb, tracker_id, tracker_name, source_value, parent_title=None, source_item_id=None):
    key = make_reference_cache_key(tracker_id, source_value)
    cached_id = REFERENCE_ITEM_CACHE.get(key)
    if cached_id:
        return cached_id, {"id": cached_id}, False

    child_id, created = create_reference_tracker_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        source_value=source_value,
        parent_title=parent_title,
        source_item_id=source_item_id
    )
    REFERENCE_ITEM_CACHE[key] = child_id
    return child_id, created, True

def get_or_placeholder_reference(cb, tracker_id, tracker_name, source_value, parent_title=None, source_item_id=None, use_placeholder_if_blank=False):
    if is_blank(source_value):
        if use_placeholder_if_blank:
            ph = get_placeholder_reference_for_tracker(tracker_name)
            if ph:
                return ph["id"], ph["name"], False
        return None, None, False

    child_id, created, was_created = get_or_create_reference_tracker_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        source_value=clean_text(source_value),
        parent_title=parent_title,
        source_item_id=source_item_id
    )
    child_name = clean_text(source_value)
    return child_id, child_name, was_created

# =========================================================
# NF HELPERS
# =========================================================

def get_nf_effective_title(row, nf_source_cols):
    return clean_text(get_row_value(row, nf_source_cols["title"])) or "Imported New Function"

def get_nf_effective_description(row, nf_source_cols):
    return clean_text(get_row_value(row, nf_source_cols["description"])) or DEFAULT_TEXT_PLACEHOLDER

def get_nf_source_id(row, nf_source_cols):
    return clean_text(get_row_value(row, nf_source_cols["item_id"]))

def build_nf_create_custom_fields(nf_tracker_fields, nf_title, nf_desc):
    values = []

    field_meta = nf_tracker_fields.get(normalize_name("New Function"))
    if field_meta:
        fv = build_field_value(field_meta, nf_title)
        if fv:
            values.append(fv)

    desc_meta = nf_tracker_fields.get(normalize_name("Description"))
    if desc_meta:
        fv = build_field_value(desc_meta, nf_desc)
        if fv:
            values.append(fv)

    return values

def create_nf_item(cb, row, nf_source_cols, nf_tracker_fields):
    nf_title = get_nf_effective_title(row, nf_source_cols)
    nf_desc_raw = get_nf_effective_description(row, nf_source_cols)

    src_id = get_nf_source_id(row, nf_source_cols)
    desc_lines = []
    if src_id:
        desc_lines.append(f"Source Item Id: {src_id}")
        desc_lines.append("")
    if nf_desc_raw:
        desc_lines.append(nf_desc_raw)

    payload = {
        "name": nf_title,
        "descriptionFormat": "PlainText",
        "description": "\n".join(desc_lines).strip() if desc_lines else nf_desc_raw
    }

    custom_fields = build_nf_create_custom_fields(nf_tracker_fields, nf_title, nf_desc_raw)
    if custom_fields:
        payload["customFields"] = custom_fields

    created = cb.post(f"/v3/trackers/{NF_TRACKER_ID}/items", payload)
    return created["id"], created

def update_nf_item(cb, item_id, row, nf_source_cols, nf_tracker_fields):
    """
    Safe rerun update:
    - Do NOT PUT /v3/items/{id} because that can trigger workflow/state issues
    - Only update tracker field values via /fields
    """
    nf_title = get_nf_effective_title(row, nf_source_cols)
    nf_desc_raw = get_nf_effective_description(row, nf_source_cols)

    custom_fields = build_nf_create_custom_fields(nf_tracker_fields, nf_title, nf_desc_raw)
    if custom_fields:
        update_item_fields(cb, item_id, custom_fields)

def create_minimal_nf_placeholder(cb, cr_code, nf_state, nf_tracker_fields):
    """
    Create or reuse a minimal NF placeholder for a CR that has no linked NF.
    Returns: (nf_cb_id, nf_title, nf_source_key)
    """
    nf_source_id = f"{DEFAULT_MINIMAL_NF_SOURCE_PREFIX}{cr_code}"
    nf_source_key = nf_source_id.upper()
    nf_title = f"{DEFAULT_MINIMAL_NF_TITLE_PREFIX}{cr_code}"
    nf_description = (
        f"Minimal NF placeholder created because CR '{cr_code}' requires mandatory "
        f"'New Function' reference but no matching NF row was found in sbm_nf."
    )

    existing = nf_state.get(nf_source_key)
    if existing and existing.get("codebeamer_item_id"):
        try:
            candidate_id = int(existing["codebeamer_item_id"])
            is_valid, _ = validate_existing_item_in_tracker(cb, candidate_id, NF_TRACKER_ID)
            if is_valid:
                return candidate_id, nf_title, nf_source_key
        except Exception:
            pass

    payload = {
        "name": nf_title,
        "descriptionFormat": "PlainText",
        "description": f"Source Item Id: {nf_source_id}\n\n{nf_description}"
    }

    custom_fields = []

    nf_name_meta = nf_tracker_fields.get(normalize_name("New Function"))
    if nf_name_meta:
        fv = build_field_value(nf_name_meta, nf_title)
        if fv:
            custom_fields.append(fv)

    nf_desc_meta = nf_tracker_fields.get(normalize_name("Description"))
    if nf_desc_meta:
        fv = build_field_value(nf_desc_meta, nf_description)
        if fv:
            custom_fields.append(fv)

    if custom_fields:
        payload["customFields"] = custom_fields

    created = cb.post(f"/v3/trackers/{NF_TRACKER_ID}/items", payload)
    nf_cb_id = created["id"]

    update_state_entry(
        state=nf_state,
        item_id_field_name="source_nf_item_id",
        src_key=nf_source_key,
        cb_id=nf_cb_id,
        title=nf_title,
        status="CREATED_MINIMAL_NF_PLACEHOLDER",
        refs=None
    )

    logger.info(
        "Created minimal NF placeholder for CR=%s -> nf_source_id=%s -> nf_cb_id=%s",
        cr_code, nf_source_id, nf_cb_id
    )

    return nf_cb_id, nf_title, nf_source_key

# =========================================================
# CR HELPERS
# =========================================================

def get_cr_source_id(row, cr_source_cols):
    return clean_text(get_row_value(row, cr_source_cols["item_id"]))

def get_cr_title_from_row(row, cr_source_cols, is_minimal=False):
    source_id = get_cr_source_id(row, cr_source_cols)
    src_title = clean_text(get_row_value(row, cr_source_cols["title"]))
    if is_minimal:
        return f"{DEFAULT_MINIMAL_CR_TITLE_PREFIX}{source_id}" if source_id else "Imported minimal CR"
    return src_title or source_id or "Imported Change Request"

def get_cr_description_from_row(row, cr_source_cols, is_minimal=False):
    source_id = get_cr_source_id(row, cr_source_cols)
    src_desc = clean_text(get_row_value(row, cr_source_cols["description"]))

    if is_minimal:
        lines = []
        if source_id:
            lines.append(f"Missing CR code: {source_id}")
        lines.append("Minimal CR created because NF references this CR code but it was not found in sbm_cr.")
        return "\n".join(lines).strip()

    lines = []
    if source_id:
        lines.append(f"Source Item Id: {source_id}")
        lines.append("")
    if src_desc:
        lines.append(src_desc)
    return "\n".join(lines).strip() if lines else DEFAULT_TEXT_PLACEHOLDER

def get_cr_text_source_or_placeholder(row, cr_source_cols, logical_key):
    actual = cr_source_cols.get(logical_key)
    raw = get_row_value(row, actual)
    if is_blank(raw):
        return DEFAULT_TEXT_PLACEHOLDER
    return raw

def get_cr_sw_type_value(row, cr_source_cols):
    actual = cr_source_cols.get("sw_type")
    raw = get_row_value(row, actual)
    if is_blank(raw):
        return DEFAULT_SW_TYPE
    return raw

def build_cr_to_nf_reverse_map(nf_df, nf_source_cols, nf_state):
    reverse_map = defaultdict(list)
    for _, row in nf_df.iterrows():
        src_id = get_nf_source_id(row, nf_source_cols)
        if not src_id:
            continue
        st = nf_state.get(src_id.upper(), {})
        nf_cb_id = st.get("codebeamer_item_id")
        if not nf_cb_id:
            continue

        nf_title = get_nf_effective_title(row, nf_source_cols)
        cr_values = split_csv_values(get_row_value(row, nf_source_cols["cr"]))
        for cr_code in cr_values:
            reverse_map[normalize_name(cr_code)].append((int(nf_cb_id), nf_title))
    return reverse_map

def synthesize_missing_cr_rows(cr_df, cr_source_cols, referenced_cr_codes):
    """
    Add minimal CR rows for any code referenced by NF but missing from the CR source table.
    """
    existing_codes = set()
    actual_item_id_col = cr_source_cols["item_id"]
    actual_title_col = cr_source_cols["title"] or "Title"
    actual_desc_col = cr_source_cols["description"] or "Description"

    if actual_item_id_col and actual_item_id_col in cr_df.columns:
        for v in cr_df[actual_item_id_col].tolist():
            txt = clean_text(v)
            if txt:
                existing_codes.add(normalize_name(txt))

    missing_codes = []
    for cr_code in referenced_cr_codes:
        if normalize_name(cr_code) not in existing_codes:
            missing_codes.append(cr_code)

    if not missing_codes:
        return cr_df

    if "__minimal__" not in cr_df.columns:
        cr_df = cr_df.copy()
        cr_df["__minimal__"] = False

    synthetic_rows = []
    for cr_code in sorted(set(missing_codes), key=lambda x: normalize_name(x)):
        row = {c: None for c in cr_df.columns}
        if actual_item_id_col:
            row[actual_item_id_col] = cr_code
        row[actual_title_col] = f"{DEFAULT_MINIMAL_CR_TITLE_PREFIX}{cr_code}"
        row[actual_desc_col] = f"Minimal CR created because NF references missing CR code {cr_code}."
        row["__minimal__"] = True
        synthetic_rows.append(row)

    synth_df = pd.DataFrame(synthetic_rows)
    for col in cr_df.columns:
        if col not in synth_df.columns:
            synth_df[col] = None
    synth_df = synth_df[cr_df.columns]
    out_df = pd.concat([cr_df, synth_df], ignore_index=True)
    return out_df

def build_cr_reference_targets_for_create(cb, row, cr_source_cols, cr_title):
    """
    Build mandatory / reference targets BEFORE CR create/update.
    """
    out = {
        "first_engine_application_refs": [],
        "first_vehicle_application_refs": [],
        "function_refs": [],
        "state_refs": {
            "first_engine_application_refs": {},
            "first_vehicle_application_refs": {},
            "hems_function_refs": {},
            "hems_sub_function_refs": {},
        }
    }

    source_item_id = get_cr_source_id(row, cr_source_cols)

    # First engine application -> placeholder if missing
    fea_raw = get_row_value(row, cr_source_cols.get("first_engine_application"))
    fea_id, fea_name, _ = get_or_placeholder_reference(
        cb=cb,
        tracker_id=FIRST_ENGINE_APPLICATION_TRACKER_ID,
        tracker_name=FIRST_ENGINE_APPLICATION_TRACKER_NAME,
        source_value=fea_raw,
        parent_title=cr_title,
        source_item_id=source_item_id,
        use_placeholder_if_blank=True
    )
    if fea_id and fea_name:
        out["first_engine_application_refs"].append((fea_id, fea_name))
        out["state_refs"]["first_engine_application_refs"][clean_text(fea_raw) or fea_name] = fea_id

    # First vehicle application -> placeholder if missing
    fva_raw = get_row_value(row, cr_source_cols.get("first_vehicle_application"))
    fva_id, fva_name, _ = get_or_placeholder_reference(
        cb=cb,
        tracker_id=FIRST_VEHICLE_APPLICATION_TRACKER_ID,
        tracker_name=FIRST_VEHICLE_APPLICATION_TRACKER_NAME,
        source_value=fva_raw,
        parent_title=cr_title,
        source_item_id=source_item_id,
        use_placeholder_if_blank=True
    )
    if fva_id and fva_name:
        out["first_vehicle_application_refs"].append((fva_id, fva_name))
        out["state_refs"]["first_vehicle_application_refs"][clean_text(fva_raw) or fva_name] = fva_id

    # Function & Sub Function -> same CR field "Function"
    fsf_raw = get_row_value(row, cr_source_cols.get("function_sub_function"))
    fsf_values = split_csv_values(fsf_raw)

    for token in fsf_values:
        if "_" in token:
            child_id, child_obj, _ = get_or_create_reference_tracker_item(
                cb=cb,
                tracker_id=HEMS_SUB_FUNCTION_TRACKER_ID,
                tracker_name=HEMS_SUB_FUNCTION_TRACKER_NAME,
                source_value=token,
                parent_title=cr_title,
                source_item_id=source_item_id
            )
            out["function_refs"].append((child_id, token))
            out["state_refs"]["hems_sub_function_refs"][token] = child_id
        else:
            child_id, child_obj, _ = get_or_create_reference_tracker_item(
                cb=cb,
                tracker_id=HEMS_FUNCTION_TRACKER_ID,
                tracker_name=HEMS_FUNCTION_TRACKER_NAME,
                source_value=token,
                parent_title=cr_title,
                source_item_id=source_item_id
            )
            out["function_refs"].append((child_id, token))
            out["state_refs"]["hems_function_refs"][token] = child_id

    return out

def build_cr_field_values(row, cr_source_cols, cr_tracker_fields, nf_refs_for_this_cr, cr_reference_targets):
    values = []
    warnings = []

    # Title
    title_meta = cr_tracker_fields.get(normalize_name("Title"))
    if title_meta:
        cr_title = get_cr_title_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))
        fv = build_field_value(title_meta, cr_title)
        if fv:
            values.append(fv)

    # Description
    desc_meta = cr_tracker_fields.get(normalize_name("Description"))
    if desc_meta:
        cr_desc = get_cr_description_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))
        fv = build_field_value(desc_meta, cr_desc)
        if fv:
            values.append(fv)

    # SW type
    sw_meta = cr_tracker_fields.get(normalize_name("SW type"))
    if sw_meta:
        fv, err = build_choice_field_value(
            sw_meta,
            get_cr_sw_type_value(row, cr_source_cols),
            preferred_fallbacks=[DEFAULT_SW_TYPE],
            use_first_option_if_needed=False
        )
        if fv:
            values.append(fv)
        else:
            warnings.append(f"SW type: {err}")

    # Change Purpose
    cp_meta = cr_tracker_fields.get(normalize_name("Change Purpose"))
    if cp_meta:
        fv = build_field_value(cp_meta, get_cr_text_source_or_placeholder(row, cr_source_cols, "change_purpose"))
        if fv:
            values.append(fv)

    # Scope Of Change
    soc_meta = cr_tracker_fields.get(normalize_name("Scope Of Change"))
    if soc_meta:
        normalized_soc = normalize_scope_of_change_value(
            get_row_value(row, cr_source_cols.get("scope_of_change"))
        )
        fv, err = build_choice_field_value(
            soc_meta,
            normalized_soc,
            preferred_fallbacks=[DEFAULT_SCOPE_FALLBACK],
            use_first_option_if_needed=False
        )
        if fv:
            values.append(fv)
        else:
            warnings.append(f"Scope Of Change: {err}")

    # CR Pilot forced cbadmin
    pilot_meta = cr_tracker_fields.get(normalize_name("CR Pilot"))
    if pilot_meta:
        fv, err = build_member_field_value(pilot_meta, DEFAULT_USER_ID, DEFAULT_USER_NAME)
        if fv:
            values.append(fv)
        else:
            warnings.append(f"CR Pilot: {err}")

    # Archi SW forced cbadmin
    archi_meta = cr_tracker_fields.get(normalize_name("Archi SW"))
    if archi_meta:
        fv, err = build_member_field_value(archi_meta, DEFAULT_USER_ID, DEFAULT_USER_NAME)
        if fv:
            values.append(fv)
        else:
            warnings.append(f"Archi SW: {err}")

    # Expected Delivery (shared delivery logic)
    expected_meta = cr_tracker_fields.get(normalize_name("Expected Delivery"))
    if expected_meta:
        cb_expected_value = resolve_delivery_cb_value(
            get_row_value(row, cr_source_cols.get("expected_delivery"))
        )
        fv, err = build_choice_field_value(
            expected_meta,
            cb_expected_value,
            preferred_fallbacks=[DELIVERY_CB_DEFAULT],
            use_first_option_if_needed=False
        )
        if fv:
            values.append(fv)
        else:
            warnings.append(f"Expected Delivery: {err}")

    # Perimeter
    perimeter_meta = cr_tracker_fields.get(normalize_name("Perimeter"))
    if perimeter_meta:
        normalized_perimeter = normalize_perimeter_value(
            get_row_value(row, cr_source_cols.get("perimeter"))
        )
        fv, err = build_choice_field_value(
            perimeter_meta,
            normalized_perimeter,
            preferred_fallbacks=[DEFAULT_PERIMETER_FALLBACK],
            use_first_option_if_needed=False
        )
        if fv:
            values.append(fv)
        else:
            warnings.append(f"Perimeter: {err}")

    # Program Line
    program_meta = cr_tracker_fields.get(normalize_name("Program Line"))
    if program_meta:
        fv = build_field_value(program_meta, get_cr_text_source_or_placeholder(row, cr_source_cols, "program_line"))
        if fv:
            values.append(fv)

    # Software Target
    soft_tgt_meta = cr_tracker_fields.get(normalize_name("Software Target"))
    if soft_tgt_meta:
        fv = build_field_value(soft_tgt_meta, get_cr_text_source_or_placeholder(row, cr_source_cols, "software_target"))
        if fv:
            values.append(fv)

    # Milestone project to come
    milestone_meta = cr_tracker_fields.get(normalize_name("Milestone project to come"))
    if milestone_meta:
        fv = build_field_value(
            milestone_meta,
            get_cr_text_source_or_placeholder(row, cr_source_cols, "milestone_project_to_come")
        )
        if fv:
            values.append(fv)

    # Justification
    just_meta = cr_tracker_fields.get(normalize_name("Justification"))
    if just_meta:
        fv = build_field_value(just_meta, get_cr_text_source_or_placeholder(row, cr_source_cols, "justification"))
        if fv:
            values.append(fv)

    # Assigned Delivery (shared delivery logic)
    assigned_meta = cr_tracker_fields.get(normalize_name("Assigned Delivery"))
    if assigned_meta:
        cb_assigned_value = resolve_delivery_cb_value(
            get_row_value(row, cr_source_cols.get("assigned_delivery"))
        )
        fv, err = build_choice_field_value(
            assigned_meta,
            cb_assigned_value,
            preferred_fallbacks=[DELIVERY_CB_DEFAULT],
            use_first_option_if_needed=False
        )
        if fv:
            values.append(fv)
        else:
            warnings.append(f"Assigned Delivery: {err}")

    # Mandatory New Function reference
    new_func_meta = cr_tracker_fields.get(normalize_name("New Function"))
    if new_func_meta and nf_refs_for_this_cr:
        fv = build_tracker_item_reference_field_value(
            new_func_meta,
            build_reference_values_list(nf_refs_for_this_cr)
        )
        values.append(fv)

    # Mandatory First engine application reference
    fea_meta = cr_tracker_fields.get(normalize_name("First engine application"))
    if fea_meta and cr_reference_targets["first_engine_application_refs"]:
        fv = build_tracker_item_reference_field_value(
            fea_meta,
            build_reference_values_list(cr_reference_targets["first_engine_application_refs"])
        )
        values.append(fv)

    # Mandatory First vehicle application reference
    fva_meta = cr_tracker_fields.get(normalize_name("First vehicle application"))
    if fva_meta and cr_reference_targets["first_vehicle_application_refs"]:
        fv = build_tracker_item_reference_field_value(
            fva_meta,
            build_reference_values_list(cr_reference_targets["first_vehicle_application_refs"])
        )
        values.append(fv)

    # Optional but useful to set at create/update: Function
    function_meta = cr_tracker_fields.get(normalize_name("Function"))
    if function_meta and cr_reference_targets["function_refs"]:
        fv = build_tracker_item_reference_field_value(
            function_meta,
            build_reference_values_list(cr_reference_targets["function_refs"])
        )
        values.append(fv)

    return values, warnings

def create_cr_item(cb, row, cr_source_cols, cr_tracker_fields, nf_refs_for_this_cr):
    cr_title = get_cr_title_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))
    cr_desc = get_cr_description_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))

    cr_reference_targets = build_cr_reference_targets_for_create(
        cb=cb,
        row=row,
        cr_source_cols=cr_source_cols,
        cr_title=cr_title
    )

    payload = {
        "name": cr_title,
        "descriptionFormat": "PlainText",
        "description": cr_desc
    }

    custom_fields, warnings = build_cr_field_values(
        row=row,
        cr_source_cols=cr_source_cols,
        cr_tracker_fields=cr_tracker_fields,
        nf_refs_for_this_cr=nf_refs_for_this_cr,
        cr_reference_targets=cr_reference_targets
    )

    included_names = {normalize_name(x.get("name")) for x in custom_fields if x.get("name")}
    required = {
        normalize_name("Scope Of Change"),
        normalize_name("Expected Delivery"),
        normalize_name("First engine application"),
        normalize_name("First vehicle application"),
        normalize_name("New Function"),
    }
    missing_required = [x for x in required if x not in included_names]
    if missing_required:
        raise RuntimeError(f"CR create payload missing mandatory fields before POST: {missing_required}")

    for w in warnings:
        logger.warning("CR create warning: %s | source_cr=%s", w, get_cr_source_id(row, cr_source_cols))

    if custom_fields:
        payload["customFields"] = custom_fields

    created = cb.post(f"/v3/trackers/{CR_TRACKER_ID}/items", payload)
    return created["id"], created, cr_reference_targets

def update_cr_item(cb, item_id, row, cr_source_cols, cr_tracker_fields, nf_refs_for_this_cr):
    """
    Safe rerun update:
    - Do NOT PUT /v3/items/{id}
    - Only update CR tracker fields via /fields
    """
    cr_title = get_cr_title_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))

    cr_reference_targets = build_cr_reference_targets_for_create(
        cb=cb,
        row=row,
        cr_source_cols=cr_source_cols,
        cr_title=cr_title
    )

    custom_fields, warnings = build_cr_field_values(
        row=row,
        cr_source_cols=cr_source_cols,
        cr_tracker_fields=cr_tracker_fields,
        nf_refs_for_this_cr=nf_refs_for_this_cr,
        cr_reference_targets=cr_reference_targets
    )

    for w in warnings:
        logger.warning("CR update warning: %s | source_cr=%s", w, get_cr_source_id(row, cr_source_cols))

    if custom_fields:
        update_item_fields(cb, item_id, custom_fields)

    return cr_reference_targets

# =========================================================
# SKIPPED COLUMN REPORT HELPERS
# =========================================================

def build_nf_skipped_columns_report(nf_df, nf_source_cols):
    skipped = []
    used_actuals = set(filter(None, nf_source_cols.values()))
    for col in nf_df.columns:
        if col in used_actuals:
            continue
        skipped.append({
            "source_column": col,
            "reason": "Not mapped for current NF migration scope",
            "sample_value": first_non_null_sample(nf_df, col)
        })
    return skipped

def build_cr_skipped_columns_report(cr_df, cr_source_cols):
    skipped = []
    used_actuals = set(filter(None, cr_source_cols.values()))

    for logical_key in (
        "sw_type", "change_purpose", "scope_of_change", "software_target",
        "milestone_project_to_come", "justification", "first_vehicle_application"
    ):
        actual = cr_source_cols.get(logical_key)
        if actual:
            used_actuals.add(actual)

    for col in cr_df.columns:
        if col == "__minimal__":
            continue
        if col in used_actuals:
            continue

        if normalize_name(col) == normalize_name(cr_source_cols.get("project") or "Project"):
            skipped.append({
                "source_column": col,
                "reason": "Explicitly skipped as per requirement",
                "sample_value": first_non_null_sample(cr_df, col)
            })
            continue

        skipped.append({
            "source_column": col,
            "reason": "Not mapped for current CR migration scope",
            "sample_value": first_non_null_sample(cr_df, col)
        })
    return skipped

# =========================================================
# PASSES
# =========================================================

def pass1_create_or_update_nf(cb, nf_df, nf_state, nf_source_cols, nf_tracker_fields, failed_rows):
    logger.info("PASS 1: create/update New Function items")

    for idx, row in nf_df.iterrows():
        src_id = get_nf_source_id(row, nf_source_cols)
        src_key = src_id.upper() if src_id else None
        title = get_nf_effective_title(row, nf_source_cols)

        try:
            existing = nf_state.get(src_key) if src_key else None
            nf_cb_id = None
            result_mode = None

            existing_id = existing.get("codebeamer_item_id") if existing else None

            if UPSERT_MODE == "update_if_in_state_else_create" and existing_id:
                candidate_id = int(existing_id)
                is_valid, reason = validate_existing_item_in_tracker(cb, candidate_id, NF_TRACKER_ID)
                if is_valid:
                    nf_cb_id = candidate_id
                    update_nf_item(cb, nf_cb_id, row, nf_source_cols, nf_tracker_fields)
                    result_mode = "UPDATED_EXISTING_NF_FROM_STATE"
                else:
                    logger.warning(
                        "Ignoring stale/invalid NF state for source=%s, saved nf_cb_id=%s. Reason: %s",
                        src_id, candidate_id, reason
                    )
                    nf_cb_id, _ = create_nf_item(cb, row, nf_source_cols, nf_tracker_fields)
                    result_mode = "CREATED_NF_REPLACED_INVALID_STATE"
            else:
                nf_cb_id, _ = create_nf_item(cb, row, nf_source_cols, nf_tracker_fields)
                result_mode = "CREATED_NF"

            if src_key and nf_cb_id:
                update_state_entry(
                    state=nf_state,
                    item_id_field_name="source_nf_item_id",
                    src_key=src_key,
                    cb_id=nf_cb_id,
                    title=title,
                    status=result_mode,
                    refs=None
                )

            logger.info("NF pass result: source=%s -> nf_cb_id=%s | %s", src_id, nf_cb_id, result_mode)

        except Exception as ex:
            logger.exception("PASS 1 failed for NF source=%s", src_id)
            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "PASS_1_NF_CREATE_UPDATE",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(NF_STATE_FILE_CSV, nf_state, "source_nf_item_id")

    save_state(NF_STATE_FILE_CSV, nf_state, "source_nf_item_id")

def pass2_create_or_update_cr(
    cb,
    cr_df_all,
    cr_state,
    cr_source_cols,
    cr_tracker_fields,
    reverse_cr_to_nf_map,
    nf_state,
    nf_tracker_fields,
    failed_rows
):
    logger.info("PASS 2: create/update Change Request items")

    for idx, row in cr_df_all.iterrows():
        src_id = get_cr_source_id(row, cr_source_cols)
        src_key = src_id.upper() if src_id else None
        title = get_cr_title_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__")))

        try:
            linked_nfs = reverse_cr_to_nf_map.get(normalize_name(src_id), [])

            # If no NF is linked from source, create a minimal NF placeholder
            # because CR field "New Function" is mandatory.
            if not linked_nfs:
                nf_cb_id, nf_title, nf_source_key = create_minimal_nf_placeholder(
                    cb=cb,
                    cr_code=src_id,
                    nf_state=nf_state,
                    nf_tracker_fields=nf_tracker_fields
                )
                linked_nfs = [(int(nf_cb_id), nf_title)]
                reverse_cr_to_nf_map[normalize_name(src_id)] = linked_nfs

                logger.warning(
                    "CR source=%s had no NF mapping from sbm_nf, so minimal NF placeholder was created: %s -> %s",
                    src_id, nf_source_key, nf_cb_id
                )

            existing = cr_state.get(src_key) if src_key else None
            cr_cb_id = None
            result_mode = None
            cr_reference_targets = None

            existing_id = existing.get("codebeamer_item_id") if existing else None

            if UPSERT_MODE == "update_if_in_state_else_create" and existing_id:
                candidate_id = int(existing_id)
                is_valid, reason = validate_existing_item_in_tracker(cb, candidate_id, CR_TRACKER_ID)
                if is_valid:
                    cr_cb_id = candidate_id
                    cr_reference_targets = update_cr_item(
                        cb, cr_cb_id, row, cr_source_cols, cr_tracker_fields, linked_nfs
                    )
                    result_mode = "UPDATED_EXISTING_CR_FROM_STATE"
                else:
                    logger.warning(
                        "Ignoring stale/invalid CR state for source=%s, saved cr_cb_id=%s. Reason: %s",
                        src_id, candidate_id, reason
                    )
                    cr_cb_id, _, cr_reference_targets = create_cr_item(
                        cb, row, cr_source_cols, cr_tracker_fields, linked_nfs
                    )
                    result_mode = "CREATED_CR_REPLACED_INVALID_STATE"
            else:
                cr_cb_id, _, cr_reference_targets = create_cr_item(
                    cb, row, cr_source_cols, cr_tracker_fields, linked_nfs
                )
                result_mode = "CREATED_CR"

            if src_key and cr_cb_id:
                update_state_entry(
                    state=cr_state,
                    item_id_field_name="source_cr_item_id",
                    src_key=src_key,
                    cb_id=cr_cb_id,
                    title=title,
                    status=result_mode,
                    refs=cr_reference_targets["state_refs"] if cr_reference_targets else None
                )

            logger.info("CR pass result: source=%s -> cr_cb_id=%s | %s", src_id, cr_cb_id, result_mode)

        except Exception as ex:
            logger.exception("PASS 2 failed for CR source=%s", src_id)
            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "PASS_2_CR_CREATE_UPDATE",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(CR_STATE_FILE_CSV, cr_state, "source_cr_item_id")
            save_state(NF_STATE_FILE_CSV, nf_state, "source_nf_item_id")

    save_state(CR_STATE_FILE_CSV, cr_state, "source_cr_item_id")
    save_state(NF_STATE_FILE_CSV, nf_state, "source_nf_item_id")

# =========================================================
# REPORTS
# =========================================================

def write_nf_reports(nf_df, nf_state, nf_source_cols, failed_rows, skipped_columns):
    refreshed_rows = []

    for _, row in nf_df.iterrows():
        src_id = get_nf_source_id(row, nf_source_cols)
        if not src_id:
            continue
        st = nf_state.get(src_id.upper(), {})
        refreshed_rows.append({
            "source_item_id": src_id,
            "nf_codebeamer_item_id": st.get("codebeamer_item_id"),
            "title": st.get("title") or get_nf_effective_title(row, nf_source_cols),
            "status": st.get("status"),
            "refs_json": st.get("refs_json"),
        })

    for src_key, st in nf_state.items():
        if src_key.startswith(DEFAULT_MINIMAL_NF_SOURCE_PREFIX.upper()):
            refreshed_rows.append({
                "source_item_id": src_key,
                "nf_codebeamer_item_id": st.get("codebeamer_item_id"),
                "title": st.get("title"),
                "status": st.get("status"),
                "refs_json": st.get("refs_json"),
            })

    if refreshed_rows:
        pd.DataFrame(refreshed_rows).drop_duplicates(subset=["source_item_id"]).to_csv(
            NF_CREATED_MAP_CSV, index=False, encoding="utf-8-sig"
        )
        logger.info("NF created/updated report written: %s", NF_CREATED_MAP_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(NF_FAILED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.info("NF failed rows report written: %s", NF_FAILED_ROWS_CSV)
    else:
        logger.info("NF: no failed rows.")

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates(subset=["source_column", "reason"]).to_csv(
            NF_SKIPPED_COLUMNS_REPORT_CSV, index=False, encoding="utf-8-sig"
        )
        logger.info("NF skipped columns report written: %s", NF_SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("NF: no skipped columns.")

def write_cr_reports(cr_df_all, cr_state, cr_source_cols, failed_rows, skipped_columns):
    refreshed_rows = []
    for _, row in cr_df_all.iterrows():
        src_id = get_cr_source_id(row, cr_source_cols)
        if not src_id:
            continue
        st = cr_state.get(src_id.upper(), {})
        refreshed_rows.append({
            "source_item_id": src_id,
            "cr_codebeamer_item_id": st.get("codebeamer_item_id"),
            "title": get_cr_title_from_row(row, cr_source_cols, is_minimal=bool(row.get("__minimal__"))),
            "status": st.get("status"),
            "refs_json": st.get("refs_json"),
            "is_minimal": bool(row.get("__minimal__"))
        })

    if refreshed_rows:
        pd.DataFrame(refreshed_rows).to_csv(CR_CREATED_MAP_CSV, index=False, encoding="utf-8-sig")
        logger.info("CR created/updated report written: %s", CR_CREATED_MAP_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(CR_FAILED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.info("CR failed rows report written: %s", CR_FAILED_ROWS_CSV)
    else:
        logger.info("CR: no failed rows.")

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates(subset=["source_column", "reason"]).to_csv(
            CR_SKIPPED_COLUMNS_REPORT_CSV, index=False, encoding="utf-8-sig"
        )
        logger.info("CR skipped columns report written: %s", CR_SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("CR: no skipped columns.")

# =========================================================
# MAIN
# =========================================================

def main():
    logger.info("Loading local state...")
    nf_state = load_state(NF_STATE_FILE_CSV, "source_nf_item_id")
    cr_state = load_state(CR_STATE_FILE_CSV, "source_cr_item_id")

    logger.info("Connecting to MySQL...")
    conn_url = URL.create(
        "mysql+mysqlconnector",
        username=MYSQL_USER,
        password=MYSQL_PASS,
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        database=MYSQL_DB,
        query={"charset": "utf8mb4"}
    )
    engine = create_engine(conn_url)

    logger.info("Reading NF source rows...")
    nf_df = pd.read_sql(text(NF_SOURCE_SQL), engine)
    nf_df = nf_df.astype(object).where(pd.notna(nf_df), None)
    if nf_df.empty:
        logger.info("No NF rows found. Exiting.")
        return

    logger.info("Reading CR source rows...")
    cr_df = pd.read_sql(text(CR_SOURCE_SQL), engine)
    cr_df = cr_df.astype(object).where(pd.notna(cr_df), None)
    if cr_df.empty:
        logger.warning("No CR rows found in source table. Missing CRs may still be synthesized from NF references.")

    logger.info("Resolving source columns...")
    nf_source_cols = resolve_source_columns(list(nf_df.columns), NF_SOURCE_COLUMN_ALIASES)

    if cr_df.empty:
        cols = []
        for aliases in CR_SOURCE_COLUMN_ALIASES.values():
            cols.append(aliases[0])
        cols = list(dict.fromkeys(cols))
        cr_df = pd.DataFrame(columns=cols)

    cr_source_cols = resolve_source_columns(list(cr_df.columns), CR_SOURCE_COLUMN_ALIASES)

    # validate NF required
    for req in ("item_id", "title", "description", "cr"):
        if not nf_source_cols.get(req):
            raise RuntimeError(f"Required NF source column not resolved: {req}")

    # validate CR key required
    if not cr_source_cols.get("item_id"):
        raise RuntimeError("Required CR source column not resolved: item_id")

    logger.info("Connecting to Codebeamer...")
    cb = CodebeamerClient(
        CB_BASE_URL,
        CB_USER,
        CB_PASS,
        verify_ssl=VERIFY_SSL,
        timeout=TIMEOUT
    )

    logger.info("Loading NF tracker fields...")
    nf_tracker_fields = load_tracker_fields(cb, NF_TRACKER_ID)

    logger.info("Loading CR tracker fields...")
    cr_tracker_fields = load_tracker_fields(cb, CR_TRACKER_ID)

    # Debug logs for actual choice options exposed by API
    log_choice_field_options(cr_tracker_fields, "Scope Of Change")
    log_choice_field_options(cr_tracker_fields, "Expected Delivery")
    log_choice_field_options(cr_tracker_fields, "Assigned Delivery")
    log_choice_field_options(cr_tracker_fields, "Perimeter")

    seed_reference_cache_from_cr_state(cr_state)

    # PASS 1: NF from source
    nf_failed_rows = []
    pass1_create_or_update_nf(
        cb=cb,
        nf_df=nf_df,
        nf_state=nf_state,
        nf_source_cols=nf_source_cols,
        nf_tracker_fields=nf_tracker_fields,
        failed_rows=nf_failed_rows
    )

    # Build reverse CR -> NF map from real source NF rows
    reverse_cr_to_nf_map = build_cr_to_nf_reverse_map(nf_df, nf_source_cols, nf_state)

    # Collect CR codes referenced by NF
    referenced_cr_codes = []
    for _, row in nf_df.iterrows():
        referenced_cr_codes.extend(split_csv_values(get_row_value(row, nf_source_cols["cr"])))

    # Synthesize missing CR rows if NF references CR not present in sbm_cr
    cr_df_all = synthesize_missing_cr_rows(cr_df, cr_source_cols, referenced_cr_codes)
    cr_df_all = cr_df_all.astype(object).where(pd.notna(cr_df_all), None)

    # re-resolve after synthesis
    cr_source_cols = resolve_source_columns(list(cr_df_all.columns), CR_SOURCE_COLUMN_ALIASES)

    # PASS 2: CR create/update with mandatory refs included at create time
    cr_failed_rows = []
    pass2_create_or_update_cr(
        cb=cb,
        cr_df_all=cr_df_all,
        cr_state=cr_state,
        cr_source_cols=cr_source_cols,
        cr_tracker_fields=cr_tracker_fields,
        reverse_cr_to_nf_map=reverse_cr_to_nf_map,
        nf_state=nf_state,
        nf_tracker_fields=nf_tracker_fields,
        failed_rows=cr_failed_rows
    )

    save_state(NF_STATE_FILE_CSV, nf_state, "source_nf_item_id")
    save_state(CR_STATE_FILE_CSV, cr_state, "source_cr_item_id")

    nf_skipped_columns = build_nf_skipped_columns_report(nf_df, nf_source_cols)
    cr_skipped_columns = build_cr_skipped_columns_report(cr_df_all, cr_source_cols)

    write_nf_reports(
        nf_df=nf_df,
        nf_state=nf_state,
        nf_source_cols=nf_source_cols,
        failed_rows=nf_failed_rows,
        skipped_columns=nf_skipped_columns
    )

    write_cr_reports(
        cr_df_all=cr_df_all,
        cr_state=cr_state,
        cr_source_cols=cr_source_cols,
        failed_rows=cr_failed_rows,
        skipped_columns=cr_skipped_columns
    )

    logger.info("NF + CR sync completed successfully.")

if __name__ == "__main__":
    main()