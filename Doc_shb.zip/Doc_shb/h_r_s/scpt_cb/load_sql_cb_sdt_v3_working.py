import re
import os
import json
import logging
import time

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from requests.auth import HTTPBasicAuth

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"

TABLE_NAME = "sbm_sdt"

SOURCE_SQL = f"""
SELECT *
FROM `{TABLE_NAME}`
-- WHERE `Item Id` = 'ASDT115478'
LIMIT 10
"""


# =========================================================
# CODEBEAMER CONFIGURATION
# =========================================================

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 20
SLEEP_BETWEEN_REQUESTS_SEC = 0.0


# =========================================================
# TRACKER IDS
# =========================================================

AEMS_SDT_TRACKER_ID = 295425
AEMS_SDT_TRACKER_NAME = "A-EMS Specification"

MODEL_DELIVERY_TRACKER_ID = 293885
MODEL_DELIVERY_TRACKER_NAME = "Model Delivery"

TAG_MANAGEMENT_TRACKER_ID = 293706
TAG_MANAGEMENT_TRACKER_NAME = "Tag Management"

CR_MANAGEMENT_TRACKER_ID = 293926
CR_MANAGEMENT_TRACKER_NAME = "Change Request"

ISSUE_MANAGEMENT_TRACKER_ID = 294498
ISSUE_MANAGEMENT_TRACKER_NAME = "Issue"


# =========================================================
# CODEBEAMER FIELD NAMES
# =========================================================

AEMS_SDT_SOURCE_ID_FIELD_NAME = "SBM SDT Id"
TAG_SOURCE_ID_FIELD_NAME = "SBM Tag Id"

CR_SOURCE_ID_FIELD_NAME = "SBM CR Id"
ISSUE_SOURCE_ID_FIELD_NAME = "SBM Item Id"

ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME = "Impacted Specification"


# =========================================================
# OPTIONAL CR TARGET FIELD CANDIDATES ON A-EMS SPECIFICATION
# =========================================================

AEMS_SDT_AFFECTED_CR_FIELD_CANDIDATES = [
    "Affected CR",
    "Affected Change Request",
    "Change Request",
    "Change Requests",
    "Impacted CR",
    "Impacted Change Request",
]


# =========================================================
# DEFAULT VALUES
# =========================================================

DEFAULT_STATUS_VALUE = "New"

MIGRATED_DATA_FIELD_NAME = "Migrated Data ?"
MIGRATED_DATA_VALUE = "Yes"

UPDATE_MANDATORY_FIELDS_ON_EXISTING = False


# =========================================================
# OUTPUT FILES
# =========================================================

STATE_FILE_CSV = "codebeamer_aems_sdt_state.csv"
CREATED_MAP_CSV = "created_updated_aems_sdt.csv"
FAILED_ROWS_CSV = "failed_rows_aems_sdt.csv"
SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_aems_sdt.csv"
CHANGE_AUDIT_CSV = "changed_fields_aems_sdt.csv"
LOG_FILE = "codebeamer_aems_sdt_import.log"


# =========================================================
# SOURCE COLUMN ALIASES
# =========================================================

SOURCE_ALIASES = {
    "Item Id": ["Item Id", "Item_Id"],
    "Spec Version": ["Spec Version", "Spec_Version"],
    "Active/Inactive": ["Active/Inactive", "Active_Inactive"],
    "Affected CR": ["Affected CR", "Affected_CR"],
    "Affected Issues": ["Affected Issues", "Affected_Issues"],
    "ASIL Level": ["ASIL Level", "ASIL_Level"],
    "Associated Tags": ["Associated Tags", "Associated_Tags"],
    "Classification": ["Classification"],
    "Item Type": ["Item Type", "Item_Type"],
    "Last Modified Date": ["Last Modified Date", "Last_Modified_Date"],
    "Metier Delivery": ["Metier Delivery", "Metier_Delivery"],
    "New or Evolution?": [
        "New or Evolution?",
        "New or Evolution ?",
        "New_or_Evolution",
        "New_or_Evolution_?",
    ],
    "Owner": ["Owner"],
    "Previous Specification Version": [
        "Previous Specification Version",
        "Previous_Specification_Version",
    ],
    "Project": ["Project"],
    "State": ["State"],
    "Submit Date": ["Submit Date", "Submit_Date"],
    "Submitter": ["Submitter"],
    "SW Item Type": ["SW Item Type", "SW_Item_Type"],
    "SW Project": ["SW Project", "SW_Project"],
    "Associated Attachments": ["Associated Attachments", "Associated_Attachments"],
}


# =========================================================
# CHOICE VALUE MAPPINGS
# =========================================================

NEW_OR_EVOLUTION_TO_CB = {
    "NEW": "NEW",
    "New": "NEW",
    "new": "NEW",
    "EVOL": "EVOL",
    "Evol": "EVOL",
    "evol": "EVOL",
    "Evolution": "EVOL",
}

ACTIVE_INACTIVE_TO_CB = {
    "Active": "Active",
    "ACTIVE": "Active",
    "active": "Active",
    "Inactive": "InActive",
    "INACTIVE": "InActive",
    "inactive": "InActive",
    "InActive": "InActive",
}

CLASSIFICATION_TO_CB = {
    "ASW": "ASW",
    "BSW": "BSW",
    "MODULE": "MODULE",
    "MW": "MW",
}

STATE_TO_CB_STATUS = {
    "New": "New",
    "NEW": "New",
    "Delivered": "Delivered",
    "DELIVERED": "Delivered",
    "Closed": "Closed",
    "CLOSED": "Closed",
    "Obsolete": "Obsolete",
    "OBSOLETE": "Obsolete",
}


# =========================================================
# FIELD MAPPING
# =========================================================
# Spec Version is NOT mapped because Codebeamer field is Decimal.
# Spec Version is used as item title/name.
# Assigned to is NOT mapped because Codebeamer says it is not writable.
# =========================================================

SAFE_SCALAR_MAPPING = {
    "Item Id": {
        "field": AEMS_SDT_SOURCE_ID_FIELD_NAME,
    },
    "Classification": {
        "field": "Classification",
        "kind": "choice",
        "value_map": CLASSIFICATION_TO_CB,
    },
    "New or Evolution?": {
        "field": "New or Evolution?",
        "kind": "choice",
        "value_map": NEW_OR_EVOLUTION_TO_CB,
    },
    "Active/Inactive": {
        "field": "Active/Inactive",
        "kind": "choice",
        "value_map": ACTIVE_INACTIVE_TO_CB,
    },
    "SW Project": {
        "field": "SW Project",
        "kind": "choice",
    },
    "SW Item Type": {
        "field": "SW Item Type",
        "kind": "choice",
    },
    "ASIL Level": {
        "field": "ASIL Level",
        "kind": "choice",
    },
}


REFERENCE_RULES = [
    {
        "source_logical": "Metier Delivery",
        "target_tracker_id": MODEL_DELIVERY_TRACKER_ID,
        "target_tracker_name": MODEL_DELIVERY_TRACKER_NAME,
        "target_field": "Metier Delivery",
        "model_delivery": True,
        "create_missing": True,
        "multi_value": False,
    }
]


# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger_obj = logging.getLogger("cb_aems_sdt_sync")
    logger_obj.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.INFO)

    logger_obj.handlers.clear()
    logger_obj.addHandler(fh)
    logger_obj.addHandler(ch)

    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(s):
    return re.sub(r"\s+", " ", str(s).strip()).lower()


def normalize_cache_key(s):
    return re.sub(r"\s+", "", str(s).strip()).lower()


def is_blank(v):
    if v is None:
        return True

    try:
        if pd.isna(v):
            return True
    except Exception:
        pass

    if isinstance(v, str):
        s = v.strip()
        if s in ("", "(None)", "None", "nan", "NaN", "--", "null", "NULL"):
            return True

    return False


def clean_text(v):
    if is_blank(v):
        return None

    s = str(v).replace("\r", "").replace("_x000D_", "").strip()
    return s if s else None


def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def get_source_value(row, logical_name):
    aliases = SOURCE_ALIASES.get(logical_name, [logical_name])

    for col in aliases:
        if col in row.index:
            return row.get(col)

    return None


def get_source_text(row, logical_name):
    return clean_text(get_source_value(row, logical_name))


def split_multi_values(v):
    txt = clean_text(v)

    if not txt:
        return []

    parts = [p.strip() for p in txt.split(",")]
    out = []
    seen = set()

    for p in parts:
        if is_blank(p):
            continue

        key = normalize_name(p)

        if key in seen:
            continue

        seen.add(key)
        out.append(p)

    return out


def extract_id_title(value):
    txt = clean_text(value)

    if not txt:
        return None, None

    if ":" in txt:
        left, right = txt.split(":", 1)
        return clean_text(left), clean_text(right)

    return txt, txt


def extract_entries_with_prefix(value, prefix_regex):
    txt = clean_text(value)

    if not txt:
        return []

    parts = split_multi_values(txt)
    result = []
    seen = set()

    for entry in parts:
        m = re.search(prefix_regex, entry, flags=re.IGNORECASE)

        if not m:
            continue

        item_id = m.group(1).upper()

        if item_id in seen:
            continue

        seen.add(item_id)

        _, title = extract_id_title(entry)

        result.append({
            "source_id": item_id,
            "title": title or item_id,
            "raw": entry,
        })

    return result


def extract_tag_entries(value):
    entries = extract_entries_with_prefix(value, r"\b(TGM\d+)\b")

    return [
        {
            "tag_id": e["source_id"],
            "title": e["title"],
            "raw": e["raw"],
        }
        for e in entries
    ]


def normalize_model_delivery_value(v):
    txt = clean_text(v)

    if not txt:
        return None

    s = txt.upper().replace(" ", "")
    m = re.fullmatch(r"MD0*([1-9]|[1-3][0-9]|4[0-2])", s)

    if not m:
        return txt

    return f"MD{int(m.group(1)):02d}"


def first_non_null_sample(df, col):
    if col not in df.columns:
        return None

    ser = df[col].dropna()

    if ser.empty:
        return None

    return clean_text(ser.iloc[0])


def find_field_meta_by_candidates(tracker_fields, candidate_names):
    for field_name in candidate_names:
        meta = tracker_fields.get(normalize_name(field_name))
        if meta:
            return meta, field_name

    return None, None


def print_all_tracker_fields(tracker_fields, title="Tracker Fields"):
    print(f"\n========== {title} ==========")
    for _, meta in sorted(tracker_fields.items(), key=lambda kv: str(kv[1].get("name"))):
        print(
            f"name={meta.get('name')} | "
            f"id={meta.get('id')} | "
            f"valueModel={meta.get('valueModel')} | "
            f"type={meta.get('type')}"
        )
    print("=======================================================\n")


def validate_config():
    required = {
        "AEMS_SDT_TRACKER_ID": AEMS_SDT_TRACKER_ID,
        "MODEL_DELIVERY_TRACKER_ID": MODEL_DELIVERY_TRACKER_ID,
        "TAG_MANAGEMENT_TRACKER_ID": TAG_MANAGEMENT_TRACKER_ID,
        "CR_MANAGEMENT_TRACKER_ID": CR_MANAGEMENT_TRACKER_ID,
        "ISSUE_MANAGEMENT_TRACKER_ID": ISSUE_MANAGEMENT_TRACKER_ID,
    }

    missing = []

    for key, value in required.items():
        try:
            if not value or int(value) <= 0:
                missing.append(key)
        except Exception:
            missing.append(key)

    if missing:
        raise RuntimeError("Please update tracker IDs before running: " + ", ".join(missing))


# =========================================================
# STATE HELPERS
# =========================================================

def load_state(path):
    state = {}

    if not os.path.exists(path):
        return state

    try:
        if os.path.getsize(path) == 0:
            return state
    except OSError:
        return state

    try:
        df = pd.read_csv(path, dtype=str)
    except Exception:
        return state

    if df.empty:
        return state

    for _, row in df.iterrows():
        src = str(row.get("source_sdt_id", "")).strip().upper()

        if not src:
            continue

        refs = {}
        raw_refs = row.get("refs_json")

        if raw_refs and str(raw_refs).strip():
            try:
                parsed = json.loads(raw_refs)
                if isinstance(parsed, dict):
                    refs = parsed
            except Exception:
                refs = {}

        state[src] = {
            "source_sdt_id": src,
            "aems_sdt_codebeamer_item_id": row.get("aems_sdt_codebeamer_item_id"),
            "title": row.get("title"),
            "status": row.get("status"),
            "refs_json": json.dumps(refs, ensure_ascii=False),
        }

    return state


def save_state(path, state):
    rows = list(state.values())

    if rows:
        df = pd.DataFrame(rows)
    else:
        df = pd.DataFrame(columns=[
            "source_sdt_id",
            "aems_sdt_codebeamer_item_id",
            "title",
            "status",
            "refs_json",
        ])

    df.to_csv(path, index=False, encoding="utf-8-sig")


def get_refs_from_state_entry(entry):
    if not entry:
        return {}

    raw = entry.get("refs_json")

    if not raw:
        return {}

    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    return {}


def update_state_entry(state, src_key, cb_id, title, status, refs=None):
    existing = state.get(src_key, {})
    current_refs = get_refs_from_state_entry(existing)

    if refs:
        for bucket, value_map in refs.items():
            current_refs.setdefault(bucket, {})

            if isinstance(value_map, dict):
                for source_value, item_id in value_map.items():
                    if item_id is not None:
                        current_refs[bucket][str(source_value)] = str(item_id)

    state[src_key] = {
        "source_sdt_id": src_key,
        "aems_sdt_codebeamer_item_id": str(cb_id) if cb_id else existing.get("aems_sdt_codebeamer_item_id"),
        "title": title or existing.get("title"),
        "status": status or existing.get("status"),
        "refs_json": json.dumps(current_refs, ensure_ascii=False),
    }


# =========================================================
# GLOBAL CACHES
# =========================================================

AEMS_SDT_EXISTING_BY_SBM_SDT_ID = {}

TAG_EXISTING_BY_SBM_TAG_ID = {}
TAG_EXISTING_BY_NAME_OR_DESC_ID = {}

CR_EXISTING_BY_SOURCE_ID = {}

REFERENCE_ITEM_CACHE = {}
REFERENCE_TRACKER_EXISTING_CACHE = {}

CHANGE_AUDIT_ROWS = []


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url, username, password, verify_ssl=True, timeout=60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Content-Type": "application/json"})

        retry = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )

        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path):
        return f"{self.base_url}{path}"

    def get(self, path, params=None):
        safe_sleep()
        r = self.session.get(self._url(path), params=params, timeout=self.timeout)
        self._raise_for_status(r)
        return r.json()

    def post(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.post(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def put(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.put(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    @staticmethod
    def _raise_for_status(r):
        try:
            r.raise_for_status()
        except requests.HTTPError:
            raise RuntimeError(f"HTTP {r.status_code} | URL={r.url} | Response={r.text}")


# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb, tracker_id):
    refs = cb.get(f"/v3/trackers/{tracker_id}/fields")

    field_map = {}

    for ref in refs:
        fid = ref["id"]
        detail = cb.get(f"/v3/trackers/{tracker_id}/fields/{fid}")
        field_map[normalize_name(detail["name"])] = detail

    return field_map


def log_field_debug(tracker_fields, field_name):
    meta = tracker_fields.get(normalize_name(field_name))

    if not meta:
        logger.warning("Field '%s' not found in tracker metadata", field_name)
        return

    logger.info(
        "Field debug | name=%s | id=%s | valueModel=%s | type=%s | options_count=%s",
        meta.get("name"),
        meta.get("id"),
        meta.get("valueModel"),
        meta.get("type"),
        len(meta.get("options") or [])
    )


def get_item_detail(cb, item_id):
    return cb.get(f"/v3/items/{item_id}")


def get_tracker_item_name(cb, item_id):
    try:
        item = get_item_detail(cb, item_id)
        return item.get("name") or str(item_id)
    except Exception:
        return str(item_id)


def load_item_fields_robust(cb, item_id):
    all_fields = []

    try:
        fields_response = cb.get(f"/v3/items/{item_id}/fields")

        if isinstance(fields_response, list):
            all_fields.extend(fields_response)

        elif isinstance(fields_response, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = fields_response.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load /fields for item_id=%s. Error=%s", item_id, ex)

    try:
        item_detail = cb.get(f"/v3/items/{item_id}")

        if isinstance(item_detail, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = item_detail.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load item detail fields for item_id=%s. Error=%s", item_id, ex)

    return all_fields


def extract_items_from_query_response(data):
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("items", "itemRefs", "results", "data"):
            val = data.get(key)
            if isinstance(val, list):
                return val

    return []


def extract_item_id_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("id", "itemId"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("id", "itemId"):
                value = nested.get(key)
                if value:
                    return value

    uri = item_ref.get("uri") or item_ref.get("url")

    if uri:
        m = re.search(r"/items/(\d+)", str(uri))
        if m:
            return int(m.group(1))

    return None


def extract_item_name_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("name", "title"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("name", "title"):
                value = nested.get(key)
                if value:
                    return value

    return None


def extract_field_value_by_name_from_fields(field_values, field_name):
    target_key = normalize_name(field_name)

    if not isinstance(field_values, list):
        return None

    for fv in field_values:
        if not isinstance(fv, dict):
            continue

        possible_names = [
            fv.get("name"),
            fv.get("fieldName"),
            fv.get("label"),
        ]

        field_obj = fv.get("field")
        if isinstance(field_obj, dict):
            possible_names.extend([
                field_obj.get("name"),
                field_obj.get("fieldName"),
                field_obj.get("label"),
            ])

        if not any(normalize_name(x) == target_key for x in possible_names if x):
            continue

        if fv.get("value") is not None:
            val = fv.get("value")

            if isinstance(val, dict):
                return clean_text(
                    val.get("name")
                    or val.get("value")
                    or val.get("text")
                    or val.get("label")
                    or val.get("id")
                )

            return clean_text(val)

        if fv.get("text") is not None:
            return clean_text(fv.get("text"))

        values = fv.get("values")

        if isinstance(values, list) and values:
            names = []

            for item in values:
                if isinstance(item, dict):
                    names.append(
                        clean_text(
                            item.get("name")
                            or item.get("value")
                            or item.get("text")
                            or item.get("label")
                            or item.get("id")
                        )
                    )
                else:
                    names.append(clean_text(item))

            names = [x for x in names if x]

            if names:
                return ", ".join(names)

    return None


def validate_existing_item_in_tracker(cb, item_id, expected_tracker_id):
    try:
        item = get_item_detail(cb, item_id)
    except Exception as ex:
        return False, f"Item {item_id} not accessible: {ex}"

    tracker = item.get("tracker") or {}
    tracker_id = tracker.get("id")

    if str(tracker_id) != str(expected_tracker_id):
        return False, f"Item {item_id} belongs to tracker {tracker_id}, expected {expected_tracker_id}"

    return True, "OK"


# =========================================================
# SCANS / DIRECT SEARCHES
# =========================================================

def scan_existing_items_by_field(cb, tracker_id, tracker_name, field_name, target_cache, page_size=500):
    logger.info("Scanning existing %s items by field '%s'...", tracker_name, field_name)

    target_cache.clear()

    page = 1
    total_loaded = 0
    total_cached = 0
    total_without_source_id = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({tracker_id})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query existing %s items. Error=%s", tracker_name, ex)
            return

        items = extract_items_from_query_response(data)

        logger.info(
            "Existing %s query page=%s returned %s item(s)",
            tracker_name,
            page,
            len(items)
        )

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            item_name = extract_item_name_from_query_item(item_ref) or str(item_id)

            try:
                fields = load_item_fields_robust(cb, item_id)
            except Exception as ex:
                logger.warning("Unable to read fields for %s item id=%s. Error=%s", tracker_name, item_id, ex)
                continue

            total_loaded += 1

            source_value = extract_field_value_by_name_from_fields(fields, field_name)

            if not source_value:
                total_without_source_id += 1
                continue

            source_key = clean_text(source_value).upper()

            if not source_key:
                total_without_source_id += 1
                continue

            if source_key not in target_cache:
                target_cache[source_key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": field_name
                }
                total_cached += 1
            else:
                logger.warning(
                    "Duplicate %s item found for %s=%s. Cached item_id=%s, duplicate item_id=%s",
                    tracker_name,
                    field_name,
                    source_key,
                    target_cache[source_key]["id"],
                    item_id
                )

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "%s existing scan completed. loaded=%s | cached=%s | without_%s=%s",
        tracker_name,
        total_loaded,
        total_cached,
        field_name,
        total_without_source_id
    )


def find_issue_in_tracker_by_sbm_item_id(cb, issue_key, page_size=500):
    expected_key = clean_text(issue_key)

    if not expected_key:
        return None

    expected_key = expected_key.upper()

    logger.info(
        "Searching Issue tracker directly by %s=%s",
        ISSUE_SOURCE_ID_FIELD_NAME,
        expected_key
    )

    page = 1

    while True:
        payload = {
            "queryString": f"tracker.id IN ({ISSUE_MANAGEMENT_TRACKER_ID})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning(
                "Issue search failed while querying Issue tracker. issue_key=%s | error=%s",
                expected_key,
                ex
            )
            return None

        items = extract_items_from_query_response(data)

        if not items:
            break

        logger.info("Issue search page=%s returned %s item(s)", page, len(items))

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            try:
                fields = load_item_fields_robust(cb, item_id)
            except Exception as ex:
                logger.warning(
                    "Unable to load fields for Issue item_id=%s. Error=%s",
                    item_id,
                    ex
                )
                continue

            sbm_item_id = extract_field_value_by_name_from_fields(
                fields,
                ISSUE_SOURCE_ID_FIELD_NAME
            )

            if not sbm_item_id:
                continue

            found_key = clean_text(sbm_item_id)

            if not found_key:
                continue

            found_key = found_key.upper()

            if found_key == expected_key:
                item_name = extract_item_name_from_query_item(item_ref) or get_tracker_item_name(cb, item_id)

                logger.info(
                    "Existing Issue found by %s=%s -> item_id=%s | name=%s",
                    ISSUE_SOURCE_ID_FIELD_NAME,
                    expected_key,
                    item_id,
                    item_name
                )

                return {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": ISSUE_SOURCE_ID_FIELD_NAME
                }

        if len(items) < page_size:
            break

        page += 1

    logger.warning(
        "Existing Issue not found in Issue tracker by %s=%s",
        ISSUE_SOURCE_ID_FIELD_NAME,
        expected_key
    )

    return None


# =========================================================
# REFERENCE TRACKER SCANS
# =========================================================

def scan_existing_reference_tracker_by_name(cb, tracker_id, tracker_name, page_size=500):
    logger.info("Scanning existing reference tracker by name: %s (%s)", tracker_name, tracker_id)

    page = 1
    total_loaded = 0
    total_cached = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({tracker_id})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query %s. Error=%s", tracker_name, ex)
            return

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            try:
                item = get_item_detail(cb, item_id)
            except Exception:
                item = item_ref

            item_name = item.get("name") or extract_item_name_from_query_item(item_ref) or str(item_id)

            total_loaded += 1

            key = (tracker_id, normalize_cache_key(item_name))

            if key not in REFERENCE_TRACKER_EXISTING_CACHE:
                REFERENCE_TRACKER_EXISTING_CACHE[key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": "name"
                }
                total_cached += 1

        if len(items) < page_size:
            break

        page += 1

    logger.info("Reference scan completed: %s | loaded=%s | cached=%s", tracker_name, total_loaded, total_cached)


def scan_existing_tag_items(cb, page_size=500):
    logger.info("Scanning existing Tag Management items by SBM Tag Id and name/description TGM id...")

    TAG_EXISTING_BY_SBM_TAG_ID.clear()
    TAG_EXISTING_BY_NAME_OR_DESC_ID.clear()

    page = 1
    total_loaded = 0
    total_cached_by_field = 0
    total_cached_by_text = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({TAG_MANAGEMENT_TRACKER_ID})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query existing Tag Management items. Error=%s", ex)
            return

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            try:
                item_detail = get_item_detail(cb, item_id)
            except Exception:
                item_detail = item_ref

            item_name = item_detail.get("name") or extract_item_name_from_query_item(item_ref) or str(item_id)
            item_description = item_detail.get("description") or ""

            total_loaded += 1

            sbm_tag_id = None

            try:
                fields = load_item_fields_robust(cb, item_id)
                sbm_tag_id = extract_field_value_by_name_from_fields(fields, TAG_SOURCE_ID_FIELD_NAME)
            except Exception as ex:
                logger.warning("Unable to read Tag fields for item=%s. Error=%s", item_id, ex)

            if sbm_tag_id:
                tag_key = clean_text(sbm_tag_id).upper()

                if tag_key and tag_key not in TAG_EXISTING_BY_SBM_TAG_ID:
                    TAG_EXISTING_BY_SBM_TAG_ID[tag_key] = {
                        "id": int(item_id),
                        "name": item_name,
                        "matched_by": TAG_SOURCE_ID_FIELD_NAME
                    }
                    total_cached_by_field += 1

            combined_text = f"{item_name} {item_description}"

            for match in re.finditer(r"\b(TGM\d+)\b", combined_text, flags=re.IGNORECASE):
                tag_key = match.group(1).upper()

                if tag_key not in TAG_EXISTING_BY_NAME_OR_DESC_ID:
                    TAG_EXISTING_BY_NAME_OR_DESC_ID[tag_key] = {
                        "id": int(item_id),
                        "name": item_name,
                        "matched_by": "name_or_description"
                    }
                    total_cached_by_text += 1

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "Tag scan completed. loaded=%s | cached_by_field=%s | cached_by_text=%s",
        total_loaded,
        total_cached_by_field,
        total_cached_by_text
    )


# =========================================================
# FIELD VALUE BUILDERS
# =========================================================

def build_text_date_number_bool_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None

    field_id = field_meta["id"]
    field_name = field_meta["name"]
    value_model = field_meta.get("valueModel")

    if value_model == "TextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "TextFieldValue",
            "value": txt
        }

    if value_model == "WikiTextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "WikiTextFieldValue",
            "value": txt
        }

    if value_model == "DateFieldValue":
        dt = pd.to_datetime(raw_value, errors="coerce")
        if pd.isna(dt):
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DateFieldValue",
            "value": dt.strftime("%Y-%m-%dT%H:%M:%S.000")
        }

    if value_model == "IntegerFieldValue":
        try:
            iv = int(float(raw_value))
        except Exception:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "IntegerFieldValue",
            "value": iv
        }

    if value_model == "DecimalFieldValue":
        try:
            dv = float(raw_value)
        except Exception:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DecimalFieldValue",
            "value": dv
        }

    if value_model == "BoolFieldValue":
        s = str(raw_value).strip().lower()

        if s in ("active", "yes", "true", "1", "y"):
            bv = True
        elif s in ("inactive", "no", "false", "0", "n"):
            bv = False
        else:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "BoolFieldValue",
            "value": bv
        }

    return None


def build_choice_field_value(field_meta, raw_value, value_map=None):
    if is_blank(raw_value):
        return None, None

    source_text = clean_text(raw_value)

    if not source_text:
        return None, None

    target_text = value_map.get(source_text, source_text) if value_map else source_text

    options = field_meta.get("options") or []

    if not options:
        return None, f"Field '{field_meta.get('name')}' has no choice options metadata"

    matched = None

    for opt in options:
        if normalize_name(opt.get("name")) == normalize_name(target_text):
            matched = opt
            break

    if not matched:
        available = [o.get("name") for o in options]
        return None, f"Choice '{target_text}' not found for field '{field_meta.get('name')}'. Available={available}"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": matched["id"],
            "name": matched.get("name"),
            "type": matched.get("type", "ChoiceOptionReference")
        }]
    }, None


def build_reference_field_value(field_meta, refs):
    values = []
    seen = set()

    for item_id, item_name in refs:
        if not item_id:
            continue

        key = str(item_id)

        if key in seen:
            continue

        seen.add(key)

        values.append({
            "id": int(item_id),
            "name": str(item_name),
            "type": "TrackerItemReference"
        })

    if not values:
        return None

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": values
    }


def update_item_fields(cb, item_id, field_values):
    if not field_values:
        return

    payload = {"fieldValues": field_values}
    cb.put(f"/v3/items/{item_id}/fields", payload)


# =========================================================
# REFERENCE CREATE / REUSE
# =========================================================

def create_generic_reference_item(cb, tracker_id, tracker_name, name, description=None, custom_fields=None):
    payload = {
        "name": clean_text(name) or "Imported Reference",
        "descriptionFormat": "PlainText",
        "description": description or f"Imported {tracker_name}: {name}"
    }

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    created = cb.post(f"/v3/trackers/{tracker_id}/items", payload)

    return created["id"], created


def get_or_create_reference_by_name(cb, tracker_id, tracker_name, source_value, create_missing=False):
    value = clean_text(source_value)

    if not value:
        return None, None, False

    key = (tracker_id, normalize_cache_key(value))

    cached_id = REFERENCE_ITEM_CACHE.get(key)

    if cached_id:
        return cached_id, get_tracker_item_name(cb, cached_id), False

    existing = REFERENCE_TRACKER_EXISTING_CACHE.get(key)

    if existing:
        item_id = existing["id"]
        item_name = existing["name"]
        REFERENCE_ITEM_CACHE[key] = item_id
        return item_id, item_name, False

    if not create_missing:
        logger.warning("Reference not found and create_missing=False | tracker=%s | value=%s", tracker_name, value)
        return None, None, False

    child_id, _ = create_generic_reference_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        name=value
    )

    REFERENCE_ITEM_CACHE[key] = int(child_id)
    REFERENCE_TRACKER_EXISTING_CACHE[key] = {
        "id": int(child_id),
        "name": value,
        "matched_by": "created"
    }

    return int(child_id), value, True


def get_or_create_model_delivery_item(cb, source_value):
    md_value = normalize_model_delivery_value(source_value)

    if not md_value:
        return None, None, False

    return get_or_create_reference_by_name(
        cb=cb,
        tracker_id=MODEL_DELIVERY_TRACKER_ID,
        tracker_name=MODEL_DELIVERY_TRACKER_NAME,
        source_value=md_value,
        create_missing=True
    )


def get_or_create_tag_management_item(cb, tag_tracker_fields, tag_id, tag_title):
    tag_key = clean_text(tag_id).upper()

    existing = TAG_EXISTING_BY_SBM_TAG_ID.get(tag_key)

    if existing:
        return existing["id"], existing["name"], False

    existing_text = TAG_EXISTING_BY_NAME_OR_DESC_ID.get(tag_key)

    if existing_text:
        return existing_text["id"], existing_text["name"], False

    custom_fields = []

    sbm_tag_field = tag_tracker_fields.get(normalize_name(TAG_SOURCE_ID_FIELD_NAME))

    if sbm_tag_field:
        fv = build_text_date_number_bool_value(sbm_tag_field, tag_key)
        if fv:
            custom_fields.append(fv)

    created_id, _ = create_generic_reference_item(
        cb=cb,
        tracker_id=TAG_MANAGEMENT_TRACKER_ID,
        tracker_name=TAG_MANAGEMENT_TRACKER_NAME,
        name=tag_title or tag_key,
        description=f"Created from A-EMS Specification Associated Tags migration. SBM Tag Id: {tag_key}",
        custom_fields=custom_fields
    )

    TAG_EXISTING_BY_SBM_TAG_ID[tag_key] = {
        "id": int(created_id),
        "name": tag_title or tag_key,
        "matched_by": "created"
    }

    logger.info("Created missing Tag Management item: SBM Tag Id=%s -> item_id=%s", tag_key, created_id)

    return int(created_id), tag_title or tag_key, True


# =========================================================
# SDT FIELD BUILDERS
# =========================================================

def get_sdt_source_id(row):
    return get_source_text(row, "Item Id")


def get_sdt_title(row):
    spec_version = get_source_text(row, "Spec Version")
    src_id = get_sdt_source_id(row)

    return spec_version or src_id or "Imported A-EMS Specification"


def build_mandatory_create_fields(row, aems_sdt_fields, skipped_columns):
    values = []

    status_meta = aems_sdt_fields.get(normalize_name("Status"))

    if status_meta:
        source_status = get_source_text(row, "State") or DEFAULT_STATUS_VALUE

        fv, err = build_choice_field_value(
            field_meta=status_meta,
            raw_value=source_status,
            value_map=STATE_TO_CB_STATUS
        )

        if not fv and source_status != DEFAULT_STATUS_VALUE:
            logger.warning(
                "Status '%s' not resolved. Falling back to default Status '%s'. Error=%s",
                source_status,
                DEFAULT_STATUS_VALUE,
                err
            )

            fv, err = build_choice_field_value(
                field_meta=status_meta,
                raw_value=DEFAULT_STATUS_VALUE,
                value_map=STATE_TO_CB_STATUS
            )

        if fv:
            values.append(fv)
        else:
            skipped_columns.append({
                "source_column": "State",
                "reason": err or "Unable to build Status",
                "sample_value": source_status
            })

    assigned_meta = aems_sdt_fields.get(normalize_name("Assigned to"))

    if assigned_meta:
        skipped_columns.append({
            "source_column": "Assigned to",
            "reason": "Skipped because Codebeamer field 'Assigned to' is not writable during item creation",
            "sample_value": "cbadmin"
        })

        logger.warning(
            "Skipping 'Assigned to' because field id=%s is not writable during create.",
            assigned_meta.get("id")
        )

    migrated_meta = aems_sdt_fields.get(normalize_name(MIGRATED_DATA_FIELD_NAME))

    if migrated_meta:
        fv, err = build_choice_field_value(
            field_meta=migrated_meta,
            raw_value=MIGRATED_DATA_VALUE
        )

        if fv:
            values.append(fv)
        else:
            skipped_columns.append({
                "source_column": MIGRATED_DATA_FIELD_NAME,
                "reason": err or "Unable to build Migrated Data ?",
                "sample_value": MIGRATED_DATA_VALUE
            })

    return values


def build_scalar_field_values(row, aems_sdt_fields, skipped_columns):
    values = []

    for logical_col, cfg in SAFE_SCALAR_MAPPING.items():
        raw_value = get_source_value(row, logical_col)

        if is_blank(raw_value):
            continue

        field_name = cfg["field"]
        field_meta = aems_sdt_fields.get(normalize_name(field_name))

        if not field_meta:
            skipped_columns.append({
                "source_column": logical_col,
                "reason": f"Target A-EMS Specification field '{field_name}' not found",
                "sample_value": clean_text(raw_value)
            })
            continue

        kind = cfg.get("kind")

        if kind == "choice":
            fv, err = build_choice_field_value(
                field_meta=field_meta,
                raw_value=raw_value,
                value_map=cfg.get("value_map")
            )

            if fv:
                values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": logical_col,
                    "reason": err,
                    "sample_value": clean_text(raw_value)
                })

            continue

        fv = build_text_date_number_bool_value(field_meta, raw_value)

        if fv:
            values.append(fv)
        else:
            skipped_columns.append({
                "source_column": logical_col,
                "reason": f"Unsupported or unresolved field '{field_name}'",
                "sample_value": clean_text(raw_value)
            })

    return values


def build_associated_tags_reference(cb, row, aems_sdt_fields, tag_tracker_fields, skipped_columns):
    raw_tags = get_source_value(row, "Associated Tags")
    entries = extract_tag_entries(raw_tags)

    if not entries:
        return None, {}

    field_meta = aems_sdt_fields.get(normalize_name("Associated Tags"))

    if not field_meta:
        skipped_columns.append({
            "source_column": "Associated Tags",
            "reason": "Target A-EMS Specification field 'Associated Tags' not found",
            "sample_value": clean_text(raw_tags)
        })
        return None, {}

    refs = []
    state_refs = {}

    for entry in entries:
        tag_id = entry["tag_id"]
        tag_title = entry["title"]

        tag_cb_id, tag_name, created = get_or_create_tag_management_item(
            cb=cb,
            tag_tracker_fields=tag_tracker_fields,
            tag_id=tag_id,
            tag_title=tag_title
        )

        refs.append((tag_cb_id, tag_name))
        state_refs[tag_id] = tag_cb_id

        logger.info(
            "Associated Tag %s: %s -> tag_item_id=%s",
            "created" if created else "reused",
            tag_id,
            tag_cb_id
        )

    fv = build_reference_field_value(field_meta, refs)

    return fv, state_refs


def build_affected_cr_reference(row, aems_sdt_fields, skipped_columns):
    raw_value = get_source_value(row, "Affected CR")
    entries = extract_entries_with_prefix(raw_value, r"\b([AH]CR\d+)\b")

    if not entries:
        return None, {}

    field_meta, matched_field_name = find_field_meta_by_candidates(
        aems_sdt_fields,
        AEMS_SDT_AFFECTED_CR_FIELD_CANDIDATES
    )

    if not field_meta:
        skipped_columns.append({
            "source_column": "Affected CR",
            "reason": (
                "No target CR reference field found in A-EMS Specification tracker. "
                f"Tried names: {AEMS_SDT_AFFECTED_CR_FIELD_CANDIDATES}"
            ),
            "sample_value": clean_text(raw_value)
        })
        return None, {}

    refs = []
    state_refs = {}

    for entry in entries:
        cr_key = clean_text(entry.get("source_id"))

        if not cr_key:
            continue

        cr_key = cr_key.upper()
        existing = CR_EXISTING_BY_SOURCE_ID.get(cr_key)

        if not existing:
            skipped_columns.append({
                "source_column": "Affected CR",
                "reason": f"Existing Change Request not found by {CR_SOURCE_ID_FIELD_NAME}: {cr_key}. Creation skipped.",
                "sample_value": entry.get("raw")
            })
            continue

        refs.append((existing["id"], existing["name"]))
        state_refs[cr_key] = existing["id"]

        logger.info(
            "Resolved Affected CR: %s -> Codebeamer item_id=%s | target_field='%s'",
            cr_key,
            existing["id"],
            matched_field_name
        )

    fv = build_reference_field_value(field_meta, refs)

    return fv, state_refs


def build_previous_spec_reference(row, aems_sdt_fields, skipped_columns):
    raw_value = get_source_value(row, "Previous Specification Version")
    prev_id, prev_title = extract_id_title(raw_value)

    if not prev_id:
        return None, {}

    prev_key = prev_id.upper()

    field_meta = aems_sdt_fields.get(normalize_name("Previous Specification Version"))

    if not field_meta:
        skipped_columns.append({
            "source_column": "Previous Specification Version",
            "reason": "Target field 'Previous Specification Version' not found",
            "sample_value": clean_text(raw_value)
        })
        return None, {}

    found = AEMS_SDT_EXISTING_BY_SBM_SDT_ID.get(prev_key)

    if not found:
        skipped_columns.append({
            "source_column": "Previous Specification Version",
            "reason": f"Previous specification not found by SBM SDT Id {prev_key}. Run script again after all SDTs are created.",
            "sample_value": clean_text(raw_value)
        })
        return None, {}

    fv = build_reference_field_value(field_meta, [(found["id"], found["name"])])

    return fv, {prev_key: found["id"]}


def build_reference_field_values(cb, row, aems_sdt_fields, tag_tracker_fields, skipped_columns):
    field_values = []
    refs_for_state = {}

    associated_tags_fv, tag_state_refs = build_associated_tags_reference(
        cb=cb,
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    if associated_tags_fv:
        field_values.append(associated_tags_fv)
        refs_for_state["Associated Tags"] = tag_state_refs

    affected_cr_fv, affected_cr_refs = build_affected_cr_reference(
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        skipped_columns=skipped_columns
    )

    if affected_cr_fv:
        field_values.append(affected_cr_fv)
        refs_for_state["Affected CR"] = affected_cr_refs

    previous_spec_fv, previous_spec_refs = build_previous_spec_reference(
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        skipped_columns=skipped_columns
    )

    if previous_spec_fv:
        field_values.append(previous_spec_fv)
        refs_for_state["Previous Specification Version"] = previous_spec_refs

    for rule in REFERENCE_RULES:
        raw_value = get_source_value(row, rule["source_logical"])

        if is_blank(raw_value):
            continue

        if rule.get("model_delivery"):
            one = normalize_model_delivery_value(raw_value)
            source_values = [one] if one else []
        elif rule.get("multi_value"):
            source_values = split_multi_values(raw_value)
        else:
            one = clean_text(raw_value)
            source_values = [one] if one else []

        if not source_values:
            continue

        field_meta = aems_sdt_fields.get(normalize_name(rule["target_field"]))

        if not field_meta:
            skipped_columns.append({
                "source_column": rule["source_logical"],
                "reason": f"Target reference field '{rule['target_field']}' not found",
                "sample_value": clean_text(raw_value)
            })
            continue

        refs = []
        state_map = {}

        for source_value in source_values:
            if rule.get("model_delivery"):
                child_id, child_name, created = get_or_create_model_delivery_item(
                    cb=cb,
                    source_value=source_value
                )
            else:
                child_id, child_name, created = get_or_create_reference_by_name(
                    cb=cb,
                    tracker_id=rule["target_tracker_id"],
                    tracker_name=rule["target_tracker_name"],
                    source_value=source_value,
                    create_missing=rule.get("create_missing", False)
                )

            if not child_id:
                skipped_columns.append({
                    "source_column": rule["source_logical"],
                    "reason": f"Reference value not resolved in {rule['target_tracker_name']}: {source_value}",
                    "sample_value": clean_text(raw_value)
                })
                continue

            refs.append((child_id, child_name))
            state_map[source_value] = child_id

            logger.info(
                "Reference %s: source_field=%s | tracker=%s | value=%s | child_id=%s",
                "created" if created else "reused",
                rule["source_logical"],
                rule["target_tracker_name"],
                source_value,
                child_id
            )

        fv = build_reference_field_value(field_meta, refs)

        if fv:
            field_values.append(fv)
            refs_for_state[rule["source_logical"]] = state_map

    return field_values, refs_for_state


# =========================================================
# ISSUE REVERSE LINK HANDLING
# =========================================================

def get_existing_reference_ids_from_item_field(cb, item_id, reference_field_name):
    existing_refs = []

    try:
        fields = load_item_fields_robust(cb, item_id)
    except Exception as ex:
        logger.warning(
            "Unable to read existing references. item_id=%s | field=%s | error=%s",
            item_id,
            reference_field_name,
            ex
        )
        return existing_refs

    target_key = normalize_name(reference_field_name)

    for fv in fields:
        if not isinstance(fv, dict):
            continue

        possible_names = [
            fv.get("name"),
            fv.get("fieldName"),
            fv.get("label"),
        ]

        field_obj = fv.get("field")
        if isinstance(field_obj, dict):
            possible_names.extend([
                field_obj.get("name"),
                field_obj.get("fieldName"),
                field_obj.get("label"),
            ])

        if not any(normalize_name(x) == target_key for x in possible_names if x):
            continue

        values = fv.get("values") or []

        for val in values:
            if isinstance(val, dict) and val.get("id"):
                existing_refs.append((
                    int(val.get("id")),
                    val.get("name") or str(val.get("id"))
                ))

    return existing_refs


def link_aems_specification_on_issue(
    cb,
    issue_item_id,
    issue_tracker_fields,
    aems_sdt_item_id,
    aems_sdt_title,
    skipped_columns
):
    field_meta = issue_tracker_fields.get(normalize_name(ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME))

    if not field_meta:
        skipped_columns.append({
            "source_column": "Affected Issues",
            "reason": f"Issue tracker field '{ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME}' not found",
            "sample_value": aems_sdt_title
        })

        logger.warning(
            "Cannot link A-EMS Specification to Issue because Issue field '%s' was not found.",
            ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME
        )

        return False

    existing_refs = get_existing_reference_ids_from_item_field(
        cb=cb,
        item_id=issue_item_id,
        reference_field_name=ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME
    )

    merged_refs = existing_refs + [(aems_sdt_item_id, aems_sdt_title)]

    fv = build_reference_field_value(field_meta, merged_refs)

    if not fv:
        return False

    update_item_fields(cb, issue_item_id, [fv])

    logger.info(
        "Linked A-EMS Specification item_id=%s to Issue item_id=%s field='%s'",
        aems_sdt_item_id,
        issue_item_id,
        ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME
    )

    return True


def process_affected_issues_reverse_links(
    cb,
    row,
    issue_tracker_fields,
    aems_sdt_item_id,
    aems_sdt_title,
    skipped_columns
):
    raw_value = get_source_value(row, "Affected Issues")
    entries = extract_entries_with_prefix(raw_value, r"\b(IS\d+)\b")

    if not entries:
        logger.info("No Affected Issues found for A-EMS Specification item_id=%s", aems_sdt_item_id)
        return {}

    linked_refs = {}

    for entry in entries:
        issue_key = clean_text(entry.get("source_id"))

        if not issue_key:
            continue

        issue_key = issue_key.upper()

        logger.info(
            "Processing Affected Issue reverse link. raw='%s' | extracted_issue_id='%s'",
            entry.get("raw"),
            issue_key
        )

        existing_issue = find_issue_in_tracker_by_sbm_item_id(
            cb=cb,
            issue_key=issue_key
        )

        if not existing_issue:
            skipped_columns.append({
                "source_column": "Affected Issues",
                "reason": (
                    f"Existing Issue not found in Issue tracker by "
                    f"{ISSUE_SOURCE_ID_FIELD_NAME}: {issue_key}. "
                    "Issue creation skipped as per current scope."
                ),
                "sample_value": entry.get("raw")
            })

            logger.warning(
                "Skipped Issue reverse link because Issue was not found by %s=%s",
                ISSUE_SOURCE_ID_FIELD_NAME,
                issue_key
            )

            continue

        linked = link_aems_specification_on_issue(
            cb=cb,
            issue_item_id=existing_issue["id"],
            issue_tracker_fields=issue_tracker_fields,
            aems_sdt_item_id=aems_sdt_item_id,
            aems_sdt_title=aems_sdt_title,
            skipped_columns=skipped_columns
        )

        if linked:
            linked_refs[issue_key] = existing_issue["id"]

    return linked_refs


# =========================================================
# DESCRIPTION
# =========================================================

def build_description(row):
    lines = []

    src_id = get_sdt_source_id(row)
    spec_version = get_source_text(row, "Spec Version")
    classification = get_source_text(row, "Classification")
    previous_spec = get_source_text(row, "Previous Specification Version")
    affected_cr = get_source_text(row, "Affected CR")
    affected_issues = get_source_text(row, "Affected Issues")
    associated_attachments = get_source_text(row, "Associated Attachments")

    if src_id:
        lines.append(f"Source SBM SDT Id: {src_id}")

    if spec_version:
        lines.append(f"Spec Version: {spec_version}")

    if classification:
        lines.append(f"Classification: {classification}")

    if previous_spec:
        lines.append(f"Previous Specification Version: {previous_spec}")

    if affected_cr:
        lines.append("")
        lines.append("Affected CR:")
        lines.append(affected_cr)

    if affected_issues:
        lines.append("")
        lines.append("Affected Issues:")
        lines.append(affected_issues)

    if associated_attachments:
        lines.append("")
        lines.append("Associated Attachments:")
        lines.append(associated_attachments)

    return "\n".join(lines).strip() if lines else None


# =========================================================
# CREATE / UPDATE SDT
# =========================================================

def create_aems_sdt_item(cb, row, aems_sdt_fields, tag_tracker_fields, skipped_columns):
    title = get_sdt_title(row)

    payload = {
        "name": title,
        "descriptionFormat": "PlainText",
        "description": build_description(row)
    }

    mandatory_values = build_mandatory_create_fields(
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        skipped_columns=skipped_columns
    )

    scalar_values = build_scalar_field_values(
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        skipped_columns=skipped_columns
    )

    ref_values, refs_for_state = build_reference_field_values(
        cb=cb,
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    custom_fields = mandatory_values + scalar_values + ref_values

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    logger.info("Creating A-EMS Specification with title='%s'", title)

    created = cb.post(f"/v3/trackers/{AEMS_SDT_TRACKER_ID}/items", payload)

    return created["id"], created, refs_for_state


def update_aems_sdt_item(cb, item_id, row, aems_sdt_fields, tag_tracker_fields, skipped_columns):
    src_id = get_sdt_source_id(row)

    scalar_values = build_scalar_field_values(
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        skipped_columns=skipped_columns
    )

    ref_values, refs_for_state = build_reference_field_values(
        cb=cb,
        row=row,
        aems_sdt_fields=aems_sdt_fields,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    candidate_fields = scalar_values + ref_values

    if candidate_fields:
        update_item_fields(cb, item_id, candidate_fields)
        changed_count = len(candidate_fields)
    else:
        changed_count = 0

    CHANGE_AUDIT_ROWS.append({
        "object_type": "AEMS_SDT",
        "source_item_id": src_id,
        "codebeamer_item_id": item_id,
        "field_name": None,
        "old_value": None,
        "new_value": None,
        "action": "UPDATED_FIELDS" if changed_count else "NO_CHANGE"
    })

    return refs_for_state, changed_count


# =========================================================
# EXISTING SDT FINDERS
# =========================================================

def find_existing_aems_sdt_by_sbm_sdt_id(src_key):
    if not src_key:
        return None

    key = clean_text(src_key)

    if not key:
        return None

    key = key.upper()

    existing = AEMS_SDT_EXISTING_BY_SBM_SDT_ID.get(key)

    if existing:
        logger.info("Existing A-EMS Specification found by SBM SDT Id cache: %s -> item_id=%s", key, existing.get("id"))
        return existing.get("id")

    logger.info("No existing A-EMS Specification found by SBM SDT Id cache: %s", key)
    return None


def live_find_existing_aems_sdt_by_sbm_sdt_id(cb, src_key, page_size=500):
    if not src_key:
        return None

    expected_key = clean_text(src_key)

    if not expected_key:
        return None

    expected_key = expected_key.upper()

    logger.info("Live lookup started for existing A-EMS Specification by %s=%s", AEMS_SDT_SOURCE_ID_FIELD_NAME, expected_key)

    page = 1

    while True:
        payload = {
            "queryString": f"tracker.id IN ({AEMS_SDT_TRACKER_ID})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Live lookup failed while querying A-EMS Specification. source=%s | error=%s", expected_key, ex)
            return None

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            fields = load_item_fields_robust(cb, item_id)

            sbm_sdt_id = extract_field_value_by_name_from_fields(
                fields,
                AEMS_SDT_SOURCE_ID_FIELD_NAME
            )

            if not sbm_sdt_id:
                continue

            found_key = clean_text(sbm_sdt_id).upper()

            if found_key == expected_key:
                item_name = extract_item_name_from_query_item(item_ref) or str(item_id)

                AEMS_SDT_EXISTING_BY_SBM_SDT_ID[expected_key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": f"LIVE_LOOKUP_{AEMS_SDT_SOURCE_ID_FIELD_NAME}"
                }

                logger.info("Live lookup found existing A-EMS Specification: %s=%s -> item_id=%s", AEMS_SDT_SOURCE_ID_FIELD_NAME, expected_key, item_id)

                return int(item_id)

        if len(items) < page_size:
            break

        page += 1

    logger.info("Live lookup did not find existing A-EMS Specification for %s=%s", AEMS_SDT_SOURCE_ID_FIELD_NAME, expected_key)

    return None


# =========================================================
# MAIN PASS
# =========================================================

def pass_create_or_update_aems_sdt(
    cb,
    df,
    state,
    aems_sdt_fields,
    tag_tracker_fields,
    issue_tracker_fields,
    skipped_columns,
    failed_rows
):
    logger.info("PASS: create/update A-EMS Specification items using SBM SDT Id lookup")

    for idx, row in df.iterrows():
        src_id = get_sdt_source_id(row)
        src_key = src_id.upper() if src_id else None
        title = get_sdt_title(row)

        if not src_key:
            failed_rows.append({
                "row_index": idx,
                "source_item_id": None,
                "title": title,
                "phase": "SOURCE_VALIDATION",
                "error": "Missing source Item Id"
            })
            continue

        try:
            cb_id = None
            result_mode = None
            refs_for_state = None
            changed_count = 0

            existing_id = find_existing_aems_sdt_by_sbm_sdt_id(src_key)

            if not existing_id:
                existing_id = live_find_existing_aems_sdt_by_sbm_sdt_id(
                    cb=cb,
                    src_key=src_key
                )

            if existing_id:
                is_valid, reason = validate_existing_item_in_tracker(
                    cb=cb,
                    item_id=existing_id,
                    expected_tracker_id=AEMS_SDT_TRACKER_ID
                )

                if not is_valid:
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "EXISTING_AEMS_SDT_VALIDATION",
                        "error": reason,
                        "aems_sdt_id": existing_id
                    })
                    continue

                cb_id = int(existing_id)

                refs_for_state, changed_count = update_aems_sdt_item(
                    cb=cb,
                    item_id=cb_id,
                    row=row,
                    aems_sdt_fields=aems_sdt_fields,
                    tag_tracker_fields=tag_tracker_fields,
                    skipped_columns=skipped_columns
                )

                result_mode = "UPDATED_EXISTING_AEMS_SDT" if changed_count else "NO_CHANGE_EXISTING_AEMS_SDT"

            if not cb_id:
                cb_id, _, refs_for_state = create_aems_sdt_item(
                    cb=cb,
                    row=row,
                    aems_sdt_fields=aems_sdt_fields,
                    tag_tracker_fields=tag_tracker_fields,
                    skipped_columns=skipped_columns
                )

                result_mode = "CREATED_AEMS_SDT"

                AEMS_SDT_EXISTING_BY_SBM_SDT_ID[src_key] = {
                    "id": int(cb_id),
                    "name": title,
                    "matched_by": "created"
                }

                CHANGE_AUDIT_ROWS.append({
                    "object_type": "AEMS_SDT",
                    "source_item_id": src_id,
                    "codebeamer_item_id": cb_id,
                    "field_name": None,
                    "old_value": None,
                    "new_value": None,
                    "action": "CREATED_AEMS_SDT"
                })

                logger.info("Created A-EMS Specification item: source=%s -> cb_id=%s", src_id, cb_id)

            affected_issue_refs = process_affected_issues_reverse_links(
                cb=cb,
                row=row,
                issue_tracker_fields=issue_tracker_fields,
                aems_sdt_item_id=cb_id,
                aems_sdt_title=title,
                skipped_columns=skipped_columns
            )

            if affected_issue_refs:
                if refs_for_state is None:
                    refs_for_state = {}

                refs_for_state["Issue -> Impacted Specification"] = affected_issue_refs

            update_state_entry(
                state=state,
                src_key=src_key,
                cb_id=cb_id,
                title=title,
                status=result_mode,
                refs=refs_for_state
            )

            logger.info("A-EMS Specification result: source=%s -> cb_id=%s | %s", src_id, cb_id, result_mode)

        except Exception as ex:
            logger.exception("Failed for A-EMS Specification source=%s", src_id)

            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "AEMS_SDT_CREATE_UPDATE",
                "error": str(ex)
            })

        if idx % 10 == 0:
            save_state(STATE_FILE_CSV, state)

    save_state(STATE_FILE_CSV, state)


# =========================================================
# REPORTS
# =========================================================

def write_reports(df, state, failed_rows, skipped_columns):
    refreshed_rows = []

    for _, row in df.iterrows():
        src_id = get_sdt_source_id(row)

        if not src_id:
            continue

        st = state.get(src_id.upper(), {})

        refreshed_rows.append({
            "source_sdt_id": src_id,
            "aems_sdt_codebeamer_item_id": st.get("aems_sdt_codebeamer_item_id"),
            "title": st.get("title") or get_sdt_title(row),
            "status": st.get("status"),
            "refs_json": st.get("refs_json"),
        })

    if refreshed_rows:
        pd.DataFrame(refreshed_rows).to_csv(CREATED_MAP_CSV, index=False, encoding="utf-8-sig")
        logger.info("Created/updated map written: %s", CREATED_MAP_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(FAILED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.info("Failed rows report written: %s", FAILED_ROWS_CSV)
    else:
        logger.info("No failed rows.")

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates(
            subset=["source_column", "reason", "sample_value"]
        ).to_csv(SKIPPED_COLUMNS_REPORT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Skipped columns report written: %s", SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("No skipped columns.")

    if CHANGE_AUDIT_ROWS:
        pd.DataFrame(CHANGE_AUDIT_ROWS).to_csv(CHANGE_AUDIT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Change audit report written: %s", CHANGE_AUDIT_CSV)
    else:
        logger.info("No change audit rows.")


# =========================================================
# MAIN
# =========================================================

def main():
    validate_config()

    logger.info("Loading local state for reporting continuity only...")
    state = load_state(STATE_FILE_CSV)

    logger.info("Connecting to MySQL...")

    conn_url = URL.create(
        "mysql+mysqlconnector",
        username=MYSQL_USER,
        password=MYSQL_PASS,
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        database=MYSQL_DB,
        query={"charset": "utf8mb4"}
    )

    engine = create_engine(conn_url)

    logger.info("Reading source rows from MySQL table: %s", TABLE_NAME)

    df = pd.read_sql(text(SOURCE_SQL), engine)

    if df.empty:
        logger.info("No source rows found. Exiting.")
        return

    df = df.astype(object).where(pd.notna(df), None)

    logger.info("Loaded %s A-EMS Specification rows.", len(df))

    required_logical_columns = [
        "Item Id",
        "Spec Version",
    ]

    missing_logical = []

    for logical in required_logical_columns:
        aliases = SOURCE_ALIASES.get(logical, [logical])

        if not any(a in df.columns for a in aliases):
            missing_logical.append(logical)

    if missing_logical:
        raise RuntimeError(
            f"Missing required source columns in SQL result: {missing_logical}. "
            f"Available columns: {list(df.columns)}"
        )

    logger.info("Connecting to Codebeamer...")

    cb = CodebeamerClient(
        CB_BASE_URL,
        CB_USER,
        CB_PASS,
        verify_ssl=VERIFY_SSL,
        timeout=TIMEOUT
    )

    logger.info("Loading A-EMS Specification tracker fields...")
    aems_sdt_fields = load_tracker_fields(cb, AEMS_SDT_TRACKER_ID)

    log_field_debug(aems_sdt_fields, "Status")
    log_field_debug(aems_sdt_fields, "Assigned to")
    log_field_debug(aems_sdt_fields, AEMS_SDT_SOURCE_ID_FIELD_NAME)
    log_field_debug(aems_sdt_fields, "Spec Version")
    log_field_debug(aems_sdt_fields, "Metier Delivery")
    log_field_debug(aems_sdt_fields, "Previous Specification Version")
    log_field_debug(aems_sdt_fields, "Classification")
    log_field_debug(aems_sdt_fields, "Associated Tags")
    log_field_debug(aems_sdt_fields, "New or Evolution?")
    log_field_debug(aems_sdt_fields, "Affected CR")
    log_field_debug(aems_sdt_fields, "SW Project")
    log_field_debug(aems_sdt_fields, "SW Item Type")
    log_field_debug(aems_sdt_fields, "ASIL Level")
    log_field_debug(aems_sdt_fields, "Active/Inactive")
    log_field_debug(aems_sdt_fields, MIGRATED_DATA_FIELD_NAME)

    logger.info("Loading Tag Management tracker fields...")
    tag_tracker_fields = load_tracker_fields(cb, TAG_MANAGEMENT_TRACKER_ID)

    log_field_debug(tag_tracker_fields, TAG_SOURCE_ID_FIELD_NAME)

    logger.info("Loading Issue tracker fields...")
    issue_tracker_fields = load_tracker_fields(cb, ISSUE_MANAGEMENT_TRACKER_ID)

    log_field_debug(issue_tracker_fields, ISSUE_SOURCE_ID_FIELD_NAME)
    log_field_debug(issue_tracker_fields, ISSUE_IMPACTED_SPECIFICATION_FIELD_NAME)

    logger.info("Scanning existing A-EMS Specification items by SBM SDT Id...")
    scan_existing_items_by_field(
        cb=cb,
        tracker_id=AEMS_SDT_TRACKER_ID,
        tracker_name=AEMS_SDT_TRACKER_NAME,
        field_name=AEMS_SDT_SOURCE_ID_FIELD_NAME,
        target_cache=AEMS_SDT_EXISTING_BY_SBM_SDT_ID
    )

    logger.info("Scanning existing Tag Management items...")
    scan_existing_tag_items(cb=cb)

    logger.info("Scanning existing Change Request items by SBM CR Id...")
    scan_existing_items_by_field(
        cb=cb,
        tracker_id=CR_MANAGEMENT_TRACKER_ID,
        tracker_name=CR_MANAGEMENT_TRACKER_NAME,
        field_name=CR_SOURCE_ID_FIELD_NAME,
        target_cache=CR_EXISTING_BY_SOURCE_ID
    )

    logger.info("Scanning Model Delivery tracker by name...")
    scan_existing_reference_tracker_by_name(
        cb=cb,
        tracker_id=MODEL_DELIVERY_TRACKER_ID,
        tracker_name=MODEL_DELIVERY_TRACKER_NAME
    )

    skipped_columns = []
    failed_rows = []

    used_logical = set(SAFE_SCALAR_MAPPING.keys())
    used_logical.add("Associated Tags")
    used_logical.add("Affected CR")
    used_logical.add("Affected Issues")
    used_logical.add("Previous Specification Version")

    for r in REFERENCE_RULES:
        used_logical.add(r["source_logical"])

    used_actual_columns = set()

    for logical in used_logical:
        for alias in SOURCE_ALIASES.get(logical, [logical]):
            used_actual_columns.add(alias)

    for logical in [
        "Spec Version",
        "Associated Attachments",
        "State",
    ]:
        for alias in SOURCE_ALIASES.get(logical, [logical]):
            used_actual_columns.add(alias)

    for col in df.columns:
        if col not in used_actual_columns:
            skipped_columns.append({
                "source_column": col,
                "reason": "Not mapped for current A-EMS Specification migration scope",
                "sample_value": first_non_null_sample(df, col)
            })

    pass_create_or_update_aems_sdt(
        cb=cb,
        df=df,
        state=state,
        aems_sdt_fields=aems_sdt_fields,
        tag_tracker_fields=tag_tracker_fields,
        issue_tracker_fields=issue_tracker_fields,
        skipped_columns=skipped_columns,
        failed_rows=failed_rows
    )

    save_state(STATE_FILE_CSV, state)

    write_reports(
        df=df,
        state=state,
        failed_rows=failed_rows,
        skipped_columns=skipped_columns
    )

    logger.info("A-EMS Specification sync completed successfully.")


if __name__ == "__main__":
    main()

