import re
import os
import json
import time
import logging
import mimetypes

import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL


# =========================================================
# CONFIGURATION
# =========================================================

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"

TABLE_NAME = "sbm_tag"

SOURCE_SQL = f"""
SELECT *
FROM `{TABLE_NAME}`
-- WHERE `Item Id` = 'TGM100879'
-- LIMIT 10
"""

CB_BASE_URL = "https://hnjhyvdi24.tatatechnologies.com:7443/cb/api"
CB_USER = "cbadmin"
CB_PASS = "cbadmin"

VERIFY_SSL = True
TIMEOUT = 20
SLEEP_BETWEEN_REQUESTS_SEC = 0.0

PROJECT_ID = 48

TAG_MANAGEMENT_TRACKER_ID = 293706
TAG_MANAGEMENT_TRACKER_NAME = "Tag Management"

TAG_ITEM_TYPE_TRACKER_ID = 348582
TAG_ITEM_TYPE_TRACKER_NAME = "Tag Item Type"

TAG_HIGH_LEVEL_TRACKER_ID = 348921
TAG_HIGH_LEVEL_TRACKER_NAME = "Tag High Level"

TAG_MIDDLE_LEVEL_TRACKER_ID = 348791
TAG_MIDDLE_LEVEL_TRACKER_NAME = "Tag Middle Level"

TAG_BOTTOM_LEVEL_TRACKER_ID = 348744
TAG_BOTTOM_LEVEL_TRACKER_NAME = "Tag Bottom Level"

MODEL_DELIVERY_TRACKER_ID = 293885
MODEL_DELIVERY_TRACKER_NAME = "Model Delivery"

SOURCE_KEY_COLUMN = "Item Id"
SOURCE_TITLE_COLUMN = "Title"

SBM_TAG_ID_FIELD_NAME = "SBM Tag Id"

MIGRATED_DATA_FIELD_NAME = "Migrated Data ?"
MIGRATED_DATA_VALUE = "Yes"

CREATED_MAP_CSV = "created_updated_tag_management.csv"
FAILED_ROWS_CSV = "failed_rows_tag_management.csv"
SKIPPED_COLUMNS_REPORT_CSV = "skipped_columns_tag_management.csv"
CHANGE_AUDIT_CSV = "changed_fields_tag_management.csv"
DUPLICATE_SOURCE_ROWS_CSV = "duplicate_source_rows_tag_management.csv"
DUPLICATE_EXISTING_TAGS_CSV = "duplicate_existing_tag_management_by_sbm_tag_id.csv"
ROW_ATTACHMENT_REPORT_CSV = "row_attachments_tag_management.csv"

LOG_FILE = "codebeamer_tag_management_import.log"
RUN_LOCK_FILE = "codebeamer_tag_management_import.lock"

ATTACH_SOURCE_ROW_EXCEL = True
ATTACH_CREATED_EXCEL_TO_TAG = True
ATTACH_EXCEL_TO_EXISTING_TAG = True
ATTACH_ROW_EXCEL_EVEN_IF_NO_CHANGE = True
DELETE_ROW_EXCEL_AFTER_UPLOAD = False
PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT = True
TRUST_MANIFEST_TO_SKIP_ATTACHMENT = False
ATTACHMENT_DESCRIPTION_TEXT = "MySQL source row export attached during migration."
TAG_EXCEL_EXPORT_DIR = os.path.abspath("tag_source_row_exports")
ATTACHMENT_MANIFEST_CSV = "tag_excel_attachment_manifest.csv"
CB_ATTACHMENT_UPLOAD_PATH_TEMPLATE = "/v3/items/{item_id}/attachments"
CB_ATTACHMENT_LIST_PATH_TEMPLATE = "/v3/items/{item_id}/attachments"

SAFE_TAG_FIELD_MAPPING = {
    "Item Id": {
        "field": "SBM Tag Id"
    },
    "Tag Description": {
        "field": "Tag Description"
    },
    "Tag Classification": {
        "field": "Tag Classification",
        "kind": "choice_or_text"
    },
}

STATE_TO_CB_STATUS = {
    "Active": "Active",
    "ACTIVE": "Active",
    "active": "Active",
    "Inactive": "Inactive",
    "INACTIVE": "Inactive",
    "inactive": "Inactive",
    "InActive": "Inactive",
    "Obsolete": "Obsolete",
    "OBSOLETE": "Obsolete",
    "Draft": "Draft",
    "New": "New",
    "NEW": "New",
}

REFERENCE_RULES = [
    {
        "source_column": "Tag Item Type",
        "target_tracker_id": TAG_ITEM_TYPE_TRACKER_ID,
        "target_tracker_name": TAG_ITEM_TYPE_TRACKER_NAME,
        "tag_management_field": "Tag Item Type",
        "multi_value": False,
    },
    {
        "source_column": "Tag High Level",
        "target_tracker_id": TAG_HIGH_LEVEL_TRACKER_ID,
        "target_tracker_name": TAG_HIGH_LEVEL_TRACKER_NAME,
        "tag_management_field": "Tag High Level",
        "multi_value": False,
    },
    {
        "source_column": "Tag Middle Level",
        "target_tracker_id": TAG_MIDDLE_LEVEL_TRACKER_ID,
        "target_tracker_name": TAG_MIDDLE_LEVEL_TRACKER_NAME,
        "tag_management_field": "Tag Middle Level",
        "multi_value": False,
    },
    {
        "source_column": "Tag Bottom Level",
        "target_tracker_id": TAG_BOTTOM_LEVEL_TRACKER_ID,
        "target_tracker_name": TAG_BOTTOM_LEVEL_TRACKER_NAME,
        "tag_management_field": "Tag Bottom Level",
        "multi_value": False,
    },
    {
        "source_column": "Introduction MD",
        "target_tracker_id": MODEL_DELIVERY_TRACKER_ID,
        "target_tracker_name": MODEL_DELIVERY_TRACKER_NAME,
        "tag_management_field": "Introduction MD",
        "multi_value": False,
        "model_delivery": True,
    },
    {
        "source_column": "Obsolescence MD",
        "target_tracker_id": MODEL_DELIVERY_TRACKER_ID,
        "target_tracker_name": MODEL_DELIVERY_TRACKER_NAME,
        "tag_management_field": "Obsolescence MD",
        "multi_value": False,
        "model_delivery": True,
    },
]

PRECREATE_MODEL_DELIVERY_VALUES = [f"MD{i:02d}" for i in range(1, 43)]


# =========================================================
# LOGGING
# =========================================================

def setup_logging():
    logger_obj = logging.getLogger("cb_tag_management_sync")
    logger_obj.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.setLevel(logging.INFO)

    logger_obj.handlers.clear()
    logger_obj.addHandler(fh)
    logger_obj.addHandler(ch)

    return logger_obj


logger = setup_logging()


# =========================================================
# BASIC HELPERS
# =========================================================

def normalize_name(s):
    return re.sub(r"\s+", " ", str(s).strip()).lower()


def normalize_cache_key(s):
    return re.sub(r"\s+", "", str(s).strip()).lower()


def is_blank(v):
    if v is None:
        return True

    try:
        if pd.isna(v):
            return True
    except Exception:
        pass

    if isinstance(v, str):
        s = v.strip()
        if s in ("", "(None)", "None", "nan", "NaN", "--", "null", "NULL"):
            return True

    return False


def clean_text(v):
    if is_blank(v):
        return None

    s = str(v).replace("\r", "").replace("_x000D_", "").strip()
    return s if s else None


SOURCE_COLUMN_ALIASES = {
    "Item Id": ["Item Id", "Item_Id", "ITEM_ID", "ItemId", "ITEMID"],
    "Title": ["Title", "TITLE", "Name", "NAME"],
    "Tag Item Type": ["Tag Item Type", "Tag_Item_Type", "TAG_ITEM_TYPE"],
    "Tag High Level": ["Tag High Level", "Tag_High_Level", "TAG_HIGH_LEVEL"],
    "Tag Middle Level": ["Tag Middle Level", "Tag_Middle_Level", "TAG_MIDDLE_LEVEL"],
    "Tag Bottom Level": ["Tag Bottom Level", "Tag_Bottom_Level", "TAG_BOTTOM_LEVEL"],
    "Tag Description": ["Tag Description", "Tag_Description", "TAG_DESCRIPTION"],
    "State": ["State", "STATE", "Status", "STATUS"],
    "Introduction MD": ["Introduction MD", "Introduction_MD", "INTRODUCTION_MD"],
    "Obsolescence MD": ["Obsolescence MD", "Obsolescence_MD", "OBSOLESCENCE_MD"],
    "Tag Classification": ["Tag Classification", "Tag_Classification", "TAG_CLASSIFICATION"],
}


def normalize_source_column_key(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def apply_source_schema_adapter(df):
    """Rename recognized source aliases to canonical names without changing MySQL schema."""
    if df is None or df.empty:
        return df

    normalized_actual = {normalize_source_column_key(c): c for c in df.columns}
    rename_map = {}

    for canonical, aliases in SOURCE_COLUMN_ALIASES.items():
        if canonical in df.columns:
            continue
        for alias in aliases:
            actual = normalized_actual.get(normalize_source_column_key(alias))
            if actual and actual not in rename_map:
                rename_map[actual] = canonical
                break

    if rename_map:
        logger.info("Source schema adapter rename map: %s", rename_map)
        df = df.rename(columns=rename_map)

    return df


def safe_sleep():
    if SLEEP_BETWEEN_REQUESTS_SEC and SLEEP_BETWEEN_REQUESTS_SEC > 0:
        time.sleep(SLEEP_BETWEEN_REQUESTS_SEC)


def split_values(v):
    txt = clean_text(v)

    if not txt:
        return []

    parts = [p.strip() for p in str(txt).split(",")]
    out = []
    seen = set()

    for p in parts:
        if is_blank(p):
            continue

        key = normalize_name(p)

        if key in seen:
            continue

        seen.add(key)
        out.append(p)

    return out


def normalize_model_delivery_value(v):
    txt = clean_text(v)

    if not txt:
        return None

    s = txt.strip().upper().replace(" ", "")
    m = re.fullmatch(r"MD0*([1-9]|[1-3][0-9]|4[0-2])", s)

    if not m:
        return None

    return f"MD{int(m.group(1)):02d}"


def first_non_null_sample(df, col):
    if col not in df.columns:
        return None

    ser = df[col].dropna()

    if ser.empty:
        return None

    return clean_text(ser.iloc[0])


def sanitize_filename_part(value, max_len=80):
    txt = clean_text(value) or "NA"
    txt = re.sub(r"[^\w\-\.]+", "_", txt, flags=re.UNICODE)
    txt = txt.strip("_")

    if not txt:
        txt = "NA"

    return txt[:max_len]


def validate_config():
    required_ids = {
        "TAG_MANAGEMENT_TRACKER_ID": TAG_MANAGEMENT_TRACKER_ID,
        "TAG_ITEM_TYPE_TRACKER_ID": TAG_ITEM_TYPE_TRACKER_ID,
        "TAG_HIGH_LEVEL_TRACKER_ID": TAG_HIGH_LEVEL_TRACKER_ID,
        "TAG_MIDDLE_LEVEL_TRACKER_ID": TAG_MIDDLE_LEVEL_TRACKER_ID,
        "TAG_BOTTOM_LEVEL_TRACKER_ID": TAG_BOTTOM_LEVEL_TRACKER_ID,
        "MODEL_DELIVERY_TRACKER_ID": MODEL_DELIVERY_TRACKER_ID,
    }

    missing = [k for k, v in required_ids.items() if not v or int(v) <= 0]

    if missing:
        raise RuntimeError("Please update tracker IDs before running: " + ", ".join(missing))


def log_field_debug(tracker_fields, field_name):
    meta = tracker_fields.get(normalize_name(field_name))

    if not meta:
        logger.warning("Field '%s' not found in tracker metadata", field_name)
        return

    logger.info(
        "Field debug | name=%s | id=%s | valueModel=%s | type=%s | options_count=%s",
        meta.get("name"),
        meta.get("id"),
        meta.get("valueModel"),
        meta.get("type"),
        len(meta.get("options") or [])
    )


# =========================================================
# RUN LOCK / SOURCE DEDUP
# =========================================================

def is_pid_running(pid):
    if not pid:
        return False
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except (TypeError, ValueError, OSError):
        return False


def read_pid_from_lock_file(lock_file):
    try:
        with open(lock_file, "r", encoding="utf-8") as f:
            match = re.search(r"^PID:\s*(\d+)\s*$", f.read(), flags=re.MULTILINE)
        return int(match.group(1)) if match else None
    except Exception:
        return None


def acquire_run_lock():
    if os.path.exists(RUN_LOCK_FILE):
        existing_pid = read_pid_from_lock_file(RUN_LOCK_FILE)
        if existing_pid and is_pid_running(existing_pid):
            raise RuntimeError(
                f"Another import is active. lock={RUN_LOCK_FILE}, pid={existing_pid}"
            )
        logger.warning("Removing stale/unreadable lock file: %s", RUN_LOCK_FILE)
        try:
            os.remove(RUN_LOCK_FILE)
        except OSError as ex:
            raise RuntimeError(f"Unable to remove stale lock file {RUN_LOCK_FILE}: {ex}") from ex

    with open(RUN_LOCK_FILE, "w", encoding="utf-8") as f:
        f.write(f"Started at: {pd.Timestamp.now()}\n")
        f.write(f"PID: {os.getpid()}\n")

    logger.info("Run lock acquired: %s", RUN_LOCK_FILE)

def release_run_lock():
    try:
        if os.path.exists(RUN_LOCK_FILE):
            os.remove(RUN_LOCK_FILE)
            logger.info("Run lock released: %s", RUN_LOCK_FILE)
    except Exception as ex:
        logger.warning("Unable to remove run lock file %s. Error=%s", RUN_LOCK_FILE, ex)


def deduplicate_source_rows_by_item_id(df):
    if SOURCE_KEY_COLUMN not in df.columns:
        return df

    df = df.copy()

    df["_normalized_source_key"] = df[SOURCE_KEY_COLUMN].apply(
        lambda x: clean_text(x).upper() if clean_text(x) else None
    )

    duplicate_mask = df.duplicated(subset=["_normalized_source_key"], keep="first")
    duplicate_count = int(duplicate_mask.sum())

    if duplicate_count > 0:
        duplicate_df = df.loc[duplicate_mask].drop(columns=["_normalized_source_key"])

        duplicate_df.to_csv(
            DUPLICATE_SOURCE_ROWS_CSV,
            index=False,
            encoding="utf-8-sig"
        )

        duplicate_keys = (
            df.loc[duplicate_mask, "_normalized_source_key"]
            .dropna()
            .unique()
            .tolist()
        )

        logger.warning(
            "Duplicate source rows found in MySQL result. duplicate_count=%s | duplicate_keys=%s",
            duplicate_count,
            duplicate_keys[:50]
        )

        logger.warning("Duplicate source row report written: %s", DUPLICATE_SOURCE_ROWS_CSV)

    df = df.drop_duplicates(subset=["_normalized_source_key"], keep="first")
    df = df.drop(columns=["_normalized_source_key"])

    return df


# =========================================================
# GLOBAL CACHES / REPORT ROWS
# =========================================================

TAG_MANAGEMENT_EXISTING_BY_SBM_ID = {}
DUPLICATE_EXISTING_TAG_ROWS = []

REFERENCE_ITEM_CACHE = {}
REFERENCE_TRACKER_EXISTING_CACHE = {}

CHANGE_AUDIT_ROWS = []
ROW_ATTACHMENT_ROWS = []
ROW_ATTACHMENT_CACHE = set()
ATTACHMENT_MANIFEST_ROWS = []
ATTACHMENT_MANIFEST_KEYS = set()

PROCESSED_SBM_TAG_IDS_THIS_RUN = set()


# =========================================================
# CODEBEAMER CLIENT
# =========================================================

class CodebeamerClient:
    def __init__(self, base_url, username, password, verify_ssl=True, timeout=60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.session.verify = verify_ssl
        self.session.headers.update({"Content-Type": "application/json"})

        retry = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )

        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _url(self, path):
        return f"{self.base_url}{path}"

    def get(self, path, params=None):
        safe_sleep()
        r = self.session.get(self._url(path), params=params, timeout=self.timeout)
        self._raise_for_status(r)
        return r.json()

    def post(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.post(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def put(self, path, payload=None, params=None):
        safe_sleep()
        r = self.session.put(
            self._url(path),
            params=params,
            data=json.dumps(payload or {}),
            timeout=self.timeout
        )
        self._raise_for_status(r)
        return r.json() if r.text.strip() else {}

    def post_multipart(self, path, files=None, data=None, params=None):
        """Send multipart/form-data without the session JSON Content-Type header."""
        safe_sleep()
        old_content_type = self.session.headers.pop("Content-Type", None)
        try:
            response = self.session.post(
                self._url(path),
                params=params,
                files=files,
                data=data or {},
                headers={"Accept": "application/json"},
                timeout=self.timeout
            )
            self._raise_for_status(response)
            return response.json() if response.text.strip() else {}
        finally:
            if old_content_type:
                self.session.headers["Content-Type"] = old_content_type

    @staticmethod
    def _raise_for_status(r):
        try:
            r.raise_for_status()
        except requests.HTTPError:
            raise RuntimeError(f"HTTP {r.status_code} | URL={r.url} | Response={r.text}")


# =========================================================
# CODEBEAMER DISCOVERY
# =========================================================

def load_tracker_fields(cb, tracker_id):
    refs = cb.get(f"/v3/trackers/{tracker_id}/fields")

    field_map = {}

    for ref in refs:
        fid = ref["id"]
        detail = cb.get(f"/v3/trackers/{tracker_id}/fields/{fid}")
        field_map[normalize_name(detail["name"])] = detail

    return field_map


def get_item_detail(cb, item_id):
    return cb.get(f"/v3/items/{item_id}")


def get_tracker_item_name(cb, item_id):
    try:
        item = get_item_detail(cb, item_id)
        return item.get("name") or str(item_id)
    except Exception:
        return str(item_id)


def load_item_fields_robust(cb, item_id):
    all_fields = []

    try:
        fields_response = cb.get(f"/v3/items/{item_id}/fields")

        if isinstance(fields_response, list):
            all_fields.extend(fields_response)

        elif isinstance(fields_response, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = fields_response.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load /fields for item_id=%s. Error=%s", item_id, ex)

    try:
        item_detail = cb.get(f"/v3/items/{item_id}")

        if isinstance(item_detail, dict):
            for key in ("fieldValues", "customFields", "fields"):
                val = item_detail.get(key)
                if isinstance(val, list):
                    all_fields.extend(val)

    except Exception as ex:
        logger.warning("Unable to load item detail fields for item_id=%s. Error=%s", item_id, ex)

    return all_fields


def extract_items_from_query_response(data):
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("items", "itemRefs", "results", "data"):
            val = data.get(key)
            if isinstance(val, list):
                return val

    return []


def extract_item_id_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("id", "itemId"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("id", "itemId"):
                value = nested.get(key)
                if value:
                    return value

    uri = item_ref.get("uri") or item_ref.get("url")

    if uri:
        m = re.search(r"/items/(\d+)", str(uri))
        if m:
            return int(m.group(1))

    return None


def extract_item_name_from_query_item(item_ref):
    if not isinstance(item_ref, dict):
        return None

    for key in ("name", "title"):
        value = item_ref.get(key)
        if value:
            return value

    for nested_key in ("item", "trackerItem", "reference", "itemRef"):
        nested = item_ref.get(nested_key)

        if isinstance(nested, dict):
            for key in ("name", "title"):
                value = nested.get(key)
                if value:
                    return value

    return None


def validate_existing_item_in_tracker(cb, item_id, expected_tracker_id):
    try:
        item = get_item_detail(cb, item_id)
    except Exception as ex:
        return False, f"Item {item_id} not accessible: {ex}"

    tracker = item.get("tracker") or {}
    tracker_id = tracker.get("id")

    if str(tracker_id) != str(expected_tracker_id):
        return False, f"Item {item_id} belongs to tracker {tracker_id}, expected {expected_tracker_id}"

    return True, "OK"


def extract_field_value_by_name_from_fields(field_values, field_name):
    target_key = normalize_name(field_name)

    if not isinstance(field_values, list):
        return None

    for fv in field_values:
        if not isinstance(fv, dict):
            continue

        possible_names = [
            fv.get("name"),
            fv.get("fieldName"),
            fv.get("label"),
        ]

        field_obj = fv.get("field")
        if isinstance(field_obj, dict):
            possible_names.extend([
                field_obj.get("name"),
                field_obj.get("fieldName"),
                field_obj.get("label"),
            ])

        if not any(normalize_name(x) == target_key for x in possible_names if x):
            continue

        if fv.get("value") is not None:
            val = fv.get("value")

            if isinstance(val, dict):
                return clean_text(
                    val.get("name")
                    or val.get("value")
                    or val.get("text")
                    or val.get("label")
                    or val.get("id")
                )

            return clean_text(val)

        if fv.get("text") is not None:
            return clean_text(fv.get("text"))

        values = fv.get("values")

        if isinstance(values, list) and values:
            names = []

            for item in values:
                if isinstance(item, dict):
                    names.append(
                        clean_text(
                            item.get("name")
                            or item.get("value")
                            or item.get("text")
                            or item.get("label")
                            or item.get("id")
                        )
                    )
                else:
                    names.append(clean_text(item))

            names = [x for x in names if x]

            if names:
                return ", ".join(names)

    return None


def extract_tgm_id_from_any_payload(*payloads, expected_key=None):
    combined = ""

    for payload in payloads:
        if payload is None:
            continue

        try:
            combined += " " + json.dumps(payload, ensure_ascii=False)
        except Exception:
            combined += " " + str(payload)

    if expected_key:
        expected_key = clean_text(expected_key).upper()
        pattern = rf"\b{re.escape(expected_key)}\b"
        if re.search(pattern, combined, flags=re.IGNORECASE):
            return expected_key
        return None

    m = re.search(r"\b(TGM\d+)\b", combined, flags=re.IGNORECASE)

    if m:
        return m.group(1).upper()

    return None


# =========================================================
# EXISTING TAG LOOKUP
# =========================================================

def scan_existing_tag_management_items_by_sbm_tag_id(cb, page_size=500):
    logger.info("Scanning existing Tag Management items by field '%s'...", SBM_TAG_ID_FIELD_NAME)

    TAG_MANAGEMENT_EXISTING_BY_SBM_ID.clear()
    DUPLICATE_EXISTING_TAG_ROWS.clear()

    page = 1
    total_loaded = 0
    total_cached = 0
    total_without_sbm_id = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({TAG_MANAGEMENT_TRACKER_ID})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query existing Tag Management items. Error=%s", ex)
            return

        items = extract_items_from_query_response(data)

        logger.info(
            "Existing Tag Management query page=%s returned %s item(s)",
            page,
            len(items)
        )

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                logger.warning("Unable to extract item id from query item: %s", item_ref)
                continue

            item_name = extract_item_name_from_query_item(item_ref) or str(item_id)
            fields = load_item_fields_robust(cb, item_id)

            try:
                item_detail = get_item_detail(cb, item_id)
            except Exception:
                item_detail = {}

            total_loaded += 1

            sbm_tag_id = extract_field_value_by_name_from_fields(fields, SBM_TAG_ID_FIELD_NAME)

            if not sbm_tag_id:
                sbm_tag_id = extract_tgm_id_from_any_payload(
                    item_ref,
                    fields,
                    item_detail
                )

            if not sbm_tag_id:
                total_without_sbm_id += 1
                logger.warning(
                    "Existing Tag item has no readable '%s'. item_id=%s | name=%s",
                    SBM_TAG_ID_FIELD_NAME,
                    item_id,
                    item_name
                )
                continue

            key = clean_text(sbm_tag_id).upper()

            if not key:
                total_without_sbm_id += 1
                continue

            if key not in TAG_MANAGEMENT_EXISTING_BY_SBM_ID:
                TAG_MANAGEMENT_EXISTING_BY_SBM_ID[key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": SBM_TAG_ID_FIELD_NAME
                }

                total_cached += 1

                logger.info(
                    "Cached existing Tag by %s: %s -> item_id=%s",
                    SBM_TAG_ID_FIELD_NAME,
                    key,
                    item_id
                )

            else:
                existing = TAG_MANAGEMENT_EXISTING_BY_SBM_ID[key]

                DUPLICATE_EXISTING_TAG_ROWS.append({
                    "sbm_tag_id": key,
                    "cached_item_id": existing.get("id"),
                    "duplicate_item_id": item_id,
                    "cached_item_name": existing.get("name"),
                    "duplicate_item_name": item_name,
                    "action": "DUPLICATE_FOUND_EXISTING_CODEBEAMER"
                })

                logger.warning(
                    "Duplicate Tag Management item found for %s=%s. Cached=%s duplicate=%s",
                    SBM_TAG_ID_FIELD_NAME,
                    key,
                    existing.get("id"),
                    item_id
                )

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "Tag Management scan completed. loaded=%s | cached=%s | without_%s=%s | duplicates=%s",
        total_loaded,
        total_cached,
        SBM_TAG_ID_FIELD_NAME,
        total_without_sbm_id,
        len(DUPLICATE_EXISTING_TAG_ROWS)
    )


def find_existing_tag_by_sbm_tag_id(src_key):
    if not src_key:
        return None

    key = clean_text(src_key)

    if not key:
        return None

    key = key.upper()

    existing = TAG_MANAGEMENT_EXISTING_BY_SBM_ID.get(key)

    if existing:
        logger.info("Existing Tag found by SBM Tag Id cache: %s -> item_id=%s", key, existing.get("id"))
        return existing.get("id")

    logger.info("No existing Tag found by SBM Tag Id cache: %s", key)
    return None


def live_find_existing_tag_by_sbm_tag_id(cb, src_key, page_size=500):
    if not src_key:
        return None

    expected_key = clean_text(src_key)

    if not expected_key:
        return None

    expected_key = expected_key.upper()

    logger.info(
        "Live lookup started for existing Tag by %s=%s",
        SBM_TAG_ID_FIELD_NAME,
        expected_key
    )

    page = 1

    while True:
        payload = {
            "queryString": f"tracker.id IN ({TAG_MANAGEMENT_TRACKER_ID})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning(
                "Live lookup failed while querying Tag Management. source=%s | error=%s",
                expected_key,
                ex
            )
            return None

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            fields = load_item_fields_robust(cb, item_id)

            try:
                item_detail = get_item_detail(cb, item_id)
            except Exception:
                item_detail = {}

            sbm_tag_id = extract_field_value_by_name_from_fields(fields, SBM_TAG_ID_FIELD_NAME)

            if not sbm_tag_id:
                sbm_tag_id = extract_tgm_id_from_any_payload(
                    item_ref,
                    fields,
                    item_detail,
                    expected_key=expected_key
                )

            if not sbm_tag_id:
                continue

            found_key = clean_text(sbm_tag_id).upper()

            if found_key == expected_key:
                item_name = extract_item_name_from_query_item(item_ref) or str(item_id)

                TAG_MANAGEMENT_EXISTING_BY_SBM_ID[expected_key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": f"LIVE_LOOKUP_{SBM_TAG_ID_FIELD_NAME}"
                }

                logger.info(
                    "Live lookup found existing Tag: %s=%s -> item_id=%s",
                    SBM_TAG_ID_FIELD_NAME,
                    expected_key,
                    item_id
                )

                return int(item_id)

        if len(items) < page_size:
            break

        page += 1

    logger.info(
        "Live lookup did not find existing Tag for %s=%s",
        SBM_TAG_ID_FIELD_NAME,
        expected_key
    )

    return None


# =========================================================
# COMPARISON HELPERS
# =========================================================

def canonicalize_value_for_compare(value):
    if is_blank(value):
        return None

    if isinstance(value, list):
        cleaned = [clean_text(v) for v in value if not is_blank(v)]
        cleaned = [v for v in cleaned if v]
        return "|".join(sorted(cleaned, key=lambda x: x.lower()))

    txt = clean_text(value)

    if txt is None:
        return None

    txt = re.sub(r"\s+", " ", txt).strip()

    if "," in txt:
        parts = [p.strip() for p in txt.split(",") if p.strip()]
        return "|".join(sorted(parts, key=lambda x: x.lower()))

    return txt


def field_value_to_comparable_value(field_value):
    if not field_value:
        return None

    fv_type = field_value.get("type")

    if fv_type in (
        "TextFieldValue",
        "WikiTextFieldValue",
        "DateFieldValue",
        "IntegerFieldValue",
        "DecimalFieldValue",
        "BoolFieldValue",
    ):
        return canonicalize_value_for_compare(field_value.get("value"))

    if fv_type == "ChoiceFieldValue":
        values = field_value.get("values") or []
        names = []

        for v in values:
            if isinstance(v, dict):
                names.append(clean_text(v.get("name") or v.get("value") or v.get("id")))
            else:
                names.append(clean_text(v))

        names = [n for n in names if n]
        return canonicalize_value_for_compare(names)

    return canonicalize_value_for_compare(field_value.get("value"))


def extract_existing_single_field_value(field_value):
    if not field_value:
        return None

    if "value" in field_value and field_value.get("value") is not None:
        return canonicalize_value_for_compare(field_value.get("value"))

    values = field_value.get("values")

    if isinstance(values, list):
        names = []

        for v in values:
            if isinstance(v, dict):
                names.append(clean_text(v.get("name") or v.get("value") or v.get("id")))
            else:
                names.append(clean_text(v))

        names = [n for n in names if n]
        return canonicalize_value_for_compare(names)

    return None


def get_existing_field_values(cb, item_id):
    result = {}

    try:
        fields = load_item_fields_robust(cb, item_id)
    except Exception as ex:
        logger.warning("Unable to load existing fields for item_id=%s. Error=%s", item_id, ex)
        return result

    for fv in fields:
        if not isinstance(fv, dict):
            continue

        field_name = fv.get("name")

        if not field_name:
            field_obj = fv.get("field")
            if isinstance(field_obj, dict):
                field_name = field_obj.get("name")

        if not field_name:
            continue

        result[normalize_name(field_name)] = extract_existing_single_field_value(fv)

    return result


def filter_changed_field_values(cb, item_id, source_item_id, candidate_field_values, object_type):
    existing_values = get_existing_field_values(cb, item_id)
    changed_fields = []

    for fv in candidate_field_values:
        field_name = fv.get("name")

        if not field_name:
            continue

        old_value = existing_values.get(normalize_name(field_name))
        new_value = field_value_to_comparable_value(fv)

        old_cmp = canonicalize_value_for_compare(old_value)
        new_cmp = canonicalize_value_for_compare(new_value)

        if old_cmp != new_cmp:
            changed_fields.append(fv)

            CHANGE_AUDIT_ROWS.append({
                "object_type": object_type,
                "source_item_id": source_item_id,
                "codebeamer_item_id": item_id,
                "field_name": field_name,
                "old_value": old_cmp,
                "new_value": new_cmp,
                "action": "UPDATED_FIELD"
            })

            logger.info(
                "%s field changed: source=%s | item_id=%s | field=%s | old=%s | new=%s",
                object_type,
                source_item_id,
                item_id,
                field_name,
                old_cmp,
                new_cmp
            )

    return changed_fields


# =========================================================
# FIELD BUILDERS
# =========================================================

def build_text_date_number_bool_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None

    field_id = field_meta["id"]
    field_name = field_meta["name"]
    value_model = field_meta.get("valueModel")

    if value_model == "TextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "TextFieldValue",
            "value": txt
        }

    if value_model == "WikiTextFieldValue":
        txt = clean_text(raw_value)
        if not txt:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "WikiTextFieldValue",
            "value": txt
        }

    if value_model == "DateFieldValue":
        dt = pd.to_datetime(raw_value, errors="coerce")
        if pd.isna(dt):
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DateFieldValue",
            "value": dt.strftime("%Y-%m-%dT%H:%M:%S.000")
        }

    if value_model == "IntegerFieldValue":
        try:
            iv = int(float(raw_value))
        except Exception:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "IntegerFieldValue",
            "value": iv
        }

    if value_model == "DecimalFieldValue":
        try:
            dv = float(raw_value)
        except Exception:
            return None
        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "DecimalFieldValue",
            "value": dv
        }

    if value_model == "BoolFieldValue":
        s = str(raw_value).strip().lower()

        if s in ("yes", "true", "1", "y", "active"):
            bv = True
        elif s in ("no", "false", "0", "n", "inactive"):
            bv = False
        else:
            return None

        return {
            "fieldId": field_id,
            "name": field_name,
            "type": "BoolFieldValue",
            "value": bv
        }

    return None


def build_choice_field_value(field_meta, raw_value, value_map=None):
    if is_blank(raw_value):
        return None, None

    source_text = clean_text(raw_value)

    if not source_text:
        return None, None

    target_text = value_map.get(source_text, source_text) if value_map else source_text

    options = field_meta.get("options") or []

    if not options:
        return None, f"Field '{field_meta.get('name')}' has no choice options metadata"

    matched = None

    for opt in options:
        if normalize_name(opt.get("name")) == normalize_name(target_text):
            matched = opt
            break

    if not matched:
        available = [o.get("name") for o in options]
        return None, f"Choice '{target_text}' not found for field '{field_meta.get('name')}'. Available={available}"

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": [{
            "id": matched["id"],
            "name": matched.get("name"),
            "type": matched.get("type", "ChoiceOptionReference")
        }]
    }, None


def build_choice_or_text_field_value(field_meta, raw_value):
    if is_blank(raw_value):
        return None, None

    value_model = field_meta.get("valueModel")

    if value_model == "ChoiceFieldValue":
        return build_choice_field_value(field_meta, raw_value)

    fv = build_text_date_number_bool_value(field_meta, raw_value)

    if fv:
        return fv, None

    return None, f"Unsupported field model for {field_meta.get('name')}: {value_model}"


def build_reference_field_value(field_meta, refs):
    values = []
    seen = set()

    for item_id, item_name in refs:
        if not item_id:
            continue

        key = str(item_id)

        if key in seen:
            continue

        seen.add(key)

        values.append({
            "id": int(item_id),
            "name": str(item_name),
            "type": "TrackerItemReference"
        })

    if not values:
        return None

    return {
        "fieldId": field_meta["id"],
        "name": field_meta["name"],
        "type": "ChoiceFieldValue",
        "values": values
    }


def update_item_fields(cb, item_id, field_values):
    if not field_values:
        return

    payload = {"fieldValues": field_values}
    cb.put(f"/v3/items/{item_id}/fields", payload)


# =========================================================
# MIGRATED DATA LOGIC
# =========================================================

def build_migrated_data_field_value(tag_tracker_fields, skipped_columns):
    migrated_meta = tag_tracker_fields.get(normalize_name(MIGRATED_DATA_FIELD_NAME))

    if not migrated_meta:
        skipped_columns.append({
            "source_column": MIGRATED_DATA_FIELD_NAME,
            "reason": f"Target field '{MIGRATED_DATA_FIELD_NAME}' not found",
            "sample_value": MIGRATED_DATA_VALUE
        })
        return None

    fv, err = build_choice_field_value(
        field_meta=migrated_meta,
        raw_value=MIGRATED_DATA_VALUE
    )

    if fv:
        return fv

    skipped_columns.append({
        "source_column": MIGRATED_DATA_FIELD_NAME,
        "reason": err or "Unable to build Migrated Data ?",
        "sample_value": MIGRATED_DATA_VALUE
    })

    return None


def force_set_migrated_data_yes(cb, item_id, tag_tracker_fields, skipped_columns, source_item_id=None):
    fv = build_migrated_data_field_value(tag_tracker_fields, skipped_columns)

    if not fv:
        logger.warning(
            "Unable to set '%s'='%s' for source=%s | item_id=%s",
            MIGRATED_DATA_FIELD_NAME, MIGRATED_DATA_VALUE, source_item_id, item_id
        )
        return 0

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=item_id,
        source_item_id=source_item_id,
        candidate_field_values=[fv],
        object_type="TagMigratedData"
    )
    if not changed_fields:
        logger.info("Migrated Data already Yes: source=%s | item_id=%s", source_item_id, item_id)
        return 0

    update_item_fields(cb, item_id, changed_fields)
    logger.info("Set Migrated Data to Yes: source=%s | item_id=%s", source_item_id, item_id)
    return 1


# =========================================================
# REFERENCE REUSE / CREATE
# =========================================================

def create_generic_reference_item(cb, tracker_id, tracker_name, name, description=None, custom_fields=None):
    payload = {
        "name": clean_text(name) or "Imported Reference",
        "descriptionFormat": "PlainText",
        "description": description or f"Imported {tracker_name}: {name}"
    }

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    created = cb.post(f"/v3/trackers/{tracker_id}/items", payload)

    return created["id"], created


def scan_existing_reference_tracker_by_name(cb, tracker_id, tracker_name, page_size=500):
    logger.info("Scanning existing reference tracker by name: %s (%s)", tracker_name, tracker_id)

    page = 1
    total_loaded = 0
    total_cached = 0

    while True:
        payload = {
            "queryString": f"tracker.id IN ({tracker_id})",
            "page": page,
            "pageSize": page_size
        }

        try:
            data = cb.post("/v3/items/query", payload)
        except Exception as ex:
            logger.warning("Unable to query %s. Error=%s", tracker_name, ex)
            return

        items = extract_items_from_query_response(data)

        if not items:
            break

        for item_ref in items:
            item_id = extract_item_id_from_query_item(item_ref)

            if not item_id:
                continue

            try:
                item = get_item_detail(cb, item_id)
            except Exception:
                item = item_ref

            item_name = item.get("name") or extract_item_name_from_query_item(item_ref) or str(item_id)

            total_loaded += 1

            key = (tracker_id, normalize_cache_key(item_name))

            if key not in REFERENCE_TRACKER_EXISTING_CACHE:
                REFERENCE_TRACKER_EXISTING_CACHE[key] = {
                    "id": int(item_id),
                    "name": item_name,
                    "matched_by": "name"
                }
                total_cached += 1

        if len(items) < page_size:
            break

        page += 1

    logger.info("Reference scan completed: %s | loaded=%s | cached=%s", tracker_name, total_loaded, total_cached)


def get_or_create_reference_by_name(cb, tracker_id, tracker_name, source_value):
    value = clean_text(source_value)

    if not value:
        return None, None, False

    key = (tracker_id, normalize_cache_key(value))

    cached_id = REFERENCE_ITEM_CACHE.get(key)

    if cached_id:
        return cached_id, get_tracker_item_name(cb, cached_id), False

    existing = REFERENCE_TRACKER_EXISTING_CACHE.get(key)

    if existing:
        item_id = existing["id"]
        item_name = existing["name"]
        REFERENCE_ITEM_CACHE[key] = item_id
        return item_id, item_name, False

    child_id, _ = create_generic_reference_item(
        cb=cb,
        tracker_id=tracker_id,
        tracker_name=tracker_name,
        name=value
    )

    REFERENCE_ITEM_CACHE[key] = int(child_id)
    REFERENCE_TRACKER_EXISTING_CACHE[key] = {
        "id": int(child_id),
        "name": value,
        "matched_by": "created"
    }

    return int(child_id), value, True


def get_or_create_model_delivery_item(cb, source_value):
    md_value = normalize_model_delivery_value(source_value)

    if not md_value:
        return None, None, False

    return get_or_create_reference_by_name(
        cb=cb,
        tracker_id=MODEL_DELIVERY_TRACKER_ID,
        tracker_name=MODEL_DELIVERY_TRACKER_NAME,
        source_value=md_value
    )


def precreate_model_delivery_items(cb):
    logger.info("Ensuring Model Delivery values MD01..MD42 are available...")

    for md in PRECREATE_MODEL_DELIVERY_VALUES:
        child_id, child_name, created = get_or_create_model_delivery_item(cb, md)

        logger.info(
            "Model Delivery %s: %s -> item_id=%s",
            "created" if created else "reused",
            md,
            child_id
        )


# =========================================================
# ATTACHMENT HELPERS
# =========================================================

def build_stable_excel_file_name(source_id, tracker_name, item_id):
    return (
        f"{sanitize_filename_part(tracker_name)}_"
        f"{sanitize_filename_part(source_id)}_"
        f"{sanitize_filename_part(item_id)}_source_row.xlsx"
    )


def build_attachment_manifest_key(source_id, item_id, file_name):
    return (
        (clean_text(source_id) or "").upper(),
        str(item_id or "").strip(),
        str(file_name or "").strip().lower(),
    )


def load_attachment_manifest():
    ATTACHMENT_MANIFEST_ROWS.clear()
    ATTACHMENT_MANIFEST_KEYS.clear()
    if not os.path.exists(ATTACHMENT_MANIFEST_CSV):
        return
    try:
        manifest_df = pd.read_csv(ATTACHMENT_MANIFEST_CSV, dtype=str).fillna("")
        for row in manifest_df.to_dict("records"):
            ATTACHMENT_MANIFEST_ROWS.append(row)
            if str(row.get("attached_status", "")).upper() in {"ATTACHED", "ALREADY_ATTACHED"}:
                ATTACHMENT_MANIFEST_KEYS.add(build_attachment_manifest_key(
                    row.get("source_item_id"), row.get("codebeamer_item_id"), row.get("attachment_file")
                ))
        logger.info("Loaded %s attachment manifest rows", len(ATTACHMENT_MANIFEST_ROWS))
    except Exception as ex:
        logger.warning("Unable to load attachment manifest %s: %s", ATTACHMENT_MANIFEST_CSV, ex)


def add_attachment_manifest_row(source_id, item_id, file_path, item_mode, attached_status, action, error=None):
    file_name = os.path.basename(file_path) if file_path else None
    row = {
        "source_item_id": source_id,
        "tracker_name": TAG_MANAGEMENT_TRACKER_NAME,
        "codebeamer_item_id": item_id,
        "attachment_file": file_name,
        "item_mode": item_mode,
        "attached_status": attached_status,
        "action": action,
        "error": error,
        "recorded_on": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    ATTACHMENT_MANIFEST_ROWS.append(row)
    if attached_status in {"ATTACHED", "ALREADY_ATTACHED"}:
        ATTACHMENT_MANIFEST_KEYS.add(build_attachment_manifest_key(source_id, item_id, file_name))


def write_attachment_manifest():
    if ATTACHMENT_MANIFEST_ROWS:
        pd.DataFrame(ATTACHMENT_MANIFEST_ROWS).drop_duplicates(
            subset=["source_item_id", "codebeamer_item_id", "attachment_file", "attached_status", "action"],
            keep="last"
        ).to_csv(ATTACHMENT_MANIFEST_CSV, index=False, encoding="utf-8-sig")
        logger.info("Attachment manifest written: %s", ATTACHMENT_MANIFEST_CSV)


def extract_attachments_from_response(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("attachments", "items", "results", "data", "itemRefs"):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def extract_attachment_file_name(obj):
    if not isinstance(obj, dict):
        return None
    keys = ("fileName", "filename", "name", "title", "originalFileName", "originalFilename")
    for key in keys:
        value = clean_text(obj.get(key))
        if value:
            return value
    for nested_key in ("file", "attachment", "attachmentReference"):
        nested = obj.get(nested_key)
        if isinstance(nested, dict):
            value = extract_attachment_file_name(nested)
            if value:
                return value
    return None


def get_existing_attachment_file_names(cb, item_id):
    names = set()
    if not item_id:
        return names

    paths = [
        CB_ATTACHMENT_LIST_PATH_TEMPLATE.format(item_id=item_id),
        f"/v3/items/{item_id}/comments/attachments",
    ]
    for path in paths:
        try:
            data = cb.get(path)
            attachments = extract_attachments_from_response(data)
            logger.info(
                "Attachment-list response: item_id=%s | path=%s | records=%s",
                item_id, path, len(attachments)
            )
            for attachment in attachments:
                name = extract_attachment_file_name(attachment)
                if name:
                    names.add(name.strip().lower())
            if names:
                logger.info(
                    "Existing attachments found: item_id=%s | path=%s | names=%s",
                    item_id, path, sorted(names)
                )
                return names
        except Exception as ex:
            logger.warning(
                "Unable to list attachments: item_id=%s | path=%s | error=%s",
                item_id, path, ex
            )
    return names


def create_source_row_excel_file(row, source_id, tracker_name, item_id, item_mode):
    os.makedirs(TAG_EXCEL_EXPORT_DIR, exist_ok=True)
    file_name = build_stable_excel_file_name(source_id, tracker_name, item_id)
    file_path = os.path.join(TAG_EXCEL_EXPORT_DIR, file_name)

    if PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT and os.path.exists(file_path):
        logger.info(
            "Source-row Excel already exists locally; reusing: source=%s | item_id=%s | file=%s",
            source_id, item_id, file_path
        )
        return file_path

    row_dict = {
        col: (clean_text(row.get(col)) if not is_blank(row.get(col)) else None)
        for col in row.index
    }
    source_df = pd.DataFrame([row_dict])
    metadata_df = pd.DataFrame([{
        "source_item_id": source_id,
        "tracker_name": tracker_name,
        "codebeamer_item_id": item_id,
        "item_mode": item_mode,
        "generated_on": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
    }])

    with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
        source_df.to_excel(writer, sheet_name="source_row", index=False)
        metadata_df.to_excel(writer, sheet_name="metadata", index=False)

    logger.info(
        "Created source-row Excel: source=%s | item_id=%s | file=%s",
        source_id, item_id, file_path
    )
    return file_path


def attach_file_to_codebeamer_item(cb, item_id, file_path, source_id=None, item_mode=None):
    if not item_id:
        raise RuntimeError("Cannot attach Excel because item_id is missing")
    if not file_path or not os.path.exists(file_path):
        raise RuntimeError(f"Excel file not found for attachment: {file_path}")

    file_name = os.path.basename(file_path)
    mime_type, _ = mimetypes.guess_type(file_path)
    if not mime_type:
        mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    logger.info(
        "Uploading Tag attachment: source=%s | item_id=%s | mode=%s | file=%s | mime=%s",
        source_id, item_id, item_mode, file_name, mime_type
    )

    with open(file_path, "rb") as file_obj:
        files = {
            "attachments": (file_name, file_obj, mime_type)
        }
        response = cb.post_multipart(
            path=CB_ATTACHMENT_UPLOAD_PATH_TEMPLATE.format(item_id=item_id),
            files=files,
            data={"description": ATTACHMENT_DESCRIPTION_TEXT}
        )

    logger.info(
        "Attachment upload completed: source=%s | item_id=%s | file=%s | response=%s",
        source_id, item_id, file_name, response
    )
    return response


def attach_source_row_excel_to_item(cb, row, item_id, source_id, reason, item_mode):
    if not ATTACH_SOURCE_ROW_EXCEL or not item_id:
        return False
    if item_mode == "CREATED" and not ATTACH_CREATED_EXCEL_TO_TAG:
        return False
    if item_mode == "EXISTING" and not ATTACH_EXCEL_TO_EXISTING_TAG:
        return False

    file_name = build_stable_excel_file_name(source_id, TAG_MANAGEMENT_TRACKER_NAME, item_id)
    manifest_key = build_attachment_manifest_key(source_id, item_id, file_name)
    cache_key = (str(item_id), str(source_id).upper(), file_name.lower())

    if cache_key in ROW_ATTACHMENT_CACHE:
        logger.info("Attachment already processed in this run: item_id=%s | file=%s", item_id, file_name)
        return False

    if (PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT
            and TRUST_MANIFEST_TO_SKIP_ATTACHMENT
            and manifest_key in ATTACHMENT_MANIFEST_KEYS):
        ROW_ATTACHMENT_ROWS.append({
            "source_item_id": source_id,
            "tracker_name": TAG_MANAGEMENT_TRACKER_NAME,
            "codebeamer_item_id": item_id,
            "attachment_file": file_name,
            "reason": reason,
            "item_mode": item_mode,
            "status": "SKIPPED_MANIFEST"
        })
        return False

    file_path = None
    try:
        if PREVENT_DUPLICATE_EXCEL_CREATION_AND_ATTACHMENT:
            existing_names = get_existing_attachment_file_names(cb, item_id)
            if file_name.lower() in existing_names:
                ROW_ATTACHMENT_CACHE.add(cache_key)
                add_attachment_manifest_row(
                    source_id, item_id, file_name, item_mode,
                    "ALREADY_ATTACHED", "SKIPPED_CODEBEAMER_DUPLICATE"
                )
                ROW_ATTACHMENT_ROWS.append({
                    "source_item_id": source_id,
                    "tracker_name": TAG_MANAGEMENT_TRACKER_NAME,
                    "codebeamer_item_id": item_id,
                    "attachment_file": file_name,
                    "reason": reason,
                    "item_mode": item_mode,
                    "status": "ALREADY_ATTACHED"
                })
                logger.info(
                    "Attachment already exists in Codebeamer; skipped: item_id=%s | file=%s",
                    item_id, file_name
                )
                return False

        file_path = create_source_row_excel_file(
            row, source_id, TAG_MANAGEMENT_TRACKER_NAME, item_id, item_mode
        )
        upload_response = attach_file_to_codebeamer_item(
            cb, item_id, file_path, source_id=source_id, item_mode=item_mode
        )
        ROW_ATTACHMENT_CACHE.add(cache_key)
        add_attachment_manifest_row(
            source_id, item_id, file_path, item_mode,
            "ATTACHED", "UPLOADED_ATTACHMENT_TO_CODEBEAMER"
        )
        ROW_ATTACHMENT_ROWS.append({
            "source_item_id": source_id,
            "tracker_name": TAG_MANAGEMENT_TRACKER_NAME,
            "codebeamer_item_id": item_id,
            "attachment_file": os.path.basename(file_path),
            "reason": reason,
            "item_mode": item_mode,
            "status": "ATTACHED",
            "upload_response": json.dumps(upload_response, ensure_ascii=False, default=str)
        })
        logger.info(
            "Attached source-row Excel: source=%s | item_id=%s | file=%s",
            source_id, item_id, os.path.basename(file_path)
        )
        if DELETE_ROW_EXCEL_AFTER_UPLOAD and os.path.exists(file_path):
            os.remove(file_path)
        return True
    except Exception as ex:
        failed_path = file_path or file_name
        add_attachment_manifest_row(
            source_id, item_id, failed_path, item_mode,
            "FAILED", "UPLOAD_FAILED", str(ex)
        )
        ROW_ATTACHMENT_ROWS.append({
            "source_item_id": source_id,
            "tracker_name": TAG_MANAGEMENT_TRACKER_NAME,
            "codebeamer_item_id": item_id,
            "attachment_file": os.path.basename(failed_path),
            "reason": reason,
            "item_mode": item_mode,
            "status": "FAILED",
            "error": str(ex)
        })
        logger.exception(
            "Attachment failed but Tag processing remains successful: source=%s | item_id=%s",
            source_id, item_id
        )
        return False


# =========================================================
# TAG MANAGEMENT PAYLOAD BUILDERS
# =========================================================

def get_tag_title(row):
    title = clean_text(row.get(SOURCE_TITLE_COLUMN))
    item_id = clean_text(row.get(SOURCE_KEY_COLUMN))
    return title or item_id or "Imported Tag"


def build_scalar_field_values(row, tag_tracker_fields, skipped_columns):
    values = []

    for src_col, cfg in SAFE_TAG_FIELD_MAPPING.items():
        if src_col not in row.index:
            continue

        raw_value = row.get(src_col)

        if is_blank(raw_value):
            continue

        target_field_name = cfg["field"]
        field_meta = tag_tracker_fields.get(normalize_name(target_field_name))

        if not field_meta:
            skipped_columns.append({
                "source_column": src_col,
                "reason": f"Target field '{target_field_name}' not found in Tag Management tracker",
                "sample_value": clean_text(raw_value)
            })
            continue

        kind = cfg.get("kind")

        if kind == "choice_or_text":
            fv, err = build_choice_or_text_field_value(field_meta, raw_value)

            if fv:
                values.append(fv)
            elif err:
                skipped_columns.append({
                    "source_column": src_col,
                    "reason": err,
                    "sample_value": clean_text(raw_value)
                })

            continue

        fv = build_text_date_number_bool_value(field_meta, raw_value)

        if fv:
            values.append(fv)
        else:
            skipped_columns.append({
                "source_column": src_col,
                "reason": f"Unsupported or unresolved field '{target_field_name}'",
                "sample_value": clean_text(raw_value)
            })

    migrated_fv = build_migrated_data_field_value(tag_tracker_fields, skipped_columns)

    if migrated_fv:
        values.append(migrated_fv)

    return values


def build_reference_field_values(cb, row, tag_tracker_fields, skipped_columns):
    values = []

    for rule in REFERENCE_RULES:
        source_col = rule["source_column"]

        if source_col not in row.index:
            continue

        raw_value = row.get(source_col)

        if is_blank(raw_value):
            continue

        if rule.get("model_delivery"):
            one_value = normalize_model_delivery_value(raw_value)
            source_values = [one_value] if one_value else []
        elif rule.get("multi_value"):
            source_values = split_values(raw_value)
        else:
            one_value = clean_text(raw_value)
            source_values = [one_value] if one_value else []

        if not source_values:
            continue

        field_meta = tag_tracker_fields.get(normalize_name(rule["tag_management_field"]))

        if not field_meta:
            skipped_columns.append({
                "source_column": source_col,
                "reason": f"Reference field '{rule['tag_management_field']}' not found in Tag Management tracker",
                "sample_value": clean_text(raw_value)
            })
            continue

        refs = []

        for source_value in source_values:
            if rule.get("model_delivery"):
                child_id, child_name, created = get_or_create_model_delivery_item(cb, source_value)
            else:
                child_id, child_name, created = get_or_create_reference_by_name(
                    cb=cb,
                    tracker_id=rule["target_tracker_id"],
                    tracker_name=rule["target_tracker_name"],
                    source_value=source_value
                )

            if not child_id:
                continue

            refs.append((child_id, child_name))

            logger.info(
                "Reference %s: field=%s | value=%s | child_id=%s",
                "created" if created else "reused",
                source_col,
                source_value,
                child_id
            )

        fv = build_reference_field_value(field_meta, refs)

        if fv:
            values.append(fv)

    return values


def build_description(row):
    description_lines = []

    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
    tag_description = clean_text(row.get("Tag Description"))

    if src_id:
        description_lines.append(f"Source SBM Tag Id: {src_id}")

    if tag_description:
        description_lines.append("")
        description_lines.append("Tag Description:")
        description_lines.append(tag_description)

    return "\n".join(description_lines).strip() if description_lines else None


def create_tag_management_item(cb, row, tag_tracker_fields, skipped_columns):
    title = get_tag_title(row)

    payload = {
        "name": title,
        "descriptionFormat": "PlainText",
        "description": build_description(row)
    }

    scalar_values = build_scalar_field_values(
        row=row,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    reference_values = build_reference_field_values(
        cb=cb,
        row=row,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    custom_fields = scalar_values + reference_values

    if custom_fields:
        payload["customFields"] = custom_fields

    payload = {k: v for k, v in payload.items() if v is not None}

    created = cb.post(f"/v3/trackers/{TAG_MANAGEMENT_TRACKER_ID}/items", payload)

    return created["id"], created


def update_tag_management_item(cb, item_id, row, tag_tracker_fields, skipped_columns):
    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))

    scalar_values = build_scalar_field_values(
        row=row,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    reference_values = build_reference_field_values(
        cb=cb,
        row=row,
        tag_tracker_fields=tag_tracker_fields,
        skipped_columns=skipped_columns
    )

    candidate_fields = scalar_values + reference_values

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=item_id,
        source_item_id=src_id,
        candidate_field_values=candidate_fields,
        object_type="Tag"
    )

    if changed_fields:
        update_item_fields(cb, item_id, changed_fields)

        logger.info(
            "Updated %s changed Tag field(s): source=%s | item_id=%s",
            len(changed_fields),
            src_id,
            item_id
        )
    else:
        CHANGE_AUDIT_ROWS.append({
            "object_type": "Tag",
            "source_item_id": src_id,
            "codebeamer_item_id": item_id,
            "field_name": None,
            "old_value": None,
            "new_value": None,
            "action": "NO_CHANGE"
        })

        logger.info("No Tag field changes detected: source=%s | item_id=%s", src_id, item_id)

    return len(changed_fields)


def update_tag_status_last(cb, item_id, row, tag_tracker_fields, skipped_columns):
    src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
    raw_status = row.get("State")

    if is_blank(raw_status):
        return 0

    status_meta = tag_tracker_fields.get(normalize_name("Status"))

    if not status_meta:
        skipped_columns.append({
            "source_column": "State",
            "reason": "Target field 'Status' not found in Tag Management tracker",
            "sample_value": clean_text(raw_status)
        })
        return 0

    fv, err = build_choice_field_value(
        field_meta=status_meta,
        raw_value=raw_status,
        value_map=STATE_TO_CB_STATUS
    )

    if not fv:
        skipped_columns.append({
            "source_column": "State",
            "reason": err or "Unable to build Status value",
            "sample_value": clean_text(raw_status)
        })
        return 0

    changed_fields = filter_changed_field_values(
        cb=cb,
        item_id=item_id,
        source_item_id=src_id,
        candidate_field_values=[fv],
        object_type="TagStatus"
    )

    if changed_fields:
        update_item_fields(cb, item_id, changed_fields)
        logger.info("Updated Tag Status: source=%s | item_id=%s", src_id, item_id)
        return 1

    return 0


# =========================================================
# MAIN PASS
# =========================================================

def pass_create_or_update_tags(cb, df, tag_tracker_fields, skipped_columns, failed_rows):
    logger.info("PASS: create/update Tag Management items")

    processed_rows = []

    for idx, row in df.iterrows():
        src_id = clean_text(row.get(SOURCE_KEY_COLUMN))
        src_key = src_id.upper() if src_id else None
        title = get_tag_title(row)

        if not src_key:
            failed_rows.append({
                "row_index": idx,
                "source_item_id": None,
                "title": title,
                "phase": "SOURCE_VALIDATION",
                "error": "Missing Item Id"
            })
            continue

        if src_key in PROCESSED_SBM_TAG_IDS_THIS_RUN:
            logger.warning("Skipping duplicate source row already processed in this run: %s", src_key)

            processed_rows.append({
                "source_item_id": src_id,
                "tag_management_codebeamer_item_id": None,
                "title": title,
                "status": "SKIPPED_DUPLICATE_SOURCE_ROW_ALREADY_PROCESSED_THIS_RUN",
                "matched_by": SOURCE_KEY_COLUMN
            })

            continue

        PROCESSED_SBM_TAG_IDS_THIS_RUN.add(src_key)

        try:
            cb_id = None
            result_mode = None
            changed_count = 0
            status_changed = 0
            migrated_changed = 0
            item_mode = "EXISTING"

            existing_id = find_existing_tag_by_sbm_tag_id(src_key)

            if not existing_id:
                existing_id = live_find_existing_tag_by_sbm_tag_id(
                    cb=cb,
                    src_key=src_key
                )

            if existing_id:
                is_valid, reason = validate_existing_item_in_tracker(
                    cb=cb,
                    item_id=existing_id,
                    expected_tracker_id=TAG_MANAGEMENT_TRACKER_ID
                )

                if is_valid:
                    cb_id = int(existing_id)

                    changed_count = update_tag_management_item(
                        cb=cb,
                        item_id=cb_id,
                        row=row,
                        tag_tracker_fields=tag_tracker_fields,
                        skipped_columns=skipped_columns
                    )

                    result_mode = (
                        "UPDATED_CHANGED_FIELDS_BY_SBM_TAG_ID"
                        if changed_count > 0
                        else "NO_CHANGE_EXISTING_TAG_BY_SBM_TAG_ID"
                    )

                else:
                    failed_rows.append({
                        "row_index": idx,
                        "source_item_id": src_id,
                        "title": title,
                        "phase": "EXISTING_TAG_VALIDATION",
                        "error": reason,
                        "tag_id": existing_id
                    })
                    continue

            if not cb_id:
                cb_id, _ = create_tag_management_item(
                    cb=cb,
                    row=row,
                    tag_tracker_fields=tag_tracker_fields,
                    skipped_columns=skipped_columns
                )

                result_mode = "CREATED_TAG"
                item_mode = "CREATED"

                TAG_MANAGEMENT_EXISTING_BY_SBM_ID[src_key] = {
                    "id": int(cb_id),
                    "name": title,
                    "matched_by": "created"
                }

                CHANGE_AUDIT_ROWS.append({
                    "object_type": "Tag",
                    "source_item_id": src_id,
                    "codebeamer_item_id": cb_id,
                    "field_name": None,
                    "old_value": None,
                    "new_value": None,
                    "action": "CREATED_TAG"
                })

                logger.info("Created Tag Management item: source=%s -> cb_id=%s", src_id, cb_id)

            status_changed = update_tag_status_last(
                cb=cb,
                item_id=cb_id,
                row=row,
                tag_tracker_fields=tag_tracker_fields,
                skipped_columns=skipped_columns
            )

            if status_changed:
                result_mode = f"{result_mode}_STATUS_UPDATED"

            try:
                migrated_changed = force_set_migrated_data_yes(
                    cb=cb,
                    item_id=cb_id,
                    tag_tracker_fields=tag_tracker_fields,
                    skipped_columns=skipped_columns,
                    source_item_id=src_id
                )

                if migrated_changed:
                    result_mode = f"{result_mode}_MIGRATED_DATA_SET_YES"

            except Exception as migrated_ex:
                logger.error(
                    "Migrated Data update failed but continuing: source=%s | item_id=%s | error=%s",
                    src_id,
                    cb_id,
                    migrated_ex
                )

                failed_rows.append({
                    "row_index": idx,
                    "source_item_id": src_id,
                    "title": title,
                    "phase": "MIGRATED_DATA_UPDATE",
                    "error": str(migrated_ex),
                    "tag_id": cb_id
                })

            should_attach = (
                str(result_mode).startswith("CREATED_TAG")
                or "UPDATED_CHANGED_FIELDS" in str(result_mode)
                or status_changed > 0
                or migrated_changed > 0
                or ATTACH_ROW_EXCEL_EVEN_IF_NO_CHANGE
            )

            if cb_id and should_attach:
                attach_source_row_excel_to_item(
                    cb=cb,
                    row=row,
                    item_id=cb_id,
                    source_id=src_id,
                    reason=result_mode,
                    item_mode=item_mode
                )

            processed_rows.append({
                "source_item_id": src_id,
                "tag_management_codebeamer_item_id": cb_id,
                "title": title,
                "status": result_mode,
                "matched_by": SBM_TAG_ID_FIELD_NAME
            })

            logger.info("Tag result: source=%s -> cb_id=%s | %s", src_id, cb_id, result_mode)

        except Exception as ex:
            logger.exception("Failed for Tag source=%s", src_id)

            failed_rows.append({
                "row_index": idx,
                "source_item_id": src_id,
                "title": title,
                "phase": "TAG_CREATE_UPDATE",
                "error": str(ex)
            })

    return processed_rows


# =========================================================
# REPORTS
# =========================================================

def write_reports(processed_rows, failed_rows, skipped_columns):
    if processed_rows:
        pd.DataFrame(processed_rows).to_csv(CREATED_MAP_CSV, index=False, encoding="utf-8-sig")
        logger.info("Created/updated map written: %s", CREATED_MAP_CSV)

    if failed_rows:
        pd.DataFrame(failed_rows).to_csv(FAILED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.info("Failed rows report written: %s", FAILED_ROWS_CSV)
    else:
        logger.info("No failed rows.")

    if skipped_columns:
        pd.DataFrame(skipped_columns).drop_duplicates(
            subset=["source_column", "reason"]
        ).to_csv(SKIPPED_COLUMNS_REPORT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Skipped columns report written: %s", SKIPPED_COLUMNS_REPORT_CSV)
    else:
        logger.info("No skipped columns.")

    if CHANGE_AUDIT_ROWS:
        pd.DataFrame(CHANGE_AUDIT_ROWS).to_csv(CHANGE_AUDIT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Change audit report written: %s", CHANGE_AUDIT_CSV)
    else:
        logger.info("No change audit rows.")

    if ROW_ATTACHMENT_ROWS:
        pd.DataFrame(ROW_ATTACHMENT_ROWS).to_csv(ROW_ATTACHMENT_REPORT_CSV, index=False, encoding="utf-8-sig")
        logger.info("Row attachment report written: %s", ROW_ATTACHMENT_REPORT_CSV)
    else:
        logger.info("No row attachment rows.")

    write_attachment_manifest()

    if DUPLICATE_EXISTING_TAG_ROWS:
        pd.DataFrame(DUPLICATE_EXISTING_TAG_ROWS).to_csv(
            DUPLICATE_EXISTING_TAGS_CSV,
            index=False,
            encoding="utf-8-sig"
        )
        logger.warning("Duplicate existing Tag report written: %s", DUPLICATE_EXISTING_TAGS_CSV)


# =========================================================
# MAIN
# =========================================================

def main():
    acquire_run_lock()

    try:
        validate_config()
        load_attachment_manifest()

        logger.info("Connecting to MySQL...")

        conn_url = URL.create(
            "mysql+mysqlconnector",
            username=MYSQL_USER,
            password=MYSQL_PASS,
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            database=MYSQL_DB,
            query={"charset": "utf8mb4"}
        )

        engine = create_engine(conn_url)

        logger.info("Reading source rows from MySQL table: %s", TABLE_NAME)

        df = pd.read_sql(text(SOURCE_SQL), engine)

        if df.empty:
            logger.info("No source rows found. Exiting.")
            return

        df = df.astype(object).where(pd.notna(df), None)
        df = apply_source_schema_adapter(df)

        logger.info("Loaded %s raw Tag rows from MySQL.", len(df))

        df = deduplicate_source_rows_by_item_id(df)

        logger.info("Loaded %s unique Tag rows after Item Id deduplication.", len(df))

        required_columns = [
            "Item Id",
            "Title",
            "Tag Item Type",
            "Tag High Level",
            "Tag Middle Level",
            "Tag Bottom Level",
            "Tag Description",
            "State",
            "Introduction MD",
            "Obsolescence MD",
            "Tag Classification",
        ]

        missing = [c for c in required_columns if c not in df.columns]

        if missing:
            raise RuntimeError(
                f"Missing required source columns in MySQL result: {missing}. "
                f"Available columns: {list(df.columns)}"
            )

        logger.info("Connecting to Codebeamer...")

        cb = CodebeamerClient(
            CB_BASE_URL,
            CB_USER,
            CB_PASS,
            verify_ssl=VERIFY_SSL,
            timeout=TIMEOUT
        )

        logger.info("Loading Tag Management tracker fields...")

        tag_tracker_fields = load_tracker_fields(
            cb=cb,
            tracker_id=TAG_MANAGEMENT_TRACKER_ID
        )

        log_field_debug(tag_tracker_fields, SBM_TAG_ID_FIELD_NAME)
        log_field_debug(tag_tracker_fields, "Status")
        log_field_debug(tag_tracker_fields, "Tag Description")
        log_field_debug(tag_tracker_fields, "Tag Classification")
        log_field_debug(tag_tracker_fields, MIGRATED_DATA_FIELD_NAME)
        log_field_debug(tag_tracker_fields, "Tag Item Type")
        log_field_debug(tag_tracker_fields, "Tag High Level")
        log_field_debug(tag_tracker_fields, "Tag Middle Level")
        log_field_debug(tag_tracker_fields, "Tag Bottom Level")
        log_field_debug(tag_tracker_fields, "Introduction MD")
        log_field_debug(tag_tracker_fields, "Obsolescence MD")

        logger.info("Scanning existing Tag Management items by SBM Tag Id...")

        scan_existing_tag_management_items_by_sbm_tag_id(cb)

        logger.info("Scanning existing reference trackers...")

        scan_existing_reference_tracker_by_name(
            cb=cb,
            tracker_id=TAG_ITEM_TYPE_TRACKER_ID,
            tracker_name=TAG_ITEM_TYPE_TRACKER_NAME
        )

        scan_existing_reference_tracker_by_name(
            cb=cb,
            tracker_id=TAG_HIGH_LEVEL_TRACKER_ID,
            tracker_name=TAG_HIGH_LEVEL_TRACKER_NAME
        )

        scan_existing_reference_tracker_by_name(
            cb=cb,
            tracker_id=TAG_MIDDLE_LEVEL_TRACKER_ID,
            tracker_name=TAG_MIDDLE_LEVEL_TRACKER_NAME
        )

        scan_existing_reference_tracker_by_name(
            cb=cb,
            tracker_id=TAG_BOTTOM_LEVEL_TRACKER_ID,
            tracker_name=TAG_BOTTOM_LEVEL_TRACKER_NAME
        )

        scan_existing_reference_tracker_by_name(
            cb=cb,
            tracker_id=MODEL_DELIVERY_TRACKER_ID,
            tracker_name=MODEL_DELIVERY_TRACKER_NAME
        )

        logger.info("Ensuring Model Delivery MD01..MD42...")

        precreate_model_delivery_items(cb)

        skipped_columns = []
        failed_rows = []

        used_columns = set(SAFE_TAG_FIELD_MAPPING.keys())
        used_columns.add(SOURCE_TITLE_COLUMN)
        used_columns.add("State")
        used_columns.add(MIGRATED_DATA_FIELD_NAME)

        for rule in REFERENCE_RULES:
            used_columns.add(rule["source_column"])

        for col in df.columns:
            if col not in used_columns:
                skipped_columns.append({
                    "source_column": col,
                    "reason": "Not mapped for current Tag Management migration scope",
                    "sample_value": first_non_null_sample(df, col)
                })

        logger.info("Starting Tag Management create/update pass...")

        processed_rows = pass_create_or_update_tags(
            cb=cb,
            df=df,
            tag_tracker_fields=tag_tracker_fields,
            skipped_columns=skipped_columns,
            failed_rows=failed_rows
        )

        write_reports(
            processed_rows=processed_rows,
            failed_rows=failed_rows,
            skipped_columns=skipped_columns
        )

        logger.info("Tag Management sync completed successfully.")

    finally:
        release_run_lock()


if __name__ == "__main__":
    main()