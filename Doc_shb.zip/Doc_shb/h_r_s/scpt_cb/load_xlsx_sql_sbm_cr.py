import re
import pandas as pd
from sqlalchemy import create_engine, text

# ----------------------------
# CONFIGURATION
# ----------------------------

EXCEL_PATH = r"D:\SBM\SBM_CR.xlsx"

# Try these sheet names in order
PREFERRED_SHEETS = ["CR", "HCR"]

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB   = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"
TABLE_NAME = "sbm_cr"

CHUNK_SIZE = 1000

TRUNCATION_REPORT_CSV = "truncations_report.csv"
INVALID_TEMPORAL_REPORT_CSV = "invalid_temporal_report.csv"
SKIPPED_DUPLICATES_REPORT_CSV = "skipped_duplicate_item_ids.csv"

SQUASH_WHITESPACE = False

# Exact source header names
COLUMN_MAPPING = {
    "Item ID": "Item ID",
    "Title": "Title",
    "Perimeter": "Perimeter",
    "Program Line": "Program Line",
    "Assigned Delivery": "Assigned Delivery",
    "Expected Delivery": "Expected Delivery",
    "Archi SW": "Archi SW",
    "Project": "Project",
    "First engine application": "First engine application",
    "Function & Sub Function": "Function & Sub Function",
}

VARIANT_DB_NAMES = {
    "ApplicationScope": ["Application Scope", "applicationscope", "Application scope", "ApplicationScope"],
    "GRADE Rating": ["GRADE Rating", "Grade Rating", "grade rating"],
    "Safe State": ["Safe State", "SafeState", "safe state"],
    "Req Milestone": ["Req Milestone", "ReqMilestone", "req milestone"],
    "Object Identifier": ["Object Identifier", "ObjectIdentifier"],
    "Partners": ["Partners", "Partners Ownership", "PartnersOwnership"],
}

# ----------------------------
# UTILITY FUNCTIONS
# ----------------------------

def clean_header(h):
    return (
        str(h)
        .strip()
        .replace("\uFEFF", "")
        .replace("\r", "")
        .replace("\n", "")
        .replace("_x000D_", "")
        .replace("\xa0", " ")
        .strip()
    )

def clean_value(v):
    """
    General value cleaning:
    - pandas/NumPy missing -> None
    - empty strings / (None) / None / nan -> None
    - strips strings and removes _x000D_
    """
    if pd.isna(v):
        return None

    if isinstance(v, str):
        s = (
            v.strip()
             .replace("\r", "")
             .replace("_x000D_", "")
             .strip()
        )
        if s in {"", "(None)", "None", "nan", "NaN"}:
            return None
        return s

    return v

def squash_whitespace(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()

def normalize_for_match(name: str) -> str:
    return "".join(str(name).split()).lower()

def choose_sheet_name(excel_path: str, preferred_sheets: list) -> str:
    xls = pd.ExcelFile(excel_path, engine="openpyxl")
    available = xls.sheet_names

    for s in preferred_sheets:
        if s in available:
            return s

    raise ValueError(
        f"None of the preferred sheets {preferred_sheets} were found. "
        f"Available sheets: {available}"
    )

def detect_header_row(excel_path: str, sheet_name: str, max_scan_rows: int = 25) -> int:
    """
    Scan the first few rows and detect the actual header row.
    """
    preview = pd.read_excel(
        excel_path,
        sheet_name=sheet_name,
        engine="openpyxl",
        header=None,
        nrows=max_scan_rows,
        dtype=object
    )

    expected = {
        "item id",
        "title",
        "perimeter",
        "program line",
        "assigned delivery",
        "expected delivery",
        "archi sw",
        "project",
        "first engine application",
        "function & sub function",
    }

    best_row = None
    best_score = -1

    for i in range(len(preview)):
        row_vals = set()

        for val in preview.iloc[i].tolist():
            if pd.isna(val):
                continue
            s = clean_header(val).lower()
            if s:
                row_vals.add(s)

        score = len(expected.intersection(row_vals))

        if score > best_score:
            best_score = score
            best_row = i

    if best_row is None or best_score < 2:
        raise ValueError(
            f"Could not reliably detect header row in sheet '{sheet_name}'. "
            f"Best row={best_row}, score={best_score}"
        )

    print(f"Detected header row: {best_row} (0-based), matched {best_score} expected columns.")
    return best_row

def get_db_columns_and_defs(engine, table_name: str):
    """
    Returns:
      cols: list of DB column names
      defs: dict {col: {"type": "...", "nullable": bool, "maxlen": int or None}}
      norm_key_map: normalized_name -> actual DB column
    """
    import re as _re

    defs = {}
    cols = []

    with engine.connect() as conn:
        rs = conn.execute(text(f"SHOW COLUMNS FROM `{table_name}`"))
        for row in rs:
            field = row[0]
            col_type = row[1]
            nullable = (str(row[2]).upper() == "YES")
            cols.append(field)

            maxlen = None
            m = _re.match(r"varchar\((\d+)\)", col_type, flags=_re.I)
            if m:
                maxlen = int(m.group(1))

            defs[field] = {
                "type": col_type,
                "nullable": nullable,
                "maxlen": maxlen
            }

    norm_key_map = {normalize_for_match(c): c for c in cols}
    return cols, defs, norm_key_map

def resolve_columns_against_db(df: pd.DataFrame, db_cols: list) -> pd.DataFrame:
    """
    Renames DataFrame columns to exact DB names wherever possible.
    Drops unmatched columns.
    """
    db_set = set(db_cols)
    db_norm_map = {normalize_for_match(c): c for c in db_cols}

    renames = {}
    unmatched = []

    for c in df.columns:
        if not isinstance(c, str):
            unmatched.append(c)
            continue

        if c in db_set:
            continue

        logical = c
        variants = VARIANT_DB_NAMES.get(logical, [])
        found = None

        for v in variants:
            if v in db_set:
                found = v
                break

        if not found:
            key = normalize_for_match(c)
            if key in db_norm_map:
                found = db_norm_map[key]

        if found:
            renames[c] = found
        else:
            unmatched.append(c)

    if renames:
        print("Resolved column variants:", renames)
        df = df.rename(columns=renames)

    if unmatched:
        print("Dropping columns not in DB:", unmatched)
        df = df.drop(columns=unmatched, errors="ignore")

    keep = [c for c in df.columns if isinstance(c, str) and c in db_set]
    df = df[keep]

    return df

def enforce_varchar_maxlen(df: pd.DataFrame, col_defs: dict, db_norm_map: dict, report_path: str, squash_ws: bool = False):
    """
    Truncate values that exceed varchar limits, and write a report.
    """
    truncations = []

    for df_col in df.columns:
        norm = normalize_for_match(df_col)
        db_col_name = db_norm_map.get(norm, df_col)

        info = col_defs.get(db_col_name, {})
        maxlen = info.get("maxlen")

        if not maxlen:
            continue

        new_vals = []
        for row_idx, val in enumerate(df[df_col].tolist()):
            if val is None or pd.isna(val):
                new_vals.append(None)
                continue

            if isinstance(val, str):
                s = squash_whitespace(val) if squash_ws else val
                if len(s) > maxlen:
                    truncations.append({
                        "row_index": row_idx,
                        "column": df_col,
                        "db_column": db_col_name,
                        "original_length": len(val),
                        "max_allowed": maxlen,
                        "original_value": val,
                        "truncated_value": s[:maxlen]
                    })
                    new_vals.append(s[:maxlen])
                else:
                    new_vals.append(s)
            else:
                new_vals.append(val)

        df[df_col] = new_vals

    if truncations:
        rep_df = pd.DataFrame(truncations)
        rep_df.to_csv(report_path, index=False, encoding="utf-8-sig")
        print(f"WARNING: {len(truncations)} value(s) exceeded varchar limits and were truncated.")
        print(f"Truncation report written to: {report_path}")

def coerce_temporal_columns(df: pd.DataFrame, col_defs: dict, report_path: str = None):
    """
    Convert DATE / DATETIME / TIMESTAMP columns safely.
    Invalid placeholders like:
      0, '0', '', '(None)', 'None', 'nan'
    are converted to None.
    """
    invalid_rows = []

    for col in df.columns:
        info = col_defs.get(col, {})
        col_type = str(info.get("type", "")).lower()

        is_temporal = (
            col_type.startswith("date")
            or col_type.startswith("datetime")
            or col_type.startswith("timestamp")
        )

        if not is_temporal:
            continue

        original_values = df[col].copy()

        def _prep(v):
            if pd.isna(v):
                return None

            if isinstance(v, str):
                s = v.strip()
                if s in {"", "0", "(None)", "None", "nan", "NaN"}:
                    return None
                return s

            if v == 0:
                return None

            return v

        cleaned = original_values.map(_prep)
        parsed = pd.to_datetime(cleaned, errors="coerce")

        bad_mask = cleaned.notna() & parsed.isna()
        if bad_mask.any():
            for idx in df.index[bad_mask]:
                invalid_rows.append({
                    "row_index": idx,
                    "column": col,
                    "db_type": col_type,
                    "original_value": original_values.loc[idx]
                })

        if col_type.startswith("date") and not col_type.startswith("datetime"):
            df[col] = [None if pd.isna(x) else x.date() for x in parsed]
        else:
            df[col] = [None if pd.isna(x) else x.to_pydatetime() for x in parsed]

    if invalid_rows:
        rep_df = pd.DataFrame(invalid_rows)
        if report_path:
            rep_df.to_csv(report_path, index=False, encoding="utf-8-sig")
            print(f"WARNING: Invalid temporal values found. Report written to: {report_path}")

        print("Sample invalid temporal values converted to NULL:")
        print(rep_df.head(20).to_string(index=False))

# ----------------------------
# MAIN
# ----------------------------

print("Resolving sheet name...")
SHEET_NAME = choose_sheet_name(EXCEL_PATH, PREFERRED_SHEETS)
print(f"Using sheet: {SHEET_NAME}")

print("Detecting header row...")
HEADER_ROW = detect_header_row(EXCEL_PATH, SHEET_NAME)

print("Reading Excel...")
df = pd.read_excel(
    EXCEL_PATH,
    sheet_name=SHEET_NAME,
    engine="openpyxl",
    header=HEADER_ROW,
    dtype=object
)

# Excel row reference for reporting
df["__source_excel_row__"] = df.index + HEADER_ROW + 2

# Clean headers
df.columns = [clean_header(c) for c in df.columns]

# Drop empty / invalid headers
valid_columns = []
for c in df.columns:
    if pd.isna(c):
        continue
    if not isinstance(c, str):
        continue
    if c.strip() == "":
        continue
    valid_columns.append(c)

df = df[valid_columns]

print("Final cleaned Excel headers:")
for c in df.columns:
    print("  ", repr(c))

# Keep only mapped Excel columns that exist
present_src_cols = [c for c in COLUMN_MAPPING.keys() if c in df.columns]
missing_src_cols = [c for c in COLUMN_MAPPING.keys() if c not in df.columns]

if missing_src_cols:
    print("WARNING: Missing Excel columns:")
    for c in missing_src_cols:
        print("  ", c)

if not present_src_cols:
    raise ValueError(
        "None of the expected Excel columns were found after header detection. "
        f"Detected headers: {list(df.columns)}"
    )

helper_cols = ["__source_excel_row__"]
df = df[present_src_cols + [c for c in helper_cols if c in df.columns]].copy()

# Rename Excel -> DB names
df.rename(columns=COLUMN_MAPPING, inplace=True)

# Ensure all mapped DB columns exist in df
for _, db_col in COLUMN_MAPPING.items():
    if db_col not in df.columns:
        df[db_col] = None

# Clean all values except helper cols
for col in df.columns:
    if col in helper_cols:
        continue
    df[col] = df[col].map(clean_value)

# Convert all remaining NaN / NA to None
df = df.astype(object)
df = df.where(pd.notna(df), None)

before_rows = len(df)

# Drop completely empty business rows
business_cols = [c for c in df.columns if c not in helper_cols]
df = df.dropna(subset=business_cols, how="all")

after_rows = len(df)
print(f"Filtered out {before_rows - after_rows} empty rows. Rows after empty-row filter: {after_rows}")

if after_rows == 0:
    print("No rows to insert. Exiting.")
    raise SystemExit(0)

# Ensure Item ID exists
if "Item ID" not in df.columns:
    raise ValueError("Required column 'Item ID' not found after mapping.")

# Remove rows where Item ID is blank
before_itemid = len(df)
df = df[df["Item ID"].notna()].copy()
after_itemid = len(df)
print(f"Removed {before_itemid - after_itemid} rows with null Item ID.")

# ----------------------------
# DUPLICATE HANDLING IN EXCEL
# Keep first, skip second/later duplicates
# ----------------------------
skip_reports = []

dup_mask_excel = df.duplicated(subset=["Item ID"], keep="first")
if dup_mask_excel.any():
    dup_report_excel = df.loc[dup_mask_excel, ["__source_excel_row__", "Item ID", "Title"]].copy()
    dup_report_excel.rename(columns={"__source_excel_row__": "Excel Row"}, inplace=True)
    dup_report_excel["Reason"] = "Duplicate Item ID in Excel source - first occurrence kept, this row skipped"
    skip_reports.append(dup_report_excel)

    print(f"Skipping {len(dup_report_excel)} duplicate Excel row(s) based on Item ID (keeping first occurrence).")

# Keep only first occurrence
df = df.loc[~dup_mask_excel].copy()

print(f"Rows after Excel duplicate handling: {len(df)}")

# ----------------------------
# DB CONNECTION
# ----------------------------
conn_url = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASS}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
engine = create_engine(conn_url)

# Read DB schema
db_cols, col_defs, db_norm_map = get_db_columns_and_defs(engine, TABLE_NAME)
print(f"Detected {len(db_cols)} DB columns.")

# ----------------------------
# SKIP ROWS ALREADY IN DB
# ----------------------------
existing_ids_df = pd.read_sql(text(f"SELECT `Item ID` FROM `{TABLE_NAME}`"), engine)
existing_ids = set(existing_ids_df["Item ID"].dropna().astype(str).tolist())

db_exists_mask = df["Item ID"].astype(str).isin(existing_ids)
if db_exists_mask.any():
    dup_report_db = df.loc[db_exists_mask, ["__source_excel_row__", "Item ID", "Title"]].copy()
    dup_report_db.rename(columns={"__source_excel_row__": "Excel Row"}, inplace=True)
    dup_report_db["Reason"] = "Item ID already exists in MySQL table - row skipped"
    skip_reports.append(dup_report_db)

    print(f"Skipping {len(dup_report_db)} row(s) because Item ID already exists in DB.")

df = df.loc[~db_exists_mask].copy()

# Write combined skip report
if skip_reports:
    skipped_df = pd.concat(skip_reports, ignore_index=True)
    skipped_df.to_csv(SKIPPED_DUPLICATES_REPORT_CSV, index=False, encoding="utf-8-sig")
    print(f"Skip report written to: {SKIPPED_DUPLICATES_REPORT_CSV}")

# Remove helper column before DB insert
df = df.drop(columns=helper_cols, errors="ignore")

if len(df) == 0:
    print("No new rows remain to insert after duplicate checks. Exiting.")
    raise SystemExit(0)

# ----------------------------
# ALIGN TO DB
# ----------------------------
df = resolve_columns_against_db(df, db_cols)

good_cols = []
for c in df.columns:
    if pd.isna(c):
        continue
    if not isinstance(c, str):
        continue
    if c.strip() == "":
        continue
    if c.lower() == "nan":
        continue
    good_cols.append(c)

df = df[good_cols]

print("Final DataFrame columns going to MySQL:")
for c in df.columns:
    print("  ", repr(c))

# Temporal cleanup
coerce_temporal_columns(df, col_defs, report_path=INVALID_TEMPORAL_REPORT_CSV)

# Enforce varchar max length
enforce_varchar_maxlen(
    df,
    col_defs,
    db_norm_map,
    TRUNCATION_REPORT_CSV,
    squash_ws=SQUASH_WHITESPACE
)

# Final cleanup
df = df.astype(object)
df = df.where(pd.notna(df), None)

# ----------------------------
# BUILD INSERT SQL
# ----------------------------
cols = list(df.columns)
columns_sql = ", ".join([f"`{c}`" for c in cols])
placeholders = ", ".join([f":p{i}" for i in range(len(cols))])

sql = text(f"""
    INSERT INTO `{TABLE_NAME}` ({columns_sql})
    VALUES ({placeholders})
""")

print("Inserting rows into DB...")

total = len(df)
start_index = 0

with engine.begin() as conn:
    while start_index < total:
        end_index = min(start_index + CHUNK_SIZE, total)
        chunk = df.iloc[start_index:end_index]

        records = []
        for _, row in chunk.iterrows():
            rec = {}
            for i, col in enumerate(cols):
                val = row[col]

                if pd.isna(val):
                    val = None

                rec[f"p{i}"] = val

            records.append(rec)

        # Safety check for NaN
        for r_idx, rec in enumerate(records):
            for k, v in rec.items():
                if isinstance(v, float) and str(v).lower() == "nan":
                    print(f"ERROR: NaN still found in record {r_idx}, field {k}")
                    print(rec)
                    raise ValueError("NaN value still present before INSERT")

        if records:
            conn.execute(sql, records)

        print(f"Inserted rows {start_index + 1}-{end_index} of {total}")
        start_index = end_index

print("DONE — Data loaded successfully!")
