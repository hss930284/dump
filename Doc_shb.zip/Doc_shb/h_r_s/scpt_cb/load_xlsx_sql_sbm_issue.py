import re
import pandas as pd
from sqlalchemy import create_engine, text

# ----------------------------
# CONFIGURATION
# ----------------------------

EXCEL_PATH = r"D:\SBM\SBM_Items.xlsx"
SHEET_NAME = "report"

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB   = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"
TABLE_NAME = "sbm_issue"

CHUNK_SIZE = 1000
TRUNCATION_REPORT_CSV = "truncations_report.csv"
INVALID_TEMPORAL_REPORT_CSV = "invalid_temporal_report.csv"
SQUASH_WHITESPACE = False

COLUMN_MAPPING = {
    "Item Id": "Item_Id",
    "Title": "Title",
    "State": "State",
    "Severity": "Severity",
    "Pilot": "Pilot",
    "Retex": "Retex",
    "Detailed Context": "Detailed_Context",
    "Expected Behavior": "Expected_Behavior",
    "Observed Behavior": "Observed_Behavior",
    "Solution Description": "Solution_Description",

    # Add more mappings here as needed
    "Delivered Solution": "Delivered_Solution",
    "Impacted Modules AEMS": "Impacted_Modules_AEMS",
    "Impacted Specifications AEMS": "Impacted_Specifications_AEMS",
    "Corrected Specifications AEMS": "Corrected_Specifications_AEMS",
    "Active/Inactive": "Active_Inactive",
    "AEMS detected project name": "AEMS_detected_project_name",
    "Affected CDT": "Affected_CDT",
    "Affected MDT": "Affected_MDT",
    "Ampere RF Impact Analysis": "Ampere_RF_Impact_Analysis",
    "Ampere RF Impact Analysis Date": "Ampere_RF_Impact_Analysis_Date",
    "Applicability": "Applicability",
    "Auto Impact Projects AEMS": "Auto_Impact_Projects_AEMS",
    "Auto Impact SOFs": "Auto_Impact_SOFs",
    "Auto Impact Specifications AEMS": "Auto_Impact_Specifications_AEMS",
    "Auto Impacts BCCs": "Auto_Impacts_BCCs",
    "Auto Impacts Modules": "Auto_Impacts_Modules",
    "Calibration File Name": "Calibration_File_Name",
    "Calibration Impact": "Calibration_Impact",
    "Calibration Impact Description": "Calibration_Impact_Description",
    "Calibration Name": "Calibration_Name",
    "Calibration Redeposit": "Calibration_Redeposit",
    "Calibration Reference": "Calibration_Reference",
    "Calibration Workaround": "Calibration_Workaround",
    "Change Request No": "Change_Request_No",
    "Close Cause": "Close_Cause",
    "Close Date": "Close_Date",
    "Comments (IS Closed)": "Comments_IS_Closed",
    "Context (Test condition)": "Context_Test_condition",
    "Corrected BCP/BL/BCC Versions": "Corrected_BCP_BL_BCC_Versions",
    "Corrected BL/BCP/BCC BMS/AC3/INV": "Corrected_BL_BCP_BCC_BMS_AC3_INV",
    "Corrected Delivery Label": "Corrected_Delivery_Label",
    "Corrected FID Reference": "Corrected_FID_Reference",
    "Corrected HW Version": "Corrected_HW_Version",
    "Corrected Module Versions": "Corrected_Module_Versions",
    "Corrected Requirement References": "Corrected_Requirement_References",
    "Corrected Software": "Corrected_Software",
    "Corrected Software AEMS": "Corrected_Software_AEMS",
    "Corrected Specifications": "Corrected_Specifications",
    "Corrected Specifications BMS/AC3/INV": "Corrected_Specifications_BMS_AC3_INV",
    "Corrected Specifications BMS/AC3/INV (TEXT)": "Corrected_Specifications_BMS_AC3_INV_TEXT",
    "Corrected TDH Reference": "Corrected_TDH_Reference",
    "Corrective SDTs": "Corrective_SDTs",
    "DDT Base File (xml)": "DDT_Base_File_xml",
    "DEA-MCC Analysis Started": "DEA_MCC_Analysis_Started",
    "DEA-MCC Solution Delivered": "DEA_MCC_Solution_Delivered",
    "Defined Solutions": "Defined_Solutions",
    "Detailed Trouble Type": "Detailed_Trouble_Type",
    "Detected BL/BCP/BCC": "Detected_BL_BCP_BCC",
    "Detected BL/BCP/BCC BMS/AC3/INV": "Detected_BL_BCP_BCC_BMS_AC3_INV",
    "Detected Engine": "Detected_Engine",
    "Detected Module AEMS": "Detected_Module_AEMS",
    "Detected Module Version": "Detected_Module_Version",
    "Detected SOF AEMS": "Detected_SOF_AEMS",
    "Detected Software AEMS": "Detected_Software_AEMS",
    "Detected Specifications": "Detected_Specifications",
    "Detected Specifications AEMS": "Detected_Specifications_AEMS",
    "Detected Specifications BMS/AC3/INV": "Detected_Specifications_BMS_AC3_INV",
    "Detected Specifications BMS/AC3/INV (TEXT)": "Detected_Specifications_BMS_AC3_INV_TEXT",
    "Detected Vehicle": "Detected_Vehicle",
    "Dettected Software": "Dettected_Software",
    "dIssue Type": "dIssue_Type",
    "Double IS Id": "Double_IS_Id",
    "ECU/Part Name": "ECU_Part_Name",
    "ECU/Part Type": "ECU_Part_Type",
    "ECU/Part Version": "ECU_Part_Version",
    "Exchanges": "Exchanges",
    "Expected Resolution Date": "Expected_Resolution_Date",
    "FID Reference": "FID_Reference",
    "Function Expert Analysis Ended": "Function_Expert_Analysis_Ended",
    "Function Expert Analysis Started": "Function_Expert_Analysis_Started",
    "Function in manual mode is OK on HIL bench": "Function_in_manual_mode_is_OK_on_HIL_bench",
    "Function Leader Analysis Ended": "Function_Leader_Analysis_Ended",
    "Function Leader Analysis Started": "Function_Leader_Analysis_Started",
    "HIL Bench Name": "HIL_Bench_Name",
    "HIL ECU Reference": "HIL_ECU_Reference",
    "HIL Environment Name": "HIL_Environment_Name",
    "HIL Harness or EcuBox Name (BRxx/EBxx)": "HIL_Harness_or_EcuBox_Name_BRxx_EBxx",
    "HIL Loadrack Name (LRxx)": "HIL_Loadrack_Name_LRxx",
    "HIL Supplier": "HIL_Supplier",
    "Horse RF Impact Analysis": "Horse_RF_Impact_Analysis",
    "Horse RF Impact Analysis Date": "Horse_RF_Impact_Analysis_Date",
    "ID Migration": "ID_Migration",
    "Impact": "Impact",
    "Impacted Engines": "Impacted_Engines",
    "Impacted Module Versions": "Impacted_Module_Versions",
    "Impacted Projects": "Impacted_Projects",
    "Impacted Software AEMS": "Impacted_Software_AEMS",
    "Impacted SW Version": "Impacted_SW_Version",
    "Impacted Technical Definition": "Impacted_Technical_Definition",
    "Impacted Vehicles": "Impacted_Vehicles",
    "Input file name": "Input_file_name",
    "Introduction Module Version": "Introduction_Module_Version",
    "Introduction Specifications": "Introduction_Specifications",
    "Introduction Specifications AEMS": "Introduction_Specifications_AEMS",
    "Introduction SW Version": "Introduction_SW_Version",
    "IS Category": "IS_Category",
    "Justification (Regulation Impact)": "Justification_Regulation_Impact",
    "Justification (Safety Impact)": "Justification_Safety_Impact",
    "Last Modified Date": "Last_Modified_Date",
    "Last Modifier": "Last_Modifier",
    "Last State Change Date": "Last_State_Change_Date",
    "Last State Changer": "Last_State_Changer",
    "Max Project Severity": "Max_Project_Severity",
    "Metier Perimeter": "Metier_Perimeter",
    "Night launch ID": "Night_launch_ID",
    "NISSAN corrected Specifications AEMS": "NISSAN_corrected_Specifications_AEMS",
    "Occurence": "Occurence",
    "Open Date": "Open_Date",
    "Original IS link": "Original_IS_link",
    "Owner": "Owner",
    "Part Reference": "Part_Reference",
    "Path to results archive": "Path_to_results_archive",
    "Perimeter": "Perimeter",
    "Pilot Groups": "Pilot_Groups",
    "Planned Delivery Label": "Planned_Delivery_Label",
    "Planned Model Delivery": "Planned_Model_Delivery",
    "Prestation": "Prestation",
    "Project": "Project",
    "Propagation": "Propagation",
    "RA PIE Number": "RA_PIE_Number",
    "RCTL Name": "RCTL_Name",
    "Redeposit": "Redeposit",
    "Regulation Impact": "Regulation_Impact",
    "Reprog File (BTP, PROF)": "Reprog_File_BTP_PROF",
    "Requirement References": "Requirement_References",
    "Responsibility": "Responsibility",
    "Safety Impact": "Safety_Impact",
    "SCDR#0 Date prev": "SCDR_0_Date_prev",
    "SCDR#0 Date real": "SCDR_0_Date_real",
    "SCDR#0 Leader": "SCDR_0_Leader",
    "SCDR#0 Status": "SCDR_0_Status",
    "SCDR#1 Date prev": "SCDR_1_Date_prev",
    "SCDR#1 Date real": "SCDR_1_Date_real",
    "SCDR#1 Leader": "SCDR_1_Leader",
    "SCDR#1 Status": "SCDR_1_Status",
    "SCDR#2 Date prev": "SCDR_2_Date_prev",
    "SCDR#2 Date real": "SCDR_2_Date_real",
    "SCDR#2 Leader": "SCDR_2_Leader",
    "SCDR#2 Status": "SCDR_2_Status",
    "SCDR#3 Date prev": "SCDR_3_Date_prev",
    "SCDR#3 Date real": "SCDR_3_Date_real",
    "SCDR#3 Leader": "SCDR_3_Leader",
    "SCDR#3 Status": "SCDR_3_Status",
    "SCDR#4 Date prev": "SCDR_4_Date_prev",
    "SCDR#4 Date real": "SCDR_4_Date_real",
    "SCDR#4 Leader": "SCDR_4_Leader",
    "SCDR#4 Status": "SCDR_4_Status",
    "Secondary Owner": "Secondary_Owner",
    "Software AEMS not  impacted": "Software_AEMS_not_impacted",
    "Sub-category": "Sub_category",
    "Sub-context": "Sub_context",
    "Submitter": "Submitter",
    "TDH Reference": "TDH_Reference",
    "Technical Conclusion": "Technical_Conclusion",
    "Trouble type": "Trouble_type",
    "Trouble Type Responsible": "Trouble_Type_Responsible",
    "UET Pilot": "UET_Pilot",
    "UET Trouble Type Responsible": "UET_Trouble_Type_Responsible",
    "Validation Type": "Validation_Type",
    "Associated Attachments": "Associated_Attachments",
}

VARIANT_DB_NAMES = {
    "ApplicationScope": ["Application Scope", "applicationscope", "Application scope", "ApplicationScope"],
    "GRADE Rating": ["GRADE Rating", "Grade Rating", "grade rating"],
    "Safe State": ["Safe State", "SafeState", "safe state"],
    "Req Milestone": ["Req Milestone", "ReqMilestone", "req milestone"],
    "Object Identifier": ["Object Identifier", "ObjectIdentifier"],
    "Partners": ["Partners", "Partners Ownership", "PartnersOwnership"],
}

# ----------------------------
# UTILITY FUNCTIONS
# ----------------------------

def clean_header(h):
    return (
        str(h)
        .strip()
        .replace("\uFEFF", "")
        .replace("\r", "")
        .replace("\n", "")
        .replace("_x000D_", "")
        .replace("\xa0", " ")
        .strip()
    )

def clean_value(v):
    """
    General value cleaning:
    - pandas/NumPy missing -> None
    - empty strings / (None) / None / nan -> None
    - strips strings and removes _x000D_
    """
    if pd.isna(v):
        return None

    if isinstance(v, str):
        s = (
            v.strip()
             .replace("\r", "")
             .replace("_x000D_", "")
             .strip()
        )
        if s in {"", "(None)", "None", "nan", "NaN"}:
            return None
        return s

    return v

def squash_whitespace(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()

def normalize_for_match(name: str) -> str:
    return "".join(str(name).split()).lower()

def get_db_columns_and_defs(engine, table_name: str):
    """
    Returns:
      cols: list of DB column names
      defs: dict {col: {"type": "...", "nullable": bool, "maxlen": int or None}}
      norm_key_map: normalized_name -> actual DB column
    """
    import re as _re

    defs = {}
    cols = []

    with engine.connect() as conn:
        rs = conn.execute(text(f"SHOW COLUMNS FROM `{table_name}`"))
        for row in rs:
            field = row[0]
            col_type = row[1]
            nullable = (str(row[2]).upper() == "YES")
            cols.append(field)

            maxlen = None
            m = _re.match(r"varchar\((\d+)\)", col_type, flags=_re.I)
            if m:
                maxlen = int(m.group(1))

            defs[field] = {
                "type": col_type,
                "nullable": nullable,
                "maxlen": maxlen
            }

    norm_key_map = {normalize_for_match(c): c for c in cols}
    return cols, defs, norm_key_map

def resolve_columns_against_db(df: pd.DataFrame, db_cols: list) -> pd.DataFrame:
    """
    Renames DataFrame columns to exact DB names wherever possible.
    Drops unmatched columns.
    """
    db_set = set(db_cols)
    db_norm_map = {normalize_for_match(c): c for c in db_cols}

    renames = {}
    unmatched = []

    for c in df.columns:
        if not isinstance(c, str):
            unmatched.append(c)
            continue

        if c in db_set:
            continue

        logical = c
        variants = VARIANT_DB_NAMES.get(logical, [])
        found = None

        for v in variants:
            if v in db_set:
                found = v
                break

        if not found:
            key = normalize_for_match(c)
            if key in db_norm_map:
                found = db_norm_map[key]

        if found:
            renames[c] = found
        else:
            unmatched.append(c)

    if renames:
        print("Resolved column variants:", renames)
        df = df.rename(columns=renames)

    if unmatched:
        print("Dropping columns not in DB:", unmatched)
        df = df.drop(columns=unmatched, errors="ignore")

    keep = [c for c in df.columns if isinstance(c, str) and c in db_set]
    df = df[keep]

    return df

def enforce_varchar_maxlen(df: pd.DataFrame, col_defs: dict, db_norm_map: dict, report_path: str, squash_ws: bool = False):
    """
    Truncate values that exceed varchar limits, and write a report.
    """
    truncations = []

    for df_col in df.columns:
        norm = normalize_for_match(df_col)
        db_col_name = db_norm_map.get(norm, df_col)

        info = col_defs.get(db_col_name, {})
        maxlen = info.get("maxlen")

        if not maxlen:
            continue

        new_vals = []
        for row_idx, val in enumerate(df[df_col].tolist()):
            if val is None or pd.isna(val):
                new_vals.append(None)
                continue

            if isinstance(val, str):
                s = squash_whitespace(val) if squash_ws else val
                if len(s) > maxlen:
                    truncations.append({
                        "row_index": row_idx,
                        "column": df_col,
                        "db_column": db_col_name,
                        "original_length": len(val),
                        "max_allowed": maxlen,
                        "original_value": val,
                        "truncated_value": s[:maxlen]
                    })
                    new_vals.append(s[:maxlen])
                else:
                    new_vals.append(s)
            else:
                new_vals.append(val)

        df[df_col] = new_vals

    if truncations:
        rep_df = pd.DataFrame(truncations)
        rep_df.to_csv(report_path, index=False, encoding="utf-8-sig")
        print(f"WARNING: {len(truncations)} value(s) exceeded varchar limits and were truncated.")
        print(f"Truncation report written to: {report_path}")

def coerce_temporal_columns(df: pd.DataFrame, col_defs: dict, report_path: str = None):
    """
    Convert DATE / DATETIME / TIMESTAMP columns safely.
    Invalid placeholders like:
      0, '0', '', '(None)', 'None', 'nan'
    are converted to None.

    Valid values are parsed into Python date/datetime objects.
    Invalid parseable values are logged and set to None.
    """
    invalid_rows = []

    for col in df.columns:
        info = col_defs.get(col, {})
        col_type = str(info.get("type", "")).lower()

        is_temporal = (
            col_type.startswith("date")
            or col_type.startswith("datetime")
            or col_type.startswith("timestamp")
        )

        if not is_temporal:
            continue

        original_values = df[col].copy()

        def _prep(v):
            if pd.isna(v):
                return None

            if isinstance(v, str):
                s = v.strip()
                if s in {"", "0", "(None)", "None", "nan", "NaN"}:
                    return None
                return s

            if v == 0:
                return None

            return v

        cleaned = original_values.map(_prep)
        parsed = pd.to_datetime(cleaned, errors="coerce")

        bad_mask = cleaned.notna() & parsed.isna()
        if bad_mask.any():
            for idx in df.index[bad_mask]:
                invalid_rows.append({
                    "row_index": idx,
                    "column": col,
                    "db_type": col_type,
                    "original_value": original_values.loc[idx]
                })

        # Convert parsed timestamps to plain Python objects
        if col_type.startswith("date") and not col_type.startswith("datetime"):
            df[col] = [None if pd.isna(x) else x.date() for x in parsed]
        else:
            df[col] = [None if pd.isna(x) else x.to_pydatetime() for x in parsed]

    if invalid_rows:
        rep_df = pd.DataFrame(invalid_rows)
        if report_path:
            rep_df.to_csv(report_path, index=False, encoding="utf-8-sig")
            print(f"WARNING: Invalid temporal values found. Report written to: {report_path}")

        print("Sample invalid temporal values converted to NULL:")
        print(rep_df.head(20).to_string(index=False))

# ----------------------------
# MAIN
# ----------------------------

print("Reading Excel...")
df = pd.read_excel(EXCEL_PATH, sheet_name=SHEET_NAME, engine="openpyxl", dtype=object)

# Clean headers
df.columns = [clean_header(c) for c in df.columns]

# Drop empty / invalid headers
valid_columns = []
for c in df.columns:
    if pd.isna(c):
        continue
    if not isinstance(c, str):
        continue
    if c.strip() == "":
        continue
    valid_columns.append(c)

df = df[valid_columns]

print("Final cleaned Excel headers:")
for c in df.columns:
    print("  ", repr(c))

# Keep only mapped Excel columns that exist
present_src_cols = [c for c in COLUMN_MAPPING.keys() if c in df.columns]
missing_src_cols = [c for c in COLUMN_MAPPING.keys() if c not in df.columns]

if missing_src_cols:
    print("WARNING: Missing Excel columns:")
    for c in missing_src_cols:
        print("  ", c)

df = df[present_src_cols].copy()

# Rename Excel -> DB names
df.rename(columns=COLUMN_MAPPING, inplace=True)

# Ensure all mapped DB columns exist in df
for excel_col, db_col in COLUMN_MAPPING.items():
    if db_col not in df.columns:
        df[db_col] = None

# Clean all values
for col in df.columns:
    df[col] = df[col].map(clean_value)

# Convert all remaining NaN / NA to None
df = df.astype(object)
df = df.where(pd.notna(df), None)

before_rows = len(df)
df = df.dropna(how="all")
after_rows = len(df)

print(f"Filtered out {before_rows - after_rows} empty rows. Rows to insert: {after_rows}")

if after_rows == 0:
    print("No rows to insert. Exiting.")
    raise SystemExit(0)

# DB connection
conn_url = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASS}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
engine = create_engine(conn_url)

# Read DB schema
db_cols, col_defs, db_norm_map = get_db_columns_and_defs(engine, TABLE_NAME)
print(f"Detected {len(db_cols)} DB columns.")

# Align DataFrame to DB
df = resolve_columns_against_db(df, db_cols)

# Final cleanup of bad columns
good_cols = []
for c in df.columns:
    if pd.isna(c):
        continue
    if not isinstance(c, str):
        continue
    if c.strip() == "":
        continue
    if c.lower() == "nan":
        continue
    good_cols.append(c)

df = df[good_cols]

print("Final DataFrame columns going to MySQL:")
for c in df.columns:
    print("  ", repr(c))

# NEW: safely coerce DATE / DATETIME / TIMESTAMP columns
coerce_temporal_columns(df, col_defs, report_path=INVALID_TEMPORAL_REPORT_CSV)

# Enforce varchar limits
enforce_varchar_maxlen(
    df,
    col_defs,
    db_norm_map,
    TRUNCATION_REPORT_CSV,
    squash_ws=SQUASH_WHITESPACE
)

# Final protection: convert any remaining missing values to None
df = df.astype(object)
df = df.where(pd.notna(df), None)

# Build INSERT SQL
cols = list(df.columns)
columns_sql = ", ".join([f"`{c}`" for c in cols])
placeholders = ", ".join([f":p{i}" for i in range(len(cols))])

sql = text(f"""
    INSERT INTO `{TABLE_NAME}` ({columns_sql})
    VALUES ({placeholders})
""")

print("Inserting rows into DB...")

total = len(df)
start_index = 0

with engine.begin() as conn:
    while start_index < total:
        end_index = min(start_index + CHUNK_SIZE, total)
        chunk = df.iloc[start_index:end_index]

        records = []
        for _, row in chunk.iterrows():
            rec = {}
            for i, col in enumerate(cols):
                val = row[col]

                # absolute final protection against NaN / NA
                if pd.isna(val):
                    val = None

                rec[f"p{i}"] = val

            records.append(rec)

        # Debug check: ensure no NaN slips through
        for r_idx, rec in enumerate(records):
            for k, v in rec.items():
                if isinstance(v, float) and str(v).lower() == "nan":
                    print(f"ERROR: NaN still found in record {r_idx}, field {k}")
                    print(rec)
                    raise ValueError("NaN value still present before INSERT")

        if records:
            conn.execute(sql, records)

        print(f"Inserted rows {start_index + 1}–{end_index} of {total}")
        start_index = end_index

print("✔ DONE — Data loaded successfully!")