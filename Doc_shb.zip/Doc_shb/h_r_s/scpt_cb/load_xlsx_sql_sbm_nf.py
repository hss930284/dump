#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final importer for Extract HNFs.xlsx -> MySQL table sbm_nf.

Aligned naming:
- Excel column: Validators
- MySQL table column: Validators

Special handling:
- If Validators has [Deleted Field], it is inserted as NULL.
- Any cell with [Deleted Field] is treated as NULL.
- Older Excel column Validators2 is automatically renamed to Validators.
- Compatible with newer pandas versions using DataFrame.map().
"""

import re
import sys
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"

TABLE_NAME = "sbm_nf"
EXCEL_FILE = r"D:\SBM\Extract HNFs.xlsx"
SHEET_NAME = 0
SOURCE_KEY_COLUMN = "Item Id"

UPSERT_ON_DUPLICATE_ITEM_ID = True
DROP_ROWS_WITHOUT_ITEM_ID = True

LOG_FILE = "import_extract_hnfs_to_sbm_nf.log"
REJECTED_ROWS_CSV = "rejected_extract_hnfs_rows.csv"
IMPORT_SUMMARY_CSV = "import_extract_hnfs_summary.csv"

SBM_NF_COLUMNS = [
    "Horse New Function", "Item Id", "Title", "Global NF Cotation", "Active/Inactive",
    "Description", "Owner", "Perimeter", "Submitter", "Project", "Technical Context",
    "Technological Bricks", "Pilot Program Line (QC)", "Program Line (QC)", "Engine",
    "Vehicle", "Pilot", "State", "Expected deliveries", "SW Specification", "ECM",
    "Tuning", "Operating Conditions", "Corresponding NDL", "Cotation Decision",
    "Cotation Date", "Validators", "Date FpDR0 / SDR1", "FpDR0 / SDR1 Status",
    "N° IDOC FpDR0 / SDR1", "Date FpDR1 / SDR2 or QDR1",
    "FpDR1 / SDR2 or QDR1 Status", "N° IDOC FpDR1 / SDR2 or QDR1",
    "Date FpDR2 / SDR3", "FpDR2 / SDR3 Status", "N° IDOC FpDR2 / SDR3",
    "Date FpDR3 / SDR4 or QDR2", "FpDR3 / SDR4 or QDR2 Status",
    "N° IDOC FpDR3 / SDR4 or QDR2", "Date FpDR4 / SDR5 or QDR3",
    "FpDR4 / SDR5 or QDR3 Status", "N° IDOC FpDR4 / SDR5 or QDR3",
    "Associated DMFI", "Instructors", "SCDR#0 date prev", "SCDR#0 date real",
    "SCDR#0 status", "Close Date", "Associated Attachments",
]

DATE_COLUMNS = {
    "Cotation Date", "Date FpDR0 / SDR1", "Date FpDR1 / SDR2 or QDR1",
    "Date FpDR2 / SDR3", "Date FpDR3 / SDR4 or QDR2",
    "Date FpDR4 / SDR5 or QDR3", "SCDR#0 date prev", "SCDR#0 date real",
    "Close Date",
}

def setup_logging() -> logging.Logger:
    logger_obj = logging.getLogger("import_extract_hnfs_to_sbm_nf")
    logger_obj.setLevel(logging.INFO)
    logger_obj.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger_obj.addHandler(sh)
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    logger_obj.addHandler(fh)
    return logger_obj

logger = setup_logging()

def quote_identifier(identifier: str) -> str:
    return "`" + identifier.replace("`", "``") + "`"

def normalize_col_name(value: Any) -> str:
    if value is None:
        return ""
    text_value = str(value).replace("\u00a0", " ").strip()
    text_value = re.sub(r"\s+", " ", text_value)
    return text_value.lower()

def clean_cell(value: Any) -> Optional[Any]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, str):
        value = value.replace("\u00a0", " ").replace("_x000D_", "\n")
        value = re.sub(r"\r\n?", "\n", value)
        value = value.strip()
        if value.lower() in {
            "", "nan", "none", "null", "(none)", "-", "[deleted field]", "deleted field"
        }:
            return None
        return value
    return value

def clean_dataframe_values(df: pd.DataFrame) -> pd.DataFrame:
    if hasattr(df, "map"):
        return df.map(clean_cell)
    return df.applymap(clean_cell)

def clean_column_name(value: Any) -> str:
    value = "" if value is None else str(value)
    value = value.replace("\u00a0", " ").strip()
    value = re.sub(r"\s+", " ", value)
    return value

def safe_param_name(column_name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_]", "_", column_name)
    safe = re.sub(r"_+", "_", safe).strip("_")
    if not safe:
        safe = "col"
    if safe[0].isdigit():
        safe = "c_" + safe
    return safe

def to_mysql_date(value: Any) -> Optional[str]:
    if clean_cell(value) is None:
        return None
    parsed = pd.to_datetime(value, errors="coerce")
    if pd.isna(parsed):
        logger.warning("Invalid date value skipped: %r", value)
        return None
    return parsed.date().isoformat()

def get_mysql_engine():
    url = URL.create(
        "mysql+pymysql", username=MYSQL_USER, password=MYSQL_PASS,
        host=MYSQL_HOST, port=MYSQL_PORT, database=MYSQL_DB,
        query={"charset": "utf8mb4"},
    )
    return create_engine(url, pool_pre_ping=True)

def get_table_columns(conn) -> Set[str]:
    rows = conn.execute(text(f"SHOW COLUMNS FROM {quote_identifier(TABLE_NAME)}")).fetchall()
    return {row[0] for row in rows}

def validate_table_schema(conn):
    existing_columns = get_table_columns(conn)
    logger.info("Connected DB=%s, table=%s", MYSQL_DB, TABLE_NAME)
    logger.info("MySQL table columns found: %s", sorted(existing_columns))
    missing_columns = [c for c in SBM_NF_COLUMNS if c not in existing_columns]
    if missing_columns:
        raise RuntimeError(
            "Missing columns in MySQL table `sbm_nf`: "
            + ", ".join(f"`{c}`" for c in missing_columns)
        )
    logger.info("MySQL table schema validation passed.")

def find_header_row(excel_file: str, sheet_name=0) -> int:
    preview = pd.read_excel(excel_file, sheet_name=sheet_name, header=None, engine="openpyxl", dtype=object)
    required_markers = {"item id", "title"}
    optional_markers = {"description", "state", "owner"}
    best_row = None
    best_score = -1
    for idx, row in preview.iterrows():
        values = {normalize_col_name(v) for v in row.tolist() if str(v).strip() != ""}
        score = len(required_markers.intersection(values)) * 10 + len(optional_markers.intersection(values))
        if score > best_score:
            best_score = score
            best_row = idx
    if best_row is None or best_score < 20:
        raise RuntimeError("Unable to detect Excel header row. Expected row containing 'Item Id' and 'Title'.")
    logger.info("Detected Excel header row at zero-based index: %s", best_row)
    return int(best_row)

def load_excel_data(excel_file: str, sheet_name=0) -> pd.DataFrame:
    if not Path(excel_file).exists():
        raise FileNotFoundError(f"Excel file not found: {excel_file}")
    header_row = find_header_row(excel_file, sheet_name=sheet_name)
    df = pd.read_excel(excel_file, sheet_name=sheet_name, header=header_row, engine="openpyxl", dtype=object)
    df = df.dropna(axis=1, how="all")
    df = df.dropna(axis=0, how="all")
    df.columns = [clean_column_name(c) for c in df.columns]
    if SOURCE_KEY_COLUMN in df.columns:
        df = df[df[SOURCE_KEY_COLUMN].astype(str).str.strip().str.lower() != SOURCE_KEY_COLUMN.lower()]
    if "Validators2" in df.columns and "Validators" not in df.columns:
        df = df.rename(columns={"Validators2": "Validators"})
        logger.info("Renamed Excel column 'Validators2' to 'Validators'.")
    df = clean_dataframe_values(df)
    logger.info("Loaded Excel rows after cleanup: %s", len(df))
    logger.info("Loaded Excel columns: %s", list(df.columns))
    return df

def align_dataframe_to_table(df: pd.DataFrame) -> pd.DataFrame:
    rejected_rows = []
    if SOURCE_KEY_COLUMN not in df.columns:
        raise RuntimeError(f"Required source column '{SOURCE_KEY_COLUMN}' not found in Excel. Columns={list(df.columns)}")
    if DROP_ROWS_WITHOUT_ITEM_ID:
        blank_mask = df[SOURCE_KEY_COLUMN].apply(lambda x: clean_cell(x) is None)
        if blank_mask.any():
            rejected = df[blank_mask].copy()
            rejected["Reject Reason"] = f"Blank {SOURCE_KEY_COLUMN}"
            rejected_rows.append(rejected)
            df = df[~blank_mask].copy()
    for col in SBM_NF_COLUMNS:
        if col not in df.columns:
            df[col] = None
    extra_columns = [c for c in df.columns if c not in SBM_NF_COLUMNS]
    if extra_columns:
        logger.warning("Extra Excel columns not present in sbm_nf table and will be ignored: %s", extra_columns)
    df = df[SBM_NF_COLUMNS].copy()
    for col in DATE_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(to_mysql_date)
    before = len(df)
    df = df.drop_duplicates(subset=[SOURCE_KEY_COLUMN], keep="last").copy()
    after = len(df)
    if before != after:
        logger.warning("Removed duplicate Item Id rows. Before=%s After=%s", before, after)
    if rejected_rows:
        pd.concat(rejected_rows, ignore_index=True).to_csv(REJECTED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.warning("Rejected rows written to: %s", REJECTED_ROWS_CSV)
    logger.info("Rows ready for import: %s", len(df))
    return df

def build_insert_sql(columns: List[str]) -> str:
    col_sql = ", ".join(quote_identifier(c) for c in columns)
    val_sql = ", ".join(f":{safe_param_name(c)}" for c in columns)
    if UPSERT_ON_DUPLICATE_ITEM_ID:
        update_columns = [c for c in columns if c != SOURCE_KEY_COLUMN]
        update_sql = ", ".join(f"{quote_identifier(c)} = VALUES({quote_identifier(c)})" for c in update_columns)
        return f"""
        INSERT INTO {quote_identifier(TABLE_NAME)} ({col_sql})
        VALUES ({val_sql})
        ON DUPLICATE KEY UPDATE
            {update_sql}
        """
    return f"""
    INSERT INTO {quote_identifier(TABLE_NAME)} ({col_sql})
    VALUES ({val_sql})
    """

def row_to_params(row: pd.Series, columns: List[str]) -> Dict[str, Any]:
    return {safe_param_name(c): clean_cell(row.get(c)) for c in columns}

def import_to_mysql(df: pd.DataFrame) -> Dict[str, Any]:
    engine = get_mysql_engine()
    columns = SBM_NF_COLUMNS
    insert_sql = text(build_insert_sql(columns))
    inserted_or_updated = 0
    failed = []
    with engine.begin() as conn:
        validate_table_schema(conn)
        for idx, row in df.iterrows():
            params = row_to_params(row, columns)
            try:
                conn.execute(insert_sql, params)
                inserted_or_updated += 1
            except Exception as ex:
                failed.append({"row_index": idx, SOURCE_KEY_COLUMN: row.get(SOURCE_KEY_COLUMN), "error": str(ex)})
                logger.exception("Failed to import row index=%s Item Id=%s", idx, row.get(SOURCE_KEY_COLUMN))
    if failed:
        pd.DataFrame(failed).to_csv(REJECTED_ROWS_CSV, index=False, encoding="utf-8-sig")
        logger.warning("Failed import rows written to: %s", REJECTED_ROWS_CSV)
    summary = {
        "excel_file": EXCEL_FILE, "table_name": TABLE_NAME, "rows_attempted": len(df),
        "rows_inserted_or_updated": inserted_or_updated, "rows_failed": len(failed),
        "upsert_enabled": UPSERT_ON_DUPLICATE_ITEM_ID,
    }
    pd.DataFrame([summary]).to_csv(IMPORT_SUMMARY_CSV, index=False, encoding="utf-8-sig")
    logger.info("Import summary written to: %s", IMPORT_SUMMARY_CSV)
    return summary

def main():
    logger.info("Starting import from Excel to MySQL table %s", TABLE_NAME)
    df_raw = load_excel_data(EXCEL_FILE, SHEET_NAME)
    df_ready = align_dataframe_to_table(df_raw)
    summary = import_to_mysql(df_ready)
    logger.info("Import completed successfully.")
    logger.info("Summary: %s", summary)

if __name__ == "__main__":
    main()
