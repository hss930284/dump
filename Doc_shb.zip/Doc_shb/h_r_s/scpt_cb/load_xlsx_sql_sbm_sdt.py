import pandas as pd
import mysql.connector
from datetime import datetime
import math


# ============================================================
# MySQL Configuration
# ============================================================

MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "admin",
    "database": "sbm_applications",
    "port": 3306
}

EXCEL_FILE_PATH = r"D:\SBM\Extract SDT.xlsx"
SHEET_NAME = "report"
TABLE_NAME = "sbm_sdt"


# ============================================================
# Excel to MySQL Column Mapping
# Since your MySQL table uses same Excel column names,
# mapping is Excel column -> same MySQL column
# ============================================================

COLUMN_MAPPING = {
    "Item Id": "Item Id",
    "Spec Version": "Spec Version",
    "Active/Inactive": "Active/Inactive",
    "Affected CR": "Affected CR",
    "Affected Issues": "Affected Issues",
    "ASIL Level": "ASIL Level",
    "Associated Tags": "Associated Tags",
    "Classification": "Classification",
    "Item Type": "Item Type",
    "Last Modified Date": "Last Modified Date",
    "Metier Delivery": "Metier Delivery",
    "New or Evolution?": "New or Evolution?",
    "Owner": "Owner",
    "Previous Specification Version": "Previous Specification Version",
    "Project": "Project",
    "State": "State",
    "Submit Date": "Submit Date",
    "Submitter": "Submitter",
    "SW Item Type": "SW Item Type",
    "SW Project": "SW Project",
    "Associated Attachments": "Associated Attachments"
}

DATE_COLUMNS = [
    "Last Modified Date",
    "Submit Date"
]


# ============================================================
# Helper Functions
# ============================================================

def clean_value(value):
    """
    Converts NaN, NaT, empty strings, and '(None)' into None.
    This allows MySQL to store NULL.
    """
    if value is None:
        return None

    if isinstance(value, float) and math.isnan(value):
        return None

    if pd.isna(value):
        return None

    value = str(value).strip()

    if value == "" or value.lower() in ["nan", "nat", "(none)", "none", "null"]:
        return None

    return value


def parse_datetime(value):
    """
    Converts Excel/SBM datetime values into MySQL-compatible datetime.
    Example:
      4/27/2026 10:27 -> 2026-04-27 10:27:00
    """
    value = clean_value(value)

    if value is None:
        return None

    if isinstance(value, pd.Timestamp):
        return value.to_pydatetime().strftime("%Y-%m-%d %H:%M:%S")

    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")

    value = str(value).strip()

    possible_formats = [
        "%m/%d/%Y %H:%M:%S",
        "%m/%d/%Y %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M"
    ]

    for fmt in possible_formats:
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass

    raise ValueError(f"Invalid datetime format: {value}")


def backtick(name):
    """
    Wrap table/column names with backticks for MySQL.
    Required because column names contain spaces/special characters:
      Item Id
      Active/Inactive
      New or Evolution?
    """
    return f"`{name}`"


# ============================================================
# Main Import Logic
# ============================================================

def import_excel_to_mysql():
    connection = None
    cursor = None

    try:
        print("Connecting to MySQL...")

        connection = mysql.connector.connect(**MYSQL_CONFIG)
        cursor = connection.cursor()

        print("Reading Excel file...")

        df = pd.read_excel(
            EXCEL_FILE_PATH,
            sheet_name=SHEET_NAME,
            engine="openpyxl",
            dtype=str
        )

        print(f"Excel rows found: {len(df)}")

        # Strip extra spaces from Excel headers
        df.columns = [str(col).strip() for col in df.columns]

        # Keep only mapped columns that exist in Excel
        available_columns = [
            excel_col for excel_col in COLUMN_MAPPING.keys()
            if excel_col in df.columns
        ]

        missing_columns = [
            excel_col for excel_col in COLUMN_MAPPING.keys()
            if excel_col not in df.columns
        ]

        if missing_columns:
            print("Warning: These expected columns are missing in Excel:")
            for col in missing_columns:
                print(f"  - {col}")

        if not available_columns:
            raise Exception("No matching SDT columns found in Excel. Please check the Excel header row.")

        df = df[available_columns]

        # Rename Excel columns to MySQL column names
        df.rename(columns=COLUMN_MAPPING, inplace=True)

        mysql_columns = list(df.columns)

        if "Item Id" not in mysql_columns:
            raise Exception("Mandatory column 'Item Id' is missing. Cannot import data.")

        # Build insert query
        column_list = ", ".join([backtick(col) for col in mysql_columns])
        placeholder_list = ", ".join(["%s"] * len(mysql_columns))

        update_columns = [
            col for col in mysql_columns
            if col != "Item Id"
        ]

        update_clause = ", ".join([
            f"{backtick(col)} = VALUES({backtick(col)})"
            for col in update_columns
        ])

        insert_query = f"""
            INSERT INTO {backtick(TABLE_NAME)}
            ({column_list})
            VALUES ({placeholder_list})
            ON DUPLICATE KEY UPDATE
            {update_clause},
            `updated_at` = CURRENT_TIMESTAMP
        """

        inserted_or_updated_count = 0
        failed_count = 0
        skipped_count = 0

        print("Starting import...")

        for index, row in df.iterrows():
            try:
                row_data = {}

                for col in mysql_columns:
                    value = row[col]

                    if col in DATE_COLUMNS:
                        value = parse_datetime(value)
                    else:
                        value = clean_value(value)

                    row_data[col] = value

                # Skip row if Item Id is empty
                if not row_data.get("Item Id"):
                    skipped_count += 1
                    print(f"Row {index + 2} skipped: Item Id is empty")
                    continue

                values = [row_data[col] for col in mysql_columns]

                cursor.execute(insert_query, values)
                inserted_or_updated_count += 1

            except Exception as row_error:
                failed_count += 1
                print("=" * 80)
                print(f"Row {index + 2} import failed.")
                print(f"Item Id: {row.get('Item Id')}")
                print(f"Error: {row_error}")
                print("=" * 80)

        connection.commit()

        print("\nImport completed.")
        print(f"Inserted/Updated rows: {inserted_or_updated_count}")
        print(f"Skipped rows: {skipped_count}")
        print(f"Failed rows: {failed_count}")

    except Exception as error:
        if connection:
            connection.rollback()
        print(f"Import failed: {error}")

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
        print("MySQL connection closed.")


# ============================================================
# Run Script
# ============================================================

if __name__ == "__main__":
    import_excel_to_mysql()