import pandas as pd
import pymysql
from datetime import datetime

# ==========================================================
# MYSQL CONFIGURATION
# ==========================================================

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB   = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"
TABLE_NAME = "sbm_tag"

# ==========================================================
# EXCEL CONFIGURATION
# ==========================================================

EXCEL_FILE_PATH = r"D:\SBM\TAGs.xlsx"
SHEET_NAME = 0

# Excel header is at row 6.
# Pandas index starts from 0, so row 6 = index 5.
EXCEL_HEADER_ROW_INDEX = 5

# ==========================================================
# IMPORT CONTROL
# ==========================================================

SKIP_IMPORT = False

# START_DATA_ROW = 1 means first data row after header, i.e. Excel row 7
START_DATA_ROW = 1

# Example:
# END_DATA_ROW = 5 imports only first 5 data rows
# END_DATA_ROW = None imports all rows
END_DATA_ROW = 5

SKIP_DUPLICATE_ITEM_ID = True
SHOW_PREVIEW = True

# ==========================================================
# EXPECTED COLUMNS - SAME AS MYSQL TABLE
# ==========================================================

EXPECTED_COLUMNS = [
    "Item Id",
    "Title",
    "Tag Item Type",
    "Tag High Level",
    "Tag Middle Level",
    "Tag Bottom Level",
    "Tag Description",
    "State",
    "Introduction MD",
    "Obsolescence MD",
    "Tag Classification"
]

# ==========================================================
# FUNCTIONS
# ==========================================================

def clean_value(value):
    """
    Convert Excel blank values, NaN, '(None)', 'None', 'null' to Python None.
    Python None becomes SQL NULL in MySQL.
    """

    if pd.isna(value):
        return None

    value = str(value).strip()

    if value == "" or value.lower() in ["(none)", "none", "nan", "null"]:
        return None

    return value


def get_mysql_connection():
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASS,
        database=MYSQL_DB,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor
    )


def validate_columns(df):
    missing_columns = [col for col in EXPECTED_COLUMNS if col not in df.columns]

    if missing_columns:
        print("\nAvailable columns found in Excel:")
        for col in df.columns:
            print(f"- {col}")

        raise ValueError(
            "\nMissing required columns in Excel file: "
            + ", ".join(missing_columns)
        )


def read_excel_data():
    print(f"Reading Excel file: {EXCEL_FILE_PATH}")
    print("Using Excel row 6 as header...")

    df = pd.read_excel(
        EXCEL_FILE_PATH,
        sheet_name=SHEET_NAME,
        engine="openpyxl",
        header=EXCEL_HEADER_ROW_INDEX
    )

    # Clean column names
    df.columns = [str(col).strip() for col in df.columns]

    validate_columns(df)

    # Keep only expected columns
    df = df[EXPECTED_COLUMNS]

    # Drop fully blank rows
    df = df.dropna(how="all")

    # Row range selection
    start_index = max(START_DATA_ROW - 1, 0)

    if END_DATA_ROW is not None:
        df = df.iloc[start_index:END_DATA_ROW]
    else:
        df = df.iloc[start_index:]

    # Force object type so None can be stored properly
    df = df.astype(object)

    # Clean each cell
    for col in EXPECTED_COLUMNS:
        df[col] = df[col].apply(clean_value)

    # Strong replacement for any remaining pandas NaN
    df = df.where(pd.notnull(df), None)

    # Remove rows where Item Id is missing
    df = df[df["Item Id"].notna()]

    return df


def item_id_exists(cursor, item_id):
    sql = f"""
        SELECT COUNT(*) AS cnt
        FROM `{TABLE_NAME}`
        WHERE `Item Id` = %s
    """
    cursor.execute(sql, (item_id,))
    result = cursor.fetchone()
    return result["cnt"] > 0


def insert_data(df):
    if SKIP_IMPORT:
        print("\nSKIP_IMPORT is True. No data inserted into MySQL.")
        return

    if df.empty:
        print("\nNo valid data available for import.")
        return

    insert_sql = f"""
        INSERT INTO `{TABLE_NAME}` (
            `Item Id`,
            `Title`,
            `Tag Item Type`,
            `Tag High Level`,
            `Tag Middle Level`,
            `Tag Bottom Level`,
            `Tag Description`,
            `State`,
            `Introduction MD`,
            `Obsolescence MD`,
            `Tag Classification`
        )
        VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
        )
    """

    inserted_count = 0
    skipped_duplicate_count = 0
    failed_count = 0

    connection = None

    try:
        connection = get_mysql_connection()

        with connection.cursor() as cursor:

            for index, row in df.iterrows():

                # Clean Item Id also before duplicate check
                item_id = clean_value(row["Item Id"])

                try:
                    if item_id is None:
                        print(f"Skipped row index {index}: Item Id is empty")
                        failed_count += 1
                        continue

                    if SKIP_DUPLICATE_ITEM_ID and item_id_exists(cursor, item_id):
                        print(f"Skipped duplicate Item Id: {item_id}")
                        skipped_duplicate_count += 1
                        continue

                    # IMPORTANT:
                    # Clean values again right before insert.
                    # This prevents 'nan can not be used with MySQL'.
                    values = tuple(clean_value(row[col]) for col in EXPECTED_COLUMNS)

                    cursor.execute(insert_sql, values)
                    inserted_count += 1

                except Exception as row_error:
                    failed_count += 1
                    print("----------------------------------------")
                    print(f"Failed to insert Item Id: {item_id}")
                    print(f"DataFrame row index: {index}")
                    print(f"Values attempted: {tuple(clean_value(row[col]) for col in EXPECTED_COLUMNS)}")
                    print(f"Error: {row_error}")
                    print("----------------------------------------")

            connection.commit()

    except Exception as error:
        if connection:
            connection.rollback()

        print("\nImport failed. Transaction rolled back.")
        print(f"Error: {error}")

    finally:
        if connection:
            connection.close()

    print("\n========== IMPORT SUMMARY ==========")
    print(f"Database                  : {MYSQL_DB}")
    print(f"Table                     : {TABLE_NAME}")
    print(f"Excel file                : {EXCEL_FILE_PATH}")
    print(f"Header row used           : Excel row 6")
    print(f"Total selected rows       : {len(df)}")
    print(f"Inserted rows             : {inserted_count}")
    print(f"Skipped duplicate rows    : {skipped_duplicate_count}")
    print(f"Failed rows               : {failed_count}")
    print(f"Completed at              : {datetime.now()}")
    print("====================================")


# ==========================================================
# MAIN EXECUTION
# ==========================================================

if __name__ == "__main__":

    df_tags = read_excel_data()

    print("\nRows selected for import:", len(df_tags))

    if SHOW_PREVIEW:
        print("\nPreview of selected data:")
        preview_df = df_tags.copy()
        preview_df = preview_df.where(pd.notnull(preview_df), None)
        print(preview_df.head(10).to_string(index=False))

    insert_data(df_tags)
