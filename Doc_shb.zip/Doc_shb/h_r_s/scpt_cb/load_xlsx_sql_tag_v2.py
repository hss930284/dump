import os
import re
from html import unescape
from html.parser import HTMLParser
from datetime import datetime

import pandas as pd
import pymysql


# ==========================================================
# MYSQL CONFIGURATION
# ==========================================================

MYSQL_HOST = "localhost"
MYSQL_PORT = 3306
MYSQL_DB = "sbm_applications"
MYSQL_USER = "root"
MYSQL_PASS = "admin"
TABLE_NAME = "sbm_tag"


# ==========================================================
# EXCEL CONFIGURATION
# ==========================================================

EXCEL_FILE_PATH = r"D:\SBM\TAGsv2.xlsx"
SHEET_NAME = 0

# True:
# The script scans the initial rows and locates the row
# containing ISSUEID, TITLE, etc.
AUTO_DETECT_HEADER_ROW = True

# Used only when AUTO_DETECT_HEADER_ROW = False.
#
# Pandas header index starts from 0:
# Excel row 1 = 0
# Excel row 6 = 5
EXCEL_HEADER_ROW_INDEX = 0

MAX_HEADER_SCAN_ROWS = 20


# ==========================================================
# IMPORT CONTROL
# ==========================================================

# Set True to validate and preview without inserting.
SKIP_IMPORT = False

# First data row after the detected Excel header.
START_DATA_ROW = 1

# None imports all rows.
#
# Example:
# END_DATA_ROW = 5 imports only the first 5 selected data rows.
END_DATA_ROW = None

SKIP_DUPLICATE_ITEM_ID = True
SHOW_PREVIEW = True
PREVIEW_ROW_COUNT = 10

# Commit after this number of successful inserts.
COMMIT_BATCH_SIZE = 500


# ==========================================================
# REPORT CONFIGURATION
# ==========================================================

REPORT_DIRECTORY = os.path.dirname(EXCEL_FILE_PATH) or "."

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

FAILED_ROWS_REPORT = os.path.join(
    REPORT_DIRECTORY,
    f"sbm_tag_failed_rows_{TIMESTAMP}.csv"
)

DUPLICATE_ROWS_REPORT = os.path.join(
    REPORT_DIRECTORY,
    f"sbm_tag_skipped_duplicates_{TIMESTAMP}.csv"
)


# ==========================================================
# EXCEL TO MYSQL COLUMN MAPPING
# ==========================================================
#
# Dictionary format:
# "Excel column name": "MySQL column name"
#
# The Excel "id" column is deliberately not included.
# Therefore, Excel "id" will never be imported.
#
# ISSUEID is mapped to the MySQL "Item Id" column.

EXCEL_TO_MYSQL_MAPPING = {
    "ISSUEID": "Item Id",
    "TITLE": "Title",
    "TAG_ITEM_TYPE": "Tag Item Type",
    "TAG_HIGH_LEVEL": "Tag High Level",
    "TAG_MIDDLE_LEVEL": "Tag Middle Level",
    "TAG_BOTTOM_LEVEL": "Tag Bottom Level",
    "TAG_DESCRIPTION": "Tag Description",
    "STATE": "State",
    "INTRODUCTION_MD": "Introduction MD",
    "OBSOLESCENCE_MD": "Obsolescence MD",
    "TAG_CLASSIFICATION": "Tag Classification",
    "ISSUETYPE": "Issue Type",
    "TAG_PERIMETER": "Tag Perimeter",
    "AEMS_SDT": "AEMS SDT",
}


# These are the exact MySQL columns and insertion order.
MYSQL_COLUMNS = [
    "Item Id",
    "Title",
    "Tag Item Type",
    "Tag High Level",
    "Tag Middle Level",
    "Tag Bottom Level",
    "Tag Description",
    "State",
    "Introduction MD",
    "Obsolescence MD",
    "Tag Classification",
    "Issue Type",
    "Tag Perimeter",
    "AEMS SDT",
]


# ==========================================================
# HTML CLEANING
# ==========================================================

class HTMLTextExtractor(HTMLParser):
    """
    Removes HTML tags while retaining visible text.

    Examples:
        <span>A-EMS Step1</span>
        becomes:
        A-EMS Step1

        <div>Line 1</div><div>Line 2</div>
        becomes:
        Line 1
        Line 2
    """

    BLOCK_TAGS = {
        "br",
        "p",
        "div",
        "li",
        "tr",
        "table",
        "tbody",
        "thead",
        "tfoot",
        "ul",
        "ol",
        "td",
        "th",
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_startendtag(self, tag, attrs):
        if tag.lower() in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag.lower() in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data):
        self.parts.append(data)

    def get_text(self):
        return "".join(self.parts)


def contains_html(value):
    """
    Checks whether a value appears to contain an HTML tag.
    """

    if not isinstance(value, str):
        return False

    return bool(
        re.search(
            r"<\s*/?\s*[a-zA-Z][^>]*>",
            value
        )
    )


def remove_html_tags(value):
    """
    Removes HTML tags, including span references,
    while preserving the text located inside the tags.
    """

    if not isinstance(value, str):
        return value

    value = unescape(value)

    if not contains_html(value):
        return value

    try:
        parser = HTMLTextExtractor()
        parser.feed(value)
        parser.close()
        cleaned_value = parser.get_text()

    except Exception:
        # Fallback if malformed HTML is encountered.
        cleaned_value = re.sub(
            r"<\s*/?\s*[a-zA-Z][^>]*>",
            "",
            value
        )

    # Remove spaces around line breaks.
    cleaned_value = re.sub(r"[ \t]+\n", "\n", cleaned_value)
    cleaned_value = re.sub(r"\n[ \t]+", "\n", cleaned_value)

    # Do not retain excessive blank lines.
    cleaned_value = re.sub(r"\n{3,}", "\n\n", cleaned_value)

    return cleaned_value.strip()


# ==========================================================
# GENERAL CLEANING FUNCTIONS
# ==========================================================

def clean_value(value):
    """
    Performs the following cleanup:

    1. Converts Excel NaN/blank values to Python None.
    2. Converts textual null values to Python None.
    3. Removes HTML tags such as span, div, p, br, etc.
    4. Keeps the visible text inside HTML tags.
    5. Returns Python None so MySQL stores SQL NULL.
    """

    if value is None:
        return None

    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass

    value = str(value).strip()

    if value.lower() in {
        "",
        "(none)",
        "none",
        "nan",
        "null",
        "(null)",
        "nat",
    }:
        return None

    value = remove_html_tags(value)
    value = value.strip()

    if value.lower() in {
        "",
        "(none)",
        "none",
        "nan",
        "null",
        "(null)",
        "nat",
    }:
        return None

    return value


def normalize_column_name(column_name):
    """
    Normalizes a column name for matching.

    Examples:
        ISSUEID        -> issueid
        Issue Id       -> issueid
        TAG_ITEM_TYPE  -> tagitemtype
    """

    return re.sub(
        r"[^a-z0-9]",
        "",
        str(column_name).strip().lower()
    )


# ==========================================================
# MYSQL FUNCTIONS
# ==========================================================

def get_mysql_connection():
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASS,
        database=MYSQL_DB,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def test_mysql_connection(connection):
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1 AS connection_test")
        result = cursor.fetchone()

        if not result or result["connection_test"] != 1:
            raise RuntimeError("MySQL connection test failed.")

    print("[INFO] MySQL connection successful.")


def get_mysql_table_columns(connection):
    """
    Retrieves the actual column names from the MySQL table.
    """

    sql = """
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = %s
          AND TABLE_NAME = %s
        ORDER BY ORDINAL_POSITION
    """

    with connection.cursor() as cursor:
        cursor.execute(sql, (MYSQL_DB, TABLE_NAME))
        rows = cursor.fetchall()

    return [row["COLUMN_NAME"] for row in rows]


def validate_mysql_columns(connection):
    """
    Ensures that every required target column exists in MySQL
    using the exact required column name.
    """

    actual_columns = get_mysql_table_columns(connection)

    if not actual_columns:
        raise ValueError(
            f"MySQL table `{MYSQL_DB}`.`{TABLE_NAME}` "
            "does not exist or contains no columns."
        )

    missing_columns = [
        column
        for column in MYSQL_COLUMNS
        if column not in actual_columns
    ]

    if missing_columns:
        print("\n[ERROR] Columns found in MySQL:")

        for column in actual_columns:
            print(f"  - {column}")

        raise ValueError(
            "The following required MySQL columns are missing: "
            + ", ".join(missing_columns)
        )

    print("[INFO] All required MySQL columns were validated.")


def load_existing_item_ids(connection):
    """
    Loads existing Item Id values once.

    This avoids executing one SELECT query for every Excel row.
    """

    sql = f"""
        SELECT `Item Id`
        FROM `{TABLE_NAME}`
        WHERE `Item Id` IS NOT NULL
    """

    existing_item_ids = set()

    with connection.cursor() as cursor:
        cursor.execute(sql)

        for row in cursor.fetchall():
            item_id = clean_value(row["Item Id"])

            if item_id is not None:
                existing_item_ids.add(item_id)

    return existing_item_ids


# ==========================================================
# EXCEL FUNCTIONS
# ==========================================================

def detect_excel_header_row():
    """
    Detects the row containing the Excel column headers.
    The detected row must contain ISSUEID and TITLE.
    """

    preview_df = pd.read_excel(
        EXCEL_FILE_PATH,
        sheet_name=SHEET_NAME,
        engine="openpyxl",
        header=None,
        nrows=MAX_HEADER_SCAN_ROWS,
        dtype=object,
    )

    required_header_names = {
        normalize_column_name("ISSUEID"),
        normalize_column_name("TITLE"),
    }

    for row_index in range(len(preview_df)):
        row_values = {
            normalize_column_name(value)
            for value in preview_df.iloc[row_index].tolist()
            if clean_value(value) is not None
        }

        if required_header_names.issubset(row_values):
            return row_index

    raise ValueError(
        f"Could not detect the Excel header row within the first "
        f"{MAX_HEADER_SCAN_ROWS} rows. The header row must contain "
        "'ISSUEID' and 'TITLE'."
    )


def resolve_excel_columns(df):
    """
    Resolves the Excel columns using normalized matching and then
    renames them to the exact MySQL column names.

    Excel "id" is not selected and is therefore ignored.
    """

    normalized_excel_columns = {}

    for column in df.columns:
        normalized_name = normalize_column_name(column)

        if normalized_name not in normalized_excel_columns:
            normalized_excel_columns[normalized_name] = column

    rename_mapping = {}
    missing_excel_columns = []

    for excel_column, mysql_column in EXCEL_TO_MYSQL_MAPPING.items():
        normalized_expected = normalize_column_name(excel_column)

        actual_excel_column = normalized_excel_columns.get(
            normalized_expected
        )

        if actual_excel_column is None:
            missing_excel_columns.append(excel_column)
        else:
            rename_mapping[actual_excel_column] = mysql_column

    if missing_excel_columns:
        print("\n[ERROR] Columns found in Excel:")

        for column in df.columns:
            print(f"  - {column}")

        raise ValueError(
            "The following required Excel columns are missing: "
            + ", ".join(missing_excel_columns)
        )

    # Keep only mapped Excel columns.
    # Excel "id" is not present in rename_mapping and will be excluded.
    df = df[list(rename_mapping.keys())].copy()

    # Rename Excel columns to exact MySQL column names.
    df.rename(columns=rename_mapping, inplace=True)

    # Enforce the exact MySQL insertion order.
    df = df[MYSQL_COLUMNS]

    return df


def read_excel_data():
    if not os.path.isfile(EXCEL_FILE_PATH):
        raise FileNotFoundError(
            f"Excel file was not found: {EXCEL_FILE_PATH}"
        )

    print(f"[INFO] Reading Excel file: {EXCEL_FILE_PATH}")

    if AUTO_DETECT_HEADER_ROW:
        header_row_index = detect_excel_header_row()
    else:
        header_row_index = EXCEL_HEADER_ROW_INDEX

    print(
        f"[INFO] Excel header detected at row "
        f"{header_row_index + 1}."
    )

    df = pd.read_excel(
        EXCEL_FILE_PATH,
        sheet_name=SHEET_NAME,
        engine="openpyxl",
        header=header_row_index,
        dtype=object,
    )

    # Clean Excel column names.
    df.columns = [
        str(column).strip()
        for column in df.columns
    ]

    # Remove automatically generated unnamed columns.
    df = df.loc[
        :,
        ~df.columns.astype(str).str.match(
            r"^Unnamed",
            case=False,
            na=False
        )
    ]

    # Drop fully blank rows before mapping.
    df = df.dropna(how="all")

    # Resolve Excel columns and rename them to exact MySQL names.
    df = resolve_excel_columns(df)

    # Apply selected row range.
    start_index = max(START_DATA_ROW - 1, 0)

    if END_DATA_ROW is not None:
        if END_DATA_ROW < START_DATA_ROW:
            raise ValueError(
                "END_DATA_ROW cannot be less than START_DATA_ROW."
            )

        df = df.iloc[start_index:END_DATA_ROW].copy()
    else:
        df = df.iloc[start_index:].copy()

    # Preserve original DataFrame index for reporting.
    df["_Source DataFrame Index"] = df.index

    # Clean all target values.
    for column in MYSQL_COLUMNS:
        df[column] = df[column].apply(clean_value)

    # Replace any remaining pandas null values.
    df = df.astype(object)
    df = df.where(pd.notnull(df), None)

    total_before_empty_removal = len(df)

    # Remove rows where mapped Item Id is empty.
    df = df[df["Item Id"].notna()].copy()

    empty_item_id_count = total_before_empty_removal - len(df)

    if empty_item_id_count:
        print(
            f"[WARN] Removed {empty_item_id_count} row(s) because "
            "ISSUEID/Item Id was empty."
        )

    # Identify duplicate Item Id values inside the selected Excel data.
    duplicate_mask = df.duplicated(
        subset=["Item Id"],
        keep="first"
    )

    excel_duplicate_count = int(duplicate_mask.sum())

    if excel_duplicate_count:
        duplicate_excel_rows = df[duplicate_mask].copy()
        duplicate_excel_rows["Skip Reason"] = (
            "Duplicate Item Id within selected Excel data"
        )

        duplicate_excel_rows.to_csv(
            DUPLICATE_ROWS_REPORT,
            index=False,
            encoding="utf-8-sig"
        )

        if SKIP_DUPLICATE_ITEM_ID:
            df = df[~duplicate_mask].copy()

        print(
            f"[WARN] Found {excel_duplicate_count} duplicate Item Id "
            "row(s) within the Excel selection."
        )

    return df, header_row_index, excel_duplicate_count


# ==========================================================
# SQL GENERATION
# ==========================================================

def build_insert_sql():
    """
    Builds an INSERT statement using the exact MySQL column names.
    """

    column_sql = ",\n            ".join(
        f"`{column}`"
        for column in MYSQL_COLUMNS
    )

    placeholders = ", ".join(
        ["%s"] * len(MYSQL_COLUMNS)
    )

    return f"""
        INSERT INTO `{TABLE_NAME}` (
            {column_sql}
        )
        VALUES (
            {placeholders}
        )
    """


# ==========================================================
# REPORT FUNCTIONS
# ==========================================================

def write_report(rows, report_path):
    if not rows:
        return

    report_df = pd.DataFrame(rows)
    report_df.to_csv(
        report_path,
        index=False,
        encoding="utf-8-sig"
    )


# ==========================================================
# INSERT FUNCTION
# ==========================================================

def insert_data(df, header_row_index, excel_duplicate_count):
    if df.empty:
        print("\n[WARN] No valid data is available for import.")
        return

    if SKIP_IMPORT:
        print("\n[INFO] SKIP_IMPORT is True.")
        print("[INFO] Validation and preview completed.")
        print("[INFO] No data was inserted into MySQL.")
        return

    insert_sql = build_insert_sql()

    inserted_count = 0
    skipped_database_duplicate_count = 0
    failed_count = 0
    pending_insert_count = 0

    failed_rows = []
    skipped_database_duplicates = []

    connection = None

    try:
        connection = get_mysql_connection()

        test_mysql_connection(connection)
        validate_mysql_columns(connection)

        existing_item_ids = load_existing_item_ids(connection)

        print(
            f"[INFO] Existing non-empty Item Id values in MySQL: "
            f"{len(existing_item_ids)}"
        )

        with connection.cursor() as cursor:
            for row_number, (_, row) in enumerate(
                df.iterrows(),
                start=1
            ):
                item_id = clean_value(row["Item Id"])

                if item_id is None:
                    failed_count += 1

                    failed_row = {
                        column: clean_value(row[column])
                        for column in MYSQL_COLUMNS
                    }

                    failed_row["Error"] = "Item Id is empty"
                    failed_rows.append(failed_row)
                    continue

                if (
                    SKIP_DUPLICATE_ITEM_ID
                    and item_id in existing_item_ids
                ):
                    skipped_database_duplicate_count += 1

                    duplicate_row = {
                        column: clean_value(row[column])
                        for column in MYSQL_COLUMNS
                    }

                    duplicate_row["Skip Reason"] = (
                        "Item Id already exists in MySQL"
                    )

                    skipped_database_duplicates.append(
                        duplicate_row
                    )

                    print(
                        f"[SKIP] Existing Item Id: {item_id}"
                    )
                    continue

                values = tuple(
                    clean_value(row[column])
                    for column in MYSQL_COLUMNS
                )

                savepoint_name = f"row_savepoint_{row_number}"

                try:
                    cursor.execute(
                        f"SAVEPOINT `{savepoint_name}`"
                    )

                    cursor.execute(insert_sql, values)

                    cursor.execute(
                        f"RELEASE SAVEPOINT `{savepoint_name}`"
                    )

                    inserted_count += 1
                    pending_insert_count += 1

                    # Add newly inserted ID to the set.
                    # This prevents later duplicates in the same run.
                    existing_item_ids.add(item_id)

                    if pending_insert_count >= COMMIT_BATCH_SIZE:
                        connection.commit()

                        print(
                            f"[INFO] Committed batch. Total inserted: "
                            f"{inserted_count}"
                        )

                        pending_insert_count = 0

                except Exception as row_error:
                    try:
                        cursor.execute(
                            f"ROLLBACK TO SAVEPOINT `{savepoint_name}`"
                        )

                        cursor.execute(
                            f"RELEASE SAVEPOINT `{savepoint_name}`"
                        )
                    except Exception:
                        pass

                    failed_count += 1

                    failed_row = {
                        column: clean_value(row[column])
                        for column in MYSQL_COLUMNS
                    }

                    failed_row["Error"] = str(row_error)
                    failed_rows.append(failed_row)

                    print("----------------------------------------")
                    print(f"[ERROR] Failed Item Id : {item_id}")
                    print(f"[ERROR] Error          : {row_error}")
                    print("----------------------------------------")

            # Commit any remaining successful records.
            connection.commit()

        if skipped_database_duplicates:
            if os.path.isfile(DUPLICATE_ROWS_REPORT):
                previous_duplicates = pd.read_csv(
                    DUPLICATE_ROWS_REPORT,
                    dtype=object
                )

                current_duplicates = pd.DataFrame(
                    skipped_database_duplicates
                )

                combined_duplicates = pd.concat(
                    [
                        previous_duplicates,
                        current_duplicates
                    ],
                    ignore_index=True
                )

                combined_duplicates.to_csv(
                    DUPLICATE_ROWS_REPORT,
                    index=False,
                    encoding="utf-8-sig"
                )
            else:
                write_report(
                    skipped_database_duplicates,
                    DUPLICATE_ROWS_REPORT
                )

        write_report(
            failed_rows,
            FAILED_ROWS_REPORT
        )

    except Exception as error:
        if connection:
            connection.rollback()

        print("\n[FATAL] Import failed.")
        print("[FATAL] Uncommitted changes were rolled back.")
        print(f"[FATAL] Error: {error}")

        raise

    finally:
        if connection:
            connection.close()
            print("[INFO] MySQL connection closed.")

    print("\n========== IMPORT SUMMARY ==========")
    print(f"Database                       : {MYSQL_DB}")
    print(f"Table                          : {TABLE_NAME}")
    print(f"Excel file                     : {EXCEL_FILE_PATH}")
    print(
        f"Header row used                : "
        f"Excel row {header_row_index + 1}"
    )
    print(f"Valid selected rows            : {len(df)}")
    print(f"Inserted rows                  : {inserted_count}")
    print(
        f"Excel duplicate rows           : "
        f"{excel_duplicate_count}"
    )
    print(
        f"MySQL duplicate rows skipped   : "
        f"{skipped_database_duplicate_count}"
    )
    print(f"Failed rows                    : {failed_count}")
    print(f"Completed at                   : {datetime.now()}")

    if excel_duplicate_count or skipped_database_duplicate_count:
        print(
            f"Duplicate report               : "
            f"{DUPLICATE_ROWS_REPORT}"
        )

    if failed_count:
        print(
            f"Failure report                 : "
            f"{FAILED_ROWS_REPORT}"
        )

    print("====================================")


# ==========================================================
# MAIN EXECUTION
# ==========================================================

def main():
    df_tags, header_row_index, excel_duplicate_count = (
        read_excel_data()
    )

    print(f"\n[INFO] Rows selected for import: {len(df_tags)}")

    if SHOW_PREVIEW:
        print("\n========== DATA PREVIEW ==========")

        preview_df = df_tags[MYSQL_COLUMNS].head(
            PREVIEW_ROW_COUNT
        ).copy()

        preview_df = preview_df.where(
            pd.notnull(preview_df),
            None
        )

        print(preview_df.to_string(index=False))
        print("==================================")

    insert_data(
        df=df_tags,
        header_row_index=header_row_index,
        excel_duplicate_count=excel_duplicate_count
    )


if __name__ == "__main__":
    main()