// Variable that tracks if an unresolved comment was found
// -------------------------------------------------------
var isUnresolvedCommentFound = false;

// Instantiate the document object from the workflow context constructor
// ---------------------------------------------------------------------
var document = workflowContext.getTarget();

// Retrieve all Comments in the document
// See: com.polarion.alm.tracker.model.IModule for the list of all Documents Methods
// ---------------------------------------------------------------------------------
var allComments = null;
allComments = document.getComments();

// Check the status of each comments retrieved from the document
// -------------------------------------------------------------
for (i = 0; i < allComments.size(); i++)
{
  var comment = allComments.get(i);
  // Check if comment is NOT resolved
  // See: com.polarion.alm.tracker.model.IModuleComment
  // for the list of all Document Comments Methods
  // --------------------------------------------------
  if(!comment.isResolvedComment())
  {
    // As soon as we find an unresolved comment, we set the variable to true
    // --------------------------------------------------------------------
    isUnresolvedCommentFound = true;
    break;
  }
}

// When no comments are found, the script will return an empty string
// ------------------------------------------------------------------
var returnString = "";
var returnBoolean = true;
if (isUnresolvedCommentFound)
{
  returnString = "Unresolved comment found. Make sure to resolve all your comments";
  returnBoolean = false;
}

// Last line of the script is a String. If it is empty, no messages will be displayed
// to the user and the workflow action will be enabled.
// If the string is not empty, it will be shown to the user and the workflow action willl
// be deactivated.
// --------------------------------------------------------------------------------
// returnBoolean; <- Use this if you want to return a Boolean instead 
// (and comment the returnString on the nextline) 
returnString;
