// Instantiate the base object from the workflow context constructor 
// -----------------------------------------------------------------
var baseObject = workflowContext.getTarget();

// Create a new baseline for the target revision using createObjectBaselineForChange
// ---------------------------------------------------------------------------------
var baseline = baseObject.getProject().getBaselinesManager().createObjectBaselineForChange(baseObject);

// Set the Name and Description of the Baseline
// --------------------------------------------
baseline.setName(createName());
baseline.setDescription(com.polarion.core.util.types.Text.plain(createDescription()));

// Save the Baseline
// Since we are creating a new object that is not part of the current document, we must save it
// --------------------------------------------------------------------------------------------
baseline.save();

// Defines name for the created baseline.
// --------------------------------------
function createName(){
   return baseObject.getEnumerationOptionForField("status", workflowContext.getTargetStatusId()).getName(); 
}

// Defines description for the created baseline.
// ---------------------------------------------
function createDescription(){
   return "Created automatically by a workflow transition";
}
