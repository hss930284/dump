/** 
 **  Script:      emailDigestJob.js
 **
 **  Purpose:     This job will get the list of all users in the repository and notify them if:
 **                 - Documents are awaiting their signatures
 **
 **  Polarion Job Parameters - these variables, while never defined are created by the script extension
 **     senderAddress : Senders (From) Address to send the send from
 **     subjectPrefix : Subject prefix for all outgoing emails.
 **
 **   Example Configuration 
 **       This configuration will execute the job every working day in the week at 6am.
 **       <job cronExpression="0 00 6 ? * MON-FRI" disabled="false" id="script.job" name="Email Digest" scope="system">
 **         <scriptName>emailDigestJob.js</scriptName>
 **         <scriptEngine>js</scriptEngine>
 **         <properties>
 **           <subjectPrefix>[Polarion Server DEV]</subjectPrefix>
 **           <senderAddress>any_email@polarion.com</senderAddress>
 **         </properties>
 **       </job>
 */

logger.info(" ");
logger.info("-------------- Parameters --------------");
logger.info("subjectPrefix        = " + subjectPrefix);
logger.info("senderAddress        = " + senderAddress);

// Function sendEmail
// subject: Takes a string to use as the subject line of the email to be sent
// senderAddress: Takes a string to use as the sender address of the email to be sent
// emails: an array of emails addresses as strings --> string emails
// message: a string representing the html body of the emails
// ---------------------------------------------------------------------------------
function sendEmail(subject, senderAddress, emails, message)
{
  // Sending email notificaion with using the Polarion Announcement Service
  // ----------------------------------------------------------------------
  var receiver = [emails];
  var headerString = "From: "+ senderAddress + "\n";
  headerString = headerString + "To: " + emails + "\n";
  headerString = headerString + "Subject: " + subject + "\n\n";
  var announcerSrv = com.polarion.platform.core.PlatformContext.getPlatform().lookupService(com.polarion.platform.announce.IAnnouncerService.class);
  var errMsg = "";
  if (announcerSrv !== 'undefined')
  {
    var Announcement = Java.type('com.polarion.platform.announce.Announcement');
    var announcement = new Announcement();
    announcement.setSender(senderAddress);
    announcement.setReceivers(receiver);
    announcement.setContentType("text/html");
    announcement.setSubject(subject);
    announcement.setContent(message);
    try
    {
       announcerSrv.sendAnnouncement("smtp", announcement);
    }
    catch(ex)
    {
       errMsg = "Could not send email notification. Please, check mail settings for Polarion. \n\n" + ex;
       logger.error(errMsg);
    }
  }
  else
  {
    logger.info("We are not able to get the Announcer Service");
  }

  logger.info("\n---------------------------------- eMail notification ---------------------------------- \n");
  logger.info(headerString + message + "\n\n");
  if(errMsg != "")
  {
    logger.error("Error Message: " + errMsg + "\n\n");
  }
}

// Constructor EmailMessage
// subject: Takes a string that will be the subject of the email message you are writing
// addresses: Takes and array of strings that are the email address to send this email to
// body: Takes a string that will be sent as the email body. Do not include beginning and ending <html> tags
//
// void addBodyLine(string): adds a new line to the body of the email
// string getBodyHTML(): returns the body of the email wrapped in <html> tags
// string createHTMLLink(string, string): returns a valid html link pointing to url with text text
// ---------------------------------------------------------------------------------------------------------
function EmailMessage(subject, addresses, body) 
{
  this.subject = subject;
  this.addresses = addresses;
  this.body = body;

  this.addBodyLine = function(newLine) {
  this.body = this.body + "<br>\n" + newLine;
  }

  this.addBodyLineNoBR = function(newLine) {
  this.body = this.body + "\n" + newLine;
  }

  this.getBodyHTML = function() {
  return "<html>\n" + this.body + "\n</html>";
  }
}

function createHTMLLink(url, text)
{
    return "<a href=\"" + url + "\">" + text + "</a>"
}

// --------------------------------   MAIN CODE -------------------------------- //
try
{
  var dataService = trackerService.getDataService();
  var projectsService = trackerService.getProjectsService();
  var myUsers = projectsService.getUsers()

  for (i = 0; i < myUsers.size(); i++)
  {
    // Getting infos on the users
    // --------------------------
    var myUser = myUsers.get(i);
    var myUserId = myUser.getId();
    var isUserDisabled = myUser.isDisabled();
    var myUserEmailAddress = "" + myUser.getEmail() + "";
    var isMyNotificationDisabled = myUser.hasDisabledNotifications();

    // Check if the user is disabled or if user notification is disabled or user mail id is null
    // -----------------------------------------------------------------------------------------
    if( isUserDisabled || isMyNotificationDisabled || myUserEmailAddress == "null" || myUserEmailAddress == "" )
    {
      if(isUserDisabled)
      {
        // Skip processing this user as his account is disabled
        // ----------------------------------------------------
        logger.info("Skip disabled user: " + myUserId + " email ID :"+ myUserEmailAddress + "\n");
      }
      else if (isMyNotificationDisabled)
      {
        // Skip any further processing for this user ( as users email notifications are disabled)
        // --------------------------------------------------------------------------------------
        logger.info("skip processing user: " + myUserId + " Disable Notification status : " + isMyNotificationDisabled +"\n");
      }
      else if (myUserEmailAddress == "null" || myUserEmailAddress == "" )
      {
        // Skip any further processing for this user (as the user email id is not set)
        // ---------------------------------------------------------------------------
        logger.info("skip processing user: " + myUserId + " email ID is NOT SET, email ID: " + myUserEmailAddress + "\n");
      }
      continue;
    }

    // Query to find all documents a specific user has to sign 
    // -------------------------------------------------------
    var documentsToSign = dataService.searchInstances("Module", "signatures:invited=" + myUserId, null);

    // No Documents to sign
    // --------------------
    if (documentsToSign.size() == 0)
    {
      logger.info("No signatures for: " + myUserId + "\n");
    }
    else
    {
      logger.info("Preparing for user: " + myUserId + "\n");

      // Creating the email message with the subject, the user email address and the start of the email
      // ----------------------------------------------------------------------------------------------
      var message = new EmailMessage(subjectPrefix +" Polarion Awaiting Document Signatures", myUserEmailAddress, "<head><title>Polarion Awaiting Signatures Digest</title></head><h2>Awaiting Your Document Signatures</h2>");

      // If the user is assigned to sign some documents, then a table will be created in the email and every document will be listed
      // ---------------------------------------------------------------------------------------------------------------------------
      if (documentsToSign.size() > 0)
      {
        message.addBodyLineNoBR("<table cellpadding=4 ><tr bgcolor=\"#E1F0FE\"><th>Title</th><th>Space</th><th>Project</th></tr>");

        for (j = 0; j < documentsToSign.size(); j++)
        {
          var myDoc = documentsToSign.get(j);
          var pId = myDoc.getProject().getId();
          myFullDocName = myDoc.getModuleFolder() + "/" + myDoc.getModuleName();
          message.addBodyLineNoBR('<tr><td>' + myFullDocName + '</td><td>' + myDoc.getModuleFolder() + '</td><td>' + myDoc.getProject().getName() + '</td></tr>');         
        }
        message.addBodyLineNoBR("</table>");
      }
      else
      {
        message.addBodyLineNoBR("<h4>No Awaiting Signature</h4>");
      }

      // Uncomment this to print the message body in the logger (for debugging purpose)
      // ------------------------------------------------------------------------------
      // logger.info(message.getBodyHTML());

      // Send email (you can comment this line to not send any email during debugging sessions)
      // --------------------------------------------------------------------------------------
      sendEmail(message.subject, senderAddress, message.addresses, message.getBodyHTML());
    }
  }
  result=true;  // This will add this message in the log file -> Script returned: true
}
catch (e)
{
  logger.error("Job generated an error:" + e);
  result=false; // This will add this message in the log file -> Script returned: false
}
