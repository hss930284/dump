// Creating the log file
// ---------------------
var FileWriter = Java.type('java.io.FileWriter');
var outFile = new FileWriter("./logs/main/incrementDocVersionWF.log");
var BufferedWriter = Java.type('java.io.BufferedWriter');
var out = new BufferedWriter(outFile);

// Evaluate the incoming workflow action parameters
// ------------------------------------------------
var versionFieldID = arguments.getAsString("versionFieldID", "version");
out.write("Version Field Id: " + versionFieldID); out.newLine(); out.flush();
var incrementValue = arguments.getAsString("incrementValue", "1.0");
out.write("Increment Value: " + incrementValue); out.newLine(); out.flush();

// Instantiate the base object from the workflow context constructor
// -----------------------------------------------------------------
var baseObject = workflowContext.getTarget();

// Get the custom field value from the version custom field (ID: versionCustomFieldID)
// We are expecting a custom field of type string
// -----------------------------------------------------------------------------------
var oldVersion = baseObject.getCustomField(versionFieldID);
var newVersion = "";

out.write("Values:"); out.newLine(); out.flush();
out.write("Old Version: " + oldVersion); out.newLine(); out.flush();


// If no value is defined in the Version Field, we set it to the value
// of the incrementValue
// -------------------------------------------------------------------
if (oldVersion == "" || oldVersion == null || oldVersion == "NaN")
{
    newVersion = incrementValue;
    baseObject.setCustomField(versionFieldID, newVersion);
    out.write("New Version: " + newVersion); out.newLine(); out.flush();
}
// The version field already has a value, so we just increment it by incrementValue
// --------------------------------------------------------------------------------
else
{
  newVersion = parseFloat(oldVersion) + parseFloat(incrementValue);
  baseObject.setCustomField(versionFieldID, newVersion.toFixed(1).toString());
  out.write("New Version: " + newVersion.toFixed(1).toString()); out.newLine(); out.flush();
}

// Closing the Log File
// --------------------
out.close();
